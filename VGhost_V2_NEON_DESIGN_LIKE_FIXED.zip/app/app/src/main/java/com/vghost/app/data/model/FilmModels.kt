package com.vghost.app.data.model

data class Film(
    val id: Long,
    val title: String,
    val description: String,
    val posterUrl: String,
    val videoUrl: String,
    val category: String,
    val releaseYear: Int?,
    val durationMinutes: Int?,
    val isVip: Boolean,
    val isFeatured: Boolean,
    val viewCount: Int = 0,
    val playCount: Int = 0,
    val ratingAverage: Double = 0.0,
    val ratingCount: Int = 0,
    val likeCount: Int = 0,
    val likedByMe: Boolean = false
)
