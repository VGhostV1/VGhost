package az.vago.app

import az.vago.app.data.util.TikTokUrlValidator
import az.vago.app.data.util.UrlValidationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TikTokUrlValidatorTest {

    @Test
    fun `empty and blank urls return Empty result`() {
        assertEquals(UrlValidationResult.Empty, TikTokUrlValidator.validate(""))
        assertEquals(UrlValidationResult.Empty, TikTokUrlValidator.validate("   "))
    }

    @Test
    fun `valid tiktok urls return Valid`() {
        val validUrls = listOf(
            "https://www.tiktok.com/@username/video/7283749201837482",
            "https://vm.tiktok.com/ZMxxxxxx/",
            "https://vt.tiktok.com/ZSxxxxxx/",
            "https://m.tiktok.com/v/7283749201837482.html",
            "vm.tiktok.com/ZM8x21aB",
            "tiktok.com/@test/video/123456?is_from_webapp=1"
        )

        for (url in validUrls) {
            assertEquals("URL should be valid: $url", UrlValidationResult.Valid, TikTokUrlValidator.validate(url))
        }
    }

    @Test
    fun `invalid urls return InvalidFormat`() {
        val invalidUrls = listOf(
            "https://www.youtube.com/watch?v=12345",
            "https://instagram.com/p/12345",
            "hello world",
            "https://google.com"
        )

        for (url in invalidUrls) {
            assertEquals("URL should be invalid: $url", UrlValidationResult.InvalidFormat, TikTokUrlValidator.validate(url))
        }
    }

    @Test
    fun `sanitizer prepends https scheme`() {
        val sanitized = TikTokUrlValidator.sanitizeUrl("vm.tiktok.com/ZMxxxxxx/")
        assertTrue(sanitized.startsWith("https://"))
    }
}

