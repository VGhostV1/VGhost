package az.vago.app

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import az.vago.app.data.model.DownloadFormat
import az.vago.app.data.model.DownloadProgress
import az.vago.app.data.model.DownloadStatus
import az.vago.app.data.model.TikTokMediaInfo
import az.vago.app.data.network.ApiError
import az.vago.app.data.repository.DownloadRepository
import az.vago.app.data.repository.DownloadRepositoryImpl
import az.vago.app.ui.viewmodel.AppScreen
import az.vago.app.ui.viewmodel.MainViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DownloadEngineTest {

    private lateinit var app: Application

    @Before
    fun setup() {
        app = ApplicationProvider.getApplicationContext()
    }

    @Test
    fun `prepareDownload generates correct file names and format for MP4 and MP3`() = runTest {
        val repo = DownloadRepositoryImpl(context = app)
        val mediaInfo = TikTokMediaInfo(
            id = "123456789",
            title = "Test Video",
            author = "tester",
            thumbnailUrl = "https://example.com/thumb.jpg",
            durationSeconds = 60,
            mediaType = "video",
            mp4DownloadUrl = "https://example.com/video.mp4",
            mp3DownloadUrl = "https://example.com/audio.mp3",
            fileSizeText = "45.0 MB",
            quality = "HD",
            originalUrl = "https://tiktok.com/@test/video/123456789"
        )

        val mp4Item = repo.prepareDownload(mediaInfo, DownloadFormat.MP4).getOrThrow()
        assertTrue("MP4 file should end with .mp4", mp4Item.fileName.endsWith(".mp4"))
        assertEquals(DownloadFormat.MP4, mp4Item.format)

        val mp3Item = repo.prepareDownload(mediaInfo, DownloadFormat.MP3).getOrThrow()
        assertTrue("MP3 file should end with .mp3", mp3Item.fileName.endsWith(".mp3"))
        assertEquals(DownloadFormat.MP3, mp3Item.format)
    }



    @Test
    fun `no watermark format uses mp4 extension and stores clean candidate`() = runTest {
        val repo = DownloadRepositoryImpl(context = app)
        val mediaInfo = TikTokMediaInfo(
            id = "987654321",
            title = "Clean Test",
            author = "tester",
            thumbnailUrl = "",
            durationSeconds = 10,
            mediaType = "video",
            mp4DownloadUrl = "https://example.com/watermarked.mp4",
            mp3DownloadUrl = "https://example.com/audio.mp3",
            noWatermarkDownloadUrls = listOf("https://example.com/clean.mp4"),
            fileSizeText = "",
            quality = "HD",
            originalUrl = "https://www.tiktok.com/@test/video/987654321"
        )

        val item = repo.prepareDownload(mediaInfo, DownloadFormat.NO_WATERMARK_MP4).getOrThrow()
        assertTrue(item.fileName.endsWith(".mp4"))
        assertEquals(DownloadFormat.NO_WATERMARK_MP4, item.format)
        assertEquals("https://example.com/clean.mp4", item.originalUrl)
    }

    @Test
    fun `viewModel cancel download sets cancelled state`() = runTest {
        val viewModel = MainViewModel(application = app)
        viewModel.onCancelDownload()
        assertEquals(DownloadStatus.Cancelled, viewModel.uiState.value.downloadStatus)
        assertEquals(AppScreen.HOME, viewModel.uiState.value.currentScreen)
    }

    @Test
    fun `viewModel input can be cleared after paste`() = runTest {
        val viewModel = MainViewModel(application = app)
        viewModel.onPasteFromClipboard("https://www.tiktok.com/@test/video/123456789")
        assertEquals("https://www.tiktok.com/@test/video/123456789", viewModel.uiState.value.inputUrl)
        viewModel.onUrlChange("")
        assertEquals("", viewModel.uiState.value.inputUrl)
    }

    @Test
    fun `viewModel invalid url triggers az error notice`() = runTest {
        val viewModel = MainViewModel(application = app)
        viewModel.onUrlChange("https://invalid-url.com")
        viewModel.onDownloadButtonClick()
        assertEquals("Link düzgün deyil.", viewModel.uiState.value.userNotice)
    }

    @Test
    fun `viewModel empty url triggers az error notice`() = runTest {
        val viewModel = MainViewModel(application = app)
        viewModel.onUrlChange("")
        viewModel.onDownloadButtonClick()
        assertEquals("Zəhmət olmasa TikTok linkini daxil edin", viewModel.uiState.value.userNotice)
    }

    @Test
    fun `viewModel auto paste inserts valid link`() = runTest {
        val viewModel = MainViewModel(application = app)
        viewModel.onCheckAutoPaste("https://vm.tiktok.com/ZMxxxxxx/")
        assertEquals("https://vm.tiktok.com/ZMxxxxxx/", viewModel.uiState.value.inputUrl)
    }

    @Test
    fun `settings are persisted and retrieved correctly across restarts`() = runTest {
        val settingsRepo = az.vago.app.data.repository.SettingsRepositoryImpl(context = app)
        settingsRepo.updateAutoPaste(false)
        settingsRepo.updateDownloadNotifications(false)
        settingsRepo.updateDarkTheme(false)

        val newSettingsRepo = az.vago.app.data.repository.SettingsRepositoryImpl(context = app)
        val current = newSettingsRepo.settingsFlow.first()
        assertEquals(false, current.autoPasteLink)
        assertEquals(false, current.downloadNotifications)
        assertEquals(false, current.darkThemeAlways)
    }
}

