package az.vago.app.data.repository

import az.vago.app.data.model.AppSettings
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val settingsFlow: Flow<AppSettings>
    suspend fun updateAutoPaste(enabled: Boolean)
    suspend fun updateDownloadNotifications(enabled: Boolean)
    suspend fun updateDarkTheme(enabled: Boolean)
    suspend fun updateLanguage(language: String)
}

