package az.vago.app.data.network

import az.vago.app.data.model.TikTokMediaInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Fallback provider for the explicit "Filigransız MP4" option.
 *
 * TikTok does not expose a general public developer API that simply returns a
 * clean, no-watermark download URL. TikWM currently exposes a public endpoint
 * that returns clean `play`/`hdplay` URLs. We use it only when TikTok's own page
 * did not expose a clean candidate.
 *
 * This is intentionally isolated so the provider can be replaced without
 * touching the rest of the download engine.
 */
class TikwmNoWatermarkExtractor(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()
) {
    suspend fun extract(url: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val encodedUrl = URLEncoder.encode(url, "UTF-8")
            val endpoint = "https://www.tikwm.com/api/?url=$encodedUrl&hd=1"

            val request = Request.Builder()
                .url(endpoint)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json")
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw ApiError.ServerError

                val body = response.body?.string().orEmpty()
                val root = JSONObject(body)
                if (root.optInt("code", -1) != 0) {
                    throw ApiError.DownloadUrlInvalid
                }

                val data = root.optJSONObject("data") ?: throw ApiError.DownloadUrlInvalid

                // TikWM documents `play` as the no-watermark URL and `hdplay`
                // as the high-quality no-watermark variant.
                val cleanUrl = listOf(
                    data.optString("hdplay"),
                    data.optString("play")
                ).firstOrNull(::isHttpUrl)
                    ?: throw ApiError.DownloadUrlInvalid

                cleanUrl
            }
        }.fold(
            onSuccess = { Result.success(it) },
            onFailure = { error ->
                when (error) {
                    is ApiError -> Result.failure(error)
                    else -> Result.failure(
                        ApiError.Unknown(error.localizedMessage ?: "Filigransız video linki əldə edilə bilmədi.")
                    )
                }
            }
        )
    }

    private fun isHttpUrl(value: String): Boolean =
        value.startsWith("https://", ignoreCase = true) ||
            value.startsWith("http://", ignoreCase = true)

    private companion object {
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }
}

