package az.vago.app.data.model

sealed interface DownloadStatus {
    object Idle : DownloadStatus
    object Loading : DownloadStatus
    data class InProgress(val progress: DownloadProgress) : DownloadStatus
    data class Success(val item: DownloadItem) : DownloadStatus
    data class Error(val message: String) : DownloadStatus
    object Cancelled : DownloadStatus
}

