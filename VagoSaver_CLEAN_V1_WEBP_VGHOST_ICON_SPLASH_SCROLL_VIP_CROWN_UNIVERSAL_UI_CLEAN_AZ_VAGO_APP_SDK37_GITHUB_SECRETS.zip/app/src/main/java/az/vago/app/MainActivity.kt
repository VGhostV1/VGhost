package az.vago.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import az.vago.app.ads.VagoAds
import az.vago.app.ui.screens.DownloadCompletedScreen
import az.vago.app.ui.screens.DownloadProgressScreen
import az.vago.app.ui.screens.FormatSelectionScreen
import az.vago.app.ui.screens.HomeScreen
import az.vago.app.ui.screens.SettingsScreen
import az.vago.app.ui.theme.MyApplicationTheme
import az.vago.app.ui.theme.VagoBackground
import az.vago.app.ui.viewmodel.AppScreen
import az.vago.app.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        VagoAds.initialize(this)
        setContent {
            VagoSaverApp(
                viewModel = viewModel,
                onRequestNotificationPermission = ::requestNotificationPermissionIfNeeded
            )
        }
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemLanguage()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val sharedText = intent?.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        val sharedUrl = intent?.dataString?.trim().orEmpty()
        val candidate = when {
            sharedUrl.isNotBlank() -> sharedUrl
            sharedText.isNotBlank() -> sharedText
            else -> return
        }
        viewModel.onExternalLink(candidate)
    }
}

@Composable
fun VagoSaverApp(
    viewModel: MainViewModel,
    onRequestNotificationPermission: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    BackHandler(enabled = uiState.currentScreen != AppScreen.HOME) {
        viewModel.onNavigateBack()
    }

    MyApplicationTheme(darkTheme = uiState.settings.darkThemeAlways) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = VagoBackground
        ) {
            AnimatedContent(
        targetState = uiState.currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            AppScreen.HOME -> {
                HomeScreen(
                    uiState = uiState,
                    onUrlChange = viewModel::onUrlChange,
                    onPasteClicked = viewModel::onPasteFromClipboard,
                    onAutoPasteCheck = viewModel::onCheckAutoPaste,
                    onClearClicked = viewModel::onClearInput,
                    onDownloadClicked = {
                        if (uiState.settings.downloadNotifications) {
                            onRequestNotificationPermission()
                        }
                        viewModel.onDownloadButtonClick()
                    },
                    onSettingsClicked = viewModel::onNavigateToSettings,
                    onLanguageSelected = viewModel::onLanguageSelected,
                    onDismissNotice = viewModel::onDismissNotice
                )
            }
            AppScreen.FORMAT_SELECTION -> {
                FormatSelectionScreen(
                    onFormatSelected = viewModel::onFormatSelected,
                    language = uiState.settings.language,
                    onDismiss = viewModel::onNavigateBack
                )
            }
            AppScreen.DOWNLOADING -> {
                DownloadProgressScreen(
                    uiState = uiState,
                    onBackClicked = viewModel::onCancelDownload,
                )
            }
            AppScreen.COMPLETED -> {
                DownloadCompletedScreen(
                    uiState = uiState,
                    onCloseClicked = viewModel::onCloseCompletedScreen
                )
            }
            AppScreen.SETTINGS -> {
                SettingsScreen(
                    uiState = uiState,
                    onBackClicked = viewModel::onNavigateBack,
                    onToggleAutoPaste = viewModel::onToggleAutoPaste,
                    onToggleNotifications = viewModel::onToggleNotifications,
                    onToggleDarkTheme = viewModel::onToggleDarkTheme,
                    onLanguageSelected = viewModel::onLanguageSelected,
                    onShowAboutDialog = viewModel::onShowAboutDialog,
                    onShowContactDialog = viewModel::onShowContactDialog,
                    onShowPrivacyDialog = viewModel::onShowPrivacyDialog,
                )
            }
            }
        }
    }
}
}

