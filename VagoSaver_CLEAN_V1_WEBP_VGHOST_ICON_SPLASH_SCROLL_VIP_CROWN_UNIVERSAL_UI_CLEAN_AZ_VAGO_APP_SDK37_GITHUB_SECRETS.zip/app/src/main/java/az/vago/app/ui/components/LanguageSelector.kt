package az.vago.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.i18n.LanguageManager
import az.vago.app.data.i18n.L
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoCardBorder
import az.vago.app.ui.theme.VagoSurface

@Composable
fun LanguageSelector(
    language: String,
    onLanguageSelected: (String) -> Unit,
    selectedLanguage: String = language,
    modifier: Modifier = Modifier
) {
    var open = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val current = LanguageManager.options.firstOrNull { it.code == selectedLanguage }
        ?: LanguageManager.options.firstOrNull { it.code == language }
        ?: LanguageManager.options.first()

    Box(
        modifier = modifier
            .size(76.dp, 44.dp)
            .background(VagoSurface, androidx.compose.foundation.shape.RoundedCornerShape(22.dp))
            .border(1.dp, VagoCardBorder, androidx.compose.foundation.shape.RoundedCornerShape(22.dp))
            .clickable { open.value = true }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(current.flag, fontSize = 22.sp)
        }
    }

    if (open.value) {
        AlertDialog(
            onDismissRequest = { open.value = false },
            containerColor = VagoSurface,
            title = { Text(L.t("language", language), color = TextWhite, fontWeight = FontWeight.Bold) },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.heightIn(max = 360.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(LanguageManager.options, key = { it.code }) { option ->
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .background(
                                    if (option.code == selectedLanguage) NeonPink.copy(alpha = .16f) else VagoSurface,
                                    androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                                )
                                .border(
                                    1.dp,
                                    if (option.code == selectedLanguage) NeonPink else VagoCardBorder,
                                    androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                                )
                                .clickable {
                                    onLanguageSelected(option.code)
                                    open.value = false
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(option.flag, fontSize = 27.sp)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}

