package az.vago.app.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.model.DownloadFormat
import az.vago.app.ui.components.GradientPillButton
import az.vago.app.ui.components.OutlinedActionButton
import az.vago.app.data.i18n.L
import az.vago.app.ui.theme.NeonBlue
import az.vago.app.ui.theme.NeonCyan
import az.vago.app.ui.theme.NeonGreen
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.NeonPurpleBright
import az.vago.app.ui.theme.NeonPurpleLight
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoBackground
import az.vago.app.ui.theme.VagoCardBorder
import az.vago.app.ui.theme.VagoSurface
import az.vago.app.ui.viewmodel.MainUiState

@Composable
fun DownloadCompletedScreen(
    uiState: MainUiState,
    onCloseClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val item = uiState.completedItem ?: return
    val isAudio = item.format == DownloadFormat.MP3

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VagoBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP BAR (Close X on right)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCloseClicked,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("completed_close_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = L.t("close", uiState.settings.language),
                        tint = TextWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SUCCESS GLOWING CIRCLE & TITLE
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SuccessCheckBadge(size = 90.dp)

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = L.t("completed", uiState.settings.language),
                    color = TextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.3.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isAudio) "MP3 fayl cihazınıza endirildi." else "Fayl uğurla cihazınıza endirildi.",
                    color = TextGray,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // FILE PREVIEW CARD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VagoSurface, RoundedCornerShape(18.dp))
                    .border(1.dp, VagoCardBorder, RoundedCornerShape(18.dp))
                    .padding(14.dp)
                    .testTag("completed_file_card"),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Thumbnail or Music icon box
                        if (isAudio) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .background(
                                        brush = Brush.linearGradient(
                                            listOf(NeonPurple, NeonPink)
                                        ),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = TextWhite,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .background(
                                        color = Color(0xFF261942),
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .border(1.dp, Color(0xFF4C2F7A), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(26.dp)
                                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                        .border(1.dp, TextWhite.copy(alpha = 0.8f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = TextWhite,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.fileName,
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.fileSizeText,
                                color = TextGray,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = L.t("success", uiState.settings.language),
                        tint = NeonCyan,
                        modifier = Modifier
                            .size(24.dp)
                            .padding(start = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // ACTION BUTTONS
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                GradientPillButton(
                    text = if (isAudio) "Musiqini aç" else "Videonu aç",
                    icon = Icons.Default.PlayArrow,
                    onClick = {
                        val fileUri = item.localUri?.let { android.net.Uri.parse(it) }
                        if (fileUri != null) {
                            try {
                                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(fileUri, item.format.mimeType)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                val chooser = Intent.createChooser(viewIntent, if (isAudio) "Musiqini aç" else "Videonu aç").apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(chooser)
                            } catch (e: Exception) {
                                val errorMsg = if (isAudio) "Musiqi açıla bilmədi" else "Video açıla bilmədi"
                                Toast.makeText(context, errorMsg, Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Fayl tapılmadı", Toast.LENGTH_SHORT).show()
                        }
                    },
                    testTag = "open_media_button"
                )

                OutlinedActionButton(
                    text = L.t("share", uiState.settings.language),
                    icon = Icons.Outlined.Share,
                    onClick = {
                        val fileUri = item.localUri?.let { android.net.Uri.parse(it) }
                        if (fileUri != null) {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = item.format.mimeType
                                putExtra(Intent.EXTRA_STREAM, fileUri)
                                putExtra(Intent.EXTRA_SUBJECT, item.fileName)
                                putExtra(Intent.EXTRA_TEXT, "VagoSaver ilə endirildi: ${item.fileName}")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            try {
                                val chooser = Intent.createChooser(shareIntent, "Faylı paylaş").apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(chooser)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Paylaşmaq mümkün olmadı", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Fayl tapılmadı", Toast.LENGTH_SHORT).show()
                        }
                    },
                    testTag = "share_media_button"
                )
            }
        }
    }
}

@Composable
private fun SuccessCheckBadge(
    size: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.size(size * 1.5f),
        contentAlignment = Alignment.Center
    ) {
        // Decorative Sparkles
        Canvas(modifier = Modifier.size(size * 1.5f)) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val radius = this.size.width / 2

            // Sparkle dots around
            drawCircle(color = NeonPurpleBright.copy(alpha = 0.8f), radius = 4f, center = Offset(center.x - radius * 0.7f, center.y - radius * 0.4f))
            drawCircle(color = NeonCyan.copy(alpha = 0.8f), radius = 5f, center = Offset(center.x + radius * 0.75f, center.y - radius * 0.35f))
            drawCircle(color = NeonPink.copy(alpha = 0.9f), radius = 3.5f, center = Offset(center.x - radius * 0.6f, center.y + radius * 0.5f))
            drawCircle(color = NeonPurpleLight.copy(alpha = 0.7f), radius = 4.5f, center = Offset(center.x + radius * 0.65f, center.y + radius * 0.45f))
            drawCircle(color = NeonCyan.copy(alpha = 0.6f), radius = 3f, center = Offset(center.x, center.y - radius * 0.85f))
        }

        // Center Glowing Check Circle
        Box(
            modifier = Modifier
                .size(size)
                .shadow(
                    elevation = 20.dp,
                    shape = CircleShape,
                    ambientColor = NeonCyan.copy(alpha = 0.4f),
                    spotColor = NeonPurple.copy(alpha = 0.7f)
                )
                .background(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF6366F1), Color(0xFF9333EA))
                    ),
                    shape = CircleShape
                )
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(listOf(NeonCyan, NeonPurpleBright, NeonPink, NeonCyan)),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = TextWhite,
                modifier = Modifier.size(size * 0.48f)
            )
        }
    }
}
