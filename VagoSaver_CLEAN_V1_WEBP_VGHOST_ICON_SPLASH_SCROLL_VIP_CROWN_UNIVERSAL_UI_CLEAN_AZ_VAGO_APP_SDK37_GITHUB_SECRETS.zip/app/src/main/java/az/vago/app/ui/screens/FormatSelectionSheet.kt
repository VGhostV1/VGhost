package az.vago.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.model.DownloadFormat
import az.vago.app.ui.components.FormatCard
import az.vago.app.ui.components.VagoSaverLogoBadge
import az.vago.app.ui.theme.TextGray
import az.vago.app.data.i18n.L
import az.vago.app.data.i18n.LanguageManager
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoBackground
import az.vago.app.ui.theme.VagoCardBorder
import az.vago.app.ui.theme.VagoSurface

@Composable
fun FormatSelectionScreen(
    onFormatSelected: (DownloadFormat) -> Unit,
    onDismiss: () -> Unit,
    language: String = LanguageManager.EN,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VagoBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Centered Logo
                VagoSaverLogoBadge(size = 76.dp)

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = L.t("format_select", language),
                    color = TextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.3.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = L.t("format_sub", language),
                    color = TextGray,
                    fontSize = 14.sp
                )
            }

            // Options: Musiqi, Video və Filigransız
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                FormatCard(
                    format = DownloadFormat.MP3,
                    onClick = { onFormatSelected(DownloadFormat.MP3) },
                    language = language
                )

                FormatCard(
                    format = DownloadFormat.MP4,
                    onClick = { onFormatSelected(DownloadFormat.MP4) },
                    language = language
                )

                FormatCard(
                    format = DownloadFormat.NO_WATERMARK_MP4,
                    onClick = { onFormatSelected(DownloadFormat.NO_WATERMARK_MP4) },
                    language = language
                )
            }

            // Bottom Dismiss / Cancel Button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(VagoSurface, CircleShape)
                        .border(1.dp, VagoCardBorder, CircleShape)
                        .clip(CircleShape)
                        .clickable(onClick = onDismiss)
                        .testTag("cancel_format_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = L.t("cancel", language),
                        tint = TextWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = L.t("cancel", language),
                    color = TextGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(onClick = onDismiss)
                )
            }
        }
    }
}

