package az.vago.app.data.repository

import az.vago.app.data.model.DownloadFormat
import az.vago.app.data.model.DownloadItem
import az.vago.app.data.model.DownloadProgress
import az.vago.app.data.model.DownloadStatus
import az.vago.app.data.model.TikTokMediaInfo
import az.vago.app.data.network.ApiError
import az.vago.app.data.network.DirectTikTokExtractor
import az.vago.app.data.network.retryWithBackoff
import az.vago.app.data.util.TikTokUrlValidator
import az.vago.app.data.util.UrlValidationResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException

import android.content.Context
import az.vago.app.data.network.MediaDownloader
import az.vago.app.data.network.TikwmNoWatermarkExtractor
import az.vago.app.data.network.TikwmMediaExtractor
import az.vago.app.data.storage.MediaStorageManager
import az.vago.app.data.storage.StorageDestination
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class DownloadRepositoryImpl(
    private val context: Context? = null,
    private val extractor: DirectTikTokExtractor = DirectTikTokExtractor(),
    private val noWatermarkExtractor: TikwmNoWatermarkExtractor = TikwmNoWatermarkExtractor(),
    private val tikwmMediaExtractor: TikwmMediaExtractor = TikwmMediaExtractor(),
    private val mediaDownloader: MediaDownloader = MediaDownloader(),
    private val storageManager: MediaStorageManager? = context?.let { MediaStorageManager(it) }
) : DownloadRepository {

    private val _currentDownloadStatus = MutableStateFlow<DownloadStatus>(DownloadStatus.Idle)
    override val currentDownloadStatus: Flow<DownloadStatus> = _currentDownloadStatus.asStateFlow()

    override suspend fun fetchMediaInfo(url: String): Result<TikTokMediaInfo> {
        val validation = TikTokUrlValidator.validate(url)
        if (validation != UrlValidationResult.Valid) {
            return Result.failure(ApiError.InvalidUrl)
        }

        val sanitizedUrl = TikTokUrlValidator.sanitizeUrl(url)

        return try {
            val mediaInfo = retryWithBackoff {
                executeNetworkRequest(sanitizedUrl)
            }
            Result.success(mediaInfo)
        } catch (directError: Throwable) {
            // TikTok frequently changes/blocks its public web HTML, especially
            // for vm.tiktok.com short links. Do not stop the UI here: fall back
            // to the same TikTok link through TikWM, which supports short links
            // and returns video + music metadata and clean video URLs.
            val fallback = tikwmMediaExtractor.extract(sanitizedUrl)
            if (fallback.isSuccess) {
                fallback
            } else {
                when (directError) {
                    is ApiError -> Result.failure(directError)
                    is IOException -> Result.failure(ApiError.NoInternet)
                    else -> Result.failure(
                        ApiError.Unknown(
                            directError.localizedMessage ?: "Gözlənilməyən xəta baş verdi."
                        )
                    )
                }
            }
        }
    }

    private suspend fun executeNetworkRequest(sanitizedUrl: String): TikTokMediaInfo {
        return extractor.extract(sanitizedUrl)
    }

    override suspend fun prepareDownload(
        mediaInfo: TikTokMediaInfo,
        format: DownloadFormat
    ): Result<DownloadItem> {
        val sanitizedTitle = mediaInfo.title
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            .take(30)
            .ifBlank { "media_${mediaInfo.id}" }

        val fileName = when (format) {
            DownloadFormat.MP3 -> "${sanitizedTitle}_${mediaInfo.id}.mp3"
            DownloadFormat.MP4, DownloadFormat.NO_WATERMARK_MP4 ->
                "${sanitizedTitle}_${mediaInfo.id}.mp4"
        }

        val targetUrl = when (format) {
            DownloadFormat.MP3 -> mediaInfo.mp3DownloadUrl
            DownloadFormat.MP4 -> mediaInfo.mp4DownloadUrl
            DownloadFormat.NO_WATERMARK_MP4 -> mediaInfo.noWatermarkDownloadUrls.firstOrNull().orEmpty()
        }

        val fileSizeText = mediaInfo.fileSizeText.ifBlank { "Ölçü endirmə zamanı müəyyən ediləcək" }

        val item = DownloadItem(
            id = mediaInfo.id,
            fileName = fileName,
            fileSizeText = fileSizeText,
            format = format,
            filePath = null,
            localUri = null,
            originalUrl = targetUrl.ifBlank { mediaInfo.originalUrl }
        )

        return Result.success(item)
    }

    override suspend fun executeDownload(
        mediaInfo: TikTokMediaInfo,
        format: DownloadFormat,
        onProgress: suspend (DownloadProgress) -> Unit
    ): Result<DownloadItem> {
        val targetUrls = when (format) {
            DownloadFormat.MP4 -> buildList {
                addAll(mediaInfo.mp4DownloadUrls)
                add(mediaInfo.mp4DownloadUrl)
            }.filter { it.isNotBlank() }.distinct()

            DownloadFormat.MP3 -> listOf(mediaInfo.mp3DownloadUrl)
                .filter { it.isNotBlank() }

            DownloadFormat.NO_WATERMARK_MP4 -> {
                // Prefer a clean URL extracted directly from TikTok's response.
                // If TikTok does not expose one, ask the dedicated no-watermark
                // provider for a fresh signed CDN URL.
                val direct = mediaInfo.noWatermarkDownloadUrls
                    .filter { it.isNotBlank() }
                    .distinct()

                if (direct.isNotEmpty()) {
                    direct
                } else {
                    noWatermarkExtractor.extract(mediaInfo.originalUrl)
                        .getOrElse { return Result.failure(it) }
                        .let { listOf(it) }
                }
            }
        }

        if (targetUrls.isEmpty()) {
            return Result.failure(
                if (format == DownloadFormat.NO_WATERMARK_MP4) {
                    ApiError.NoWatermarkUnavailable
                } else {
                    ApiError.DownloadUrlInvalid
                }
            )
        }

        val sanitizedTitle = mediaInfo.title
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            .take(30)
            .ifBlank { "vagosaver_${mediaInfo.id}" }

        val preferredFileName = when (format) {
            DownloadFormat.MP4, DownloadFormat.NO_WATERMARK_MP4 ->
                "${sanitizedTitle}_${mediaInfo.id}.mp4"
            DownloadFormat.MP3 -> "${sanitizedTitle}_${mediaInfo.id}.mp3"
        }

        var lastError: ApiError = ApiError.DownloadUrlInvalid

        for ((index, targetUrl) in targetUrls.withIndex()) {
            val destination: StorageDestination = try {
                if (storageManager != null) {
                    storageManager.createDownloadDestination(preferredFileName, format)
                } else {
                    val tempFile = File.createTempFile(
                        "vagosaver_",
                        if (format == DownloadFormat.MP3) ".mp3" else ".mp4"
                    )
                    StorageDestination(
                        outputStream = FileOutputStream(tempFile),
                        file = tempFile,
                        uri = android.net.Uri.fromFile(tempFile),
                        finalFileName = preferredFileName,
                        onComplete = {},
                        onCancel = { tempFile.delete() }
                    )
                }
            } catch (_: Throwable) {
                return Result.failure(ApiError.StorageError)
            }

            try {
                val bytesDownloaded = mediaDownloader.download(
                    url = targetUrl,
                    destination = destination,
                    expectedSizeBytes = 0L,
                    referer = mediaInfo.originalUrl,
                    extraHeaders = mediaInfo.downloadHeaders,
                    onProgress = onProgress
                )

                if (bytesDownloaded <= 0L) {
                    destination.onCancel()
                    lastError = ApiError.DownloadFailed
                    continue
                }

                val finalSizeMb = String.format(
                    Locale.US,
                    "%.1f MB",
                    bytesDownloaded / (1024.0 * 1024.0)
                )

                val completedItem = DownloadItem(
                    id = mediaInfo.id,
                    fileName = destination.finalFileName,
                    fileSizeText = finalSizeMb,
                    format = format,
                    filePath = destination.file?.absolutePath,
                    localUri = destination.uri.toString(),
                    originalUrl = targetUrl
                )

                _currentDownloadStatus.value = DownloadStatus.Success(completedItem)
                return Result.success(completedItem)
            } catch (e: ApiError) {
                lastError = e
                if (e is ApiError.DownloadCancelled) {
                    _currentDownloadStatus.value = DownloadStatus.Cancelled
                    return Result.failure(e)
                }

                // A signed TikTok CDN URL can expire or reject one representation.
                // Only that URL-specific failure is eligible for the next real candidate.
                if (e !is ApiError.DownloadUrlInvalid) {
                    _currentDownloadStatus.value = DownloadStatus.Error(e.messageAz)
                    return Result.failure(e)
                }

                if (index == targetUrls.lastIndex) {
                    _currentDownloadStatus.value = DownloadStatus.Error(e.messageAz)
                    return Result.failure(e)
                }
            } catch (e: Throwable) {
                lastError = ApiError.Unknown(e.localizedMessage ?: "Endirmə xətası baş verdi.")
                if (index == targetUrls.lastIndex) {
                    _currentDownloadStatus.value = DownloadStatus.Error(lastError.messageAz)
                    return Result.failure(lastError)
                }
            }
        }

        _currentDownloadStatus.value = DownloadStatus.Error(lastError.messageAz)
        return Result.failure(lastError)
    }

    override suspend fun prepareDownload(url: String, format: DownloadFormat): Result<DownloadItem> {
        val sanitizedId = System.currentTimeMillis().toString().takeLast(12)
        val fileName = when (format) {
            DownloadFormat.MP3 -> "audio_$sanitizedId.mp3"
            DownloadFormat.MP4, DownloadFormat.NO_WATERMARK_MP4 -> "video_$sanitizedId.mp4"
        }
        val fileSize = "Ölçü endirmə zamanı müəyyən ediləcək"
        val item = DownloadItem(
            id = sanitizedId,
            fileName = fileName,
            fileSizeText = fileSize,
            format = format,
            originalUrl = url
        )
        return Result.success(item)
    }

    override fun cancelActiveDownload() {
        _currentDownloadStatus.value = DownloadStatus.Cancelled
    }
}


