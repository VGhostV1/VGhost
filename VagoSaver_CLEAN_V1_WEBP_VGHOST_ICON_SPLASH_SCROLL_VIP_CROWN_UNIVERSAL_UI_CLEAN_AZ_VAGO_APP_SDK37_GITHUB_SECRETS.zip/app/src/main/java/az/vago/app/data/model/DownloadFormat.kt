package az.vago.app.data.model

enum class DownloadFormat(
    val extension: String,
    val mimeType: String
) {
    MP3("mp3", "audio/mpeg"),
    MP4("mp4", "video/mp4"),
    NO_WATERMARK_MP4("mp4", "video/mp4")
}
