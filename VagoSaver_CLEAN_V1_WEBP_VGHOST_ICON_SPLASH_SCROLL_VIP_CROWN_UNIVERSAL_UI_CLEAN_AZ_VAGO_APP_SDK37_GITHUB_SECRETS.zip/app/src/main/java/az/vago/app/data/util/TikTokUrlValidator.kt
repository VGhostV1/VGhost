package az.vago.app.data.util

sealed interface UrlValidationResult {
    object Valid : UrlValidationResult
    object Empty : UrlValidationResult
    object InvalidFormat : UrlValidationResult
}

object TikTokUrlValidator {

    private val TIKTOK_DOMAINS = listOf(
        "tiktok.com",
        "www.tiktok.com",
        "vm.tiktok.com",
        "vt.tiktok.com",
        "m.tiktok.com",
        "v.douyin.com"
    )

    private val URL_REGEX = Regex(
        pattern = "^(https?://)?([a-zA-Z0-9-]+\\.)*(tiktok\\.com|douyin\\.com)/.*$",
        option = RegexOption.IGNORE_CASE
    )

    fun validate(rawUrl: String): UrlValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return UrlValidationResult.Empty
        }

        if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            // Check if adding https:// makes it valid
            val candidate = "https://$trimmed"
            if (!URL_REGEX.matches(candidate)) {
                return UrlValidationResult.InvalidFormat
            }
        } else {
            if (!URL_REGEX.matches(trimmed)) {
                return UrlValidationResult.InvalidFormat
            }
        }

        return UrlValidationResult.Valid
    }

    fun sanitizeUrl(rawUrl: String): String {
        var clean = rawUrl.trim()
        if (!clean.startsWith("http://", ignoreCase = true) &&
            !clean.startsWith("https://", ignoreCase = true)
        ) {
            clean = "https://$clean"
        }
        return clean
    }
}

