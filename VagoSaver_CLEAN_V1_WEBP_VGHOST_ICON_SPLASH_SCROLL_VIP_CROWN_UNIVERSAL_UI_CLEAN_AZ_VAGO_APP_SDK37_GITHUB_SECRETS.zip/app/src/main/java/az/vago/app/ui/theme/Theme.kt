package az.vago.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private fun darkScheme() = darkColorScheme(
    primary = NeonPurpleBright,
    onPrimary = Color.White,
    secondary = NeonPink,
    onSecondary = Color.White,
    tertiary = NeonCyan,
    onTertiary = Color.White,
    background = Color(0xFF050812),
    onBackground = Color.White,
    surface = Color(0xFF0A1020),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF111A32),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF24345F)
)

private fun lightScheme() = lightColorScheme(
    primary = NeonPurple,
    onPrimary = Color.White,
    secondary = NeonPink,
    onSecondary = Color.White,
    tertiary = NeonCyan,
    onTertiary = Color.White,
    background = Color(0xFFF4F7FF),
    onBackground = Color(0xFF0E1424),
    surface = Color.White,
    onSurface = Color(0xFF0E1424),
    surfaceVariant = Color(0xFFE8EEFF),
    onSurfaceVariant = Color(0xFF58657A),
    outline = Color(0xFFD1DBF5)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) darkScheme() else lightScheme()
    val view = LocalView.current

    SideEffect {
        if (darkTheme) {
            VagoBackground = Color(0xFF050812)
            VagoSurface = Color(0xFF0A1020)
            VagoSurfaceVariant = Color(0xFF111A32)
            VagoCardBorder = Color(0xFF24345F)
            VagoCardBorderActive = Color(0xFF4C6FFF)
            TextWhite = Color(0xFFFFFFFF)
            TextGray = Color(0xFF94A3B8)
            TextMuted = Color(0xFF64748B)
            TextDarkGray = Color(0xFF475569)
        } else {
            VagoBackground = Color(0xFFF4F7FF)
            VagoSurface = Color(0xFFFFFFFF)
            VagoSurfaceVariant = Color(0xFFE8EEFF)
            VagoCardBorder = Color(0xFFD1DBF5)
            VagoCardBorderActive = Color(0xFF6D4AFF)
            TextWhite = Color(0xFF0E1424)
            TextGray = Color(0xFF58657A)
            TextMuted = Color(0xFF6B768A)
            TextDarkGray = Color(0xFF354055)
        }

        if (!view.isInEditMode) {
            val window = (view.context as? Activity)?.window
            window?.let { win ->
                WindowCompat.getInsetsController(win, view).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

