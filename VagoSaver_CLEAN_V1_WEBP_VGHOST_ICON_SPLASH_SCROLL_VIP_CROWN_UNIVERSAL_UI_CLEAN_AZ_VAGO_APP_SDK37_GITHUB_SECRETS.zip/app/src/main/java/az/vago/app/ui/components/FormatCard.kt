package az.vago.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.model.DownloadFormat
import az.vago.app.ui.theme.CyanBlueGradient
import az.vago.app.ui.theme.NeonBlue
import az.vago.app.ui.theme.NeonCyan
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.PurplePinkGradient
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoSurface
import az.vago.app.data.i18n.L
import az.vago.app.data.i18n.LanguageManager

@Composable
fun FormatCard(
    format: DownloadFormat,
    onClick: () -> Unit,
    language: String = LanguageManager.EN,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(targetValue = if (isPressed) 0.98f else 1f, label = "format_card_scale")

    val (icon, gradient, glowColor, borderBrush) = when (format) {
        DownloadFormat.MP3 -> Quadruple(
            Icons.Default.MusicNote,
            PurplePinkGradient,
            NeonPurple.copy(alpha = 0.4f),
            Brush.horizontalGradient(listOf(NeonPurple, NeonPink.copy(alpha = 0.8f)))
        )
        DownloadFormat.MP4 -> Quadruple(
            Icons.Default.Videocam,
            CyanBlueGradient,
            NeonCyan.copy(alpha = 0.4f),
            Brush.horizontalGradient(listOf(NeonCyan, NeonBlue.copy(alpha = 0.8f)))
        )
        DownloadFormat.NO_WATERMARK_MP4 -> Quadruple(
            Icons.Default.Star,
            PurplePinkGradient,
            NeonPink.copy(alpha = 0.4f),
            Brush.horizontalGradient(listOf(NeonPink, NeonPurple.copy(alpha = 0.8f)))
        )
    }

    val shape = RoundedCornerShape(20.dp)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .scale(scale)
            .shadow(
                elevation = 8.dp,
                shape = shape,
                ambientColor = glowColor,
                spotColor = glowColor
            )
            .background(color = VagoSurface, shape = shape)
            .border(
                width = 1.5.dp,
                brush = borderBrush,
                shape = shape
            )
            .clip(shape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 18.dp, vertical = 18.dp)
            .testTag("format_card_${format.name.lowercase()}"),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Icon squircle
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(
                            brush = Brush.linearGradient(gradient),
                            shape = RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = L.t(when(format){ DownloadFormat.MP3 -> "music"; DownloadFormat.MP4 -> "video"; DownloadFormat.NO_WATERMARK_MP4 -> "no_watermark" }, language),
                        tint = TextWhite,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = L.t(when(format){ DownloadFormat.MP3 -> "music"; DownloadFormat.MP4 -> "video"; DownloadFormat.NO_WATERMARK_MP4 -> "no_watermark" }, language),
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.3.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = L.t(when(format){ DownloadFormat.MP3 -> "audio_file"; DownloadFormat.MP4 -> "video_file"; DownloadFormat.NO_WATERMARK_MP4 -> "no_watermark_desc" }, language),
                        color = TextGray,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = when (format) {
                    DownloadFormat.MP3 -> NeonPink
                    DownloadFormat.MP4 -> NeonCyan
                    DownloadFormat.NO_WATERMARK_MP4 -> NeonPink
                },
                modifier = Modifier.size(26.dp)
            )
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

