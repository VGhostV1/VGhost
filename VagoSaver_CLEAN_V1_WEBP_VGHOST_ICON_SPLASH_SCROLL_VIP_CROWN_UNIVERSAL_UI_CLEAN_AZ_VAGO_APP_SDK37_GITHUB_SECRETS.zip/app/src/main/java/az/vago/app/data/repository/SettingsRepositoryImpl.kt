package az.vago.app.data.repository

import android.content.Context
import android.content.SharedPreferences
import az.vago.app.data.i18n.LanguageManager
import az.vago.app.data.model.AppSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepositoryImpl(context: Context? = null) : SettingsRepository {
    private val appContext = context?.applicationContext
    private val prefs: SharedPreferences? = appContext?.getSharedPreferences("vagosaver_settings_prefs", Context.MODE_PRIVATE)
    private val initialSelection = LanguageManager.SYSTEM
    private val initialLanguage = appContext?.let { LanguageManager.systemLanguage(it) } ?: LanguageManager.EN

    private val _settings = MutableStateFlow(
        AppSettings(
            autoPasteLink = prefs?.getBoolean(KEY_AUTO_PASTE, true) ?: true,
            downloadNotifications = prefs?.getBoolean(KEY_NOTIFICATIONS, true) ?: true,
            darkThemeAlways = prefs?.getBoolean(KEY_DARK_THEME, true) ?: true,
            language = initialLanguage,
            languageSelection = initialSelection
        )
    )
    override val settingsFlow: Flow<AppSettings> = _settings.asStateFlow()

    override suspend fun updateAutoPaste(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_AUTO_PASTE, enabled)?.apply()
        _settings.value = _settings.value.copy(autoPasteLink = enabled)
    }
    override suspend fun updateDownloadNotifications(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_NOTIFICATIONS, enabled)?.apply()
        _settings.value = _settings.value.copy(downloadNotifications = enabled)
    }
    override suspend fun updateDarkTheme(enabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_DARK_THEME, enabled)?.apply()
        _settings.value = _settings.value.copy(darkThemeAlways = enabled)
    }
    override suspend fun updateLanguage(language: String) {
        val selectedLanguage = appContext?.let { LanguageManager.resolve(language, it) } ?: LanguageManager.EN
        val selection = if (language == LanguageManager.SYSTEM) LanguageManager.SYSTEM else language
        prefs?.edit()?.putString(KEY_LANGUAGE, selection)?.apply()
        _settings.value = _settings.value.copy(language = selectedLanguage, languageSelection = selection)
    }
    companion object {
        private const val KEY_AUTO_PASTE = "key_auto_paste"
        private const val KEY_NOTIFICATIONS = "key_notifications"
        private const val KEY_DARK_THEME = "key_dark_theme"
        private const val KEY_LANGUAGE = "key_language"
    }
}

