package az.vago.app.data.network

import az.vago.app.data.model.DownloadProgress
import az.vago.app.data.storage.StorageDestination
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale

class MediaDownloader(
    private val okHttpClient: OkHttpClient = NetworkClient.okHttpClient
) {

    suspend fun download(
        url: String,
        destination: StorageDestination,
        expectedSizeBytes: Long = 0L,
        referer: String = "https://www.tiktok.com/",
        extraHeaders: Map<String, String> = emptyMap(),
        onProgress: suspend (DownloadProgress) -> Unit
    ): Long = withContext(Dispatchers.IO) {
        val normalizedReferer = referer.takeIf { it.startsWith("https://www.tiktok.com") || it.startsWith("https://m.tiktok.com") }
            ?: "https://www.tiktok.com/"

        // TikTok CDN URLs are signed. Do not send a forced Range header on the
        // first request: some CDN variants reject range requests even though
        // the same signed URL is downloadable normally.
        val requestBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", MOBILE_USER_AGENT)
            .header("Accept", "*/*")
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Referer", normalizedReferer)
            .header("Accept-Encoding", "identity")

        // Preserve cookies/session headers captured from the TikTok page.
        // Some signed CDN URLs return 403 without them.
        extraHeaders.forEach { (name, value) ->
            if (name.isNotBlank() && value.isNotBlank() &&
                !name.equals("User-Agent", true) &&
                !name.equals("Referer", true) &&
                !name.equals("Host", true) &&
                !name.equals("Content-Length", true)) {
                requestBuilder.header(name, value)
            }
        }

        val request = requestBuilder.build()

        var totalBytesRead = 0L

        try {
            val response = okHttpClient.newCall(request).execute()
            response.use { safeResponse ->
                if (!safeResponse.isSuccessful) {
                    destination.onCancel()
                    when (safeResponse.code) {
                        404, 410, 416 -> throw ApiError.DownloadUrlInvalid
                        401, 403 -> throw ApiError.DownloadUrlInvalid
                        in 500..599 -> throw ApiError.ServerError
                        else -> throw ApiError.DownloadUrlInvalid
                    }
                }

                val body = safeResponse.body ?: run {
                    destination.onCancel()
                    throw ApiError.DownloadUrlInvalid
                }

                // TikTok can return an empty Content-Type for a valid CDN stream,
                // so reject only responses that are explicitly HTML/JSON.
                val contentType = body.contentType()?.toString()?.lowercase(Locale.US).orEmpty()
                if (contentType.startsWith("text/html") ||
                    contentType.startsWith("application/json") ||
                    contentType.startsWith("text/plain")
                ) {
                    destination.onCancel()
                    throw ApiError.DownloadUrlInvalid
                }

                val contentLength = body.contentLength()
                val totalSize = when {
                contentLength > 0 -> contentLength
                expectedSizeBytes > 0 -> expectedSizeBytes
                else -> 0L
            }

            val inputStream = body.byteStream()
            val outputStream = destination.outputStream
            val buffer = ByteArray(16 * 1024)
            var bytesRead: Int

            var lastProgressTime = System.currentTimeMillis()
            var bytesSinceLastSpeedCalc = 0L
            var currentSpeedText = "0.0 MB/s"

            inputStream.use { input ->
                outputStream.use { output ->
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        if (!currentCoroutineContext().isActive) {
                            throw CancellationException("Download cancelled by user")
                        }

                        output.write(buffer, 0, bytesRead)
                        totalBytesRead += bytesRead
                        bytesSinceLastSpeedCalc += bytesRead

                        val now = System.currentTimeMillis()
                        val timeDiff = now - lastProgressTime
                        if (timeDiff >= 300) {
                            val speedBytesPerSec = (bytesSinceLastSpeedCalc * 1000.0) / timeDiff.coerceAtLeast(1)
                            currentSpeedText = formatSpeed(speedBytesPerSec)
                            bytesSinceLastSpeedCalc = 0L
                            lastProgressTime = now

                            val percentage = if (totalSize > 0L) {
                                ((totalBytesRead.toDouble() / totalSize) * 100)
                                    .toInt()
                                    .coerceIn(0, 99)
                            } else {
                                0
                            }

                            val downloadedMb = String.format(Locale.US, "%.1f", totalBytesRead / (1024.0 * 1024.0))
                            val totalMb = String.format(Locale.US, "%.1f", totalSize / (1024.0 * 1024.0))

                            onProgress(
                                DownloadProgress(
                                    percentage = percentage,
                                    speedText = currentSpeedText,
                                    downloadedMb = downloadedMb,
                                    totalMb = totalMb,
                                    fileName = destination.finalFileName
                                )
                            )
                        }
                    }
                    output.flush()
                }
            }

            if (totalBytesRead <= 0L) {
                destination.onCancel()
                throw ApiError.DownloadFailed
            }

            destination.onComplete()

            // Final 100% progress update
            val finalTotalMb = String.format(Locale.US, "%.1f", totalBytesRead / (1024.0 * 1024.0))
            onProgress(
                DownloadProgress(
                    percentage = 100,
                    speedText = currentSpeedText,
                    downloadedMb = finalTotalMb,
                    totalMb = finalTotalMb,
                    fileName = destination.finalFileName
                )
            )

                totalBytesRead
            }
        } catch (e: CancellationException) {
            destination.onCancel()
            throw ApiError.DownloadCancelled
        } catch (e: UnknownHostException) {
            destination.onCancel()
            throw ApiError.NoInternet
        } catch (e: SocketTimeoutException) {
            destination.onCancel()
            throw ApiError.ServerError
        } catch (e: ConnectException) {
            destination.onCancel()
            throw ApiError.ServerError
        } catch (e: IOException) {
            destination.onCancel()
            throw ApiError.StorageError
        } catch (e: ApiError) {
            destination.onCancel()
            throw e
        } catch (e: Throwable) {
            destination.onCancel()
            throw ApiError.Unknown(e.localizedMessage ?: "Gözlənilməyən xəta baş verdi.")
        }
    }

    private companion object {
        const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }

    private fun formatSpeed(bytesPerSec: Double): String {
        val mbPerSec = bytesPerSec / (1024.0 * 1024.0)
        return if (mbPerSec >= 1.0) {
            String.format(Locale.US, "%.1f MB/s", mbPerSec)
        } else {
            val kbPerSec = bytesPerSec / 1024.0
            String.format(Locale.US, "%.0f KB/s", kbPerSec)
        }
    }
}

