package az.vago.app.data.repository

import az.vago.app.data.model.DownloadFormat
import az.vago.app.data.model.DownloadItem
import az.vago.app.data.model.DownloadProgress
import az.vago.app.data.model.DownloadStatus
import az.vago.app.data.model.TikTokMediaInfo
import kotlinx.coroutines.flow.Flow

interface DownloadRepository {
    val currentDownloadStatus: Flow<DownloadStatus>
    suspend fun fetchMediaInfo(url: String): Result<TikTokMediaInfo>
    suspend fun prepareDownload(url: String, format: DownloadFormat): Result<DownloadItem>
    suspend fun prepareDownload(mediaInfo: TikTokMediaInfo, format: DownloadFormat): Result<DownloadItem>
    suspend fun executeDownload(
        mediaInfo: TikTokMediaInfo,
        format: DownloadFormat,
        onProgress: suspend (DownloadProgress) -> Unit
    ): Result<DownloadItem>
    fun cancelActiveDownload()
}


