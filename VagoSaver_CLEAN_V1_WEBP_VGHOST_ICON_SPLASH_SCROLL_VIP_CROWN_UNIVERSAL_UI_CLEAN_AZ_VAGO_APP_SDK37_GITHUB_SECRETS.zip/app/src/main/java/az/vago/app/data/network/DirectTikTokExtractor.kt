package az.vago.app.data.network

import android.text.Html
import az.vago.app.data.model.TikTokMediaInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.util.concurrent.TimeUnit

/**
 * Backend-free TikTok extractor.
 *
 * The app talks directly to TikTok from the device. There is deliberately no
 * VagoSaver-owned API/server in this class.
 *
 * Strategy:
 *  1) Fetch the public TikTok page and inspect the embedded JSON/metadata.
 *  2) If the page does not contain media data, resolve the final URL and try
 *     TikTok's public item-detail web endpoint using the video id.
 *
 * TikTok may change or restrict these public web surfaces at any time. When
 * that happens this class fails cleanly instead of fabricating a download URL.
 */
class DirectTikTokExtractor(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()
) {

    suspend fun extract(inputUrl: String): TikTokMediaInfo = withContext(Dispatchers.IO) {
        var finalUrl = inputUrl

        // Strategy 1: normal TikTok page.
        val pageResult = runCatching {
            val request = Request.Builder()
                .url(inputUrl)
                .headers(tiktokHeaders())
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    null
                } else {
                    finalUrl = response.request.url.toString()
                    val html = response.body?.string().orEmpty()
                    val cookieHeader = cookieHeader(response)
                    if (html.isBlank()) null else parsePage(finalUrl, html, cookieHeader)
                }
            }
        }.getOrNull()

        if (pageResult != null) return@withContext pageResult

        // Strategy 2: TikTok item detail endpoint, using the resolved video id.
        val videoId = extractVideoId(finalUrl) ?: extractVideoId(inputUrl)
        if (!videoId.isNullOrBlank()) {
            val detailResult = runCatching {
                val endpoint = "https://www.tiktok.com/api/item/detail/?itemId=$videoId"
                val request = Request.Builder()
                    .url(endpoint)
                    .headers(tiktokHeaders())
                    .header("Referer", finalUrl)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) null
                    else parseItemDetail(finalUrl, response.body?.string().orEmpty(), videoId, cookieHeader(response))
                }
            }.getOrNull()

            if (detailResult != null) return@withContext detailResult
        }

        throw ApiError.MediaFetchFailed
    }

    private fun parsePage(originalUrl: String, rawHtml: String, cookieHeader: String = ""): TikTokMediaInfo? {
        val htmlText = Html.fromHtml(rawHtml, Html.FROM_HTML_MODE_LEGACY).toString()

        val noWatermarkCandidates = buildList {
            addAll(findJsonValues(rawHtml, "download_no_watermark_addr"))
            addAll(findJsonValues(rawHtml, "downloadNoWatermarkAddr"))
            addAll(findJsonValues(rawHtml, "play_addr_no_watermark"))
            addAll(findJsonValues(rawHtml, "playAddrNoWatermark"))
            addAll(findUrlListValues(rawHtml, "download_no_watermark_addr"))
            addAll(findUrlListValues(rawHtml, "downloadNoWatermarkAddr"))
        }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()

        val mp4Candidates = buildList {
            addAll(findJsonValues(rawHtml, "downloadAddr"))
            addAll(findJsonValues(rawHtml, "playAddr"))
            addAll(findJsonValues(rawHtml, "playAddrH264"))
            addAll(findJsonValues(rawHtml, "playAddrBytevc1"))
            addAll(findJsonValues(rawHtml, "PlayAddr"))
            findMeta(rawHtml, "og:video")?.let(::add)
            findMeta(rawHtml, "og:video:url")?.let(::add)
        }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()

        val mp4 = mp4Candidates.firstOrNull()

        val mp3 = firstNonBlank(
            findMusicPlayUrl(rawHtml),
            findJsonValue(rawHtml, "musicPlayUrl"),
            findMeta(rawHtml, "og:audio")
        )?.let(::decodeUrl)

        val videoId = extractVideoId(originalUrl)
            ?: findJsonValue(rawHtml, "id")
            ?: findJsonValue(rawHtml, "itemId")

        if (mp4.isNullOrBlank() && mp3.isNullOrBlank()) {
            // Some page responses escape JSON twice. Try the unescaped body too.
            val unescaped = decodeUrl(rawHtml)
            val fallbackNoWatermarkCandidates = buildList {
                addAll(findJsonValues(unescaped, "download_no_watermark_addr"))
                addAll(findJsonValues(unescaped, "downloadNoWatermarkAddr"))
                addAll(findJsonValues(unescaped, "play_addr_no_watermark"))
                addAll(findJsonValues(unescaped, "playAddrNoWatermark"))
                addAll(findUrlListValues(unescaped, "download_no_watermark_addr"))
                addAll(findUrlListValues(unescaped, "downloadNoWatermarkAddr"))
            }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()

            val fallbackMp4Candidates = buildList {
                addAll(findJsonValues(unescaped, "downloadAddr"))
                addAll(findJsonValues(unescaped, "playAddr"))
                addAll(findJsonValues(unescaped, "playAddrH264"))
                addAll(findJsonValues(unescaped, "playAddrBytevc1"))
                addAll(findJsonValues(unescaped, "PlayAddr"))
            }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()
            val fallbackMp4 = fallbackMp4Candidates.firstOrNull()
            val fallbackMp3 = firstNonBlank(
                findMusicPlayUrl(unescaped),
                findJsonValue(unescaped, "musicPlayUrl")
            )?.let(::decodeUrl)

            if (fallbackMp4.isNullOrBlank() && fallbackMp3.isNullOrBlank()) {
                return null
            }

            return buildMediaInfo(
                originalUrl = originalUrl,
                rawSource = unescaped,
                videoId = videoId,
                mp4 = fallbackMp4,
                mp4Candidates = fallbackMp4Candidates,
                mp3 = fallbackMp3,
                htmlText = htmlText,
                downloadHeaders = cookieHeader.takeIf { it.isNotBlank() }?.let { mapOf("Cookie" to it) }.orEmpty(),
                noWatermarkDownloadUrls = fallbackNoWatermarkCandidates
            )
        }

        return buildMediaInfo(
            originalUrl = originalUrl,
            rawSource = rawHtml,
            videoId = videoId,
            mp4 = mp4,
            mp4Candidates = mp4Candidates,
            mp3 = mp3,
            htmlText = htmlText,
            downloadHeaders = cookieHeader.takeIf { it.isNotBlank() }?.let { mapOf("Cookie" to it) }.orEmpty(),
            noWatermarkDownloadUrls = noWatermarkCandidates
        )
    }

    private fun parseItemDetail(
        originalUrl: String,
        jsonText: String,
        videoId: String,
        cookieHeader: String = ""
    ): TikTokMediaInfo? {
        if (jsonText.isBlank()) return null

        val root = runCatching { JSONObject(jsonText) }.getOrNull() ?: return null

        val videoObject = findObjectContainingAny(
            root,
            setOf(
                "downloadAddr",
                "playAddr",
                "download_no_watermark_addr",
                "downloadNoWatermarkAddr",
                "originCover",
                "duration"
            )
        )

        val noWatermarkCandidates = buildList {
            videoObject?.optString("download_no_watermark_addr")?.takeIf { it.isNotBlank() }?.let(::add)
            videoObject?.optString("downloadNoWatermarkAddr")?.takeIf { it.isNotBlank() }?.let(::add)
            videoObject?.optJSONObject("download_no_watermark_addr")?.optJSONArray("url_list")?.let { urls ->
                for (i in 0 until urls.length()) urls.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            }
            videoObject?.optJSONObject("downloadNoWatermarkAddr")?.optJSONArray("url_list")?.let { urls ->
                for (i in 0 until urls.length()) urls.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            }
            addAll(findJsonValues(jsonText, "download_no_watermark_addr"))
            addAll(findJsonValues(jsonText, "downloadNoWatermarkAddr"))
            addAll(findUrlListValues(jsonText, "download_no_watermark_addr"))
            addAll(findUrlListValues(jsonText, "downloadNoWatermarkAddr"))
            addAll(findJsonValues(jsonText, "play_addr_no_watermark"))
        }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()

        val musicObject = findObjectContainingAny(
            root,
            setOf("playUrl", "title", "authorName")
        )

        val mp4Candidates = buildList {
            videoObject?.optString("downloadAddr")?.takeIf { it.isNotBlank() }?.let(::add)
            videoObject?.optString("playAddr")?.takeIf { it.isNotBlank() }?.let(::add)
            videoObject?.optString("playAddrH264")?.takeIf { it.isNotBlank() }?.let(::add)
            addAll(findJsonValues(jsonText, "downloadAddr"))
            addAll(findJsonValues(jsonText, "playAddr"))
            addAll(findJsonValues(jsonText, "playAddrH264"))
            addAll(findJsonValues(jsonText, "playAddrBytevc1"))
            addAll(findJsonValues(jsonText, "PlayAddr"))
        }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()
        val mp4 = mp4Candidates.firstOrNull()

        val mp3 = firstNonBlank(
            musicObject?.optString("playUrl").orEmpty(),
            musicObject?.optString("play_url").orEmpty()
        )?.let(::decodeUrl)

        if (mp4.isNullOrBlank() && mp3.isNullOrBlank()) return null

        val title = firstNonBlank(
            findString(root, setOf("desc", "title")),
            "TikTok video $videoId"
        ) ?: "TikTok video $videoId"

        val author = firstNonBlank(
            findString(root, setOf("nickname", "uniqueId", "authorName")),
            ""
        ).orEmpty()

        val thumbnail = firstNonBlank(
            videoObject?.optString("originCover").orEmpty(),
            videoObject?.optString("cover").orEmpty(),
            videoObject?.optString("dynamicCover").orEmpty()
        )?.let(::decodeUrl).orEmpty()

        val duration = videoObject?.optLong("duration", 0L) ?: 0L

        return TikTokMediaInfo(
            id = videoId,
            title = title,
            author = author,
            thumbnailUrl = thumbnail,
            durationSeconds = duration,
            mediaType = "video",
            mp4DownloadUrl = mp4.orEmpty(),
            mp3DownloadUrl = mp3.orEmpty(),
            mp4DownloadUrls = mp4Candidates,
            fileSizeText = "",
            quality = "HD",
            originalUrl = originalUrl,
            downloadHeaders = cookieHeader.takeIf { it.isNotBlank() }?.let { mapOf("Cookie" to it) }.orEmpty(),
            noWatermarkDownloadUrls = noWatermarkCandidates
        )
    }

    private fun buildMediaInfo(
        originalUrl: String,
        rawSource: String,
        videoId: String?,
        mp4: String?,
        mp4Candidates: List<String> = emptyList(),
        mp3: String?,
        htmlText: String,
        downloadHeaders: Map<String, String> = emptyMap(),
        noWatermarkDownloadUrls: List<String> = emptyList()
    ): TikTokMediaInfo {
        val id = videoId ?: findJsonValue(rawSource, "id") ?: System.currentTimeMillis().toString().takeLast(12)

        val title = firstNonBlank(
            findJsonValue(rawSource, "desc"),
            findMeta(rawSource, "og:title")
        )?.let(::decodeUrl)
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
            ?.ifBlank { null }
            ?: "TikTok video $id"

        val author = firstNonBlank(
            findJsonValue(rawSource, "nickname"),
            findJsonValue(rawSource, "uniqueId"),
            findMeta(rawSource, "author")
        )?.let(::decodeUrl).orEmpty()

        val thumbnail = firstNonBlank(
            findJsonValue(rawSource, "cover"),
            findJsonValue(rawSource, "originCover"),
            findJsonValue(rawSource, "dynamicCover"),
            findMeta(rawSource, "og:image")
        )?.let(::decodeUrl).orEmpty()

        val duration = findJsonLong(rawSource, "duration") ?: 0L

        // Keep this check explicit: never invent a media URL.
        if (mp4.isNullOrBlank() && mp3.isNullOrBlank()) {
            throw ApiError.MediaFetchFailed
        }

        return TikTokMediaInfo(
            id = id,
            title = title,
            author = author,
            thumbnailUrl = thumbnail,
            durationSeconds = duration,
            mediaType = "video",
            mp4DownloadUrl = mp4.orEmpty(),
            mp3DownloadUrl = mp3.orEmpty(),
            mp4DownloadUrls = mp4Candidates.ifEmpty { listOfNotNull(mp4) },
            fileSizeText = "",
            quality = "HD",
            originalUrl = originalUrl,
            downloadHeaders = downloadHeaders,
            noWatermarkDownloadUrls = noWatermarkDownloadUrls
        )
    }

    private fun findJsonValues(source: String, key: String): List<String> {
        val escapedKey = Regex.escape(key)
        val patterns = listOf(
            Regex("\\\"$escapedKey\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)),
            Regex("\\\"$escapedKey\\\"\\s*:\\s*'([^']*)'", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        )
        return patterns.flatMap { pattern ->
            pattern.findAll(source).mapNotNull { it.groupValues.getOrNull(1) }.toList()
        }.map(::decodeUrl).filter(::isUsableMediaUrl).distinct()
    }

    private fun isUsableMediaUrl(value: String): Boolean {
        return value.startsWith("https://", ignoreCase = true) ||
            value.startsWith("http://", ignoreCase = true)
    }

    private fun findUrlListValues(source: String, key: String): List<String> {
        val escapedKey = Regex.escape(key)
        val pattern = Regex(
            "\\\"$escapedKey\\\"\\s*:\\s*\\{[^{}]*?\\\"url_list\\\"\\s*:\\s*\\[(.*?)\\]",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        )
        val block = pattern.find(source)?.groupValues?.getOrNull(1).orEmpty()
        return Regex("\\\"((?:\\\\.|[^\\\"])*)\\\"")
            .findAll(block)
            .mapNotNull { it.groupValues.getOrNull(1) }
            .map(::decodeUrl)
            .filter(::isUsableMediaUrl)
            .distinct()
            .toList()
    }

    private fun findJsonValue(source: String, key: String): String? {
        val escapedKey = Regex.escape(key)
        val patterns = listOf(
            Regex("\\\"$escapedKey\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)),
            Regex("\"$escapedKey\"\\s*:\\s*'([^']*)'", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
        )
        return patterns.firstNotNullOfOrNull { it.find(source)?.groupValues?.getOrNull(1) }
    }

    private fun findMusicPlayUrl(source: String): String? {
        val musicBlockPattern = Regex(
            "\\\"music\\\"\\s*:\\s*\\{(.*?)\\}",
            RegexOption.DOT_MATCHES_ALL
        )
        val musicBlock = musicBlockPattern.find(source)?.groupValues?.getOrNull(1)
        return musicBlock?.let { findJsonValue(it, "playUrl") }
            ?: findJsonValue(source, "playUrl")
    }

    private fun findJsonLong(source: String, key: String): Long? {
        val pattern = Regex("\\\"${Regex.escape(key)}\\\"\\s*:\\s*(\\d+)")
        return pattern.find(source)?.groupValues?.getOrNull(1)?.toLongOrNull()
    }

    private fun findMeta(source: String, property: String): String? {
        val escaped = Regex.escape(property)
        val pattern = Regex(
            "<meta[^>]+(?:property|name)=[\\\"']$escaped[\\\"'][^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]*>",
            RegexOption.IGNORE_CASE
        )
        val reversePattern = Regex(
            "<meta[^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]+(?:property|name)=[\\\"']$escaped[\\\"'][^>]*>",
            RegexOption.IGNORE_CASE
        )
        return pattern.find(source)?.groupValues?.getOrNull(1)
            ?: reversePattern.find(source)?.groupValues?.getOrNull(1)
    }

    private fun findObjectContainingAny(root: JSONObject, keys: Set<String>): JSONObject? {
        val stack = ArrayDeque<JSONObject>()
        stack.add(root)

        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            if (keys.any { current.has(it) && !current.isNull(it) }) {
                return current
            }

            val names = current.keys()
            while (names.hasNext()) {
                val key = names.next()
                when (val value = current.opt(key)) {
                    is JSONObject -> stack.add(value)
                    is JSONArray -> {
                        for (i in 0 until value.length()) {
                            value.optJSONObject(i)?.let(stack::add)
                        }
                    }
                }
            }
        }
        return null
    }

    private fun findString(root: JSONObject, keys: Set<String>): String? {
        val stack = ArrayDeque<JSONObject>()
        stack.add(root)

        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            for (key in keys) {
                val value = current.optString(key, "")
                if (value.isNotBlank()) return value
            }

            val names = current.keys()
            while (names.hasNext()) {
                when (val value = current.opt(names.next())) {
                    is JSONObject -> stack.add(value)
                    is JSONArray -> {
                        for (i in 0 until value.length()) {
                            value.optJSONObject(i)?.let(stack::add)
                        }
                    }
                }
            }
        }
        return null
    }

    private fun extractVideoId(url: String): String? {
        return runCatching {
            val path = URI(url).path.orEmpty()
            Regex("/video/(\\d+)").find(path)?.groupValues?.getOrNull(1)
                ?: Regex("/v/(\\d+)").find(path)?.groupValues?.getOrNull(1)
        }.getOrNull()
    }

    private fun decodeUrl(value: String): String {
        var result = Html.fromHtml(value, Html.FROM_HTML_MODE_LEGACY).toString()
            .replace("\\/", "/")
            .replace("\\u002F", "/", ignoreCase = true)
            .replace("\\u003A", ":", ignoreCase = true)
            .replace("\\u003F", "?", ignoreCase = true)
            .replace("\\u003D", "=", ignoreCase = true)
            .replace("\\u0026", "&", ignoreCase = true)
            .replace("&amp;", "&", ignoreCase = true)

        result = Regex("\\\\u([0-9a-fA-F]{4})").replace(result) {
            match -> match.groupValues[1].toInt(16).toChar().toString()
        }

        // Some TikTok responses percent-encode the CDN URL inside JSON.
        // Decode only when it still looks like a URL after decoding.
        result = runCatching {
            val decoded = URLDecoder.decode(result, "UTF-8")
            if (decoded.startsWith("https://") || decoded.startsWith("http://")) decoded else result
        }.getOrDefault(result)

        return result
    }

    /**
     * Collect cookies from the final response and any redirect responses.
     * TikTok video CDN URLs can be signed and may reject a request that does not
     * carry the session cookies issued while opening the TikTok page.
     */
    private fun cookieHeader(response: okhttp3.Response): String {
        val values = linkedMapOf<String, String>()
        var current: okhttp3.Response? = response
        while (current != null) {
            current.headers.values("Set-Cookie").forEach { raw ->
                val pair = raw.substringBefore(';').trim()
                val separator = pair.indexOf('=')
                if (separator > 0) {
                    val name = pair.substring(0, separator).trim()
                    val value = pair.substring(separator + 1).trim()
                    if (name.isNotBlank()) values[name] = value
                }
            }
            current = current.priorResponse
        }
        return values.entries.joinToString("; ") { (name, value) -> "$name=$value" }
    }

    private fun tiktokHeaders() = okhttp3.Headers.Builder()
        .add("User-Agent", MOBILE_USER_AGENT)
        .add("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
        .add("Accept-Language", "en-US,en;q=0.9")
        .add("Cache-Control", "no-cache")
        .add("Pragma", "no-cache")
        .build()

    private fun firstNonBlank(vararg values: String?): String? =
        values.firstOrNull { !it.isNullOrBlank() }

    private companion object {
        const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }
}

