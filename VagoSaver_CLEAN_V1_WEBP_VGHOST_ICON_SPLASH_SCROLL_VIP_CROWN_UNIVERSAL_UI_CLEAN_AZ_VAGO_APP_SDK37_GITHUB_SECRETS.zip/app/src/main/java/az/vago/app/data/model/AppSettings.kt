package az.vago.app.data.model

data class AppSettings(
    val autoPasteLink: Boolean = true,
    val downloadNotifications: Boolean = true,
    val darkThemeAlways: Boolean = true,
    /** Effective language used by all UI strings. */
    val language: String = "en",
    /** User selection: a concrete language code or LanguageManager.SYSTEM. */
    val languageSelection: String = "en"
)
