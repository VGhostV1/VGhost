package az.vago.app.ads

import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds

/**
 * Centralized AdMob configuration for VagoSaver.
 *
 * These are the production AdMob ad unit IDs configured for VagoSaver.
 */
object VagoAds {
    const val BANNER_AD_UNIT_ID = "ca-app-pub-1577138766992810/9276993247"

    fun initialize(context: Context) {
        MobileAds.initialize(context.applicationContext) {}
    }
}

