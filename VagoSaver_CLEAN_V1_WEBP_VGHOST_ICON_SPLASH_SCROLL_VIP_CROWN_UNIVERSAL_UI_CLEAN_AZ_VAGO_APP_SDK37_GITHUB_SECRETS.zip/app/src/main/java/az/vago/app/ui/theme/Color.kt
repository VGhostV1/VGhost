package az.vago.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

// Canvas & Surface
var VagoBackground by mutableStateOf(Color(0xFF050812))
    internal set
var VagoSurface by mutableStateOf(Color(0xFF0A1020))
    internal set
var VagoSurfaceVariant by mutableStateOf(Color(0xFF111A32))
    internal set
var VagoCardBorder by mutableStateOf(Color(0xFF24345F))
    internal set
var VagoCardBorderActive by mutableStateOf(Color(0xFF4C6FFF))
    internal set

// Neon Accents
val NeonPurple = Color(0xFF6D4AFF)
val NeonPurpleBright = Color(0xFF8B5CFF)
val NeonPurpleLight = Color(0xFFB79AFF)
val NeonPink = Color(0xFFFF2FA8)
val NeonPinkBright = Color(0xFFFF5CC8)
val NeonCyan = Color(0xFF00D9FF)
val NeonBlue = Color(0xFF2F7BFF)
val NeonGreen = Color(0xFF10B981)
val GoldCrown = Color(0xFFFBBF24)

// Text Colors
var TextWhite by mutableStateOf(Color(0xFFFFFFFF))
    internal set
var TextGray by mutableStateOf(Color(0xFF94A3B8))
    internal set
var TextMuted by mutableStateOf(Color(0xFF64748B))
    internal set
var TextDarkGray by mutableStateOf(Color(0xFF475569))
    internal set

// Gradients
val PurplePinkGradient = listOf(NeonPurple, NeonPink)
val CyanBlueGradient = listOf(NeonCyan, NeonBlue)
val DarkCardGradient = listOf(Color(0xFF0D1530), Color(0xFF070B18))


