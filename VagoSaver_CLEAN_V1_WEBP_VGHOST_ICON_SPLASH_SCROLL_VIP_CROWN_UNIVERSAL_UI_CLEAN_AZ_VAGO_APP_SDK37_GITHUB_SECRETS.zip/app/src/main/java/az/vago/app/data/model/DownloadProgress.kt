package az.vago.app.data.model

data class DownloadProgress(
    val percentage: Int = 0,
    val speedText: String = "0.0 MB/s",
    val downloadedMb: String = "0.0",
    val totalMb: String = "0.0",
    val fileName: String = ""
)

