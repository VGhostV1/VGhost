package az.vago.app.data.network

import kotlinx.coroutines.delay
import java.io.IOException

suspend fun <T> retryWithBackoff(
    maxRetries: Int = 2,
    initialDelayMs: Long = 800L,
    maxDelayMs: Long = 3000L,
    factor: Double = 2.0,
    block: suspend () -> T
): T {
    var currentDelay = initialDelayMs
    var lastException: Throwable? = null

    for (attempt in 0..maxRetries) {
        try {
            return block()
        } catch (e: ApiError.InvalidUrl) {
            // Do not retry invalid user inputs
            throw e
        } catch (e: ApiError.NotFound) {
            // Do not retry 404 Not Found
            throw e
        } catch (e: IOException) {
            lastException = e
            if (attempt == maxRetries) break
            delay(currentDelay)
            currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelayMs)
        } catch (e: Throwable) {
            lastException = e
            if (attempt == maxRetries) break
            delay(currentDelay)
            currentDelay = (currentDelay * factor).toLong().coerceAtMost(maxDelayMs)
        }
    }

    throw lastException ?: ApiError.ServerError
}

