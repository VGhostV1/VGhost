package az.vago.app.data.model

data class TikTokMediaInfo(
    val id: String,
    val title: String,
    val author: String,
    val thumbnailUrl: String,
    val durationSeconds: Long,
    val mediaType: String,
    val mp4DownloadUrl: String,
    val mp3DownloadUrl: String,
    val mp4DownloadUrls: List<String> = emptyList(),
    /** Clean/no-watermark MP4 candidates. These are preferred only for the explicit no-watermark option. */
    val noWatermarkDownloadUrls: List<String> = emptyList(),
    /** Headers captured from TikTok web responses that may be required by signed CDN URLs. */
    val downloadHeaders: Map<String, String> = emptyMap(),
    val fileSizeText: String,
    val quality: String,
    val originalUrl: String
)

