package az.vago.app.data.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import az.vago.app.data.model.DownloadFormat
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

data class StorageDestination(
    val outputStream: OutputStream,
    val file: File?,
    val uri: Uri,
    val finalFileName: String,
    val onComplete: () -> Unit,
    val onCancel: () -> Unit
)

class MediaStorageManager(private val context: Context) {

    fun createDownloadDestination(
        preferredFileName: String,
        format: DownloadFormat
    ): StorageDestination {
        val sanitizedName = sanitizeFileName(preferredFileName)
        val extension = if (format == DownloadFormat.MP3) ".mp3" else ".mp4"
        val mimeType = format.mimeType

        val nameWithoutExt = if (sanitizedName.endsWith(extension, ignoreCase = true)) {
            sanitizedName.substringBeforeLast(extension)
        } else {
            sanitizedName
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$nameWithoutExt$extension")
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VagoSaver")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val collectionUri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val uri = context.contentResolver.insert(collectionUri, contentValues)

            if (uri != null) {
                val outputStream = context.contentResolver.openOutputStream(uri)
                if (outputStream != null) {
                    return StorageDestination(
                        outputStream = outputStream,
                        file = null,
                        uri = uri,
                        finalFileName = "$nameWithoutExt$extension",
                        onComplete = {
                            val updateValues = ContentValues().apply {
                                put(MediaStore.MediaColumns.IS_PENDING, 0)
                            }
                            context.contentResolver.update(uri, updateValues, null, null)
                        },
                        onCancel = {
                            try {
                                context.contentResolver.delete(uri, null, null)
                            } catch (_: Exception) {}
                        }
                    )
                }
            }
        }

        // Fallback for pre-Q or when ContentResolver insert fails: Use App External / Public Downloads Dir
        val baseDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(context.filesDir, "downloads").apply { mkdirs() }

        if (!baseDir.exists()) {
            baseDir.mkdirs()
        }

        var candidateFile = File(baseDir, "$nameWithoutExt$extension")
        var counter = 1
        while (candidateFile.exists()) {
            candidateFile = File(baseDir, "${nameWithoutExt}_$counter$extension")
            counter++
        }

        val outputStream = FileOutputStream(candidateFile)
        val fileUri = try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                candidateFile
            )
        } catch (_: Exception) {
            Uri.fromFile(candidateFile)
        }

        return StorageDestination(
            outputStream = outputStream,
            file = candidateFile,
            uri = fileUri,
            finalFileName = candidateFile.name,
            onComplete = {},
            onCancel = {
                try {
                    if (candidateFile.exists()) {
                        candidateFile.delete()
                    }
                } catch (_: Exception) {}
            }
        )
    }

    private fun sanitizeFileName(rawName: String): String {
        return rawName
            .replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
            .replace(Regex("_+"), "_")
            .take(60)
            .ifBlank { "vagosaver_media_${System.currentTimeMillis()}" }
    }
}

