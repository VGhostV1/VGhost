package az.vago.app.data.model

data class DownloadItem(
    val id: String,
    val fileName: String,
    val fileSizeText: String,
    val format: DownloadFormat,
    val filePath: String? = null,
    val localUri: String? = null,
    val originalUrl: String,
    val downloadedAt: Long = System.currentTimeMillis()
)

