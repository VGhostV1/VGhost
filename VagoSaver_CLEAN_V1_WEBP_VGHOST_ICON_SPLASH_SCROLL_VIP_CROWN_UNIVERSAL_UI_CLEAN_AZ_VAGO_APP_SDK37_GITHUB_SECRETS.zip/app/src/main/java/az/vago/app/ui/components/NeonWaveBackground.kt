package az.vago.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import az.vago.app.ui.theme.NeonCyan
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPurple

@Composable
fun NeonWaveArt(
    modifier: Modifier = Modifier,
    height: Dp = 90.dp
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val w = size.width
        val h = size.height

        val waveBrush1 = Brush.horizontalGradient(
            colors = listOf(
                NeonPurple.copy(alpha = 0.15f),
                NeonPink.copy(alpha = 0.7f),
                NeonPurple.copy(alpha = 0.9f),
                NeonCyan.copy(alpha = 0.4f),
                Color.Transparent
            )
        )

        val waveBrush2 = Brush.horizontalGradient(
            colors = listOf(
                Color.Transparent,
                NeonCyan.copy(alpha = 0.3f),
                NeonPurple.copy(alpha = 0.8f),
                NeonPink.copy(alpha = 0.5f),
                Color.Transparent
            )
        )

        val waveBrush3 = Brush.horizontalGradient(
            colors = listOf(
                Color.Transparent,
                NeonPurple.copy(alpha = 0.4f),
                NeonPink.copy(alpha = 0.6f),
                Color.Transparent
            )
        )

        // Wave 1
        val path1 = Path().apply {
            moveTo(0f, h * 0.55f)
            cubicTo(
                w * 0.25f, h * 0.20f,
                w * 0.45f, h * 0.85f,
                w * 0.70f, h * 0.40f
            )
            cubicTo(
                w * 0.85f, h * 0.15f,
                w * 0.95f, h * 0.60f,
                w, h * 0.50f
            )
        }
        drawPath(path1, brush = waveBrush1, style = Stroke(width = 2.5f))

        // Wave 2
        val path2 = Path().apply {
            moveTo(0f, h * 0.65f)
            cubicTo(
                w * 0.30f, h * 0.80f,
                w * 0.50f, h * 0.30f,
                w * 0.75f, h * 0.75f
            )
            cubicTo(
                w * 0.90f, h * 0.95f,
                w * 0.98f, h * 0.45f,
                w, h * 0.55f
            )
        }
        drawPath(path2, brush = waveBrush2, style = Stroke(width = 2.0f))

        // Wave 3 (finer wave)
        val path3 = Path().apply {
            moveTo(w * 0.1f, h * 0.48f)
            cubicTo(
                w * 0.35f, h * 0.35f,
                w * 0.60f, h * 0.65f,
                w * 0.9f, h * 0.38f
            )
        }
        drawPath(path3, brush = waveBrush3, style = Stroke(width = 1.2f))
    }
}

