package az.vago.app.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.R
import az.vago.app.ui.components.GradientPillButton
import az.vago.app.ui.components.LanguageSelector
import az.vago.app.data.i18n.L
import az.vago.app.ui.components.VagoSaverBannerAd
import az.vago.app.ui.components.NeonWaveArt
import az.vago.app.ui.components.VagoSaverHeaderLogo
import az.vago.app.ui.theme.GoldCrown
import az.vago.app.ui.theme.NeonBlue
import az.vago.app.ui.theme.NeonCyan
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.NeonPurpleBright
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextMuted
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoBackground
import az.vago.app.ui.theme.VagoCardBorder
import az.vago.app.ui.theme.VagoSurface
import az.vago.app.ui.viewmodel.MainUiState

@Composable
fun HomeScreen(
    uiState: MainUiState,
    onUrlChange: (String) -> Unit,
    onPasteClicked: (String) -> Unit,
    onAutoPasteCheck: (String) -> Unit,
    onDownloadClicked: () -> Unit,
    onClearClicked: () -> Unit,
    onSettingsClicked: () -> Unit,
    onLanguageSelected: (String) -> Unit,
    onDismissNotice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbarHostState = remember { SnackbarHostState() }
    val currentInputUrl = rememberUpdatedState(uiState.inputUrl)
    val currentAutoPaste = rememberUpdatedState(uiState.settings.autoPasteLink)
    val currentOnPaste = rememberUpdatedState(onAutoPasteCheck)

    fun pasteTikTokFromClipboard() {
        if (!currentAutoPaste.value || currentInputUrl.value.isNotBlank()) return
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clipData = clipboard?.primaryClip
            if (clipData != null && clipData.itemCount > 0) {
                val text = clipData.getItemAt(0)?.text?.toString()?.trim().orEmpty()
                if (text.isNotBlank() &&
                    az.vago.app.data.util.TikTokUrlValidator.validate(text) == az.vago.app.data.util.UrlValidationResult.Valid
                ) {
                    currentOnPaste.value(text)
                }
            }
        } catch (_: SecurityException) {
            // Clipboard access can be restricted by Android; never crash the UI.
        } catch (_: Throwable) {}
    }

    // Paste immediately when a TikTok link is copied while VagoSaver is visible.
    DisposableEffect(uiState.settings.autoPasteLink, lifecycleOwner) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val listener = ClipboardManager.OnPrimaryClipChangedListener {
            pasteTikTokFromClipboard()
        }
        if (uiState.settings.autoPasteLink) {
            clipboard?.addPrimaryClipChangedListener(listener)
            pasteTikTokFromClipboard()
        }
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) pasteTikTokFromClipboard()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            clipboard?.removePrimaryClipChangedListener(listener)
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(uiState.userNotice) {
        uiState.userNotice?.let {
            snackbarHostState.showSnackbar(it)
            onDismissNotice()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VagoBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Premium VIP crown badge — no hand hint.
                Box(
                    modifier = Modifier.padding(end = 16.dp, bottom = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.vip_crown),
                        contentDescription = "VIP",
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("vip_crown_button")
                    )
                }

                LanguageSelector(
                    language = uiState.settings.language,
                    selectedLanguage = uiState.settings.languageSelection,
                    onLanguageSelected = onLanguageSelected
                )

                // Settings gear button
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(VagoSurface, CircleShape)
                        .border(1.dp, VagoCardBorder, CircleShape)
                        .clip(CircleShape)
                        .clickable(onClick = onSettingsClicked)
                        .testTag("settings_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = L.t("settings", uiState.settings.language),
                        tint = TextWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // CENTER LOGO & TITLE
            VagoSaverHeaderLogo()

            Spacer(modifier = Modifier.height(36.dp))

            // LINK INPUT BOX
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .background(VagoSurface, RoundedCornerShape(18.dp))
                    .border(1.2.dp, VagoCardBorder, RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Link,
                        contentDescription = L.t("link", uiState.settings.language),
                        tint = NeonPurpleBright,
                        modifier = Modifier.size(22.dp)
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Box(modifier = Modifier.weight(1f)) {
                        if (uiState.inputUrl.isEmpty()) {
                            Text(
                                text = L.t("link_placeholder", uiState.settings.language),
                                color = TextMuted,
                                fontSize = 15.sp
                            )
                        }
                        BasicTextField(
                            value = uiState.inputUrl,
                            onValueChange = onUrlChange,
                            singleLine = true,
                            textStyle = TextStyle(
                                color = TextWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Normal
                            ),
                            cursorBrush = SolidColor(NeonPink),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("tiktok_link_input")
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Clipboard Paste Icon Button
                    IconButton(
                        onClick = {
                            try {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                val clipData = clipboard?.primaryClip
                                if (clipData != null && clipData.itemCount > 0) {
                                    val text = clipData.getItemAt(0)?.text?.toString() ?: ""
                                    onPasteClicked(text)
                                }
                            } catch (_: Throwable) {}
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("paste_clipboard_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ContentPaste,
                            contentDescription = L.t("paste", uiState.settings.language),
                            tint = NeonPink,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // TƏMİZLƏ BUTTON — yalnız link olduqda görünür
            if (uiState.inputUrl.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .height(34.dp)
                        .clip(RoundedCornerShape(17.dp))
                        .background(NeonPink.copy(alpha = 0.10f))
                        .border(1.dp, NeonPink.copy(alpha = 0.55f), RoundedCornerShape(17.dp))
                        .clickable(onClick = onClearClicked)
                        .padding(horizontal = 14.dp)
                        .testTag("home_clear_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = L.t("clear", uiState.settings.language),
                            tint = NeonPink,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = L.t("clear", uiState.settings.language),
                            color = NeonPink,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
            }

            // YÜKLƏ BUTTON
            GradientPillButton(
                text = L.t("download", uiState.settings.language),
                icon = Icons.Default.Download,
                isLoading = uiState.isLoadingMediaInfo,
                onClick = onDownloadClicked,
                testTag = "home_download_button",
                loadingText = L.t("checking", uiState.settings.language)
            )

            // ADMOB BANNER — intentionally placed in the banner area shown in the design.
            VagoSaverBannerAd(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )

            // BOTTOM 3 FEATURE CARDS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FeatureCard(
                    icon = Icons.Default.Speed,
                    title = L.t("fast", uiState.settings.language),
                    subtitle = L.t("download_sub", uiState.settings.language),
                    iconColor = NeonCyan,
                    modifier = Modifier.weight(1f),
                    testTag = "feature_speed"
                )
                FeatureCard(
                    icon = Icons.Default.Lock,
                    title = L.t("safe", uiState.settings.language),
                    subtitle = "100%",
                    iconColor = NeonPurpleBright,
                    modifier = Modifier.weight(1f),
                    testTag = "feature_safe"
                )
                FeatureCard(
                    icon = Icons.Default.Bolt,
                    title = L.t("quality", uiState.settings.language),
                    subtitle = L.t("quality_sub", uiState.settings.language),
                    iconColor = NeonPink,
                    modifier = Modifier.weight(1f),
                    testTag = "feature_quality"
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
        )
    }
}

@Composable
private fun FeatureCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = "feature_card"
) {
    Box(
        modifier = modifier
            .height(86.dp)
            .background(VagoSurface, RoundedCornerShape(16.dp))
            .border(1.dp, VagoCardBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 8.dp, vertical = 10.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = TextWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Text(
                text = subtitle,
                color = TextGray,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

