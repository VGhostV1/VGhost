package az.vago.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.outlined.Headphones
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.model.DownloadFormat
import az.vago.app.ui.components.CircularProgressWithGlow
import az.vago.app.ui.components.LinearProgressWithGlow
import az.vago.app.data.i18n.L
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.NeonPurpleLight
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoBackground
import az.vago.app.ui.theme.VagoCardBorder
import az.vago.app.ui.theme.VagoSurface
import az.vago.app.ui.viewmodel.MainUiState

@Composable
fun DownloadProgressScreen(
    uiState: MainUiState,
    onBackClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAudio = uiState.selectedFormat == DownloadFormat.MP3
    val progress = uiState.downloadProgress
    val fraction = (progress.percentage / 100f).coerceIn(0f, 1f)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VagoBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClicked,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("download_progress_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = L.t("close", uiState.settings.language),
                        tint = TextWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Vago",
                            color = TextWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Save",
                            color = NeonPink,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Placeholder for symmetry
                Spacer(modifier = Modifier.size(40.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // CIRCULAR GLOWING PROGRESS
            Box(contentAlignment = Alignment.Center) {
                CircularProgressWithGlow(
                    percentage = progress.percentage,
                    isAudio = isAudio,
                    size = 200.dp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // STATUS & FILENAME
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = L.t("downloading", uiState.settings.language),
                    color = TextWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = progress.fileName,
                    color = TextGray,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // STATS & PROGRESS BAR
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = NeonPurpleLight,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = progress.speedText,
                            color = NeonPurpleLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Text(
                        text = "${progress.downloadedMb} / ${progress.totalMb} MB",
                        color = TextGray,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressWithGlow(progressFraction = fraction)
            }

            Spacer(modifier = Modifier.height(32.dp))

            // INFO CARD (Təhlükəsiz endirmə or Yüksək keyfiyyətli səs)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 28.dp)
                    .background(VagoSurface, RoundedCornerShape(18.dp))
                    .border(1.dp, VagoCardBorder, RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .testTag("download_info_card")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color(0xFF231B45), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isAudio) Icons.Outlined.Headphones else Icons.Outlined.Shield,
                                contentDescription = null,
                                tint = NeonPurpleLight,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = if (isAudio) "Yüksək keyfiyyətli səs" else "Təhlükəsiz endirmə",
                                color = TextWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isAudio) "MP3 320kbps keyfiyyətində" else "Fayl birdənbirə cihazınıza yüklənir",
                                color = TextGray,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = TextGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
