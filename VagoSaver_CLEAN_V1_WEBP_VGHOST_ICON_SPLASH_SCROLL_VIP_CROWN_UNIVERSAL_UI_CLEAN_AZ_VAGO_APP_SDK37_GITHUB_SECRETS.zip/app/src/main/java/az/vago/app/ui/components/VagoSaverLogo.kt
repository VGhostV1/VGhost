package az.vago.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.Canvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.i18n.L
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPinkBright
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.NeonPurpleBright
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextWhite

@Composable
fun VagoSaverLogoBadge(
    size: Dp = 72.dp,
    modifier: Modifier = Modifier
) {
    val gradientBrush = Brush.linearGradient(
        colors = listOf(NeonPurpleBright, NeonPinkBright),
        start = Offset(0f, 0f),
        end = Offset(100f, 100f)
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .shadow(
                elevation = 16.dp,
                shape = CircleShape,
                ambientColor = NeonPink.copy(alpha = 0.5f),
                spotColor = NeonPurple.copy(alpha = 0.8f)
            )
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF24143D), Color(0xFF110E24))
                ),
                shape = CircleShape
            )
            .border(
                width = 1.5.dp,
                brush = Brush.sweepGradient(
                    listOf(NeonPurple, NeonPink, NeonPurpleLightAlpha, NeonPurple)
                ),
                shape = CircleShape
            )
    ) {
        Canvas(modifier = Modifier.size(size * 0.55f)) {
            val w = this.size.width
            val h = this.size.height

            val leftArm = Path().apply {
                moveTo(w * 0.15f, h * 0.20f)
                lineTo(w * 0.50f, h * 0.82f)
            }
            val rightArm = Path().apply {
                moveTo(w * 0.50f, h * 0.82f)
                lineTo(w * 0.85f, h * 0.20f)
            }

            drawPath(
                path = leftArm,
                brush = gradientBrush,
                style = Stroke(
                    width = w * 0.24f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
            drawPath(
                path = rightArm,
                brush = gradientBrush,
                style = Stroke(
                    width = w * 0.24f,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}

private val NeonPurpleLightAlpha = Color(0x66C084FC)

@Composable
fun VagoSaverHeaderLogo(
    modifier: Modifier = Modifier,
    showSubtitle: Boolean = true
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
    ) {
        VagoSaverLogoBadge(size = 80.dp)
        
        Spacer(modifier = Modifier.height(14.dp))
        
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Vago",
                color = TextWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "Saver",
                color = NeonPink,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
        
        if (showSubtitle) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = L.t("logo_tagline", "en"),
                color = TextGray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.2.sp
            )
        }
    }
}
