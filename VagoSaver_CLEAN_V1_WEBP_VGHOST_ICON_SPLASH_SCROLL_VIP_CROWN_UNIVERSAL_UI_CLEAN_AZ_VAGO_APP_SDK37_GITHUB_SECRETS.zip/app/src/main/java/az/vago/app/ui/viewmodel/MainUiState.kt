package az.vago.app.ui.viewmodel

import az.vago.app.data.model.AppSettings
import az.vago.app.data.model.DownloadFormat
import az.vago.app.data.model.DownloadItem
import az.vago.app.data.model.DownloadProgress
import az.vago.app.data.model.DownloadStatus
import az.vago.app.data.model.TikTokMediaInfo

enum class AppScreen {
    HOME,
    FORMAT_SELECTION,
    DOWNLOADING,
    COMPLETED,
    SETTINGS,
}

data class MainUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val inputUrl: String = "",
    val mediaInfo: TikTokMediaInfo? = null,
    val isLoadingMediaInfo: Boolean = false,
    val selectedFormat: DownloadFormat = DownloadFormat.MP4,
    val downloadStatus: DownloadStatus = DownloadStatus.Idle,
    val downloadProgress: DownloadProgress = DownloadProgress(
        percentage = 0,
        speedText = "0.0 MB/s",
        downloadedMb = "0.0",
        totalMb = "—",
        fileName = ""
    ),
    val completedItem: DownloadItem? = null,
    val settings: AppSettings = AppSettings(),
    val userNotice: String? = null,
    val showAboutDialog: Boolean = false,
    val showContactDialog: Boolean = false,
    val showPrivacyDialog: Boolean = false,
)


