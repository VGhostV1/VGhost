package az.vago.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.ui.theme.NeonBlue
import az.vago.app.ui.theme.NeonCyan
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPinkBright
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.NeonPurpleBright
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoSurfaceVariant

@Composable
fun CircularProgressWithGlow(
    percentage: Int,
    modifier: Modifier = Modifier,
    size: Dp = 200.dp,
    strokeWidth: Dp = 16.dp,
    isAudio: Boolean = false
) {
    val animatedProgress by animateFloatAsState(
        targetValue = percentage / 100f,
        animationSpec = tween(durationMillis = 600),
        label = "progress_anim"
    )

    val sweepGradient = if (isAudio) {
        Brush.sweepGradient(
            colors = listOf(
                NeonPurple,
                NeonCyan,
                NeonPink,
                NeonPurple
            )
        )
    } else {
        Brush.sweepGradient(
            colors = listOf(
                NeonPurpleBright,
                NeonPinkBright,
                NeonPink,
                NeonPurple
            )
        )
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .shadow(
                elevation = 24.dp,
                shape = CircleShape,
                ambientColor = if (isAudio) NeonCyan.copy(alpha = 0.3f) else NeonPink.copy(alpha = 0.4f),
                spotColor = NeonPurple.copy(alpha = 0.6f)
            )
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val strokePx = strokeWidth.toPx()
            val canvasSize = this.size.width
            val radius = (canvasSize - strokePx) / 2f
            val topLeft = Offset(strokePx / 2f, strokePx / 2f)
            val arcSize = Size(radius * 2, radius * 2)

            // Background Track
            drawArc(
                color = Color(0xFF1E1A38),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Progress Arc
            drawArc(
                brush = sweepGradient,
                startAngle = -90f,
                sweepAngle = 360f * animatedProgress,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }

        // Centered Percentage Text
        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.padding(bottom = 4.dp)
        ) {
            Text(
                text = "$percentage",
                color = TextWhite,
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "%",
                color = TextWhite.copy(alpha = 0.8f),
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
            )
        }
    }
}

@Composable
fun LinearProgressWithGlow(
    progressFraction: Float,
    modifier: Modifier = Modifier,
    height: Dp = 8.dp
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 400),
        label = "linear_progress"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .background(color = Color(0xFF1F1B3C), shape = RoundedCornerShape(height / 2))
            .clip(RoundedCornerShape(height / 2))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(animatedProgress)
                .height(height)
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(NeonPurple, NeonPink)
                    ),
                    shape = RoundedCornerShape(height / 2)
                )
        )
    }
}

