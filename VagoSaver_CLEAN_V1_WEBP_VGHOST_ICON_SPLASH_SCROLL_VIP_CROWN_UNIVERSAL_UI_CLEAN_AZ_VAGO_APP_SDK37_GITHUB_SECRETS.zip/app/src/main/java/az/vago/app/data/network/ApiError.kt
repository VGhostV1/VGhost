package az.vago.app.data.network

import az.vago.app.data.i18n.L

sealed class ApiError(private val messageKey: String, fallbackAz: String) : Exception(fallbackAz) {
    fun localized(language: String): String = L.t(messageKey, language)
    val messageAz: String get() = localized("az")
    object InvalidUrl : ApiError("invalid_link", "Link düzgün deyil.")
    object NotFound : ApiError("file_not_found", "Link tapılmadı.")
    object NoInternet : ApiError("unexpected", "İnternet bağlantısı yoxdur.")
    object ServerError : ApiError("unexpected", "Serverə qoşulmaq mümkün olmadı.")
    object MediaFetchFailed : ApiError("media_failed", "Media məlumatı əldə edilə bilmədi.")
    object DownloadUrlInvalid : ApiError("download_error", "Endirmə linki işləmir.")
    object NoWatermarkUnavailable : ApiError("download_error", "Bu video üçün filigransız yükləmə linki əldə edilə bilmədi.")
    object StorageError : ApiError("download_error", "Yaddaş xətası baş verdi.")
    object DownloadCancelled : ApiError("download_cancelled", "Endirmə dayandırıldı.")
    object DownloadFailed : ApiError("download_error", "Endirmə zamanı xəta baş verdi.")
    object FileNotFound : ApiError("file_not_found", "Fayl tapılmadı.")
    data class Unknown(val customMsg: String = "Endirmə zamanı xəta baş verdi.") : ApiError("download_error", customMsg)
}

