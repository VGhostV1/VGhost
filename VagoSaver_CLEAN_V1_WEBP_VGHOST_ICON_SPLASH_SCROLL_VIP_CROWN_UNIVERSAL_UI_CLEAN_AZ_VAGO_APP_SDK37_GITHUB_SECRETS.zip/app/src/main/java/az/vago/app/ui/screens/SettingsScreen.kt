package az.vago.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import az.vago.app.data.i18n.L
import az.vago.app.ui.components.LanguageSelector
import az.vago.app.ui.components.VagoSaverLogoBadge
import az.vago.app.ui.theme.NeonPink
import az.vago.app.ui.theme.NeonPurple
import az.vago.app.ui.theme.NeonPurpleBright
import az.vago.app.ui.theme.TextGray
import az.vago.app.ui.theme.TextWhite
import az.vago.app.ui.theme.VagoBackground
import az.vago.app.ui.theme.VagoCardBorder
import az.vago.app.ui.theme.VagoSurface
import az.vago.app.ui.viewmodel.MainUiState

@Composable
fun SettingsScreen(
    uiState: MainUiState,
    onBackClicked: () -> Unit,
    onToggleAutoPaste: (Boolean) -> Unit,
    onToggleNotifications: (Boolean) -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onLanguageSelected: (String) -> Unit,
    onShowAboutDialog: (Boolean) -> Unit,
    onShowContactDialog: (Boolean) -> Unit,
    onShowPrivacyDialog: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val settings = uiState.settings
    val isRussian = settings.language.equals("ru", ignoreCase = true)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VagoBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            // TOP BAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = if (isRussian) 12.dp else 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClicked,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = L.t("close", settings.language),
                        tint = TextWhite,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = L.t("settings", settings.language),
                        color = TextWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Balance spacing
                LanguageSelector(language = settings.language, selectedLanguage = settings.languageSelection, onLanguageSelected = onLanguageSelected)
            }

            Spacer(modifier = Modifier.height(if (isRussian) 14.dp else 24.dp))

            // SCROLLABLE SETTINGS CONTENT
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // SETTINGS ITEMS
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(if (isRussian) 10.dp else 14.dp)
                ) {
                SettingToggleItem(
                    icon = Icons.Outlined.Link,
                    title = L.t("auto_paste", settings.language),
                    subtitle = L.t("auto_paste_sub", settings.language),
                    checked = settings.autoPasteLink,
                    onCheckedChange = onToggleAutoPaste,
                    testTag = "setting_auto_paste",
                    compact = isRussian
                )

                SettingToggleItem(
                    icon = Icons.Outlined.Notifications,
                    title = L.t("notifications", settings.language),
                    subtitle = L.t("notifications_sub", settings.language),
                    checked = settings.downloadNotifications,
                    onCheckedChange = onToggleNotifications,
                    testTag = "setting_notifications",
                    compact = isRussian
                )

                SettingToggleItem(
                    icon = Icons.Outlined.DarkMode,
                    title = L.t("dark_theme", settings.language),
                    subtitle = L.t("dark_theme_sub", settings.language),
                    checked = settings.darkThemeAlways,
                    onCheckedChange = onToggleDarkTheme,
                    testTag = "setting_dark_theme",
                    compact = isRussian
                )

                SettingActionItem(
                    icon = Icons.Outlined.Info,
                    title = L.t("about", settings.language),
                    onClick = { onShowAboutDialog(true) },
                    testTag = "setting_about",
                    compact = isRussian
                )

                SettingActionItem(
                    icon = Icons.Outlined.MailOutline,
                    title = L.t("contact", settings.language),
                    onClick = { onShowContactDialog(true) },
                    testTag = "setting_contact",
                    compact = isRussian
                )

                SettingActionItem(
                    icon = Icons.Outlined.Info,
                    title = L.t("privacy", settings.language),
                    onClick = { onShowPrivacyDialog(true) },
                    testTag = "setting_privacy",
                    compact = isRussian
                )

                }

                // FOOTER / APP BRANDING
                Spacer(modifier = Modifier.height(22.dp))
                VagoSaverLogoBadge(size = 72.dp)
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Vago",
                        color = TextWhite,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Saver",
                        color = NeonPink,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Versiya 1.0.0",
                    color = TextGray,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .border(1.dp, VagoCardBorder, RoundedCornerShape(20.dp))
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = "Sürətli • Təhlükəsiz • Pulsuz",
                        color = TextGray,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

        }

        // About Dialog
        if (uiState.showAboutDialog) {
            AlertDialog(
                onDismissRequest = { onShowAboutDialog(false) },
                containerColor = VagoSurface,
                title = {
                    Text(
                        text = L.t("about", settings.language),
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = L.t("about_desc", settings.language),
                        color = TextGray,
                        fontSize = 14.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { onShowAboutDialog(false) }) {
                        Text(L.t("ok", settings.language), color = NeonPink)
                    }
                }
            )
        }

        // Contact Dialog
        if (uiState.showContactDialog) {
            AlertDialog(
                onDismissRequest = { onShowContactDialog(false) },
                containerColor = VagoSurface,
                title = {
                    Text(
                        text = L.t("contact", settings.language),
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = L.t("contact_desc", settings.language),
                        color = TextGray,
                        fontSize = 14.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { onShowContactDialog(false) }) {
                        Text(L.t("close", settings.language), color = NeonPink)
                    }
                }
            )
        }

        // Privacy Dialog
        if (uiState.showPrivacyDialog) {
            AlertDialog(
                onDismissRequest = { onShowPrivacyDialog(false) },
                containerColor = VagoSurface,
                title = {
                    Text(
                        text = L.t("privacy", settings.language),
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = L.t("privacy_desc", settings.language),
                        color = TextGray,
                        fontSize = 14.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = { onShowPrivacyDialog(false) }) {
                        Text(L.t("ok", settings.language), color = NeonPink)
                    }
                }
            )
        }
    }
}

@Composable
private fun SettingToggleItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "setting_toggle",
    compact: Boolean = false
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(VagoSurface, RoundedCornerShape(18.dp))
            .border(1.dp, VagoCardBorder, RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = if (compact) 12.dp else 14.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF211B3D), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = NeonPurpleBright,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        color = TextGray,
                        fontSize = if (compact) 11.sp else 12.sp
                    )
                }
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = TextWhite,
                    checkedTrackColor = NeonPurple,
                    uncheckedThumbColor = TextGray,
                    uncheckedTrackColor = Color(0xFF24203E)
                )
            )
        }
    }
}

@Composable
private fun SettingActionItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "setting_action",
    compact: Boolean = false
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(VagoSurface, RoundedCornerShape(18.dp))
            .border(1.dp, VagoCardBorder, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (compact) 12.dp else 14.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF211B3D), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = NeonPurpleBright,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Text(
                    text = title,
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = TextGray,
                modifier = Modifier.size(20.dp)
            )
        }

    }
}

