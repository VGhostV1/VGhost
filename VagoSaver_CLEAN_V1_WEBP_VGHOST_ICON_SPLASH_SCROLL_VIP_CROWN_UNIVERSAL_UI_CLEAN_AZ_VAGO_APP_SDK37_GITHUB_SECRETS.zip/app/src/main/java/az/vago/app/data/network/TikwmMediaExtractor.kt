package az.vago.app.data.network

import az.vago.app.data.model.TikTokMediaInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Fallback metadata extractor for TikTok links.
 *
 * This is used only when the direct TikTok web extractor cannot obtain media
 * information. TikWM supports both full TikTok URLs and vm.tiktok.com short
 * share links and exposes clean video/audio URLs in its response.
 */
class TikwmMediaExtractor(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()
) {
    suspend fun extract(url: String): Result<TikTokMediaInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val encodedUrl = URLEncoder.encode(url, "UTF-8")
            val endpoint = "https://www.tikwm.com/api/?url=$encodedUrl&hd=1"

            val request = Request.Builder()
                .url(endpoint)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json")
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw ApiError.ServerError

                val body = response.body?.string().orEmpty()
                if (body.isBlank()) throw ApiError.MediaFetchFailed

                val root = JSONObject(body)
                if (root.optInt("code", -1) != 0) {
                    throw ApiError.MediaFetchFailed
                }

                val data = root.optJSONObject("data")
                    ?: throw ApiError.MediaFetchFailed

                val id = data.optString("id").ifBlank {
                    data.optString("video_id")
                }.ifBlank {
                    System.currentTimeMillis().toString().takeLast(12)
                }

                val title = data.optString("title").ifBlank {
                    "TikTok video $id"
                }

                val author = readAuthor(data)
                val cover = firstHttp(
                    data.optString("origin_cover"),
                    data.optString("cover"),
                    data.optString("ai_dynamic_cover")
                )

                val hdPlay = data.optString("hdplay")
                val play = data.optString("play")
                val watermarkPlay = data.optString("wmplay")

                val cleanVideoUrls = listOf(hdPlay, play)
                    .filter(::isHttpUrl)
                    .distinct()

                val watermarkedVideoUrls = listOf(watermarkPlay, play)
                    .filter(::isHttpUrl)
                    .distinct()

                // TikWM exposes music in both `music` and `music_info` on
                // different response versions. Prefer the explicit MP3 URL.
                val musicInfo = data.optJSONObject("music_info")
                val musicUrl = firstHttp(
                    data.optString("music"),
                    musicInfo?.optString("play").orEmpty(),
                    musicInfo?.optString("play_url").orEmpty()
                )

                if (cleanVideoUrls.isEmpty() && musicUrl.isBlank() && watermarkedVideoUrls.isEmpty()) {
                    throw ApiError.MediaFetchFailed
                }

                val selectedMp4 = cleanVideoUrls.firstOrNull()
                    ?: watermarkedVideoUrls.firstOrNull()
                    .orEmpty()

                val duration = data.optLong("duration", 0L)
                val size = data.optLong("hd_size", 0L).takeIf { it > 0 }
                    ?: data.optLong("size", 0L).takeIf { it > 0 }

                TikTokMediaInfo(
                    id = id,
                    title = title,
                    author = author,
                    thumbnailUrl = cover,
                    durationSeconds = duration,
                    mediaType = "video",
                    mp4DownloadUrl = selectedMp4,
                    mp3DownloadUrl = musicUrl,
                    mp4DownloadUrls = cleanVideoUrls.ifEmpty { watermarkedVideoUrls },
                    noWatermarkDownloadUrls = cleanVideoUrls,
                    downloadHeaders = emptyMap(),
                    fileSizeText = size?.let(::formatSize).orEmpty(),
                    quality = if (hdPlay.isNotBlank()) "HD" else "SD",
                    originalUrl = url
                )
            }
        }.fold(
            onSuccess = { Result.success(it) },
            onFailure = { error ->
                when (error) {
                    is ApiError -> Result.failure(error)
                    else -> Result.failure(
                        ApiError.Unknown(
                            error.localizedMessage ?: "TikTok media məlumatı əldə edilə bilmədi."
                        )
                    )
                }
            }
        )
    }

    private fun readAuthor(data: JSONObject): String {
        val author = data.opt("author")
        return when (author) {
            is JSONObject -> firstNonBlank(
                author.optString("unique_id"),
                author.optString("uniqueId"),
                author.optString("nickname")
            )
            is String -> author
            else -> ""
        }
    }

    private fun firstNonBlank(vararg values: String): String =
        values.firstOrNull { it.isNotBlank() }.orEmpty()

    private fun firstHttp(vararg values: String): String =
        values.firstOrNull(::isHttpUrl).orEmpty()

    private fun isHttpUrl(value: String): Boolean =
        value.startsWith("https://", ignoreCase = true) ||
            value.startsWith("http://", ignoreCase = true)

    private fun formatSize(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return String.format(java.util.Locale.US, "%.1f MB", mb)
    }

    private companion object {
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    }
}

