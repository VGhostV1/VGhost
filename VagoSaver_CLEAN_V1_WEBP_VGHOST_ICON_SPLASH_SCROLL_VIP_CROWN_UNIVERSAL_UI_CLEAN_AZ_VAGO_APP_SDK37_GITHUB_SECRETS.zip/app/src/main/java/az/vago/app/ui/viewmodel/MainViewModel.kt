package az.vago.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import az.vago.app.data.model.AppSettings
import az.vago.app.data.i18n.L
import az.vago.app.data.model.DownloadFormat
import az.vago.app.data.model.DownloadItem
import az.vago.app.data.model.DownloadProgress
import az.vago.app.data.model.DownloadStatus
import az.vago.app.data.network.ApiError
import az.vago.app.data.notification.DownloadNotificationManager
import az.vago.app.data.repository.DownloadRepository
import az.vago.app.data.repository.DownloadRepositoryImpl
import az.vago.app.data.repository.SettingsRepository
import az.vago.app.data.repository.SettingsRepositoryImpl
import az.vago.app.data.util.TikTokUrlValidator
import az.vago.app.data.util.UrlValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs

class MainViewModel @JvmOverloads constructor(
    application: Application,
    private val downloadRepository: DownloadRepository = DownloadRepositoryImpl(context = application.applicationContext),
    private val settingsRepository: SettingsRepository = SettingsRepositoryImpl(context = application.applicationContext),
    private val notificationManager: DownloadNotificationManager = DownloadNotificationManager(application.applicationContext)
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var downloadJob: Job? = null
    private var currentNotifId: Int = 1001
    private var lastAutoPastedClipboard: String? = null

    init {
        viewModelScope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                _uiState.update { it.copy(settings = settings) }
            }
        }
    }

    fun onUrlChange(newUrl: String) {
        _uiState.update { it.copy(inputUrl = newUrl) }
    }

    fun onClearInput() {
        // Clear only the current input. Keep the last auto-pasted clipboard value
        // remembered so the same clipboard content is not immediately pasted back.
        _uiState.update { it.copy(inputUrl = "") }
    }

    fun onExternalLink(value: String) {
        val candidate = value.trim()
        if (candidate.isBlank()) return
        if (TikTokUrlValidator.validate(candidate) != UrlValidationResult.Valid) return
        _uiState.update {
            if (it.inputUrl.isBlank()) it.copy(inputUrl = candidate) else it
        }
    }

    fun onPasteFromClipboard(clipboardContent: String) {
        val trimmed = clipboardContent.trim()
        if (trimmed.isNotBlank()) {
            _uiState.update { it.copy(inputUrl = trimmed) }
            lastAutoPastedClipboard = trimmed
        }
    }

    fun onCheckAutoPaste(clipboardContent: String) {
        if (!_uiState.value.settings.autoPasteLink || _uiState.value.inputUrl.isNotBlank()) return
        val trimmed = clipboardContent.trim()
        if (trimmed.isBlank() || trimmed == lastAutoPastedClipboard) return
        if (TikTokUrlValidator.validate(trimmed) == UrlValidationResult.Valid) {
            lastAutoPastedClipboard = trimmed
            _uiState.update { it.copy(inputUrl = trimmed) }
        }
    }

    fun onDownloadButtonClick() {
        if (_uiState.value.isLoadingMediaInfo || downloadJob?.isActive == true) return

        val currentUrl = _uiState.value.inputUrl.trim()
        if (currentUrl.isEmpty()) {
            _uiState.update { it.copy(userNotice = L.t("enter_link", _uiState.value.settings.language)) }
            return
        }

        val validation = TikTokUrlValidator.validate(currentUrl)
        if (validation != UrlValidationResult.Valid) {
            _uiState.update { it.copy(userNotice = L.t("invalid_link", _uiState.value.settings.language)) }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoadingMediaInfo = true,
                    downloadStatus = DownloadStatus.Loading
                )
            }

            val result = downloadRepository.fetchMediaInfo(currentUrl)
            result.onSuccess { mediaInfo ->
                _uiState.update {
                    it.copy(
                        isLoadingMediaInfo = false,
                        mediaInfo = mediaInfo,
                        downloadStatus = DownloadStatus.Idle,
                        currentScreen = AppScreen.FORMAT_SELECTION
                    )
                }
            }.onFailure { error ->
                val errorMsg = (error as? ApiError)?.localized(_uiState.value.settings.language)
                    ?: error.localizedMessage
                    ?: L.t("unexpected", _uiState.value.settings.language)
                _uiState.update {
                    it.copy(
                        isLoadingMediaInfo = false,
                        downloadStatus = DownloadStatus.Error(errorMsg),
                        userNotice = errorMsg
                    )
                }
            }
        }
    }

    fun onFormatSelected(format: DownloadFormat) {
        val media = _uiState.value.mediaInfo
        val baseId = media?.id ?: System.currentTimeMillis().toString().takeLast(12)
        val titleClean = media?.title
            ?.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
            ?.take(25)
            ?.ifBlank { "vagosaver_$baseId" }
            ?: "vagosaver_$baseId"

        val fileName = when (format) {
            DownloadFormat.MP3 -> "$titleClean.mp3"
            DownloadFormat.MP4, DownloadFormat.NO_WATERMARK_MP4 -> "$titleClean.mp4"
        }
        val totalMb = media?.fileSizeText
            ?.takeIf { it.isNotBlank() }
            ?: "—"

        val initialProgress = DownloadProgress(
            percentage = 0,
            speedText = "0.0 MB/s",
            downloadedMb = "0.0",
            totalMb = totalMb,
            fileName = fileName
        )

        currentNotifId = abs((media?.id?.hashCode() ?: System.currentTimeMillis().toInt())) % 9000 + 1000

        _uiState.update {
            it.copy(
                selectedFormat = format,
                currentScreen = AppScreen.DOWNLOADING,
                downloadStatus = DownloadStatus.InProgress(initialProgress),
                downloadProgress = initialProgress
            )
        }

        if (_uiState.value.settings.downloadNotifications) {
            notificationManager.showDownloadStarted(currentNotifId, fileName)
        }

        downloadJob?.cancel()
        downloadJob = viewModelScope.launch(Dispatchers.IO) {
            if (media == null) {
                val fetchRes = downloadRepository.fetchMediaInfo(_uiState.value.inputUrl)
                if (fetchRes.isFailure) {
                    val error = fetchRes.exceptionOrNull()
                    val errorMsg = (error as? ApiError)?.localized(_uiState.value.settings.language) ?: L.t("media_failed", _uiState.value.settings.language)
                    handleDownloadError(errorMsg, fileName)
                    return@launch
                }
            }

            val targetMedia = media ?: downloadRepository.fetchMediaInfo(_uiState.value.inputUrl).getOrNull()
            if (targetMedia == null) {
                handleDownloadError(L.t("media_failed", _uiState.value.settings.language), fileName)
                return@launch
            }

            val result = downloadRepository.executeDownload(targetMedia, format) { progress ->
                _uiState.update {
                    it.copy(
                        downloadProgress = progress,
                        downloadStatus = DownloadStatus.InProgress(progress)
                    )
                }

                if (_uiState.value.settings.downloadNotifications) {
                    notificationManager.showDownloadProgress(
                        currentNotifId,
                        progress.fileName,
                        progress.percentage,
                        progress.speedText,
                        progress.downloadedMb,
                        progress.totalMb
                    )
                }
            }

            result.onSuccess { item ->
                _uiState.update {
                    it.copy(
                        completedItem = item,
                        downloadStatus = DownloadStatus.Success(item),
                        currentScreen = AppScreen.COMPLETED,
                        // Clear the consumed URL after a successful download.
                        // The HomeScreen clipboard guard prevents the same clipboard value
                        // from being pasted back immediately.
                        inputUrl = ""
                    )
                }

                if (_uiState.value.settings.downloadNotifications) {
                    val fileUri = item.localUri?.let { Uri.parse(it) }
                    notificationManager.showDownloadCompleted(
                        currentNotifId,
                        item.fileName,
                        fileUri,
                        item.format.mimeType
                    )
                }
            }.onFailure { error ->
                if (error is ApiError.DownloadCancelled) {
                    notificationManager.cancelNotification(currentNotifId)
                    _uiState.update {
                        it.copy(
                            currentScreen = AppScreen.HOME,
                            downloadStatus = DownloadStatus.Cancelled,
                            userNotice = L.t("download_cancelled", _uiState.value.settings.language)
                        )
                    }
                } else {
                    val errorMsg = (error as? ApiError)?.localized(_uiState.value.settings.language)
                        ?: error.localizedMessage
                        ?: L.t("download_error", _uiState.value.settings.language)
                    handleDownloadError(errorMsg, fileName)
                }
            }
        }
    }

    private fun handleDownloadError(errorMessage: String, fileName: String) {
        if (_uiState.value.settings.downloadNotifications) {
            notificationManager.showDownloadError(currentNotifId, fileName, errorMessage)
        }
        _uiState.update {
            it.copy(
                downloadStatus = DownloadStatus.Error(errorMessage),
                userNotice = errorMessage
            )
        }
    }

    fun onCancelDownload() {
        downloadJob?.cancel()
        downloadRepository.cancelActiveDownload()
        notificationManager.cancelNotification(currentNotifId)
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.HOME,
                downloadStatus = DownloadStatus.Cancelled,
                userNotice = L.t("download_cancelled", _uiState.value.settings.language)
            )
        }
    }

    fun onCloseCompletedScreen() {
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.HOME,
                downloadStatus = DownloadStatus.Idle
            )
        }
    }

    fun onNavigateToSettings() {
        _uiState.update { it.copy(currentScreen = AppScreen.SETTINGS) }
    }

    fun onNavigateBack() {
        if (_uiState.value.currentScreen == AppScreen.DOWNLOADING) {
            onCancelDownload()
            return
        }

        _uiState.update {
            when (it.currentScreen) {
                AppScreen.FORMAT_SELECTION -> it.copy(currentScreen = AppScreen.HOME)
                AppScreen.DOWNLOADING -> it.copy(currentScreen = AppScreen.HOME)
                AppScreen.COMPLETED -> it.copy(currentScreen = AppScreen.HOME)
                AppScreen.SETTINGS -> it.copy(currentScreen = AppScreen.HOME)
                AppScreen.HOME -> it
            }
        }
    }

    fun onToggleAutoPaste(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateAutoPaste(enabled)
        }
    }

    fun onToggleNotifications(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateDownloadNotifications(enabled)
        }
    }

    fun onToggleDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateDarkTheme(enabled)
        }
    }

    fun onLanguageSelected(language: String) {
        viewModelScope.launch { settingsRepository.updateLanguage(language) }
    }

    /** Re-resolves the phone locale whenever the activity resumes. */
    fun refreshSystemLanguage() {
        if (_uiState.value.settings.languageSelection == az.vago.app.data.i18n.LanguageManager.SYSTEM) {
            viewModelScope.launch { settingsRepository.updateLanguage(az.vago.app.data.i18n.LanguageManager.SYSTEM) }
        }
    }

    fun onShowAboutDialog(show: Boolean) {
        _uiState.update { it.copy(showAboutDialog = show) }
    }

    fun onShowContactDialog(show: Boolean) {
        _uiState.update { it.copy(showContactDialog = show) }
    }

    fun onShowPrivacyDialog(show: Boolean) {
        _uiState.update { it.copy(showPrivacyDialog = show) }
    }

    fun onDismissNotice() {
        _uiState.update { it.copy(userNotice = null) }
    }


}


