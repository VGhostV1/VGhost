# VagoSaver

Backend-free Android downloader project.

Flow:

TikTok URL
→ direct TikTok extraction inside APK
→ MP4 / MP3 media URL
→ Android MediaStore
→ open / share

No VagoSaver-owned backend, Firebase or MySQL is required by the Android download path.

## GitHub build

Open **Actions → VagoSaver Android CI → Run workflow**.

The workflow:
1. sets up JDK 17 and Android SDK 36;
2. runs unit tests;
3. builds the debug APK;
4. uploads the APK as `VagoSaver-debug-apk`.

## Important

The app requires internet access to fetch TikTok content. “Backend-free” does not mean internet-free.

TikTok may change or restrict its public web surfaces. The app therefore does not fabricate media URLs or fake successful downloads when extraction fails.
