package com.vghost.app.ui.screens

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.state.SessionState
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.network.VGhostApi
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.ui.theme.GhostTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray

private data class DownloadJobUi(
    val id: Long,
    val type: String,
    val status: String,
    val title: String,
    val filename: String,
    val progress: Int,
    val downloadedBytes: Long,
    val totalBytes: Long?,
    val error: String
)

private fun parseJob(o: org.json.JSONObject): DownloadJobUi = DownloadJobUi(
    id = o.optLong("id"), type = o.optString("type"), status = o.optString("status"),
    title = o.optString("title"), filename = o.optString("filename"), progress = o.optInt("progress"),
    downloadedBytes = o.optLong("downloadedBytes"), totalBytes = if (o.isNull("totalBytes")) null else o.optLong("totalBytes"),
    error = o.optString("error")
)

private fun humanBytes(v: Long): String {
    if (v < 1024) return "$v B"
    if (v < 1024 * 1024) return "%.1f KB".format(v / 1024.0)
    if (v < 1024 * 1024 * 1024) return "%.1f MB".format(v / (1024.0 * 1024.0))
    return "%.2f GB".format(v / (1024.0 * 1024.0 * 1024.0))
}

@Composable
fun DownloaderScreen(
    onTabSelected: (NavTab) -> Unit,
    onAuthRequired: () -> Unit,
    isVisible: Boolean = true
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repository = VGhostRepository.instance
    val sessionState by repository.sessionState.collectAsState()
    val loggedIn = sessionState is SessionState.LoggedInNormalUser
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var url by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("video") }
    var jobs by remember { mutableStateOf<List<DownloadJobUi>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        if (!loggedIn) return
        runCatching {
            val a = VGhostApi.downloaderJobs().optJSONArray("jobs") ?: JSONArray()
            jobs = (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let(::parseJob) }
        }.onFailure { error = it.message }
    }

    LaunchedEffect(loggedIn, isVisible) {
        if (!isVisible) return@LaunchedEffect
        refresh()
        while (isVisible) {
            delay(2000L)
            refresh()
        }
    }

    fun startDownload() {
        val clean = url.trim()
        if (clean.isBlank()) { error = "Link daxil et"; return }
        if (!loggedIn) { onAuthRequired(); return }
        busy = true; error = null
        scope.launch {
            try {
                VGhostApi.downloaderCreate(clean, type)
                url = ""
                refresh()
            } catch (e: Throwable) {
                error = e.message ?: "Yükləmə başlatmaq olmadı"
            } finally { busy = false }
        }
    }

    fun enqueue(context: Context, job: DownloadJobUi) {
        if (job.id <= 0L) return
        try {
            val request = DownloadManager.Request(Uri.parse(VGhostApi.downloaderFileUrl(job.id)))
                .setTitle(job.title.ifBlank { job.filename.ifBlank { "VGhost Download" } })
                .setDescription(if (job.type == "mp3") "VGhost MP3" else "VGhost Video")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, job.filename.ifBlank { "vghost_${job.id}.${if (job.type == "mp3") "mp3" else "mp4"}" })
            VGhostApi.token()?.let { request.addRequestHeader("Authorization", "Bearer $it") }
            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
        } catch (e: Throwable) {
            error = e.message ?: "DownloadManager xətası"
        }
    }

    Column(Modifier.fillMaxSize().premiumBackdrop()) {
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("VGhost", color = GhostTextWhite, fontSize = 34.sp, fontWeight = FontWeight.Black)
                        Text("DOWNLOADER", color = Color(0xFFFF277D), fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("Video və MP3 endir, sevdiyin məzmunu saxla!", color = GhostTextSecondary, fontSize = 14.sp)
                    }
                    Icon(Icons.Outlined.Download, null, tint = Color(0xFFFF277D), modifier = Modifier.size(54.dp).shadow(18.dp))
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0xFF09070E)).border(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFFFF1F58), Color(0xFF8A3CFF))), RoundedCornerShape(22.dp)).padding(horizontal = 15.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Link, null, tint = Color(0xFFFF2D8B), modifier = Modifier.size(28.dp))
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, modifier = Modifier.weight(1f),
                        singleLine = true, placeholder = { Text("Video linkini daxil et...", color = GhostTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Transparent, unfocusedBorderColor = Color.Transparent, cursorColor = Color(0xFFFF2D8B), focusedTextColor = GhostTextWhite, unfocusedTextColor = GhostTextWhite)
                    )
                    IconButton(onClick = { url = clipboard.getText()?.text.orEmpty() }) { Icon(Icons.Outlined.ContentCopy, "Paste", tint = Color(0xFFFF2D8B)) }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DownloadChoice("VIDEO ENDİR", Icons.Outlined.VideoFile, type == "video", Color(0xFFFF175A)) { type = "video" }
                    DownloadChoice("MP3 ENDİR", Icons.Outlined.MusicNote, type == "mp3", Color(0xFF7A24FF)) { type = "mp3" }
                }
            }
            item {
                Button(onClick = ::startDownload, enabled = !busy, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary), shape = RoundedCornerShape(18.dp)) {
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Outlined.Download, null)
                    Spacer(Modifier.width(8.dp)); Text(if (busy) "Hazırlanır..." else "ENDİRMƏYƏ BAŞLA", fontWeight = FontWeight.Bold)
                }
                error?.let { Text(it, color = Color(0xFFFF6B7D), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
            item {
                Text("Son Endirmələr", color = GhostTextWhite, fontSize = 23.sp, fontWeight = FontWeight.Black)
            }
            if (!loggedIn) {
                item {
                    Surface(color = Color(0xFF0A0810), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Endirmələri saxlamaq üçün hesabına daxil ol.", color = GhostTextWhite, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            TextButton(onClick = onAuthRequired) { Text("Giriş et", color = Color(0xFFFF2D8B)) }
                        }
                    }
                }
            } else {
                items(jobs, key = { it.id }) { job ->
                    DownloadJobCard(job) { if (job.status == "completed") enqueue(context, job) }
                }
            }
        }
        VGhostBottomNavBar(currentTab = NavTab.DOWNLOADER, onTabSelected = onTabSelected)
    }
}

@Composable
private fun DownloadChoice(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, color: Color, onClick: () -> Unit) {
    Row(Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(18.dp)).background(if (selected) color else Color(0xFF0B0911)).border(1.dp, color.copy(alpha = if (selected) .9f else .45f), RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(7.dp))
        Text(label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DownloadJobCard(job: DownloadJobUi, onDownload: () -> Unit) {
    val color = if (job.type == "mp3") Color(0xFF7A24FF) else Color(0xFFFF2D73)
    Surface(color = Color(0xFF070910), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, color.copy(alpha = .25f), RoundedCornerShape(20.dp))) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (job.type == "mp3") Icons.Outlined.MusicNote else Icons.Outlined.VideoFile, null, tint = color, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(job.title.ifBlank { job.filename.ifBlank { "Endirmə #${job.id}" } }, color = GhostTextWhite, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(when(job.status) { "completed" -> "Tamamlandı"; "processing" -> "Yüklənir... ${job.progress}%"; "failed" -> "Xəta: ${job.error}"; else -> "Növbədə" }, color = if (job.status == "failed") Color(0xFFFF687A) else GhostTextSecondary, fontSize = 12.sp)
                }
                if (job.status == "completed") IconButton(onClick = onDownload) { Icon(Icons.Outlined.Download, "Download", tint = color) }
            }
            if (job.status == "processing") {
                Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { job.progress / 100f }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)), color = color, trackColor = color.copy(alpha = .12f))
                if (job.totalBytes != null) Text("${humanBytes(job.downloadedBytes)} / ${humanBytes(job.totalBytes)}", color = GhostTextSecondary, fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 3.dp))
            }
        }
    }
}
