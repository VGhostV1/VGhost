package com.vghost.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.vghost.app.MainActivity
import com.vghost.app.R
import com.vghost.app.i18n.VGhostLanguage
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

class FilmUploadForegroundService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val channelId = "vghost_film_upload"
    private val notificationId = 19071
    private var uploadStartedAt = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val filmId = intent?.getLongExtra(EXTRA_FILM_ID, 0L) ?: 0L
        val security = intent?.getStringExtra(EXTRA_SECURITY).orEmpty()
        val posterPath = intent?.getStringExtra(EXTRA_POSTER_PATH).orEmpty()
        val videoPath = intent?.getStringExtra(EXTRA_VIDEO_PATH).orEmpty()
        val existingPosterUrl = intent?.getStringExtra(EXTRA_EXISTING_POSTER).orEmpty()
        val existingVideoUrl = intent?.getStringExtra(EXTRA_EXISTING_VIDEO).orEmpty()
        val title = intent?.getStringExtra(EXTRA_TITLE).orEmpty()
        val desc = intent?.getStringExtra(EXTRA_DESC).orEmpty()
        val category = intent?.getStringExtra(EXTRA_CATEGORY).orEmpty()
        val year = intent?.getIntExtra(EXTRA_YEAR, 0) ?: 0
        val duration = intent?.getIntExtra(EXTRA_DURATION, 0) ?: 0
        val vip = intent?.getBooleanExtra(EXTRA_VIP, false) ?: false
        val featured = intent?.getBooleanExtra(EXTRA_FEATURED, false) ?: false

        if (filmId <= 0L || security.isBlank() || (posterPath.isBlank() && videoPath.isBlank())) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        uploadStartedAt = SystemClock.elapsedRealtime()
        startForeground(notificationId, buildNotification(0, VGhostLanguage.trKey("upload_background_title"), "0% • ${VGhostLanguage.trKey("upload_preparing")}" , false))
        scope.launch {
            try {
                var posterUrl = existingPosterUrl
                var videoUrl = existingVideoUrl
                if (posterPath.isNotBlank()) {
                    uploadStartedAt = SystemClock.elapsedRealtime()
                    posterUrl = upload(filmId, "poster", File(posterPath), security)
                }
                if (videoPath.isNotBlank()) {
                    uploadStartedAt = SystemClock.elapsedRealtime()
                    videoUrl = upload(filmId, "video", File(videoPath), security)
                }
                VGhostApi.adminFilmSave(
                    filmId, title, desc, posterUrl, videoUrl, category,
                    year.takeIf { it > 0 }, duration.takeIf { it > 0 },
                    vip, featured, true, 0, security
                )
                updateNotification(100, VGhostLanguage.trKey("upload_background_done"), VGhostLanguage.trKey("upload_background_done"), true)
                cleanupFiles(posterPath, videoPath)
            } catch (_: Throwable) {
                updateNotification(0, VGhostLanguage.trKey("upload_background_failed"), VGhostLanguage.trKey("upload_background_failed"), true)
            } finally {
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf(startId)
            }
        }
        return START_REDELIVER_INTENT
    }

    private suspend fun upload(filmId: Long, kind: String, file: File, security: String): String {
        if (!file.isFile) throw IllegalStateException("UPLOAD_FILE_MISSING")
        val result = VGhostApi.adminFilmUpload(filmId, kind, file, file.name, mimeFor(file, kind), security) { sent, total ->
            val percent = if (total > 0L) ((sent.toDouble() / total.toDouble()) * 100.0).toInt() else 0
            updateNotification(percent, VGhostLanguage.trKey("upload_background_title"), progressText(sent, total, percent), false)
        }
        return result.optString("url").ifBlank { throw IllegalStateException("MEDIA_UPLOAD_NO_URL") }
    }

    private fun mimeFor(file: File, kind: String): String = when (file.extension.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"
        "bmp" -> "image/bmp"; "heic" -> "image/heic"; "heif" -> "image/heif"; "avif" -> "image/avif"
        "webm" -> "video/webm"; "m4v" -> "video/x-m4v"; "mov" -> "video/quicktime"; "3gp" -> "video/3gpp"
        "3g2" -> "video/3gpp2"; "mpeg", "mpg" -> "video/mpeg"; "mkv" -> "video/x-matroska"; "ogv" -> "video/ogg"
        "ts", "m2ts" -> "video/mp2t"; "flv" -> "video/x-flv"; "mp4" -> "video/mp4"
        else -> if (kind == "poster") "image/jpeg" else "video/mp4"
    }

    private fun buildNotification(percent: Int, title: String, content: String, done: Boolean): Notification {
        val intent = PendingIntent.getActivity(this, 19072, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_stat_transparent)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setProgress(100, percent.coerceIn(0, 100), false)
            .setOngoing(!done)
            .setOnlyAlertOnce(true)
            .setContentIntent(intent)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun updateNotification(percent: Int, title: String, content: String, done: Boolean) {
        getSystemService(NotificationManager::class.java).notify(notificationId, buildNotification(percent, title, content, done))
    }

    private fun progressText(sent: Long, total: Long, percent: Int): String {
        if (total <= 0L) return "$percent% • ${VGhostLanguage.trKey("upload_preparing")}"
        val sentMb = sent / 1024.0 / 1024.0
        val totalMb = total / 1024.0 / 1024.0
        val elapsed = (SystemClock.elapsedRealtime() - uploadStartedAt).coerceAtLeast(0L)
        val speed = if (elapsed > 0L) sent.toDouble() / elapsed.toDouble() else 0.0
        val remainingBytes = (total - sent).coerceAtLeast(0L)
        val eta = if (speed > 0.0 && remainingBytes > 0L) (remainingBytes / speed).toLong() else 0L
        val elapsedText = formatDuration(elapsed / 1000L)
        val etaText = if (eta > 0L) formatDuration(eta) else "--:--"
        return String.format(java.util.Locale.US, "%.1f / %.1f MB • %s ${VGhostLanguage.trKey("upload_elapsed")} • %s ${VGhostLanguage.trKey("upload_remaining")}", sentMb, totalMb, elapsedText, etaText)
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600L
        val m = (seconds % 3600L) / 60L
        val s = seconds % 60L
        return if (h > 0L) String.format(java.util.Locale.US, "%02d:%02d:%02d", h, m, s)
        else String.format(java.util.Locale.US, "%02d:%02d", m, s)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "VGhost Upload", NotificationManager.IMPORTANCE_LOW).apply { description = "Film upload progress" }
            )
        }
    }

    private fun cleanupFiles(vararg paths: String) { paths.filter { it.isNotBlank() }.forEach { runCatching { File(it).delete() } } }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_FILM_ID = "film_id"; const val EXTRA_SECURITY = "security"
        const val EXTRA_POSTER_PATH = "poster_path"; const val EXTRA_VIDEO_PATH = "video_path"
        const val EXTRA_EXISTING_POSTER = "existing_poster"; const val EXTRA_EXISTING_VIDEO = "existing_video"
        const val EXTRA_TITLE = "title"; const val EXTRA_DESC = "desc"; const val EXTRA_CATEGORY = "category"
        const val EXTRA_YEAR = "year"; const val EXTRA_DURATION = "duration"; const val EXTRA_VIP = "vip"; const val EXTRA_FEATURED = "featured"
        fun start(context: android.content.Context, intent: Intent) = ContextCompat.startForegroundService(context, intent)
    }
}
