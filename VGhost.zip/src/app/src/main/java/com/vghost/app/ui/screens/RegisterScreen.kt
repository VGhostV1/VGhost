package com.vghost.app.ui.screens
import com.vghost.app.i18n.trKey

import kotlinx.coroutines.launch
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr

@Composable
fun RegisterScreen(
    onRegisterSuccess: (String) -> Unit,
    onNavigateToLogin: () -> Unit = {},
    onOpenPrivacyPolicy: () -> Unit = {},
    onOpenTerms: () -> Unit = {},
    onOpenGuestFilms: () -> Unit = {},
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var nickname by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    var isSubmitting by remember { mutableStateOf(false) }
    val guestFilmPulse = rememberInfiniteTransition(label = "guest_film_pulse")
    val guestFilmScale by guestFilmPulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "guest_film_scale"
    )
    var legalAccepted by remember { mutableStateOf(false) }
    var gender by remember { mutableStateOf("male") }
    // Keep both the system back gesture/button and the visible arrow on the
    // same reliable navigation callback.
    BackHandler { onNavigateToLogin() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .imePadding()
    ) {
        // Top Back Button
        IconButton(
            onClick = { onNavigateToLogin() },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 12.dp, top = 8.dp)
                .zIndex(20f)
                .testTag("register_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = trKey("back_login"),
                tint = GhostTextWhite
            )
        }

        // Guest film icon: transparent icon-only button, positioned at the top-right.
        Image(
            painter = painterResource(id = com.vghost.app.R.drawable.guest_film_icon_webp),
            contentDescription = trKey("watch_as_guest"),
            contentScale = androidx.compose.ui.layout.ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 10.dp, top = 6.dp)
                .size(120.dp)
                .graphicsLayer {
                    scaleX = guestFilmScale
                    scaleY = guestFilmScale
                }
                .zIndex(11f)
                .clickable(onClick = onOpenGuestFilms)
                .testTag("register_guest_films_button")
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            val compact = maxHeight < 700.dp
            val veryCompact = maxHeight < 620.dp
            val fieldHeight = if (veryCompact) 52.dp else if (compact) 54.dp else 56.dp
            val fieldGap = if (veryCompact) 7.dp else if (compact) 9.dp else 11.dp
            val sectionGap = if (veryCompact) 8.dp else if (compact) 12.dp else 18.dp
            val titleGap = if (veryCompact) 2.dp else 5.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = if (veryCompact) 4.dp else 8.dp, bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(modifier = Modifier.height(if (veryCompact) 2.dp else 6.dp))

            Text(
                modifier = Modifier.offset(x = (-19).dp),
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(color = GhostRedPrimary, fontWeight = FontWeight.Black)) {
                        append("V ")
                    }
                    withStyle(style = SpanStyle(color = GhostTextWhite, fontWeight = FontWeight.Bold)) {
                        append("GHOST")
                    }
                },
                fontSize = if (veryCompact) 21.sp else 23.sp,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(titleGap))

            Text(
                modifier = Modifier.offset(x = (-19).dp),
                text = trKey("create_account"),
                color = GhostTextWhite,
                fontSize = if (veryCompact) 16.sp else 18.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(1.dp))

            Text(
                modifier = Modifier.offset(x = (-19).dp),
                text = trKey("quick_simple"),
                color = GhostTextSecondary,
                fontSize = if (veryCompact) 12.sp else 13.sp
            )

            Spacer(modifier = Modifier.height(sectionGap))

            // 1. Nickname
            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it; errorMessage = null },
                placeholder = { Text(trKey("nickname_3"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_nickname_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            // 2. Recovery / login email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it; errorMessage = null },
                placeholder = { Text(trKey("email"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_email_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            // 3. Gender / avatar choice
            Text(
                text = trKey("s_n_ki_n_yoxsa_qad_n"),
                color = GhostTextSecondary,
                fontSize = if (veryCompact) 11.sp else 12.sp,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("male" to trKey("ki_i"), "female" to trKey("qad_n")).forEach { (id, label) ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (gender == id) GhostRedPrimary.copy(alpha = .14f) else GhostSurface)
                            .border(1.dp, if (gender == id) GhostRedPrimary else GhostBorder, RoundedCornerShape(12.dp))
                            .clickable { gender = id; errorMessage = null }
                            .padding(vertical = if (veryCompact) 3.dp else 5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GhostAvatar(size = if (veryCompact) 38.dp else 46.dp, showBorder = true, avatarId = "${id}_01")
                        Text(label, color = GhostTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(fieldGap))

            // 4. Password
            OutlinedTextField(
                value = password,
                onValueChange = { password = it; errorMessage = null },
                placeholder = { Text(trKey("password_2"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Lock,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = { isPasswordVisible = !isPasswordVisible },
                        modifier = Modifier.testTag("toggle_register_password_visibility")
                    ) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = null,
                            tint = GhostTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next
                ),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_password_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = errorMessage ?: "",
                    color = GhostRedPrimary,
                    fontSize = if (veryCompact) 11.sp else 12.sp,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 7.dp else 12.dp))

            Spacer(modifier = Modifier.height(if (veryCompact) 8.dp else 14.dp))

            // Local legal acceptance is required before account creation.
            Row(
                modifier = Modifier.fillMaxWidth().clickable { legalAccepted = !legalAccepted },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = legalAccepted,
                    onCheckedChange = { legalAccepted = it }
                )
                Text(
                    text = trKey("i_have_read_accept_privacy_policy_terms_conditions"),
                    color = GhostTextSecondary,
                    fontSize = if (veryCompact) 10.sp else 11.sp,
                    lineHeight = 14.sp,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = trKey("privacy_policy"),
                    color = GhostRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onOpenPrivacyPolicy)
                )
                Text(trKey("bullet"), color = GhostTextMuted, fontSize = 11.sp)
                Text(
                    text = trKey("terms_conditions"),
                    color = GhostRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onOpenTerms)
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 7.dp else 10.dp))

            // Create Account Button
            Button(
                onClick = {
                    if (isSubmitting) return@Button
                    focusManager.clearFocus()
                    if (!legalAccepted) {
                        errorMessage = trKey("must_accept_privacy_policy_terms_conditions_register")
                    } else {
                        isSubmitting = true
                        scope.launch {
                            errorMessage = repository.registerOnline(nickname.trim(), email.trim(), password, gender)
                            isSubmitting = false
                            if (errorMessage == null) onRegisterSuccess(nickname.trim())
                        }
                    }
                },
                enabled = !isSubmitting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GhostRedPrimary,
                    contentColor = GhostTextWhite
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (veryCompact) 46.dp else 50.dp)
                    .testTag("create_account_button")
            ) {
                Text(
                    text = trKey("create_account_2"),
                    fontSize = if (veryCompact) 14.sp else 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 7.dp else 12.dp))


            // Already have an account? Login
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = trKey("already_have_account"),
                    color = GhostTextSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = trKey("login"),
                    color = GhostRedPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToLogin() }
                        .testTag("register_login_link")
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 9.dp else 14.dp))
            }
        }
    }
}

@Composable
private fun outlinedTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = GhostSurface,
    unfocusedContainerColor = GhostSurface,
    focusedBorderColor = GhostRedPrimary,
    unfocusedBorderColor = GhostBorder,
    focusedTextColor = GhostTextWhite,
    unfocusedTextColor = GhostTextWhite,
    cursorColor = GhostRedPrimary
)
