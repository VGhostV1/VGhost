plugins {
    id("com.android.application") version "9.0.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.20" apply false
    id("com.google.gms.google-services") version "4.4.3" apply false
}

androidComponents {
    onVariants(selector().withBuildType("release")) {
        outputs.forEach { output ->
            output.outputFileName.set("VGhost.apk")
        }
    }
}
