package com.vghost.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.ui.components.GiftReceivedOverlay
import com.vghost.app.ui.components.LevelUpOverlay
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.AppLocale
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.screens.ChatScreen
import com.vghost.app.ui.screens.AdminScreen
import com.vghost.app.ui.screens.FindByNicknameScreen
import com.vghost.app.ui.screens.VipScreen
import com.vghost.app.ui.screens.HomeScreen
import com.vghost.app.ui.screens.FilmHomeScreen
import com.vghost.app.ui.screens.FilmDetailScreen
import com.vghost.app.ui.screens.AdminFilmsScreen
import com.vghost.app.ui.screens.LoginScreen
import com.vghost.app.ui.screens.PanicScreen
import com.vghost.app.ui.screens.StoryScreen
import com.vghost.app.ui.screens.PinLockScreen
import com.vghost.app.ui.screens.ProfileScreen
import com.vghost.app.ui.screens.OtherProfileScreen
import com.vghost.app.ui.screens.RegisterScreen
import com.vghost.app.ui.screens.SettingsScreen
import com.vghost.app.ui.components.AuthRequiredDialog
import com.vghost.app.ui.screens.LanguageScreen
import com.vghost.app.ui.screens.PrivacyScreen
import com.vghost.app.ui.screens.LegalDocument
import com.vghost.app.ui.screens.LegalDocumentScreen
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object AppRoutes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val FILMS = "films"
    const val FILM_DETAIL = "film_detail/{filmId}"
    const val FIND = "find"
    const val VIP = "vip"
    const val PANIC = "panic"
    const val STORY = "story"
    const val STORY_WITH_ID = "story?storyId={storyId}"
    const val CHAT = "chat/{nickname}"
    const val PIN_LOCK = "pin_lock"
    const val ADMIN = "admin"
    const val ADMIN_FILMS = "admin_films"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val LANGUAGE = "language"
    const val PRIVACY = "privacy"
    const val PRIVACY_POLICY = "privacy_policy"
    const val TERMS = "terms"
    const val OTHER_PROFILE = "other_profile/{nickname}?uid={uid}&online={online}&vip={vip}"

    fun filmDetailRoute(id: Long): String = "film_detail/$id"

    fun chatRoute(nickname: String): String {
        val encoded = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "chat/$encoded"
    }

    fun otherProfileRoute(nickname: String): String {
        val encoded = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "other_profile/$encoded?online=false&vip=false"
    }

    fun otherProfileRouteWithUid(uid: String, nickname: String, online: Boolean, vip: Boolean = false): String {
        val encodedUid = URLEncoder.encode(uid, StandardCharsets.UTF_8.toString())
        val encodedNickname = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "other_profile/$encodedNickname?uid=$encodedUid&online=$online&vip=$vip"
    }
}

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    initialChatNickname: String? = null,
    initialNotificationTarget: String? = null,
    initialNotificationTargetValue: String? = null,
    navController: NavHostController = rememberNavController()
) {
    val giftEvent by VGhostRepository.instance.giftReceivedEvent.collectAsState()
    val levelUpEvent by VGhostRepository.instance.levelUpEvent.collectAsState()
    val sessionState by VGhostRepository.instance.sessionState.collectAsState()
    val appLanguage by AppLocale.language.collectAsState()
    val context = LocalContext.current
    var authDialogVisible by remember { mutableStateOf(false) }
    var pendingAuthRoute by remember { mutableStateOf(AppRoutes.FILMS) }

    fun requestAuth(destination: String) {
        pendingAuthRoute = destination
        authDialogVisible = true
    }

    fun navigateAuthed(destination: String) {
        if (VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedOut) {
            requestAuth(destination)
            return
        }
        navController.navigate(destination) { launchSingleTop = true }
    }

    fun selectTab(tab: NavTab) {
        // Do nothing when the user taps the tab that is already open.
        // This prevents the current screen from being recreated/reopened.
        val currentRoute = navController.currentBackStackEntry?.destination?.route
        val targetRoute = when (tab) {
            NavTab.FILMS -> AppRoutes.FILMS
            NavTab.STORY -> AppRoutes.STORY
            NavTab.FIND -> AppRoutes.FIND
            NavTab.CHATS -> AppRoutes.HOME
            NavTab.PROFILE -> AppRoutes.PROFILE
            NavTab.PANIC -> AppRoutes.PANIC
        }
        if (currentRoute == targetRoute) return

        // Bottom navigation is a set of top-level destinations, not a history stack.
        // Reuse an existing tab state instead of creating a fresh screen every tap.
        fun navigateTab() {
            navController.navigate(targetRoute) {
                launchSingleTop = true
                restoreState = true
                popUpTo(AppRoutes.FILMS) {
                    saveState = true
                }
            }
        }

        when (tab) {
            NavTab.FILMS -> navigateTab()
            NavTab.STORY -> navigateTab()
            NavTab.FIND -> navigateTab()
            NavTab.CHATS -> {
                if (VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedOut) {
                    requestAuth(targetRoute)
                } else {
                    navigateTab()
                }
            }
            NavTab.PROFILE -> {
                if (VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedOut) {
                    requestAuth(targetRoute)
                } else {
                    navigateTab()
                }
            }
            NavTab.PANIC -> {
                if (VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedOut) {
                    requestAuth(targetRoute)
                } else {
                    navigateTab()
                }
            }
        }
    }
    Box(modifier.fillMaxSize()) {
        // Changing language rebuilds the whole destination subtree, so every
        // screen immediately reads the new translations, not only Panic.
        key(appLanguage) {
    NavHost(
        navController = navController,
        // Keep an authenticated local session on process recreation. If the
        // repository has an account/session, MainActivity handles the PIN gate
        // first; after unlock navigation must open Home, not Login.
        startDestination = when {
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && !initialChatNickname.isNullOrBlank() -> AppRoutes.chatRoute(initialChatNickname)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("chat", true) && !initialNotificationTargetValue.isNullOrBlank() -> AppRoutes.chatRoute(initialNotificationTargetValue)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("profile", true) && !initialNotificationTargetValue.isNullOrBlank() -> AppRoutes.otherProfileRoute(initialNotificationTargetValue)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("profile", true) -> AppRoutes.PROFILE
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("home", true) -> AppRoutes.HOME
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("find", true) -> AppRoutes.FIND
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("admin", true) -> AppRoutes.ADMIN
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser -> AppRoutes.FILMS
            else -> AppRoutes.FILMS
        },
        modifier = modifier,
        // Smooth app-wide transitions compatible with the Compose version used by this project.
        enterTransition = {
            fadeIn(animationSpec = tween(220)) +
                slideInHorizontally(animationSpec = tween(280)) { it / 8 }
        },
        exitTransition = {
            fadeOut(animationSpec = tween(160)) +
                slideOutHorizontally(animationSpec = tween(220)) { -it / 12 }
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(200)) +
                slideInHorizontally(animationSpec = tween(260)) { -it / 8 }
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(140)) +
                slideOutHorizontally(animationSpec = tween(200)) { it / 12 }
        }
    ) {
        // 1. Login Screen
        composable(AppRoutes.LOGIN) {
            LoginScreen(
                onLoginSuccess = { nickname ->
                    // Every successful login starts a completely fresh authenticated
                    // navigation session. Clear the old guest/profile/auth stack so a
                    // previous Profile destination can never reappear after login.
                    authDialogVisible = false
                    pendingAuthRoute = AppRoutes.FILMS
                    navController.navigate(AppRoutes.FILMS) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(AppRoutes.REGISTER) {
                        launchSingleTop = true
                    }
                },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
            )
        }

        // Language picker is available before login and from Profile.
        composable(AppRoutes.LANGUAGE) {
            LanguageScreen(onBack = { navController.popBackStack() })
        }

        // 2. Register Screen
        composable(AppRoutes.REGISTER) {
            RegisterScreen(
                onRegisterSuccess = { nickname ->
                    // Registration is also a fresh authenticated session: discard every
                    // old guest/profile/auth destination and open Films immediately.
                    authDialogVisible = false
                    pendingAuthRoute = AppRoutes.FILMS
                    navController.navigate(AppRoutes.FILMS) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToLogin = {
                    // Always make the back arrow return to Login. Clear the
                    // current auth stack first so this also works after process
                    // restore or when Register was opened from another flow.
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onOpenPrivacyPolicy = { navController.navigate(AppRoutes.PRIVACY_POLICY) },
                onOpenTerms = { navController.navigate(AppRoutes.TERMS) }
            
            )
        }

        // 3. Home / Chats Screen
        composable(AppRoutes.HOME) {
            HomeScreen(
                onChatClicked = { nickname -> navigateAuthed(AppRoutes.chatRoute(nickname)) },
                onTabSelected = ::selectTab,
                onNotificationTarget = { notification ->
                    when (notification.target.lowercase()) {
                        "chat" -> if (notification.targetValue.isNotBlank()) navigateAuthed(AppRoutes.chatRoute(notification.targetValue))
                        "profile" -> if (notification.targetValue.isNotBlank()) navController.navigate(AppRoutes.otherProfileRoute(notification.targetValue)) { launchSingleTop = true } else requestAuth(AppRoutes.PROFILE)
                        "story" -> {
                            val sid = notification.targetValue.toLongOrNull() ?: 0L
                            navController.navigate(if (sid > 0L) "story?storyId=$sid" else AppRoutes.STORY) { launchSingleTop = true }
                        }
                        "films" -> navController.navigate(AppRoutes.FILMS) { launchSingleTop = true }
                        "find" -> navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                        "admin" -> navController.navigate(AppRoutes.ADMIN) { launchSingleTop = true }
                        "link" -> {
                            val value = notification.targetValue.trim()
                            try {
                                val uri = Uri.parse(value)
                                if ((uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) && uri.host != null) {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                } else {
                                    navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                                }
                            } catch (_: Throwable) {
                                navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                            }
                        }
                        else -> navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                    }
                }
            )
        }

        // Film catalog. Language is on the upper-left; the seven-tap Admin shortcut is on the coin counter.
        composable(AppRoutes.FILMS) {
            FilmHomeScreen(
                onAdminSecret = { navController.navigate(AppRoutes.ADMIN) },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onFilmSelected = { id -> navController.navigate(AppRoutes.filmDetailRoute(id)) },
                onTabSelected = ::selectTab)
        }

        composable(
            AppRoutes.FILM_DETAIL,
            arguments = listOf(navArgument("filmId") { type = NavType.LongType })
        ) { entry ->
            FilmDetailScreen(
                filmId = entry.arguments?.getLong("filmId") ?: 0L,
                onBack = { navController.popBackStack() },
                onFilmSelected = { id -> navController.navigate(AppRoutes.filmDetailRoute(id)) { launchSingleTop = true } },
                onAuthRequired = { requestAuth(AppRoutes.filmDetailRoute(entry.arguments?.getLong("filmId") ?: 0L)) }
            )
        }

        // 4. Super Admin Control Room (inside the Android app)
        composable(AppRoutes.ADMIN) {
            AdminScreen(
                onBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                    }
                },
                onOpenFilms = { navController.navigate(AppRoutes.ADMIN_FILMS) },
                onAdminRejected = {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.ADMIN) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 5. VIP subscription / benefits screen
        // except for the crown shortcut in its top-right corner.
        composable(AppRoutes.VIP) {
            VipScreen(
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                    }
                },
                onTabSelected = ::selectTab)
        }

        // 6. Find by Nickname Screen
        composable(AppRoutes.FIND) {
            FindByNicknameScreen(
                onOpenVip = { navigateAuthed(AppRoutes.VIP) },
                onOpenChat = { nickname -> navigateAuthed(AppRoutes.chatRoute(nickname)) },
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.FIND) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                },
                onUserSelected = { user ->
                    navController.navigate(AppRoutes.otherProfileRouteWithUid(user.uid, user.nickname, user.online, user.isVip))
                },
                onTabSelected = ::selectTab)
        }

        composable(AppRoutes.ADMIN_FILMS) {
            AdminFilmsScreen(onBack = { navController.popBackStack() })
        }

        // 5. Other User Profile
        composable(
            route = AppRoutes.OTHER_PROFILE,
            arguments = listOf(
                navArgument("nickname") { type = NavType.StringType },
                navArgument("uid") { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument("online") { type = NavType.BoolType; defaultValue = false },
                navArgument("vip") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val nickname = URLDecoder.decode(backStackEntry.arguments?.getString("nickname").orEmpty(), StandardCharsets.UTF_8.toString())
            val initialUid = backStackEntry.arguments?.getString("uid")?.let { URLDecoder.decode(it, StandardCharsets.UTF_8.toString()) }
            val initialOnline = backStackEntry.arguments?.getBoolean("online") ?: false
            val initialVip = backStackEntry.arguments?.getBoolean("vip") ?: false
            OtherProfileScreen(
                nickname = nickname,
                initialUid = initialUid,
                initialOnline = initialOnline,
                initialVip = initialVip,
                onNavigateBack = {
                    if (!navController.popBackStack()) navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                },
                onOpenChat = { target -> navigateAuthed(AppRoutes.chatRoute(target)) },
                onTabSelected = ::selectTab)
        }

        // 6. Profile Screen
        composable(AppRoutes.PROFILE) {
            ProfileScreen(
                onOpenSettings = { navController.navigate(AppRoutes.SETTINGS) },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onTabSelected = ::selectTab,
                onOpenPanic = { navController.navigate(AppRoutes.PANIC) { launchSingleTop = true } },
                onLogout = {
                    // Explicit user logout: clear the local App PIN as well as the session.
                    // Network outages never call this path, so offline sessions remain intact.
                    VGhostRepository.instance.logoutAndClearLocalPin()
                    // Explicit logout returns directly to the public guest film catalog,
                    // not the login screen. The session/cache has already been cleared above.
                    navController.navigate(AppRoutes.FILMS) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 6. Chat Screen (Text Only)

        composable(AppRoutes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onOpenPrivacy = { navController.navigate(AppRoutes.PRIVACY) },
                onOpenPrivacyPolicy = { navController.navigate(AppRoutes.PRIVACY_POLICY) },
                onOpenTerms = { navController.navigate(AppRoutes.TERMS) },
                onAccountDeleted = {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.SETTINGS) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(AppRoutes.PRIVACY) {
            PrivacyScreen(onBack = { navController.popBackStack() })
        }

        composable(AppRoutes.PRIVACY_POLICY) {
            LegalDocumentScreen(LegalDocument.PRIVACY_POLICY, onBack = { navController.popBackStack() })
        }

        composable(AppRoutes.TERMS) {
            LegalDocumentScreen(LegalDocument.TERMS, onBack = { navController.popBackStack() })
        }

        composable(
            route = AppRoutes.CHAT,
            arguments = listOf(navArgument("nickname") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedNickname = backStackEntry.arguments?.getString("nickname") ?: "Shadow_7"
            val decodedNickname = URLDecoder.decode(encodedNickname, StandardCharsets.UTF_8.toString())
            ChatScreen(
                recipientNickname = decodedNickname,
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // 6. Story / Status screen
        composable(AppRoutes.STORY_WITH_ID, arguments = listOf(navArgument("storyId") { type = NavType.LongType; defaultValue = 0L })) { backStackEntry ->
            val initialStoryId = backStackEntry.arguments?.getLong("storyId") ?: 0L
            val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
            val storyVisible = currentRoute?.startsWith("story") == true
            StoryScreen(
                initialStoryId = initialStoryId,
                isVisible = storyVisible,
                onOpenRegister = { requestAuth(AppRoutes.REGISTER) },
                onAuthRequired = { requestAuth(AppRoutes.STORY) },
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.HOME) { launchSingleTop = true } },
                onOpenProfile = { uid, nickname ->
                    navController.navigate(AppRoutes.otherProfileRouteWithUid(uid.toString(), nickname, false)) { launchSingleTop = true }
                },
                onOpenFilm = { filmId ->
                    if (filmId > 0L) navController.navigate(AppRoutes.filmDetailRoute(filmId)) { launchSingleTop = true }
                },
                onTabSelected = ::selectTab)
        }

        // 7. Panic Screen — opened from My Profile
        composable(AppRoutes.PANIC) {
            PanicScreen(
                onPanicActivated = {
                    // Panic permanently deletes the account on the backend.
                    // Immediately leave the authenticated navigation graph; there is
                    // no guest/anonymous fallback after account deletion.
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onTabSelected = ::selectTab)
        }

        // 7. App Lock / PIN Entry Screen
        composable(AppRoutes.PIN_LOCK) {
            PinLockScreen(
                onUnlockSuccess = {
                    navController.navigate(AppRoutes.HOME) {
                        popUpTo(AppRoutes.PIN_LOCK) { inclusive = true }
                    }
                },
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.PIN_LOCK) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }
    }
        } // key(appLanguage)
    if (authDialogVisible) {
        AuthRequiredDialog(
            onRegister = {
                authDialogVisible = false
                navController.navigate(AppRoutes.REGISTER) { launchSingleTop = true }
            },
            onLogin = {
                authDialogVisible = false
                navController.navigate(AppRoutes.LOGIN) { launchSingleTop = true }
            },
            onDismiss = { authDialogVisible = false }
        )
    }
    giftEvent?.let { event -> GiftCatalog.find(event.giftId)?.let { gift -> GiftReceivedOverlay(gift, event.sender, event.token) { VGhostRepository.instance.clearGiftReceived(event.token) } } }
    levelUpEvent?.let { event -> LevelUpOverlay(event.level, event.coins, event.token) { VGhostRepository.instance.clearLevelUpEvent(event.token) } }
    }
}
