package com.vghost.app.ui.screens
import com.vghost.app.ui.components.VGhostCoinIcon
import com.vghost.app.i18n.AppLocale
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.media.MediaMetadataRetriever
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.vghost.app.i18n.tr
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.data.state.SessionState
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostGoldText
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostTextWhite
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

private data class StoryItem(
    val id: Long, val userId: Long, val nickname: String, val avatarUrl: String, val avatarId: String, val mediaUrl: String,
    val mediaType: String, val createdAt: String, val expiresAt: String, val visibility: String,
    val caption: String, val views: Int, val likes: Int, val comments: Int,
    val liked: Boolean, val seen: Boolean, val followed: Boolean,
    val filmId: Long = 0L, val filmTitle: String = "", val filmCategory: String = "", val filmYear: Int? = null
)
private data class StoryComment(val id: Long, val userId: Long, val nickname: String, val comment: String, val createdAt: String, val parentCommentId: Long? = null)

private fun hasInternetConnection(context: android.content.Context): Boolean {
    val cm = context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val network = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

@Composable
fun StoryScreen(
    onBack: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    onOpenProfile: (uid: Long, nickname: String) -> Unit,
    initialStoryId: Long = 0L,
    onOpenRegister: () -> Unit = {},
    onAuthRequired: () -> Unit = {},
    onOpenFilm: (Long) -> Unit = {},
    isVisible: Boolean = true
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = VGhostRepository.instance
    val isSuperAdmin by repository.isSuperAdmin.collectAsState()
    val sessionState by repository.sessionState.collectAsState()
    val isLoggedIn = sessionState is SessionState.LoggedInNormalUser
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var currentUserId by remember { mutableLongStateOf(0L) }
    var currentNickname by remember { mutableStateOf("") }
    var commentStory by remember { mutableStateOf<StoryItem?>(null) }
    var commentText by remember { mutableStateOf("") }
    var replyComment by remember { mutableStateOf<StoryComment?>(null) }
    var comments by remember { mutableStateOf<List<StoryComment>>(emptyList()) }
    var commentsLoading by remember { mutableStateOf(false) }
    var commentError by remember { mutableStateOf<String?>(null) }
    var deleteStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewersStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewers by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    var viewerLoading by remember { mutableStateOf(false) }
    var reportStory by remember { mutableStateOf<StoryItem?>(null) }
    var reportReason by remember { mutableStateOf("") }
    var menuStory by remember { mutableStateOf<StoryItem?>(null) }
    var blockStory by remember { mutableStateOf<StoryItem?>(null) }
    var giftStory by remember { mutableStateOf<StoryItem?>(null) }
    var giftSending by remember { mutableStateOf(false) }
    var createDialog by remember { mutableStateOf(false) }
    var createCaption by remember { mutableStateOf("") }
    var trailerFilms by remember { mutableStateOf<List<Pair<Long, String>>>(emptyList()) }
    var selectedFilmId by remember { mutableLongStateOf(0L) }
    var selectedFilmTitle by remember { mutableStateOf("") }
    var selectedMediaUri by remember { mutableStateOf<Uri?>(null) }
    var selectedMediaMime by remember { mutableStateOf("") }
    var mediaUploading by remember { mutableStateOf(false) }
    var mediaUploadProgress by remember { mutableFloatStateOf(0f) }
    var mediaUploadSent by remember { mutableLongStateOf(0L) }
    var mediaUploadTotal by remember { mutableLongStateOf(0L) }
    var initialPositionApplied by remember { mutableStateOf(false) }
    var isOnline by remember { mutableStateOf(hasInternetConnection(context)) }

    LaunchedEffect(Unit) {
        // Admin status is loaded in the background during login; refresh it when
        // the Trailer screen opens so the Admin Share button is available immediately.
        runCatching { repository.refreshAdminStatus() }
    }

    LaunchedEffect(createDialog, isSuperAdmin) {
        if (createDialog && isSuperAdmin) {
            runCatching {
                val a = VGhostApi.films().optJSONArray("films") ?: org.json.JSONArray()
                trailerFilms = (0 until a.length()).mapNotNull { i ->
                    a.optJSONObject(i)?.let { o -> o.optLong("id").takeIf { it > 0L }?.let { it to o.optString("title") } }
                }
            }
        }
    }

    DisposableEffect(context) {
        val cm = context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm == null) { onDispose { } } else {
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { isOnline = hasInternetConnection(context) }
                override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                    isOnline = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                }
                override fun onLost(network: Network) { isOnline = hasInternetConnection(context) }
            }
            cm.registerDefaultNetworkCallback(callback)
            onDispose { runCatching { cm.unregisterNetworkCallback(callback) } }
        }
    }

    fun parseStories(json: org.json.JSONObject): List<StoryItem> {
        val arr = json.optJSONArray("stories") ?: org.json.JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            StoryItem(o.optLong("id"), o.optLong("userId"), o.optString("nickname"), VGhostApi.publicUrl(o.optString("avatarUrl")), o.optString("avatarId","male_01").ifBlank { "male_01" }, VGhostApi.publicUrl(o.optString("mediaUrl")),
                o.optString("mediaType"), o.optString("createdAt"), o.optString("expiresAt"), o.optString("visibility", "all"), o.optString("caption"),
                o.optInt("views"), o.optInt("likes"), o.optInt("comments"), o.optBoolean("liked"), o.optBoolean("seen"), o.optBoolean("followed"),
                o.optLong("filmId", o.optLong("film_id", 0L)), o.optString("filmTitle", o.optString("film_title", "")),
                o.optString("filmCategory", o.optString("film_category", "")), if (o.has("filmYear") && !o.isNull("filmYear")) o.optInt("filmYear") else if (o.has("film_year") && !o.isNull("film_year")) o.optInt("film_year") else null)
        }
    }
    fun reload(silent: Boolean = false) {
        scope.launch {
            if (!isOnline) {
                loading = false
                error = null
                return@launch
            }
            if (!silent) loading = true
            error = null
            try {
                if (isLoggedIn) {
                    val me = VGhostApi.me()
                    currentUserId = me.optJSONObject("user")?.optLong("id") ?: 0L
                    currentNickname = me.optJSONObject("user")?.optString("nickname", "")?.trim() ?: ""
                } else {
                    currentUserId = 0L
                    currentNickname = ""
                }
                stories = parseStories(VGhostApi.stories())
            } catch (e: Throwable) {
                // A background refresh must never cover an already playable Story with
                // a red error banner. Keep the previous feed and retry on the next tick.
                if (!silent) error = VGhostApi.userFacingError(e, "story_y_kl_nm_di")
            } finally { if (!silent) loading = false }
        }
    }
    fun loadComments(story: StoryItem) {
        commentStory = story; commentText = ""; replyComment = null; commentError = null; commentsLoading = true
        scope.launch { try { val a=VGhostApi.storyComments(story.id).optJSONArray("comments") ?: org.json.JSONArray(); comments=(0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { StoryComment(it.optLong("id"),it.optLong("userId"),it.optString("nickname"),it.optString("comment"),it.optString("createdAt"),it.optLong("parentCommentId").takeIf { v -> v > 0 }) } } } catch(e:Throwable){comments=emptyList();commentError=VGhostApi.userFacingError(e, "rhl_r_y_kl_nm_di")} finally{commentsLoading=false} }
    }
    fun submitComment() {
        if (!isLoggedIn) { onAuthRequired(); return }
        val story=commentStory ?: return; val text=commentText.trim(); if(text.isBlank()) return
        val parentId = replyComment?.id
        scope.launch { try { VGhostApi.commentStory(story.id,text,parentId); commentText=""; replyComment=null; loadComments(story); reload() } catch(e:Throwable){commentError=VGhostApi.userFacingError(e, "rh_g_nd_rilm_di")} }
    }
    fun openProfile(story: StoryItem) {
        val mine=story.userId==currentUserId || (currentNickname.isNotBlank() && story.nickname.equals(currentNickname,true))
        if(mine) onTabSelected(NavTab.PROFILE) else onOpenProfile(story.userId,story.nickname)
    }
    fun loadViewers(story: StoryItem) {
        viewersStory=story; viewerLoading=true; viewers=emptyList()
        scope.launch { try { val a=VGhostApi.storyViewers(story.id).optJSONArray("viewers") ?: org.json.JSONArray(); viewers=(0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { it.optString("nickname") to it.optString("viewedAt") } } } catch(e:Throwable){error=VGhostApi.userFacingError(e, "bax_lar_y_kl_nm_di")} finally{viewerLoading=false} }
    }
    LaunchedEffect(isVisible, isOnline, isLoggedIn) {
        // Offline mode is non-blocking: keep the existing Story feed and local UI usable.
        // When connectivity returns, refresh the feed automatically.
        if (isVisible && isOnline) reload() else if (!isOnline) { loading = false; error = null }
        while (isVisible) {
            kotlinx.coroutines.delay(5_000L)
            if (isVisible && isOnline) reload(silent = true)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val mime = context.contentResolver.getType(uri).orEmpty()
        if (!mime.startsWith("video/")) {
            error = trKey("video_v_ya_kil_se")
            return@rememberLauncherForActivityResult
        }
        selectedMediaUri = uri
        selectedMediaMime = mime
        error = null
    }

    fun uploadSelectedMedia() {
        val uri = selectedMediaUri ?: return
        if (mediaUploading) return
        if (selectedFilmId <= 0L) { error = trKey("trailer_select_film_required"); return }
        scope.launch {
            mediaUploading = true
            mediaUploadProgress = 0f
            mediaUploadSent = 0L
            mediaUploadTotal = 0L
            try {
                val mime = selectedMediaMime.ifBlank { context.contentResolver.getType(uri).orEmpty() }
                if (!mime.startsWith("video/")) throw IllegalStateException(trKey("video_v_ya_kil_se"))
                val size = withContext(Dispatchers.IO) {
                    context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.SIZE)
                        if (i >= 0 && c.moveToFirst()) c.getLong(i) else -1L
                    } ?: -1L
                }
                if (size <= 0L) throw IllegalStateException(trKey("fayl_bo_dur"))
                if (size > 100L * 1024L * 1024L) throw IllegalStateException(trKey("story_file_too_large_100_mb"))
                mediaUploadTotal = size
                val stream = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException(trKey("fayl_bo_dur"))
                VGhostApi.createStoryChunked(
                    stream,
                    size,
                    mime,
                    "all",
                    createCaption,
                    selectedFilmId
                ) { sent, total ->
                    mediaUploadSent = sent
                    mediaUploadTotal = total
                    mediaUploadProgress = if (total > 0L) (sent.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                }
                createDialog = false
                createCaption = ""
                selectedMediaUri = null
                selectedMediaMime = ""
                selectedFilmId = 0L
                selectedFilmTitle = ""
                reload()
            } catch (e: Throwable) {
                error = VGhostApi.userFacingError(e, "story_y_kl_nm_di")
            } finally {
                mediaUploading = false
                if (mediaUploadProgress >= 1f) {
                    mediaUploadSent = mediaUploadTotal
                }
            }
        }
    }
    val visibleStories = stories

    Column(
        Modifier.fillMaxSize().premiumBackdrop()
    ) {
        // The Status header stays visible, but is now an overlay on top of the media.
        // The video/image therefore starts behind the avatar, @Admin and camera button
        // instead of leaving a separate empty header area above the media.
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = GhostRedPrimary)
                }
                visibleStories.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Outlined.AddAPhoto, null, tint = GhostRedPrimary, modifier = Modifier.size(72.dp))
                        Text(trKey("trailer_empty"), color = GhostTextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(trKey("bu_b_lm_d_h_l_payla_m_yoxdur"), color = Color(0xFFA7B0C9), fontSize = 14.sp)
                        Spacer(Modifier.height(22.dp))
                        if (isSuperAdmin) Button(
                            onClick = { createDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary),
                            shape = RoundedCornerShape(30.dp),
                            modifier = Modifier.fillMaxWidth(.82f).height(58.dp)
                        ) {
                            Icon(Icons.Outlined.VideoCall, null, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(trKey("t_dd95fc20ac13"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                else -> {
                    val pagerState = rememberPagerState(pageCount = { visibleStories.size })
                    LaunchedEffect(visibleStories) {
                        if (!initialPositionApplied) {
                            val target = if (initialStoryId > 0L) visibleStories.indexOfFirst { it.id == initialStoryId } else 0
                            if (target >= 0 && target < visibleStories.size) pagerState.scrollToPage(target)
                            initialPositionApplied = true
                        }
                    }
                    LaunchedEffect(pagerState.currentPage, visibleStories) {
                        visibleStories.getOrNull(pagerState.currentPage)?.let { current ->
                            if (current.userId != currentUserId && !current.seen) {
                                val result = runCatching { VGhostApi.viewStory(current.id) }.getOrNull()
                                val newView = result?.optBoolean("newView", false) ?: false
                                stories = stories.map { if (it.id == current.id) it.copy(seen = true, views = if (newView) it.views + 1 else it.views) else it }
                            }
                        }
                    }
                    VerticalPager(
                        state = pagerState,
                        // Keep the Status title area clear; media begins directly below
                        // the "Status" heading while the profile/avatar and camera controls
                        // remain over the media as requested.
                        modifier = Modifier.fillMaxSize().padding(top = 132.dp)
                    ) { page ->
                        val current = visibleStories.getOrNull(page) ?: return@VerticalPager
                        Box(Modifier.fillMaxSize().background(Color.Black)) {
                            key("story-media-${current.id}-${isVisible}") {
                                StoryMedia(current, autoPlayVideo = isVisible && page == pagerState.currentPage, fullscreen = true)
                            }

                            Column(
                                Modifier.align(Alignment.BottomEnd)
                                    .padding(end = 10.dp, bottom = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                StoryReelsAction(
                                    icon = if (current.liked) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                                    count = current.likes,
                                    tint = if (current.liked) GhostRedPrimary else GhostRedPrimary.copy(alpha = .95f),
                                    label = trKey("like"),
                                    onClick = {
                                        if (!isLoggedIn) onAuthRequired() else scope.launch {
                                            runCatching { VGhostApi.likeStory(current.id) }
                                            reload(silent = true)
                                        }
                                    }
                                )
                                Spacer(Modifier.height(16.dp))
                                StoryReelsAction(
                                    icon = Icons.Outlined.ChatBubbleOutline,
                                    count = current.comments,
                                    tint = Color(0xFFE66CFF),
                                    label = trKey("comment"),
                                    onClick = { if (!isLoggedIn) onAuthRequired() else loadComments(current) }
                                )
                                Spacer(Modifier.height(16.dp))
                                StoryReelsAction(
                                    icon = Icons.Outlined.Visibility,
                                    count = current.views,
                                    tint = Color(0xFF7BE7FF),
                                    label = trKey("bax"),
                                    onClick = { if (current.userId == currentUserId) loadViewers(current) }
                                )
                                Spacer(Modifier.height(16.dp))
                                Box(
                                    modifier = Modifier
                                        .size(58.dp)
                                        .clip(CircleShape)
                                        .background(GhostRedPrimary.copy(alpha = .10f))
                                        .border(2.dp, GhostRedPrimary.copy(alpha = .72f), CircleShape)
                                        .clickable { if (!isLoggedIn) onAuthRequired() else menuStory = current },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        Modifier.size(54.dp).clip(CircleShape)
                                            .background(Color.Black.copy(alpha = .52f))
                                            .border(1.dp, GhostRedPrimary.copy(alpha = .50f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.MoreVert,
                                            contentDescription = trKey("se_iml_r"),
                                            tint = Color.White,
                                            modifier = Modifier.size(30.dp)
                                        )
                                    }
                                }
                            }

                            Column(
                                Modifier.align(Alignment.BottomStart)
                                    .fillMaxWidth()
                                    .padding(start = 18.dp, end = 92.dp, bottom = 6.dp, top = 0.dp)
                            ) {
                                val hasFilm = current.filmId > 0L
                                Text(
                                    if (hasFilm) current.filmTitle.ifBlank { trKey("trailer_film") } else trKey("trailer_film_not_linked"),
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (current.filmCategory.isNotBlank() || current.filmYear != null) {
                                    Text(
                                        listOfNotNull(current.filmCategory.takeIf { it.isNotBlank() }, current.filmYear?.toString()).joinToString(" • "),
                                        color = Color.White.copy(alpha = .68f), fontSize = 12.sp
                                    )
                                }
                                if (current.caption.isNotBlank()) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(current.caption, color = Color.White.copy(alpha = .95f), fontSize = 14.sp, maxLines = 3)
                                }
                                if (hasFilm) {
                                    Spacer(Modifier.height(9.dp))
                                    Button(
                                        onClick = { onOpenFilm(current.filmId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary),
                                        shape = RoundedCornerShape(24.dp),
                                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(trKey("trailer_watch_film"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Header is deliberately transparent so the current media remains visible behind it.
                    Row(
                        Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars)
                            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(trKey("trailer_title"), color = GhostTextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(trKey("trailer_subtitle"), color = Color.White.copy(alpha = .58f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
                            Box(Modifier.padding(top = 7.dp).width(44.dp).height(3.dp).background(GhostRedPrimary))
                        }
                        if (isSuperAdmin) {
                            Button(
                                onClick = { createDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary),
                                shape = RoundedCornerShape(24.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Icon(Icons.Outlined.VideoCall, null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(trKey("trailer_admin_share"), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }

            if (!isOnline) {
                // Keep the offline notice away from the status bar. On the empty-story
                // screen it sits directly above the camera icon, while remaining
                // centered on other story states.
                Row(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = (-145).dp)
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.CloudOff, null, tint = GhostRedPrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        trKey("story_no_internet"),
                        color = GhostTextWhite,
                        fontSize = 12.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            error?.let { Text(it, color = GhostRedPrimary, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopStart).padding(horizontal = 18.dp)) }
        }

        VGhostBottomNavBar(
            currentTab = NavTab.STORY,
            onTabSelected = onTabSelected,
            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
        )
    }

    if (createDialog) {
        Dialog(onDismissRequest = { createDialog = false }) {
            Surface(color = Color(0xFF13080D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(.94f)) {
                Column(Modifier.padding(18.dp)) {
                    Text(trKey("trailer_create"), color = GhostTextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text(trKey("trailer_public_notice"), color = GhostTextWhite.copy(alpha = .7f), fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(trKey("trailer_select_film"), color = GhostTextWhite.copy(alpha = .72f), fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    if (trailerFilms.isEmpty()) {
                        Text(trKey("trailer_no_films"), color = GhostTextWhite.copy(alpha = .55f), fontSize = 12.sp)
                    } else {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            trailerFilms.forEach { (id, title) ->
                                FilterButton(title, selectedFilmId == id) {
                                    selectedFilmId = id
                                    selectedFilmTitle = title
                                    // When an existing film is selected, use its title as the default trailer description/caption.
                                    createCaption = title
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = createCaption, onValueChange = { createCaption = it.take(500) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(trKey("caption_yaz")) }, maxLines = 3)
                    Spacer(Modifier.height(12.dp))
                    selectedMediaUri?.let { uri ->
                        StoryCreatePreview(uri, selectedMediaMime)
                        Spacer(Modifier.height(10.dp))
                    }
                    Button(
                        onClick = { picker.launch(arrayOf("video/*", "image/*")) },
                        modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                    ) {
                        Icon(Icons.Outlined.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text(if (selectedMediaUri == null) trKey("video_v_ya_kil_se_2") else trKey("ba_qa_media_se"))
                    }
                    if (selectedMediaUri != null) {
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { uploadSelectedMedia() },
                            enabled = !mediaUploading,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                        ) {
                            if (mediaUploading) {
                                CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(trKey("payla_l_r_ellipsis"))
                            } else {
                                Icon(Icons.Outlined.Send, null); Spacer(Modifier.width(8.dp)); Text(trKey("i_ndi_payla"))
                            }
                        }
                        if (mediaUploading) {
                            Spacer(Modifier.height(6.dp))
                            Column(Modifier.fillMaxWidth()) {
                                Box(
                                    Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(GhostRedPrimary.copy(alpha = .12f))
                                        .border(1.dp, GhostRedPrimary.copy(alpha = .45f), RoundedCornerShape(50))
                                ) {
                                    Box(
                                        Modifier.fillMaxWidth(mediaUploadProgress.coerceIn(0f, 1f)).fillMaxHeight()
                                            .clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(GhostRedPrimary.copy(alpha = .55f), GhostRedPrimary)))
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                val percent = (mediaUploadProgress * 100f).toInt().coerceIn(0, 100)
                                val totalMb = mediaUploadTotal / (1024f * 1024f)
                                val sentMb = mediaUploadSent / (1024f * 1024f)
                                Text(
                                    if (mediaUploadTotal > 0L) "${percent}% • ${String.format(Locale.US, "%.1f", sentMb)} / ${String.format(Locale.US, "%.1f", totalMb)} MB" else "0% • ${trKey("uploading_ellipsis")}",
                                    color = GhostTextWhite.copy(alpha = .72f), fontSize = 11.sp, modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = { createDialog = false; selectedMediaUri = null; selectedMediaMime = ""; selectedFilmId = 0L; selectedFilmTitle = "" }, modifier = Modifier.align(Alignment.End)) { Text(trKey("cancel_3")) }
                }
            }
        }
    }

    deleteStory?.let { story ->
        AlertDialog(
            onDismissRequest = { deleteStory = null },
            title = { Text(trKey("delete_story_2"), color = GhostTextWhite) },
            text = { Text(trKey("delete_story"), color = GhostTextWhite.copy(alpha = .82f)) },
            confirmButton = { TextButton(onClick = { scope.launch { try { VGhostApi.deleteStory(story.id); deleteStory = null; reload() } catch (e: Throwable) { deleteStory = null; error = VGhostApi.userFacingError(e, "story_could_not_deleted") } } }) { Text(trKey("delete"), color = GhostRedPrimary) } },
            dismissButton = { TextButton(onClick = { deleteStory = null }) { Text(trKey("cancel_3"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    viewersStory?.let { story ->
        Dialog(onDismissRequest = { viewersStory = null }) {
            Surface(color = Color(0xFF13080D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(.94f)) {
                Column(Modifier.padding(18.dp)) {
                    Text(trKey("bax_lar"), color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    when {
                        viewerLoading -> CircularProgressIndicator(color = GhostRedPrimary)
                        viewers.isEmpty() -> Text(trKey("h_l_bax_yoxdur"), color = GhostTextWhite.copy(alpha = .65f))
                        else -> LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(viewers) { pair ->
                                Text(trKey("text_6").format(pair.first), color = GhostTextWhite, fontWeight = FontWeight.Bold)
                                Text(pair.second, color = GhostTextWhite.copy(alpha = .45f), fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                    TextButton(onClick = { viewersStory = null }, modifier = Modifier.align(Alignment.End)) { Text(trKey("close_2")) }
                }
            }
        }
    }

    menuStory?.let { story ->
        AlertDialog(
            onDismissRequest = { menuStory = null },
            title = { Text(trKey("se_iml_r"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (story.userId == currentUserId) {
                        TextButton(
                            onClick = { menuStory = null; deleteStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(trKey("delete"), color = GhostRedPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                    } else {
                        TextButton(
                            onClick = { menuStory = null; scope.launch { runCatching { VGhostApi.followStoryUser(story.userId) }; reload(silent = true) } },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (story.followed) trKey("story_izl_m_sini_dayand_r") else trKey("story_l_ri_izl"), color = GhostTextWhite, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton(
                            onClick = { menuStory = null; giftStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(trKey("send_gift"), color = GhostGoldText, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton(
                            onClick = { menuStory = null; reportReason = ""; reportStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(trKey("ikay_t_et"), color = GhostTextWhite, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton(
                            onClick = { menuStory = null; blockStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(trKey("block"), color = GhostRedPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuStory = null }) { Text(trKey("close"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    giftStory?.let { story ->
        AlertDialog(
            onDismissRequest = { if (!giftSending) giftStory = null },
            title = { Text(trKey("story_y_h_diyy"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    GiftCatalog.items.forEach { gift ->
                        TextButton(
                            enabled = !giftSending,
                            onClick = {
                                giftSending = true
                                scope.launch {
                                    try {
                                        val err = if (story.userId == currentUserId) com.vghost.app.i18n.VGhostLanguage.trKey("cannot_send_gift_own_story") else VGhostRepository.instance.giftStory(story.id, gift.id)
                                        if (err != null) { error = err } else { giftStory = null; reload(silent = true) }
                                    } catch (e: Throwable) { error = VGhostApi.userFacingError(e, "h_diyy_g_nd_rilm_di") }
                                    finally { giftSending = false }
                                }
                            }, modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                VGhostCoinIcon(size = 23.dp)
                                Spacer(Modifier.width(5.dp))
                                Text(trfKey("coin_3", gift.icon, gift.name, gift.price), color = GhostTextWhite)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(enabled = !giftSending, onClick = { giftStory = null }) { Text(trKey("close"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    blockStory?.let { story ->
        AlertDialog(
            onDismissRequest = { blockStory = null },
            title = { Text(trKey("block"), color = GhostTextWhite) },
            text = { Text(trKey("do_want_block").format(story.nickname), color = GhostTextWhite.copy(alpha = .82f)) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        try {
                            VGhostApi.addBlock(story.userId)
                            blockStory = null
                            reload()
                        } catch (e: Throwable) {
                            blockStory = null
                            error = VGhostApi.userFacingError(e, "bloklama_al_nmad")
                        }
                    }
                }) { Text(trKey("block"), color = GhostRedPrimary) }
            },
            dismissButton = { TextButton(onClick = { blockStory = null }) { Text(trKey("cancel_3"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    reportStory?.let { story ->
        AlertDialog(
            onDismissRequest = { reportStory = null },
            title = { Text(trKey("ikay_t_et"), color = GhostTextWhite) },
            text = {
                OutlinedTextField(
                    value = reportReason,
                    onValueChange = { reportReason = it.take(255) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(trKey("s_b_b")) }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        try {
                            VGhostApi.reportStory(story.id, reportReason.ifBlank { com.vghost.app.i18n.VGhostLanguage.trKey("inappropriate_content") })
                            reportStory = null
                        } catch (e: Throwable) {
                            error = VGhostApi.userFacingError(e, "ikay_t_g_nd_rilm_di")
                            reportStory = null
                        }
                    }
                }) { Text(trKey("g_nd_r"), color = GhostRedPrimary) }
            },
            dismissButton = { TextButton(onClick = { reportStory = null }) { Text(trKey("cancel_3"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    commentStory?.let { story ->
        Dialog(onDismissRequest = { commentStory = null; replyComment = null }) {
            Surface(color = Color(0xFF13080D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(.94f)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SeenAvatar(story); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(trKey("rhl_r"), color = GhostTextWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(trKey("text_23").format(story.nickname), color = GhostTextWhite.copy(alpha = .55f), fontSize = 12.sp) }
                        IconButton(onClick = { commentStory = null }) { Icon(Icons.Outlined.Close, trKey("close"), tint = GhostTextWhite) }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (commentsLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = GhostRedPrimary)
                    commentError?.let { Text(it, color = GhostRedPrimary, fontSize = 12.sp) }
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(comments, key = { it.id }) { c ->
                            Column(Modifier.fillMaxWidth().padding(start = if (c.parentCommentId != null) 18.dp else 0.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .05f)).padding(10.dp)) {
                                if (c.parentCommentId != null) {
                                    val parent = comments.firstOrNull { it.id == c.parentCommentId }
                                    Text(if (parent != null) trKey("text_6").format(parent.nickname) else com.vghost.app.i18n.VGhostLanguage.trKey("reply_reply"), color = GhostGoldText.copy(alpha = .9f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(2.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(trKey("text_2").format(c.nickname), color = GhostTextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp); Spacer(Modifier.weight(1f))
                                    TextButton(onClick = { replyComment = c; commentText = "" }) { Text(trKey("yan_tla"), color = GhostTextWhite, fontSize = 11.sp) }
                                    if (c.userId == currentUserId || story.userId == currentUserId) TextButton(onClick = { scope.launch { runCatching { VGhostApi.deleteStoryComment(c.id) }; loadComments(story); reload() } }) { Text(trKey("delete"), color = GhostRedPrimary, fontSize = 11.sp) }
                                }
                                Text(c.comment, color = GhostTextWhite.copy(alpha = .86f), fontSize = 14.sp)
                            }
                        }
                    }
                    replyComment?.let { target ->
                        Surface(color = GhostSurface, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(trKey("reply_2").format(target.nickname), color = GhostGoldText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(target.comment, color = GhostTextWhite.copy(alpha = .7f), fontSize = 12.sp, maxLines = 1)
                                }
                                IconButton(onClick = { replyComment = null }) { Icon(Icons.Outlined.Close, trKey("close"), tint = GhostTextWhite) }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = commentText, onValueChange = { commentText = it.take(500) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(trKey("rh_yaz")) }, maxLines = 4, keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { submitComment() }), trailingIcon = { IconButton(enabled = commentText.trim().isNotEmpty(), onClick = { submitComment() }) { Icon(Icons.Outlined.Send, trKey("rhi_payla"), tint = if (commentText.trim().isNotEmpty()) GhostRedPrimary else GhostTextWhite.copy(alpha = .3f)) } })
                }
            }
        }
    }
}

@Composable
private fun StoryCreatePreview(uri: Uri, mime: String) {
    val context = LocalContext.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        if (mime.startsWith("image/")) {
            var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
            LaunchedEffect(uri) { bitmap = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } }
            bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        } else {
            val player = remember(uri) {
                androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
                    setMediaItem(androidx.media3.common.MediaItem.fromUri(uri))
                    repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                    playWhenReady = true
                    prepare()
                }
            }
            DisposableEffect(player) {
                onDispose {
                    runCatching { player.stop() }
                    runCatching { player.release() }
                }
            }
            AndroidView(
                factory = { ctx ->
                    androidx.media3.ui.PlayerView(ctx).apply {
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        this.player = player
                    }
                },
                update = { it.player = player },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable private fun StoryFilterChip(title:String,selected:Boolean,modifier:Modifier=Modifier,onClick:()->Unit){Box(modifier.clip(RoundedCornerShape(30.dp)).background(if(selected)GhostRedPrimary else Color.Transparent).clickable(onClick=onClick).padding(vertical=11.dp),contentAlignment=Alignment.Center){Text(title,color=if(selected)Color.White else Color(0xFFA7B0C9),fontSize=15.sp,fontWeight=if(selected)FontWeight.Bold else FontWeight.Medium)}}
@Composable private fun FilterButton(title:String,selected:Boolean,onClick:()->Unit){TextButton(onClick=onClick){Text(title,color=if(selected)GhostRedPrimary else GhostTextWhite)}}
@Composable
private fun StoryReelsAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Int?,
    tint: Color,
    label: String,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Neon/glow-like double ring around every action.
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = .10f))
                .border(2.dp, tint.copy(alpha = .48f), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(54.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = .52f))
                    .border(1.dp, tint.copy(alpha = .72f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, label, tint = tint, modifier = Modifier.size(34.dp))
            }
        }
        count?.let { value ->
            Spacer(Modifier.height(3.dp))
            // Small dark round card keeps the number readable on bright videos.
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = .72f))
                    .border(1.dp, tint.copy(alpha = .50f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) {
                Text(
                    formatStoryCount(value),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun formatStoryCount(value: Int): String = when {
    value >= 1_000_000 -> String.format(Locale.US, "%.1fM", value / 1_000_000f).replace(".0M", "M")
    value >= 1_000 -> String.format(Locale.US, "%.1fK", value / 1_000f).replace(".0K", "K")
    else -> value.toString()
}

@Composable
private fun StoryTopAvatar(story: StoryItem, onClick: () -> Unit, modifier: Modifier = Modifier) {
    // Avatarın altında nickname göstərilir; genişlik artıq weight ilə bölüşdürülür
    // ki, 4 profil də eyni sətirdə rahat yerləşsin.
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(GhostRedPrimary.copy(alpha = .10f))
                .border(2.dp, GhostRedPrimary.copy(alpha = .78f), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            GhostAvatar(
                size = 48.dp,
                showBorder = true,
                avatarId = story.avatarId
            )
        }
        Spacer(Modifier.height(3.dp))
        Text(
            text = com.vghost.app.i18n.VGhostLanguage.trKey("text_23").format(story.nickname),
            color = GhostTextWhite.copy(alpha = .92f),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable private fun SeenAvatar(story:StoryItem){Box(Modifier.size(60.dp).clip(CircleShape).background(GhostRedPrimary.copy(alpha=.12f)).border(2.dp,if(story.seen)Color.White.copy(alpha=.28f) else GhostRedPrimary,CircleShape),contentAlignment=Alignment.Center){GhostAvatar(size=52.dp,showBorder=true,avatarId=story.avatarId)}}
@Composable
private fun StoryMedia(story: StoryItem, autoPlayVideo: Boolean = false, fullscreen: Boolean = false) {
    when {
        story.mediaType.startsWith("video/") -> StoryVideoCard(story.mediaUrl, autoPlay = autoPlayVideo, fullscreen = fullscreen)
        story.mediaType.startsWith("image/") -> StoryImageCard(story.mediaUrl)
    }
}

@Composable
private fun StoryImageCard(url: String) {
    val context = LocalContext.current
    var bitmap by remember(url) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(url) {
        bitmap = withContext(Dispatchers.IO) { runCatching {
            val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection)
            c.connectTimeout = 12000; c.readTimeout = 20000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "VGhost/1.0")
            c.setRequestProperty("X-VGhost-Client", "android")
            // Story media is protected by the backend. Only attach the session
            // token to the VGhost API origin; never leak it to third-party URLs.
            if (VGhostApi.isSameApiOrigin(url)) {
                VGhostApi.token()?.takeIf { it.isNotBlank() }?.let {
                    c.setRequestProperty("Authorization", "Bearer $it")
                }
            }
            c.connect()
            if (c.responseCode !in 200..299) throw IllegalStateException(com.vghost.app.i18n.VGhostLanguage.trKey("image_could_not_loaded"))
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        }.getOrNull() }
    }
    bitmap?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        ?: Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = GhostRedPrimary) }
}

private object TrailerMediaDataSource {
    fun factory(context: android.content.Context): androidx.media3.datasource.DataSource.Factory {
        val upstream = androidx.media3.datasource.DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("VGhost/1.0")
        if (VGhostApi.isSameApiOrigin(VGhostApi.absoluteUrl("api/stories/media"))) {
            VGhostApi.token()?.takeIf { it.isNotBlank() }?.let {
                upstream.setDefaultRequestProperties(
                    mapOf("Authorization" to "Bearer $it", "X-VGhost-Client" to "android")
                )
            }
        }
        // Deliberately no Media3 SimpleCache: trailer bytes are streamed/buffered
        // only for the current playback session and are not persisted on disk.
        return upstream
    }
}

@Composable
private fun StoryVideoCard(url: String, autoPlay: Boolean = false, fullscreen: Boolean = false) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var aspectRatio by remember(url) { mutableFloatStateOf(16f / 9f) }
    var loading by remember(url) { mutableStateOf(true) }
    var playbackError by remember(url) { mutableStateOf(false) }

    val player = remember(url) {
        val absoluteUrl = VGhostApi.absoluteUrl(url)
        androidx.media3.exoplayer.ExoPlayer.Builder(context)
            .setMediaSourceFactory(
                androidx.media3.exoplayer.source.DefaultMediaSourceFactory(
                    TrailerMediaDataSource.factory(context)
                )
            )
            .build()
            .apply {
                repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                playWhenReady = false
                addListener(object : androidx.media3.common.Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        loading = state == androidx.media3.common.Player.STATE_BUFFERING ||
                            state == androidx.media3.common.Player.STATE_IDLE
                    }
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        loading = false
                        playbackError = true
                    }
                    override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                        if (videoSize.height > 0) {
                            val ratio = (videoSize.width.toFloat() * videoSize.pixelWidthHeightRatio) / videoSize.height.toFloat()
                            if (ratio.isFinite() && ratio > 0f) aspectRatio = ratio.coerceIn(0.45f, 3.0f)
                        }
                    }
                })
                setMediaItem(androidx.media3.common.MediaItem.fromUri(absoluteUrl))
                prepare()
            }
    }

    DisposableEffect(player) {
        onDispose {
            runCatching { player.stop() }
            runCatching { player.release() }
        }
    }

    LaunchedEffect(player, autoPlay, lifecycleOwner) {
        if (autoPlay && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            player.playWhenReady = true
            player.play()
        } else {
            player.playWhenReady = false
            player.pause()
        }
    }

    DisposableEffect(lifecycleOwner, player, autoPlay) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> if (autoPlay) {
                    player.playWhenReady = true
                    player.play()
                }
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    player.pause()
                    player.playWhenReady = false
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val isTikTokStyle = aspectRatio < 0.95f
    val mediaModifier = if (fullscreen && isTikTokStyle) {
        Modifier.fillMaxSize()
    } else {
        Modifier
            .fillMaxWidth()
            .aspectRatio(aspectRatio, matchHeightConstraintsFirst = false)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clip(if (fullscreen && isTikTokStyle) RoundedCornerShape(0.dp) else RoundedCornerShape(17.dp))
            .clickable(enabled = !playbackError) {
                if (player.isPlaying) {
                    player.pause()
                    player.playWhenReady = false
                } else if (autoPlay) {
                    player.playWhenReady = true
                    player.play()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { ctx ->
                android.view.TextureView(ctx).apply {
                    isOpaque = false
                    player.setVideoTextureView(this)
                }
            },
            update = { view -> player.setVideoTextureView(view) },
            onRelease = { view -> runCatching { player.clearVideoTextureView(view) } },
            modifier = mediaModifier
        )
        if (loading) {
            CircularProgressIndicator(color = GhostRedPrimary, modifier = Modifier.size(28.dp))
        }
        if (playbackError) {
            Icon(Icons.Outlined.ErrorOutline, trKey("video_could_not_loaded"), tint = GhostRedPrimary, modifier = Modifier.size(34.dp))
        }
        if (!autoPlay && !loading && !playbackError) {
            Box(Modifier.align(Alignment.Center).size(58.dp).clip(CircleShape).background(Color.Black.copy(alpha = .42f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.PlayArrow, trKey("videonu_oynat"), tint = Color.White, modifier = Modifier.size(34.dp))
            }
        }
    }
}

@Composable private fun ActionButton(icon:androidx.compose.ui.graphics.vector.ImageVector,text:String,onClick:()->Unit){TextButton(onClick=onClick){Icon(icon,null);Spacer(Modifier.width(5.dp));Text(text)}}
@Composable
private fun StoryExpiryBar(story: StoryItem, modifier: Modifier = Modifier) {
    var now by remember(story.id) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(story.id) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val created = parseUtcMillis(story.createdAt)
    val expires = parseUtcMillis(story.expiresAt)
    val total = (expires - created).coerceAtLeast(1L)
    val remaining = (expires - now).coerceAtLeast(0L)
    val progress = (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    androidx.compose.material3.LinearProgressIndicator(
        progress = { progress },
        modifier = modifier.height(4.dp).clip(RoundedCornerShape(6.dp)),
        color = GhostGoldText,
        trackColor = GhostSurface
    )
}

private fun parseUtcMillis(value: String): Long {
    return runCatching {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        fmt.parse(value)?.time ?: System.currentTimeMillis()
    }.getOrDefault(System.currentTimeMillis())
}
private const val STORY_LIFETIME_DAYS = 7

private fun timeLeft(expires:String):String{try{val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);fmt.timeZone=TimeZone.getTimeZone("UTC");val ms=fmt.parse(expires)?.time?:return com.vghost.app.i18n.VGhostLanguage.trfKey("days_hours_left", STORY_LIFETIME_DAYS, 0);val d=ms-System.currentTimeMillis();if(d<=0)return trKey("expired");val days=d/86400000;val h=(d%86400000)/3600000;return if(days>0)com.vghost.app.i18n.VGhostLanguage.trfKey("days_hours_left", days, h) else com.vghost.app.i18n.VGhostLanguage.trfKey("hours_left", h)}catch(_:Throwable){return com.vghost.app.i18n.VGhostLanguage.trfKey("days_hours_left", STORY_LIFETIME_DAYS, 0)}}
