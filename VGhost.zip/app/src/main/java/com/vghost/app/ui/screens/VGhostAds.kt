package com.vghost.app.ui.screens

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.MobileAds

/**
 * Crash-safe, lazy Google Mobile Ads initialization.
 * Ads are never initialized from the launcher Activity. If the ads SDK cannot
 * initialize on a device, the rest of VGhost continues without ads.
 */
internal object VGhostAds {
    private val lock = Any()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var initialized = false
    private var initializing = false
    private val pending = mutableListOf<() -> Unit>()

    fun initialize(context: Context, after: () -> Unit) {
        synchronized(lock) {
            if (initialized) {
                mainHandler.post(after)
                return
            }
            pending += after
            if (initializing) return
            initializing = true
        }

        try {
            MobileAds.initialize(context.applicationContext) {
                val actions = synchronized(lock) {
                    initialized = true
                    initializing = false
                    pending.toList().also { pending.clear() }
                }
                actions.forEach { action -> mainHandler.post(action) }
            }
        } catch (_: Throwable) {
            // Never let an ad SDK/runtime failure crash VGhost.
            synchronized(lock) {
                initializing = false
                pending.clear()
            }
        }
    }
}
