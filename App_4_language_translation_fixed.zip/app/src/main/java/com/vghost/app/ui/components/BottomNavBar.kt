package com.vghost.app.ui.components
import com.vghost.app.i18n.trKey

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.filled.LocalMovies
import androidx.compose.material.icons.outlined.Whatshot
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.i18n.tr
import com.vghost.app.R


enum class NavTab { FILMS, CHATS, FIND, STORY, PANIC, PROFILE }

@Composable
fun VGhostBottomNavBar(
    currentTab: NavTab,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(22.dp)
            .background(Color(0xFF050207).copy(alpha = 0.97f))
    ) {
        HorizontalDivider(thickness = 1.dp, color = Color(0xFF5E174E).copy(.55f))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .height(76.dp)
                .padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeonBottomNavItem(
                selected = currentTab == NavTab.FILMS,
                accent = Color(0xFFFF1F58),
                accent2 = Color(0xFF8A3CFF),
                icon = Icons.Filled.LocalMovies,
                contentDescription = trKey("bottom_films"),
                testTag = "nav_films",
                onClick = { onTabSelected(NavTab.FILMS) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.STORY,
                accent = Color(0xFFFF3154),
                accent2 = Color(0xFFFF6A4A),
                icon = Icons.Outlined.Whatshot,
                contentDescription = trKey("trailer_nav"),
                testTag = "nav_story",
                onClick = { onTabSelected(NavTab.STORY) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.FIND,
                accent = Color(0xFFB45CFF),
                accent2 = Color(0xFF7D4DFF),
                icon = Icons.Outlined.People,
                contentDescription = trKey("bottom_people"),
                testTag = "nav_find",
                onClick = { onTabSelected(NavTab.FIND) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.CHATS,
                accent = Color(0xFF22C8FF),
                accent2 = Color(0xFF5968FF),
                icon = Icons.Outlined.ChatBubbleOutline,
                contentDescription = trKey("chat"),
                testTag = "nav_chats",
                onClick = { onTabSelected(NavTab.CHATS) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.PROFILE,
                accent = Color(0xFFFFD54A),
                accent2 = Color(0xFFFFA000),
                icon = Icons.Outlined.Person,
                contentDescription = trKey("profile"),
                testTag = "nav_profile",
                onClick = { onTabSelected(NavTab.PROFILE) }
            )
        }
    }
}

@Composable
private fun NeonBottomNavItem(
    selected: Boolean,
    accent: Color,
    accent2: Color,
    icon: ImageVector,
    contentDescription: String,
    testTag: String,
    onClick: () -> Unit
) {
    val iconSize = if (selected) 40.dp else 34.dp
    val glow = if (selected) 22.dp else 12.dp
    Box(
        modifier = Modifier
            .width(72.dp)
            .height(68.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier
                .size(iconSize)
                .shadow(glow, CircleShape, ambientColor = accent.copy(.85f), spotColor = accent2.copy(.75f))
        )
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .width(48.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(accent, accent2)))
                    .shadow(10.dp, RoundedCornerShape(50), ambientColor = accent.copy(.9f), spotColor = accent2.copy(.75f))
            )
        }
    }
}
