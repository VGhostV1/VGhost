package com.vghost.app.ui.screens

import com.vghost.app.i18n.trKey

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.UserListEntry
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.*
import com.vghost.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

private enum class PeopleFilter(val label: String, val icon: String, val color: Color, val api: String) {
    ALL("Hamısı", "👥", Color(0xFF24D9FF), "all"),
    ONLINE("Onlayn", "🟢", Color(0xFF19E64D), "online"),
    VIP("VIP", "👑", Color(0xFFFFD23F), "vip"),
    FRIENDS("Dostlar", "❤️", Color(0xFFFF2F9A), "friends")
}


private fun filterLabel(filter: PeopleFilter): String = when (filter) {
    PeopleFilter.ALL -> trKey("people_all")
    PeopleFilter.ONLINE -> trKey("people_online_filter")
    PeopleFilter.VIP -> trKey("films_vip")
    PeopleFilter.FRIENDS -> trKey("people_friends_filter")
}

@Composable
fun FindByNicknameScreen(
    onNavigateBack: () -> Unit,
    onUserSelected: (UserListEntry) -> Unit,
    onOpenChat: (String) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    onOpenVip: () -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(PeopleFilter.VIP) }
    var users by remember { mutableStateOf<List<UserListEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    var retryToken by remember { mutableStateOf(0) }

    suspend fun reload() {
        loading = true
        failed = false
        val result = withTimeoutOrNull(7000L) {
            repository.getUsersDirectory(filter.api, query)
        }
        if (result == null) {
            users = emptyList()
            failed = true
        } else {
            users = result
        }
        loading = false
    }

    LaunchedEffect(filter, query, retryToken) {
        if (query.isNotBlank()) delay(300)
        reload()
    }

    BackHandler { onNavigateBack() }

    val accent = filter.color
    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = { VGhostBottomNavBar(currentTab = NavTab.FIND, onTabSelected = onTabSelected) }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner).padding(horizontal = 16.dp)) {
            Row(
                Modifier.fillMaxWidth().height(76.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("find_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri", tint = GhostTextWhite, modifier = Modifier.size(30.dp))
                }
                Text(
                    trKey("people_title"),
                    color = GhostTextWhite,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = onOpenVip,
                    modifier = Modifier
                        .height(52.dp)
                        .padding(start = 6.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        "👑 VIP",
                        color = Color(0xFFFFD23F),
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text(trKey("people_search"), color = GhostTextMuted) },
                leadingIcon = { Icon(Icons.Outlined.Search, null, tint = accent, modifier = Modifier.size(28.dp)) },
                trailingIcon = { if (query.isNotBlank()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, "Təmizlə", tint = GhostTextMuted) } },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF07101B).copy(.92f),
                    unfocusedContainerColor = Color(0xFF07101B).copy(.72f),
                    focusedBorderColor = accent,
                    unfocusedBorderColor = GhostBorder.copy(.7f),
                    focusedTextColor = GhostTextWhite,
                    unfocusedTextColor = GhostTextWhite,
                    cursorColor = accent
                ),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth().height(64.dp).testTag("find_nickname_input")
            )

            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // VIP intentionally comes first because it is the premium entry point.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PeopleFilterButton(PeopleFilter.VIP, filter == PeopleFilter.VIP, { filter = PeopleFilter.VIP }, Modifier.weight(1f))
                    PeopleFilterButton(PeopleFilter.ONLINE, filter == PeopleFilter.ONLINE, { filter = PeopleFilter.ONLINE }, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PeopleFilterButton(PeopleFilter.ALL, filter == PeopleFilter.ALL, { filter = PeopleFilter.ALL }, Modifier.weight(1f))
                    PeopleFilterButton(PeopleFilter.FRIENDS, filter == PeopleFilter.FRIENDS, { filter = PeopleFilter.FRIENDS }, Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when (filter) { PeopleFilter.ALL -> "🌐 KƏŞF"; PeopleFilter.ONLINE -> "🟢 İNDİ ONLAYN"; PeopleFilter.VIP -> "👑 VIP İNSANLAR"; PeopleFilter.FRIENDS -> "❤️ DOSTLAR" },
                        color = accent, fontSize = 19.sp, fontWeight = FontWeight.Black
                    )
                    Text(if (query.isBlank()) trKey("people_for_you") else trKey("people_results"), color = GhostTextMuted, fontSize = 15.sp)
                }
                Text("${users.size}", color = GhostTextSecondary, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(8.dp))
            when {
                loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = accent, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.height(12.dp))
                        Text(trKey("people_loading"), color = GhostTextSecondary, fontSize = 12.sp)
                    }
                }
                failed -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚠️", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(trKey("people_load_failed"), color = GhostTextWhite, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = { retryToken++ }) { Text(trKey("retry")) }
                    }
                }
                users.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(trKey("people_empty"), color = GhostTextMuted, fontSize = 13.sp)
                }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(users, key = { "person_${it.uid}" }) { user ->
                        PeopleCard(user, accent, onUserSelected)
                    }
                }
            }
        }
    }
}

@Composable
private fun PeopleFilterButton(
    f: PeopleFilter,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) f.color.copy(alpha = .14f) else Color(0xFF07101B).copy(alpha = .72f),
        border = androidx.compose.foundation.BorderStroke(
            width = if (selected) 1.dp else 0.8.dp,
            color = if (selected) f.color.copy(alpha = .78f) else GhostBorder.copy(alpha = .65f)
        )
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(f.icon, fontSize = 22.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                f.label.uppercase(),
                color = if (selected) f.color else GhostTextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PeopleCard(user: UserListEntry, accent: Color, onClick: (UserListEntry) -> Unit) {
    val border = GhostBorder.copy(alpha = .55f)
    Row(
        Modifier.fillMaxWidth().height(84.dp).clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF07101B).copy(.9f)).border(1.dp, border, RoundedCornerShape(18.dp))
            .clickable { onClick(user) }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
            // VIP framing is reserved for My Profile / Other Profile; keep this directory clean.
            GhostAvatar(size = 54.dp, showBorder = true, avatarId = user.avatarId, avatarUrl = user.avatarUrl)
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (user.online) Color(0xFF19E64D) else GhostTextMuted).border(2.dp, Color(0xFF07101B), CircleShape).align(Alignment.BottomEnd))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (user.isVip) Text("👑 ", fontSize = 16.sp)
                if (user.isVip) NeonVipName(user.nickname, fontSize = 15.sp, maxLines = 1) else Text(user.nickname, color = GhostTextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (user.online) trKey("people_online") else trKey("people_offline"), color = if (user.online) Color(0xFF19E64D) else GhostTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text("LV ${user.level}", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
        }
        Icon(Icons.Outlined.PersonAdd, null, tint = accent, modifier = Modifier.size(22.dp))
    }
}
