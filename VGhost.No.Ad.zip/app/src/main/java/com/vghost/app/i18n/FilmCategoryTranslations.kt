package com.vghost.app.i18n

/** Main film categories shown in the app/admin. Backend values stay canonical. */
val mainFilmCategories = listOf(
    "Drama", "Aksiya", "Komediya", "Romantik", "Qorxu", "Fantastika",
    "Macəra", "Triller", "Detektiv", "Animasiya", "Ailə"
)

/** Short, localized film-category labels with a visual emoji. */
fun localizedFilmCategory(value: String): String {
    val normalized = value.trim().lowercase()
    val (key, emoji) = when (normalized) {
        "aksiya", "action" -> "film_cat_action" to "⚔️"
        "komediya", "komedi", "comedy" -> "film_cat_comedy" to "😂"
        "dram", "drama" -> "film_cat_drama" to "🎭"
        "romantik", "romantika", "romance", "romantic" -> "film_cat_romance" to "❤️"
        "qorxu", "korku", "horror" -> "film_cat_horror" to "👻"
        "fantastika", "fantasy" -> "film_cat_fantasy" to "🧙"
        "macəra", "macera", "adventure" -> "film_cat_adventure" to "🗺️"
        "triller", "thriller" -> "film_cat_thriller" to "🔪"
        "detektiv", "detective" -> "film_cat_detective" to "🕵️"
        "animasiya", "animation" -> "film_cat_animation" to "🎨"
        "ailə", "aile", "family" -> "film_cat_family" to "👨‍👩‍👧"
        "kriminal", "crime", "cinayət" -> "film_cat_crime" to "🕶️"
        "döyüş", "doyus", "döyüş filmi", "martial arts" -> "film_cat_action" to "🥋"
        "tarixi", "historical" -> "film_cat_historical" to "🏛️"
        "tarix", "history" -> "film_cat_history" to "📜"
        "sənədli", "senedli", "documentary" -> "film_cat_documentary" to "📚"
        "musiqili", "musical" -> "film_cat_musical" to "🎵"
        "elmi-fantastika", "science fiction", "sci-fi" -> "film_cat_scifi" to "🚀"
        "bioqrafiya", "biography" -> "film_cat_biography" to "👤"
        "misteriya", "mystery", "sirr" -> "film_cat_mystery" to "🧩"
        else -> return value
    }
    return "$emoji ${trKey(key)}"
}
