package com.vghost.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostStatusOnline
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostSurfaceElevated
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.webrtc.SurfaceViewRenderer

/** Premium VGhost WebRTC call surface. Keeps the existing signaling/controller, upgrades only UX/UI. */
@Composable
fun WebRtcCallScreen(
    callId: Long,
    callType: String,
    remoteName: String,
    remoteAvatarId: String = "ghost",
    isCaller: Boolean,
    onClosed: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val videoEnabled = callType.equals("video", true)
    var micEnabled by remember { mutableStateOf(true) }
    var cameraEnabled by remember { mutableStateOf(videoEnabled) }
    var speakerEnabled by remember { mutableStateOf(true) }
    var permissionReady by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
                (!videoEnabled || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
        )
    }
    var ended by remember { mutableStateOf(false) }
    var elapsed by remember { mutableIntStateOf(0) }
    val controller = remember(callId) { WebRtcCallController(context, callId, callType, isCaller) }
    val state by controller.state.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        permissionReady = result[Manifest.permission.RECORD_AUDIO] == true && (!videoEnabled || result[Manifest.permission.CAMERA] == true)
    }

    LaunchedEffect(state.connectionState) {
        if (state.connectionState == "CONNECTED") {
            while (!ended) { delay(1000); elapsed++ }
        }
    }

    fun closeCall() {
        if (ended) return
        ended = true
        scope.launch {
            try { VGhostApi.call("call/end", "POST", JSONObject().put("call_id", callId)) } catch (_: Throwable) {}
        }
        controller.stop()
        onClosed()
    }

    DisposableEffect(callId, permissionReady) {
        if (permissionReady) controller.start(scope)
        onDispose { controller.stop() }
    }

    LaunchedEffect(permissionReady) {
        if (!permissionReady) {
            val permissions = buildList {
                add(Manifest.permission.RECORD_AUDIO)
                if (videoEnabled) add(Manifest.permission.CAMERA)
            }.toTypedArray()
            permissionLauncher.launch(permissions)
        }
    }

    LaunchedEffect(state.connectionState) {
        if (state.connectionState == "CLOSED" || state.connectionState == "FAILED") {
            delay(350)
            if (!ended) { ended = true; controller.stop(); onClosed() }
        }
    }

    val pulse = rememberInfiniteTransition(label = "callPulse")
    val pulseScale by pulse.animateFloat(1f, 1.16f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulseScale")
    val glowAlpha by pulse.animateFloat(.20f, .55f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glowAlpha")

    val status = when {
        !permissionReady -> "Microphone / camera permission"
        state.connectionState == "CONNECTED" -> "Connected"
        state.connectionState == "RINGING" -> "Ringing…"
        state.connectionState == "CONNECTING" -> "Connecting…"
        else -> "Securing connection…"
    }
    val timeText = "%02d:%02d".format(elapsed / 60, elapsed % 60)

    Dialog(
        onDismissRequest = { closeCall() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF240711), Color(0xFF08090D), Color.Black),
                    radius = 1100f
                )
            )
        ) {
            if (videoEnabled && permissionReady) {
                AndroidView(
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).also { view ->
                            view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            view.init(controller.eglContext, null)
                            view.setEnableHardwareScaler(true)
                            view.setMirror(false)
                            controller.setRemoteRenderer(view)
                        }
                    },
                    update = { controller.setRemoteRenderer(it) }
                )
                if (cameraEnabled) {
                    AndroidView(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 54.dp, end = 18.dp)
                            .size(118.dp, 166.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .border(1.dp, Color.White.copy(alpha = .25f), RoundedCornerShape(24.dp)),
                        factory = { ctx ->
                            SurfaceViewRenderer(ctx).also { view ->
                                view.layoutParams = ViewGroup.LayoutParams(118.dp.value.toInt(), 166.dp.value.toInt())
                                view.init(controller.eglContext, null)
                                view.setEnableHardwareScaler(true)
                                view.setMirror(true)
                                controller.setLocalRenderer(view)
                            }
                        },
                        update = { controller.setLocalRenderer(it) }
                    )
                }
            } else {
                // Voice-call hero state: avatar + breathing neon ring.
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(270.dp).scale(pulseScale).clip(CircleShape)
                            .background(GhostRedPrimary.copy(alpha = glowAlpha))
                    )
                    Box(
                        Modifier.size(222.dp).clip(CircleShape)
                            .background(GhostSurface)
                            .border(2.dp, GhostRedPrimary.copy(alpha = .85f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { GhostAvatar(size = 176.dp, showBorder = true, avatarId = remoteAvatarId) }
                }
            }

            Column(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.clip(RoundedCornerShape(50.dp)).background(Color.Black.copy(alpha = .55f)).padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(if (state.connectionState == "CONNECTED") GhostStatusOnline else GhostRedPrimary))
                    Spacer(Modifier.width(7.dp))
                    Text(status, color = Color.White, fontSize = 12.sp)
                    if (state.connectionState == "CONNECTED") { Spacer(Modifier.width(10.dp)); Text(timeText, color = Color.White.copy(.7f), fontSize = 12.sp) }
                }
                Spacer(Modifier.height(12.dp))
                Text(remoteName, color = Color.White, fontSize = 22.sp)
                if (!videoEnabled || state.connectionState != "CONNECTED") Text(if (videoEnabled) "Video call" else "Voice call", color = Color.White.copy(.65f), fontSize = 12.sp)
            }

            if (videoEnabled && state.connectionState == "CONNECTED") {
                Row(
                    Modifier.align(Alignment.Center).padding(top = 80.dp).clip(RoundedCornerShape(50.dp))
                        .background(Color.Black.copy(alpha = .45f)).padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🔒  Encrypted", color = Color.White.copy(.88f), fontSize = 11.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("•", color = GhostStatusOnline)
                    Spacer(Modifier.width(8.dp))
                    Text("Excellent", color = GhostStatusOnline, fontSize = 11.sp)
                }
            }

            Row(
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp)
                    .clip(RoundedCornerShape(34.dp)).background(Color.Black.copy(alpha = .68f))
                    .border(1.dp, Color.White.copy(alpha = .12f), RoundedCornerShape(34.dp)).padding(horizontal = 12.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PremiumCallButton(
                    icon = if (micEnabled) Icons.Filled.Mic else Icons.Filled.MicOff,
                    label = if (micEnabled) "Mic" else "Muted",
                    active = micEnabled,
                    onClick = { micEnabled = !micEnabled; controller.setMicEnabled(micEnabled) }
                )
                if (videoEnabled) {
                    PremiumCallButton(
                        icon = if (cameraEnabled) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                        label = "Camera", active = cameraEnabled,
                        onClick = { cameraEnabled = !cameraEnabled; controller.setCameraEnabled(cameraEnabled) }
                    )
                    PremiumCallButton(Icons.Filled.Cameraswitch, "Switch", true) { controller.switchCamera() }
                } else {
                    PremiumCallButton(Icons.Filled.VolumeUp, "Speaker", speakerEnabled, onClick = { speakerEnabled = !speakerEnabled })
                }
                Box(
                    Modifier.size(68.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFFF5268), Color(0xFFE5092D))))
                        .border(1.dp, Color.White.copy(alpha = .25f), CircleShape), contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = { closeCall() }, modifier = Modifier.fillMaxSize()) {
                        Icon(Icons.Filled.CallEnd, "End call", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumCallButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(52.dp).clip(CircleShape)
                .background(if (active) Color.White.copy(.10f) else GhostRedPrimary.copy(.28f))
                .border(1.dp, if (active) Color.White.copy(.16f) else GhostRedPrimary.copy(.55f), CircleShape)
        ) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(23.dp)) }
        Spacer(Modifier.height(3.dp))
        Text(label, color = Color.White.copy(.72f), fontSize = 9.sp)
    }
}
