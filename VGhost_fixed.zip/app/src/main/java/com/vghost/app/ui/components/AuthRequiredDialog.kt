package com.vghost.app.ui.components

import com.vghost.app.i18n.trKey
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AuthRequiredDialog(
    onRegister: () -> Unit,
    onLogin: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF100911),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFBDB4C5),
        confirmButton = {
            // Registration is intentionally a compact text action instead of a
            // full-width red card, so Login and Back remain visible on small screens.
            TextButton(
                onClick = onRegister,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    trKey("register"),
                    color = Color(0xFFFF4B68),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            Column(Modifier.fillMaxWidth()) {
                TextButton(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Text(trKey("login"), color = Color(0xFFB86CFF), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text(trKey("back"), color = Color(0xFFA9A1AE), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        },
        title = { Text(trKey("account_required"), fontSize = 24.sp, fontWeight = FontWeight.Black) },
        text = {
            Text(
                trKey("account_required_message"),
                fontSize = 16.sp,
                lineHeight = 23.sp
            )
        }
    )
}
