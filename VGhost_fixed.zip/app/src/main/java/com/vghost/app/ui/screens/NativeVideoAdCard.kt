package com.vghost.app.ui.screens

import android.graphics.Color as AndroidColor
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.gms.ads.VideoOptions
import com.vghost.app.ui.theme.GhostRedPrimary

private const val TEST_NATIVE_VIDEO_AD_UNIT = "ca-app-pub-3940256099942544/1044960115"

/**
 * Full-page native video test ad used only inside the Trailer/Reels feed.
 * Google handles the video playback, click tracking and AdChoices overlay.
 */
@Composable
fun NativeVideoAdCard() {
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }
    var failed by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        val videoOptions = VideoOptions.Builder()
            .setStartMuted(true)
            .build()
        val nativeOptions = NativeAdOptions.Builder()
            .setVideoOptions(videoOptions)
            .build()

        val loader = AdLoader.Builder(context, TEST_NATIVE_VIDEO_AD_UNIT)
            .forNativeAd { ad -> nativeAd = ad }
            .withNativeAdOptions(nativeOptions)
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    failed = true
                }
            })
            .build()

        loader.loadAd(AdRequest.Builder().build())

        onDispose {
            nativeAd?.destroy()
            nativeAd = null
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        when {
            nativeAd != null -> AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx -> createNativeAdView(ctx) },
                update = { adView ->
                    bindNativeAd(adView, nativeAd!!)
                }
            )
            failed -> Text(
                text = "Test reklamı yüklənmədi",
                color = Color.White.copy(alpha = .75f),
                fontSize = 14.sp
            )
            else -> CircularProgressIndicator(color = GhostRedPrimary)
        }
    }
}

private fun createNativeAdView(context: android.content.Context): NativeAdView {
    val adView = NativeAdView(context).apply {
        setBackgroundColor(AndroidColor.BLACK)
    }

    val column = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(20, 24, 20, 24)
    }

    val label = TextView(context).apply {
        text = "Reklam • TEST"
        setTextColor(AndroidColor.LTGRAY)
        textSize = 12f
        gravity = Gravity.CENTER
    }
    column.addView(label, LinearLayout.LayoutParams(-1, 36))

    val media = MediaView(context).apply {
        setBackgroundColor(AndroidColor.BLACK)
    }
    column.addView(media, LinearLayout.LayoutParams(-1, 0, 1f))

    val headline = TextView(context).apply {
        setTextColor(AndroidColor.WHITE)
        textSize = 20f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        maxLines = 2
        setPadding(0, 18, 0, 4)
    }
    column.addView(headline, LinearLayout.LayoutParams(-1, -2))

    val advertiser = TextView(context).apply {
        setTextColor(AndroidColor.GRAY)
        textSize = 13f
        maxLines = 1
    }
    column.addView(advertiser, LinearLayout.LayoutParams(-1, -2))

    val cta = TextView(context).apply {
        setTextColor(AndroidColor.WHITE)
        textSize = 15f
        gravity = Gravity.CENTER
        setBackgroundColor(AndroidColor.rgb(230, 25, 60))
        setPadding(24, 12, 24, 12)
    }
    val ctaParams = LinearLayout.LayoutParams(-2, -2).apply {
        topMargin = 12
        gravity = Gravity.CENTER_HORIZONTAL
    }
    column.addView(cta, ctaParams)

    adView.addView(column, android.widget.FrameLayout.LayoutParams(-1, -1))
    adView.mediaView = media
    adView.headlineView = headline
    adView.advertiserView = advertiser
    adView.callToActionView = cta
    return adView
}

private fun bindNativeAd(adView: NativeAdView, ad: NativeAd) {
    adView.headlineView?.let { (it as TextView).text = ad.headline.orEmpty() }
    adView.advertiserView?.let { (it as TextView).text = ad.advertiser.orEmpty() }
    adView.callToActionView?.let { view ->
        view.isEnabled = !ad.callToAction.isNullOrBlank()
        (view as TextView).text = ad.callToAction.orEmpty()
    }
    adView.mediaView?.mediaContent = ad.mediaContent
    adView.setNativeAd(ad)
}
