package com.vghost.app.ui.screens

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trKey
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.LocalMovies
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.Whatshot
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.R
import com.vghost.app.data.model.Film
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.network.VGhostApi
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.VGhostCoinAmount
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextWhite
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray

private val FilmRed = Color(0xFFFF173B)
private val FilmPink = Color(0xFFFF4A78)
private val FilmPurple = Color(0xFF8B38FF)
private val FilmGold = Color(0xFFFFC83D)
private val FilmSurface = Color(0xFF120A12)

@Composable
fun FilmHomeScreen(
    onAdminSecret: () -> Unit,
    onOpenLanguage: () -> Unit,
    onFilmSelected: (Long) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val coins by repository.ghostCoins.collectAsState()
    var adminTaps by remember { mutableStateOf(0) }
    var search by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var selectedYear by remember { mutableStateOf<Int?>(null) }
    var films by remember { mutableStateOf<List<Film>>(emptyList()) }
    var popularFilms by remember { mutableStateOf<List<Film>>(emptyList()) }
    var newFilms by remember { mutableStateOf<List<Film>>(emptyList()) }
    var categories by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    suspend fun load() {
        loading = true
        error = ""
        try {
            // All three film feeds are independent. Await them together so the UI
            // gets one atomic result and never serializes network/JSON work.
            coroutineScope {
                val requests = listOf(
                    async(Dispatchers.IO) { VGhostApi.films(search.trim(), selectedCategory, year = selectedYear) },
                    async(Dispatchers.IO) { VGhostApi.films(search.trim(), selectedCategory, year = selectedYear, sort = "popular") },
                    async(Dispatchers.IO) { VGhostApi.films(search.trim(), selectedCategory, year = selectedYear, sort = "new") }
                )
                val results = requests.awaitAll()
                val result = results[0]
                val a = result.optJSONArray("films") ?: JSONArray()
                films = (0 until a.length()).map { i -> a.getJSONObject(i).toFilm() }
                val pa = results[1].optJSONArray("films") ?: JSONArray()
                popularFilms = (0 until pa.length()).map { i -> pa.getJSONObject(i).toFilm() }.take(10)
                val na = results[2].optJSONArray("films") ?: JSONArray()
                newFilms = (0 until na.length()).map { i -> na.getJSONObject(i).toFilm() }.take(10)
            }
        } catch (e: Throwable) {
            error = e.message.orEmpty()
        }
        loading = false
    }

    LaunchedEffect(Unit) {
        runCatching {
            val c = VGhostApi.filmCategories().optJSONArray("categories") ?: JSONArray()
            categories = (0 until c.length()).map { c.getString(it) }
        }
    }

    LaunchedEffect(search, selectedCategory, selectedYear) { delay(250); load() }
    LaunchedEffect(Unit) {
        while (true) {
            if (repository.hasAccount()) repository.refreshMyWallet()
            delay(15_000L)
        }
    }

    Box(modifier.fillMaxSize().premiumBackdrop()) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = { VGhostBottomNavBar(NavTab.FILMS, onTabSelected) }
        ) { inner ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(inner),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 22.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    FilmHeader(
                        coins = coins.toLong(),
                        onOpenLanguage = onOpenLanguage,
                        onCoinTap = {
                            adminTaps++
                            if (adminTaps >= 7) {
                                adminTaps = 0
                                onAdminSecret()
                            }
                        }
                    )
                }

                item {
                    FilmSearchBar(value = search, onValueChange = { search = it })
                }

                if (categories.isNotEmpty()) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item { FilmChip(tr("Hamısı"), selectedCategory.isBlank()) { selectedCategory = "" } }
                            items(categories) { category ->
                                FilmChip(localizedFilmCategory(category), selectedCategory.equals(category, true)) {
                                    selectedCategory = if (selectedCategory == category) "" else category
                                }
                            }
                        }
                    }
                }

                if (loading) {
                    item {
                        Box(Modifier.fillMaxWidth().height(330.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = FilmRed, strokeWidth = 3.dp)
                        }
                    }
                } else if (films.isEmpty()) {
                    item { EmptyFilmState(error) }
                } else {
                    val popular = popularFilms.ifEmpty { films.take(10) }
                    val newer = newFilms.ifEmpty { films.take(10) }

                    item {
                        FilmSectionTitle(tr("Populyar Filmlər"), Icons.Outlined.Whatshot) { }
                    }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(popular) { film ->
                                FilmPosterCard(film, onClick = { onFilmSelected(film.id) })
                            }
                        }
                    }

                    item {
                        FilmSectionTitle(trKey("film_history"), Icons.Outlined.DateRange) { }
                    }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            items((2000..2026).toList()) { year ->
                                GenrePill(year.toString(), selectedYear == year) {
                                    selectedYear = if (selectedYear == year) null else year
                                }
                            }
                        }
                    }

                    item {
                        FilmSectionTitle(tr("Yeni Filmlər"), Icons.Outlined.Star) { }
                    }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(newer) { film ->
                                FilmPosterCard(film, onClick = { onFilmSelected(film.id) })
                            }
                        }
                    }
                }
            }
        }
    }
}



@Composable
private fun FilmHeader(
    coins: Long,
    onOpenLanguage: () -> Unit,
    onCoinTap: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            FilmPink.copy(alpha = 0.30f),
                            FilmPurple.copy(alpha = 0.16f),
                            Color(0xFF0B0910).copy(alpha = 0.98f)
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(listOf(FilmPink, FilmPurple)),
                    shape = CircleShape
                )
                .shadow(26.dp, CircleShape, ambientColor = FilmPink.copy(alpha = 0.85f), spotColor = FilmPurple.copy(alpha = 0.72f))
                .clickable(onClick = onOpenLanguage),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Language,
                contentDescription = tr("language"),
                tint = GhostTextWhite,
                modifier = Modifier.size(30.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("VGhost", color = GhostTextWhite, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
            Text(tr("FİLMLƏR"), color = FilmRed, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.2.sp)
            Spacer(Modifier.height(3.dp))
            Text(tr("Sevdiyin filmlər, bir yerdə!"), color = GhostTextMuted, fontSize = 12.sp)
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF151018).copy(.96f))
                .border(1.dp, FilmGold.copy(.78f), RoundedCornerShape(24.dp))
                .clickable(onClick = onCoinTap)
                .padding(horizontal = 13.dp, vertical = 9.dp)
        ) {
            VGhostCoinAmount(text = coins.toString(), iconSize = 25.dp, fontSize = 14.sp, color = Color.White, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun FilmSearchBar(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth().height(64.dp),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        leadingIcon = { Icon(Icons.Outlined.Search, null, tint = FilmRed, modifier = Modifier.size(32.dp)) },
        trailingIcon = { Icon(Icons.Outlined.FilterList, null, tint = FilmPink) },
        placeholder = { Text(tr("Film axtar..."), color = GhostTextMuted, fontSize = 17.sp) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = FilmRed,
            unfocusedBorderColor = FilmRed.copy(.42f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = FilmRed,
            focusedContainerColor = Color(0xFF11080E).copy(.72f),
            unfocusedContainerColor = Color(0xFF11080E).copy(.55f)
        )
    )
}

@Composable
private fun FeaturedFilmCard(film: Film, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(22.dp)).border(1.dp, FilmRed.copy(.72f), RoundedCornerShape(22.dp)).clickable(onClick = onClick)
    ) {
        RemotePoster(VGhostApi.absoluteUrl(film.posterUrl))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF070207).copy(.94f), Color.Transparent, Color(0xFF08030A).copy(.35f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp).fillMaxWidth(.64f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (film.isVip) {
                    Text("♛ VIP", color = FilmGold, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF1A1300).copy(.92f)).border(1.dp, FilmGold.copy(.8f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 5.dp))
                    Spacer(Modifier.width(7.dp))
                }
                if (film.isFeatured) Text(tr("ÖNƏ ÇIXAN"), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(6.dp))
            Text(film.title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(film.description.ifBlank { tr("İndi izlə və film dünyasına qoşul.") }, color = Color.White.copy(.78f), fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(9.dp))
            Box(Modifier.clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(FilmRed, FilmPink))).padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.PlayArrow, null, tint = Color.White, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(tr("İndi izlə"), color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun FilmSectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onMore: () -> Unit) {
    val accent = when (title) {
        tr("Yeni Filmlər") -> FilmPurple
        "Tarix" -> FilmPink
        else -> FilmRed
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            icon, null, tint = accent,
            modifier = Modifier.size(30.dp).shadow(13.dp, CircleShape, ambientColor = accent.copy(.85f), spotColor = FilmPurple.copy(.65f))
        )
        Spacer(Modifier.width(10.dp))
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
        Row(Modifier.clickable(onClick = onMore), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Hamısı"), color = FilmPink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Icon(Icons.Outlined.ArrowForward, null, tint = FilmPink, modifier = Modifier.size(20.dp).shadow(8.dp, CircleShape, ambientColor = FilmPink.copy(.8f)))
        }
    }
}

@Composable
private fun FilmPosterCard(film: Film, onClick: () -> Unit) {
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(212.dp).clip(RoundedCornerShape(15.dp)).border(1.dp, Color.White.copy(.16f), RoundedCornerShape(15.dp))) {
            RemotePoster(VGhostApi.absoluteUrl(film.posterUrl))
            if (film.isVip) Text("♛ VIP", color = FilmGold, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopEnd).padding(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF151005).copy(.92f)).border(1.dp, FilmGold.copy(.78f), RoundedCornerShape(8.dp)).padding(horizontal = 6.dp, vertical = 4.dp))
            if (film.isFeatured) Text(tr("YENİ"), color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopStart).padding(7.dp).clip(RoundedCornerShape(8.dp)).background(FilmRed).padding(horizontal = 6.dp, vertical = 4.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(film.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(listOfNotNull(localizedFilmCategory(film.category).takeIf { it.isNotBlank() }, film.releaseYear?.toString()).joinToString(" • "), color = GhostTextMuted, fontSize = 14.sp, maxLines = 1)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("👁 ${compactCount(film.viewCount)}", color = GhostTextMuted, fontSize = 17.sp)
            Text("★ ${if (film.ratingCount > 0) String.format("%.1f", film.ratingAverage) else "—"}", color = FilmGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GenrePill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(18.dp)).background(if (selected) Brush.horizontalGradient(listOf(FilmRed.copy(.95f), FilmPink.copy(.72f))) else Brush.horizontalGradient(listOf(Color.White.copy(.07f), Color.White.copy(.035f)))).border(1.dp, if (selected) FilmRed else Color.White.copy(.14f), RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FilmChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(14.dp)).background(if (selected) FilmRed.copy(.18f) else Color.White.copy(.045f)).border(1.dp, if (selected) FilmRed.copy(.85f) else Color.White.copy(.11f), RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 8.dp)) {
        Text(text, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyFilmState(error: String) {
    Box(Modifier.fillMaxWidth().height(380.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(82.dp).clip(CircleShape).background(Brush.radialGradient(listOf(FilmRed.copy(.34f), Color.Transparent))).border(2.dp, FilmRed.copy(.75f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.PlayCircleOutline, null, tint = FilmRed, modifier = Modifier.size(54.dp))
            }
            Spacer(Modifier.height(15.dp))
            Text(tr("Hələ film yoxdur"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
            Text(if (error.isBlank()) tr("Yeni filmlər burada görünəcək.") else error, color = GhostTextMuted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 35.dp, vertical = 7.dp))
        }
    }
}

@Composable
private fun RemotePoster(url: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(url) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(url) {
        if (url.isNotBlank()) {
            val loaded = com.vghost.app.FilmMediaCache.load(context, url, VGhostApi.token().takeIf { VGhostApi.isSameApiOrigin(url) })
            bitmap = loaded
        }
    }
    if (bitmap != null) {
        Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF2A0D2E), Color(0xFF09060B))))) {
            Icon(Icons.Outlined.LocalMovies, null, tint = FilmRed.copy(.35f), modifier = Modifier.size(48.dp).align(Alignment.Center))
        }
    }
}


private fun org.json.JSONObject.toFilm() = Film(
    optLong("id"), optString("title"), optString("description"), optString("poster_url"), optString("video_url"), optString("category"),
    if (has("release_year") && !isNull("release_year")) optInt("release_year") else null,
    if (has("duration_minutes") && !isNull("duration_minutes")) optInt("duration_minutes") else null,
    optInt("is_vip") == 1 || optBoolean("is_vip"),
    optInt("is_featured") == 1 || optBoolean("is_featured"),
    optInt("view_count"), optInt("play_count"), optDouble("rating_average", 0.0), optInt("rating_count")
)

private fun compactCount(n:Int):String = when { n >= 1_000_000 -> String.format("%.1fM", n/1_000_000.0); n >= 1000 -> String.format("%.1fK", n/1000.0); else -> n.toString() }
