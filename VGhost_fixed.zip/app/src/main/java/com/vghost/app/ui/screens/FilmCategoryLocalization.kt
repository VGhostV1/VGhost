package com.vghost.app.ui.screens

import com.vghost.app.i18n.trKey

/** Converts server-stored film genre names to the currently selected UI language. */
fun localizedFilmCategory(raw: String): String {
    val value = raw.trim()
    return when (value.lowercase().replace("-", "_").replace(" ", "_")) {
        "action", "aksiya", "aksiyon", "döyüş", "doyus" -> trKey("film_action")
        "comedy", "komedi", "komediya" -> trKey("film_comedy")
        "drama", "dram" -> trKey("film_drama")
        "horror", "qorxu", "korku" -> trKey("film_horror")
        "fantasy", "fantastik", "fantastika" -> trKey("film_fantasy")
        "romance", "romantik", "romancefilm" -> trKey("film_romance")
        "thriller", "triller" -> trKey("film_thriller")
        "animation", "animasiya", "animasyon" -> trKey("film_animation")
        "adventure", "macəra", "macera" -> trKey("film_adventure")
        "crime", "cinayət", "kriminal", "suc", "suç" -> trKey("film_crime")
        "science_fiction", "sci_fi", "science_fiction", "elmi_fantastika", "elmi_fantastika", "bilim_kurgu", "fantastique_science" -> trKey("film_scifi")
        "detective", "detektiv", "детектив", "dedektif" -> trKey("film_detective")
        "documentary", "sənədli", "senedli", "belgesel", "документальный" -> trKey("film_documentary")
        "musical", "musiqili", "müzikal", "мюзикл" -> trKey("film_musical")
        "biography", "bioqrafiya", "biyografi", "биография" -> trKey("film_biography")
        "mystery", "misteriya", "gizem", "мистика", "тайна" -> trKey("film_mystery")
        "historical", "history", "tarix", "tarixi", "tarih", "история" -> trKey("film_history")
        else -> value
    }
}
