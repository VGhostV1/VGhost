-- VGHOST v38: message media attachment columns
ALTER TABLE messages ADD COLUMN IF NOT EXISTS attachment_path VARCHAR(500) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS attachment_type VARCHAR(80) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS attachment_name VARCHAR(255) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS attachment_size BIGINT UNSIGNED NULL;
