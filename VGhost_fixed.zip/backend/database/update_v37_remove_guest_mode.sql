-- V37: remove obsolete guest-mode story view storage.
-- Story views are authenticated; guest/public story access is disabled.
DROP TABLE IF EXISTS story_guest_views;
