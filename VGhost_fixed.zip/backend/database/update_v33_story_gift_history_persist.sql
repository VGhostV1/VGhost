-- Preserve Story Gift history after a Story expires/is deleted.
-- Run this once on installations that already ran update_v32_story_gifts.sql.
SET @fk := (
  SELECT CONSTRAINT_NAME
  FROM information_schema.KEY_COLUMN_USAGE
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'story_gift_transactions'
    AND COLUMN_NAME = 'story_id'
    AND REFERENCED_TABLE_NAME = 'stories'
  LIMIT 1
);
SET @sql := IF(@fk IS NULL, 'SELECT 1', CONCAT('ALTER TABLE story_gift_transactions DROP FOREIGN KEY `', @fk, '`'));
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
