-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Hazırlanma Vaxtı: 26 Sent, 2026 saat 09:59
-- Server versiyası: 10.11.19-MariaDB-cll-lve
-- PHP Versiyası: 8.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Verilənlər Bazası: `vghostsite_VG`
--

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `admins`
--

CREATE TABLE `admins` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'admin',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `admins`
--

INSERT INTO `admins` (`user_id`, `role`, `created_at`) VALUES
(1, 'super_admin', '2026-09-22 00:00:00');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `admin_coin_code_reset_tokens`
--

CREATE TABLE `admin_coin_code_reset_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `admin_coin_security`
--

CREATE TABLE `admin_coin_security` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `admin_user_id` bigint(20) UNSIGNED NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `admin_coin_security`
--

INSERT INTO `admin_coin_security` (`id`, `admin_user_id`, `code_hash`, `locked`, `updated_at`) VALUES
(1, 1, '$2y$12$BVGjkdZkPPtOEfO9aC9wVOtysplaSe/uyHktxnUgPEHQI048cxYWe', 0, '2026-09-24 16:28:56');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `admin_logs`
--

CREATE TABLE `admin_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_user_id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(100) NOT NULL,
  `target_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `admin_logs`
--

INSERT INTO `admin_logs` (`id`, `admin_user_id`, `action`, `target_user_id`, `details`, `created_at`) VALUES
(1, 1, 'broadcast', NULL, '{\"title\":\"VGhost\",\"body\":\"Hamiya Salam\",\"link\":\"https:\\/\\/vghost.site\",\"devices\":3,\"pushSent\":2,\"failed\":1,\"delivery\":\"fcm\",\"reason\":\"\"}', '2026-09-23 16:25:30'),
(2, 1, 'admin_coin_balance_edit', 1, '{\"oldBalance\":898458,\"newBalance\":1000000,\"delta\":101542}', '2026-09-24 09:49:03'),
(3, 1, 'admin_coin_balance_edit', 2, '{\"oldBalance\":822319,\"newBalance\":1000000,\"delta\":177681}', '2026-09-24 09:49:40'),
(4, 1, 'admin_security_denied', NULL, '{\"reason\":\"invalid_confirmation_code\"}', '2026-09-24 16:29:09');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `admin_security_attempts`
--

CREATE TABLE `admin_security_attempts` (
  `admin_user_id` bigint(20) UNSIGNED NOT NULL,
  `failed_attempts` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `admin_security_attempts`
--

INSERT INTO `admin_security_attempts` (`admin_user_id`, `failed_attempts`, `locked_until`, `updated_at`) VALUES
(1, 1, NULL, '2026-09-24 16:29:09');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `api_idempotency_keys`
--

CREATE TABLE `api_idempotency_keys` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `endpoint` varchar(120) NOT NULL,
  `idem_key_hash` char(64) NOT NULL,
  `request_hash` char(64) NOT NULL,
  `status` enum('pending','completed') NOT NULL DEFAULT 'pending',
  `response_json` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `app_notifications`
--

CREATE TABLE `app_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(64) NOT NULL,
  `title` varchar(190) NOT NULL,
  `body` text NOT NULL,
  `data_json` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `read_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `app_notifications`
--

INSERT INTO `app_notifications` (`id`, `user_id`, `type`, `title`, `body`, `data_json`, `is_read`, `created_at`, `read_at`) VALUES
(5, 2, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 1, '2026-09-22 15:31:21', '2026-09-25 10:44:43'),
(8, 2, 'friend_accepted', 'Dostluq qəbul edildi', 'Admin dostluq istəyini qəbul etdi.', '{\"userId\":\"1\",\"nickname\":\"Admin\",\"senderId\":\"1\",\"senderUid\":\"1\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"targetValue\":\"Admin\",\"sender\":\"Admin\",\"count\":1}', 1, '2026-09-22 17:52:56', '2026-09-25 10:44:43'),
(11, 2, 'message', 'Yeni mesaj', 'Admin sənə yeni mesaj göndərdi.', '{\"target\":\"chat\",\"targetValue\":\"Admin\",\"senderNickname\":\"Admin\",\"conversationId\":\"12\",\"sender\":\"Admin\",\"count\":20}', 1, '2026-09-24 06:47:40', '2026-09-25 10:44:43'),
(18, 2, 'broadcast', 'VGhost', 'Hamiya Salam', '{\"target\":\"link\",\"targetValue\":\"https://vghost.site\",\"url\":\"https://vghost.site\",\"count\":1}', 1, '2026-09-23 16:25:29', '2026-09-25 10:44:43'),
(20, 2, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 1, '2026-09-23 19:25:03', '2026-09-25 10:44:43'),
(24, 2, 'profile_visit', 'Profil qonağın var!', 'Admin profilinə baxdı.', '{\"viewerId\":\"1\",\"userId\":\"1\",\"nickname\":\"Admin\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"targetValue\":\"Admin\",\"sender\":\"Admin\",\"count\":13}', 1, '2026-09-24 19:59:49', '2026-09-25 10:44:43'),
(25, 2, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 1, '2026-09-24 06:41:09', '2026-09-25 10:44:43'),
(27, 2, 'gift', 'Hədiyyə alındı 🎁', 'Admin sizə hədiyyə göndərdi. +10 GC', '{\"giftId\":\"1\",\"gift_id\":\"1\",\"giftKey\":\"love\",\"giftName\":\"love\",\"amount\":\"10\",\"coinCost\":\"10\",\"senderId\":\"1\",\"senderUid\":\"1\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"action\":\"show_gift_slide\",\"sender\":\"Admin\",\"count\":1}', 1, '2026-09-24 06:41:50', '2026-09-24 06:41:53'),
(28, 2, 'gift', 'Hədiyyə alındı 🎁', 'Admin sizə hədiyyə göndərdi. +2000 GC', '{\"giftId\":\"13\",\"gift_id\":\"13\",\"giftKey\":\"thunder\",\"giftName\":\"thunder\",\"amount\":\"2000\",\"coinCost\":\"2000\",\"senderId\":\"1\",\"senderUid\":\"1\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"action\":\"show_gift_slide\",\"sender\":\"Admin\",\"count\":19}', 1, '2026-09-24 09:41:09', '2026-09-25 10:44:43'),
(30, 2, 'coin_transfer', 'Coin transferi', 'Admin sənə 10349 GC göndərdi.', '{\"amount\":\"10349\",\"senderId\":\"1\",\"senderUid\":\"1\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"targetValue\":\"1\",\"sender\":\"Admin\",\"count\":1}', 1, '2026-09-24 06:43:28', '2026-09-25 10:44:43'),
(38, 2, 'profile_visit', 'Profil qonağın var!', 'Ali profilinə baxdı.', '{\"viewerId\":\"3\",\"userId\":\"3\",\"nickname\":\"Ali\",\"senderNickname\":\"Ali\",\"target\":\"profile\",\"targetValue\":\"Ali\",\"sender\":\"Ali\",\"count\":1}', 1, '2026-09-24 09:38:24', '2026-09-25 10:44:43'),
(39, 1, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 0, '2026-09-25 08:01:53', NULL),
(40, 2, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 1, '2026-09-25 10:44:20', '2026-09-25 10:44:43'),
(41, 1, 'gift', 'Hədiyyə alındı 🎁', 'VGhost sizə hədiyyə göndərdi. +10 GC', '{\"giftId\":\"1\",\"gift_id\":\"1\",\"giftKey\":\"love\",\"giftName\":\"love\",\"amount\":\"10\",\"coinCost\":\"10\",\"senderId\":\"2\",\"senderUid\":\"2\",\"senderNickname\":\"VGhost\",\"target\":\"profile\",\"action\":\"show_gift_slide\",\"sender\":\"VGhost\",\"count\":4}', 0, '2026-09-25 12:17:37', NULL),
(42, 1, 'coin_transfer', 'Coin transferi', 'VGhost sənə 10000 GC göndərdi.', '{\"amount\":\"10000\",\"senderId\":\"2\",\"senderUid\":\"2\",\"senderNickname\":\"VGhost\",\"target\":\"profile\",\"targetValue\":\"2\",\"sender\":\"VGhost\",\"count\":2}', 0, '2026-09-25 10:50:55', NULL),
(43, 4, 'welcome_bonus', 'welcome_bonus', '', '{\"amount\":1000,\"target\":\"profile\",\"count\":1}', 0, '2026-09-25 20:36:52', NULL),
(44, 4, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 0, '2026-09-25 20:36:53', NULL),
(45, 1, 'story_view', 'Story baxışı 👀', 'Test story-nizə baxdı.', '{\"target\":\"story\",\"storyId\":\"2\",\"targetValue\":\"2\",\"senderNickname\":\"Test\",\"sender\":\"Test\",\"count\":1}', 0, '2026-09-25 20:37:01', NULL),
(46, 4, 'gift', 'Hədiyyə alındı 🎁', 'Admin sizə hədiyyə göndərdi. +400 GC', '{\"giftId\":\"8\",\"gift_id\":\"8\",\"giftKey\":\"butterfly\",\"giftName\":\"butterfly\",\"amount\":\"400\",\"coinCost\":\"400\",\"senderId\":\"1\",\"senderUid\":\"1\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"action\":\"show_gift_slide\",\"sender\":\"Admin\",\"count\":1}', 0, '2026-09-25 21:01:34', NULL),
(47, 4, 'profile_visit', 'Profil qonağın var!', 'Admin profilinə baxdı.', '{\"viewerId\":\"1\",\"userId\":\"1\",\"nickname\":\"Admin\",\"senderNickname\":\"Admin\",\"target\":\"profile\",\"targetValue\":\"Admin\",\"sender\":\"Admin\",\"count\":1}', 0, '2026-09-25 21:03:32', NULL),
(48, 1, 'daily_bonus', 'Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.', '{\"amount\":500,\"target\":\"profile\",\"count\":1}', 0, '2026-09-26 00:10:17', NULL);

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `blocks`
--

CREATE TABLE `blocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blocker_id` bigint(20) UNSIGNED NOT NULL,
  `blocked_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `conversations`
--

CREATE TABLE `conversations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_one_id` bigint(20) UNSIGNED NOT NULL,
  `user_two_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `daily_coin_rewards`
--

CREATE TABLE `daily_coin_rewards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reward_date` date NOT NULL,
  `amount` bigint(20) NOT NULL DEFAULT 500,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `daily_coin_rewards`
--

INSERT INTO `daily_coin_rewards` (`id`, `user_id`, `reward_date`, `amount`, `created_at`) VALUES
(1, 1, '2026-09-22', 500, '2026-09-22 10:40:21'),
(414, 2, '2026-09-22', 500, '2026-09-22 15:31:21'),
(792, 1, '2026-09-23', 500, '2026-09-23 03:32:02'),
(1150, 2, '2026-09-23', 500, '2026-09-23 19:25:03'),
(1155, 1, '2026-09-24', 500, '2026-09-24 04:33:47'),
(1267, 2, '2026-09-24', 500, '2026-09-24 06:41:09'),
(2052, 1, '2026-09-25', 500, '2026-09-25 08:01:53'),
(2166, 2, '2026-09-25', 500, '2026-09-25 10:44:20'),
(2560, 4, '2026-09-25', 500, '2026-09-25 20:36:53'),
(2881, 1, '2026-09-26', 500, '2026-09-26 00:10:17');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `friendships`
--

CREATE TABLE `friendships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_one_id` bigint(20) UNSIGNED NOT NULL,
  `user_two_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('pending','accepted','blocked') NOT NULL DEFAULT 'pending',
  `requester_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `friendships`
--

INSERT INTO `friendships` (`id`, `user_one_id`, `user_two_id`, `status`, `requester_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'accepted', 2, '2026-09-22 15:37:21', '2026-09-22 17:52:56');

-- --------------------------------------------------------

--
--

--
--

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `gifts`
--

CREATE TABLE `gifts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `coin_cost` bigint(20) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `gifts`
--

INSERT INTO `gifts` (`id`, `name`, `coin_cost`, `is_active`) VALUES
(1, 'love', 10, 1),
(2, 'rose', 20, 1),
(3, 'diamond', 50, 1),
(4, 'crown', 100, 1),
(5, 'cake', 150, 1),
(6, 'gift_box', 200, 1),
(7, 'money_bag', 300, 1),
(8, 'butterfly', 400, 1),
(9, 'fire', 500, 1),
(10, 'rocket', 750, 1),
(11, 'dragon', 1000, 1),
(12, 'trophy', 1500, 1),
(13, 'thunder', 2000, 1),
(14, 'ghost', 3000, 1),
(15, 'galaxy', 5000, 1),
(16, 'ufo', 7500, 1),
(17, 'meteor', 10000, 1),
(18, 'castle', 15000, 1),
(19, 'volcano', 25000, 1),
(20, 'vghost_royal', 50000, 1);

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `gift_transactions`
--

CREATE TABLE `gift_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sender_id` bigint(20) UNSIGNED NOT NULL,
  `receiver_id` bigint(20) UNSIGNED NOT NULL,
  `gift_id` bigint(20) UNSIGNED NOT NULL,
  `coin_cost` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `gift_transactions`
--

INSERT INTO `gift_transactions` (`id`, `sender_id`, `receiver_id`, `gift_id`, `coin_cost`, `created_at`) VALUES
(1, 1, 2, 1, 10, '2026-09-24 06:41:50'),
(2, 1, 2, 2, 20, '2026-09-24 06:41:54'),
(3, 1, 2, 3, 50, '2026-09-24 06:41:58'),
(4, 2, 1, 20, 50000, '2026-09-24 06:41:58'),
(5, 1, 2, 4, 100, '2026-09-24 06:42:03'),
(6, 1, 2, 5, 150, '2026-09-24 06:42:06'),
(7, 2, 1, 1, 10, '2026-09-24 06:42:10'),
(8, 1, 2, 6, 200, '2026-09-24 06:42:10'),
(9, 2, 1, 6, 200, '2026-09-24 06:42:14'),
(10, 1, 2, 7, 300, '2026-09-24 06:42:15'),
(11, 2, 1, 13, 2000, '2026-09-24 06:42:20'),
(12, 1, 2, 8, 400, '2026-09-24 06:42:22'),
(13, 2, 1, 9, 500, '2026-09-24 06:42:25'),
(14, 1, 2, 9, 500, '2026-09-24 06:42:27'),
(15, 2, 1, 7, 300, '2026-09-24 06:42:30'),
(16, 1, 2, 10, 750, '2026-09-24 06:42:32'),
(17, 2, 1, 6, 200, '2026-09-24 06:42:34'),
(18, 1, 2, 11, 1000, '2026-09-24 06:42:39'),
(19, 2, 1, 15, 5000, '2026-09-24 06:42:43'),
(20, 1, 2, 12, 1500, '2026-09-24 06:42:44'),
(21, 2, 1, 17, 10000, '2026-09-24 06:42:48'),
(22, 1, 2, 13, 2000, '2026-09-24 06:42:50'),
(23, 2, 1, 19, 25000, '2026-09-24 06:42:53'),
(24, 1, 2, 14, 3000, '2026-09-24 06:42:55'),
(25, 2, 1, 18, 15000, '2026-09-24 06:42:58'),
(26, 1, 2, 16, 7500, '2026-09-24 06:43:03'),
(27, 2, 1, 19, 25000, '2026-09-24 06:43:04'),
(28, 1, 2, 20, 50000, '2026-09-24 06:43:08'),
(29, 2, 1, 20, 50000, '2026-09-24 06:43:09'),
(30, 1, 2, 19, 25000, '2026-09-24 06:43:12'),
(31, 2, 1, 4, 100, '2026-09-24 06:43:17'),
(32, 2, 1, 3, 50, '2026-09-24 06:43:20'),
(33, 2, 1, 2, 20, '2026-09-24 06:43:29'),
(34, 2, 1, 5, 150, '2026-09-24 06:43:39'),
(35, 2, 1, 8, 400, '2026-09-24 06:43:45'),
(36, 2, 1, 11, 1000, '2026-09-24 06:43:54'),
(37, 2, 1, 12, 1500, '2026-09-24 06:43:59'),
(38, 2, 1, 14, 3000, '2026-09-24 06:44:03'),
(39, 1, 2, 1, 10, '2026-09-24 06:46:12'),
(40, 1, 2, 10, 750, '2026-09-24 06:46:20'),
(41, 1, 2, 13, 2000, '2026-09-24 09:41:09'),
(42, 2, 1, 6, 200, '2026-09-25 10:50:06'),
(43, 2, 1, 3, 50, '2026-09-25 10:50:10'),
(44, 2, 1, 11, 1000, '2026-09-25 10:50:15'),
(45, 2, 1, 1, 10, '2026-09-25 12:17:37'),
(46, 1, 4, 8, 400, '2026-09-25 21:01:34');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `conversation_id` bigint(20) UNSIGNED NOT NULL,
  `sender_id` bigint(20) UNSIGNED NOT NULL,
  `receiver_id` bigint(20) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `message_type` varchar(30) NOT NULL DEFAULT 'text',
  `sticker_id` bigint(20) UNSIGNED DEFAULT NULL,
  `reply_to_message_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `audio_path` varchar(500) DEFAULT NULL,
  `audio_duration` int(10) UNSIGNED DEFAULT NULL,
  `attachment_path` varchar(500) DEFAULT NULL,
  `attachment_type` varchar(80) DEFAULT NULL,
  `attachment_name` varchar(255) DEFAULT NULL,
  `attachment_size` bigint(20) UNSIGNED DEFAULT NULL,
  `link_preview_url` varchar(2048) DEFAULT NULL,
  `link_preview_title` varchar(500) DEFAULT NULL,
  `link_preview_description` text DEFAULT NULL,
  `link_preview_image` varchar(2048) DEFAULT NULL,
  `link_preview_site` varchar(190) DEFAULT NULL,
  `link_preview_type` varchar(30) DEFAULT NULL,
  `link_preview_video` varchar(2048) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `message_reactions`
--

CREATE TABLE `message_reactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `message_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reaction` varchar(32) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(190) NOT NULL,
  `applied_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES
(3, 1, 'a69ed72f54a62a475277f3e618b4ddecf0593e972e94d1e073b573dbd39bfeed', '2026-09-24 10:39:49', NULL, '2026-09-24 10:09:49');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `profile_views`
--

CREATE TABLE `profile_views` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `viewer_id` bigint(20) UNSIGNED NOT NULL,
  `profile_user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `profile_views`
--

INSERT INTO `profile_views` (`id`, `viewer_id`, `profile_user_id`, `created_at`) VALUES
(8, 1, 2, '2026-09-24 06:20:29'),
(9, 1, 2, '2026-09-24 06:20:33'),
(11, 1, 2, '2026-09-24 06:40:58'),
(13, 1, 2, '2026-09-24 06:41:05'),
(14, 1, 2, '2026-09-24 06:41:42'),
(15, 1, 2, '2026-09-24 06:41:45'),
(16, 1, 2, '2026-09-24 06:43:45'),
(17, 1, 2, '2026-09-24 06:46:39'),
(19, 1, 2, '2026-09-24 07:48:33'),
(20, 1, 2, '2026-09-24 07:49:02'),
(21, 1, 2, '2026-09-24 07:49:20'),
(24, 1, 2, '2026-09-24 08:27:29'),
(25, 1, 2, '2026-09-24 08:31:04'),
(26, 1, 2, '2026-09-24 08:31:56'),
(29, 1, 2, '2026-09-24 08:55:00'),
(30, 1, 2, '2026-09-24 09:06:58'),
(31, 1, 2, '2026-09-24 09:07:37'),
(32, 1, 2, '2026-09-24 09:08:37'),
(34, 1, 2, '2026-09-24 09:09:04'),
(38, 1, 2, '2026-09-24 09:41:01'),
(39, 1, 2, '2026-09-24 09:48:15'),
(45, 1, 2, '2026-09-24 19:59:49'),
(46, 1, 4, '2026-09-25 21:03:32'),
(47, 1, 4, '2026-09-25 21:04:03');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `progression_daily`
--

CREATE TABLE `progression_daily` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reward_date` date NOT NULL,
  `reason` varchar(32) NOT NULL,
  `amount` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `rate_limits`
--

CREATE TABLE `rate_limits` (
  `rate_key` varchar(191) NOT NULL,
  `window_start` datetime NOT NULL,
  `hits` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `rate_limits`
--

INSERT INTO `rate_limits` (`rate_key`, `window_start`, `hits`) VALUES
('/admin/coins-overview|62.217.156.103', '2026-09-24 16:07:43', 1),
('/admin/coins-overview|77.244.116.211', '2026-09-25 10:13:45', 1),
('/admin/coins-set|62.217.156.103', '2026-09-24 09:49:02', 2),
('/admin/security/verify|62.217.156.103', '2026-09-24 16:28:56', 2),
('/auth/register|77.244.116.211', '2026-09-25 20:36:52', 1),
('/auth/reset-confirm|62.217.156.103', '2026-09-24 10:10:08', 1),
('/auth/reset|62.217.156.103', '2026-09-24 10:09:49', 1),
('/coins/send|46.23.103.26', '2026-09-25 10:50:43', 2),
('/devices/fcm|46.23.103.26', '2026-09-25 10:50:32', 1),
('/devices/fcm|62.217.139.26', '2026-09-26 07:52:51', 3),
('/devices/fcm|62.217.156.103', '2026-09-24 19:58:47', 2),
('/devices/fcm|77.244.116.211', '2026-09-25 23:52:54', 6),
('/devices/fcm|77.244.118.48', '2026-09-26 01:20:09', 2),
('/gifs/list|77.244.116.211', '2026-09-25 19:34:33', 1),
('/gifts/send|46.23.103.26', '2026-09-25 10:50:06', 3),
('/gifts/send|62.217.156.103', '2026-09-24 09:41:09', 1),
('/gifts/send|77.244.116.211', '2026-09-25 21:01:34', 1),
('/profile/view|62.217.156.103', '2026-09-24 19:59:49', 1),
('/profile/view|77.244.116.211', '2026-09-25 21:03:32', 2),
('/stickers/list|77.244.116.211', '2026-09-25 19:34:29', 1),
('/stories/gift|62.217.156.103', '2026-09-24 08:55:42', 1),
('/stories/view|62.217.156.103', '2026-09-24 08:02:31', 1),
('/stories/view|77.244.116.211', '2026-09-25 20:37:01', 1),
('/users/avatar|62.217.156.103', '2026-09-24 16:33:17', 14),
('/users/directory|37.114.176.175', '2026-09-25 21:13:45', 1),
('/users/directory|46.23.103.26', '2026-09-25 10:49:58', 1),
('/users/directory|62.217.139.26', '2026-09-26 07:56:17', 2),
('/users/directory|62.217.156.103', '2026-09-24 20:01:54', 1),
('/users/directory|77.244.116.211', '2026-09-25 23:54:33', 4),
('/users/directory|77.244.116.215', '2026-09-26 07:38:29', 4),
('/users/directory|77.244.118.48', '2026-09-26 00:11:51', 1),
('/users/search|62.217.156.103', '2026-09-24 10:12:57', 1),
('/users/search|77.244.116.211', '2026-09-25 23:24:25', 1),
('/users/vip-frame|62.217.139.26', '2026-09-25 15:36:35', 8),
('/users/vip-frame|62.217.156.103', '2026-09-24 20:00:50', 4),
('/vip/test/activate|77.244.116.211', '2026-09-25 20:37:40', 3),
('global:/admin/dashboard|62.217.139.26', '2026-09-26 07:52:55', 2),
('global:/admin/dashboard|62.217.156.103', '2026-09-24 19:58:52', 1),
('global:/admin/dashboard|77.244.116.211', '2026-09-25 23:54:43', 1),
('global:/admin/dashboard|77.244.116.215', '2026-09-26 07:15:36', 1),
('global:/admin/dashboard|77.244.118.173', '2026-09-24 08:12:38', 1),
('global:/admin/dashboard|77.244.118.48', '2026-09-26 00:11:01', 1),
('global:/admin/logs|62.217.156.103', '2026-09-24 15:49:04', 1),
('global:/admin/messages|62.217.156.103', '2026-09-24 16:07:43', 1),
('global:/admin/messages|77.244.116.211', '2026-09-25 10:13:45', 1),
('global:/admin/user-action|62.217.156.103', '2026-09-24 16:28:56', 1),
('global:/admin/users|62.217.156.103', '2026-09-24 16:07:43', 1),
('global:/admin/users|77.244.116.211', '2026-09-25 10:13:45', 1),
('global:/auth/me|37.114.176.175', '2026-09-25 21:13:39', 1),
('global:/auth/me|46.23.103.26', '2026-09-25 10:50:32', 6),
('global:/auth/me|62.217.139.26', '2026-09-26 07:55:56', 14),
('global:/auth/me|62.217.156.103', '2026-09-24 20:02:05', 5),
('global:/auth/me|77.244.116.211', '2026-09-25 23:54:16', 10),
('global:/auth/me|77.244.116.215', '2026-09-26 07:38:34', 5),
('global:/auth/me|77.244.118.173', '2026-09-24 08:12:32', 2),
('global:/auth/me|77.244.118.48', '2026-09-26 01:20:09', 7),
('global:/blocks/list|37.114.176.175', '2026-09-25 20:46:13', 3),
('global:/blocks/list|46.23.103.26', '2026-09-25 10:44:39', 1),
('global:/blocks/list|62.217.139.26', '2026-09-26 07:56:22', 2),
('global:/blocks/list|62.217.156.103', '2026-09-24 20:01:24', 2),
('global:/blocks/list|77.244.116.211', '2026-09-25 23:54:18', 1),
('global:/blocks/list|77.244.116.215', '2026-09-26 07:37:37', 4),
('global:/blocks/list|77.244.118.48', '2026-09-26 00:11:42', 2),
('global:/gifts/profile|37.114.176.175', '2026-09-25 20:46:14', 3),
('global:/gifts/profile|46.23.103.26', '2026-09-25 10:44:39', 1),
('global:/gifts/profile|62.217.139.26', '2026-09-26 07:56:22', 2),
('global:/gifts/profile|62.217.156.103', '2026-09-24 20:01:24', 2),
('global:/gifts/profile|77.244.116.211', '2026-09-25 23:54:18', 1),
('global:/gifts/profile|77.244.116.215', '2026-09-26 07:37:37', 3),
('global:/gifts/profile|77.244.118.48', '2026-09-26 00:11:42', 2),
('global:/messages/conversations|37.114.176.175', '2026-09-25 21:13:30', 6),
('global:/messages/conversations|46.23.103.26', '2026-09-25 10:50:32', 10),
('global:/messages/conversations|62.217.139.26', '2026-09-26 07:55:57', 13),
('global:/messages/conversations|62.217.156.103', '2026-09-24 20:01:28', 12),
('global:/messages/conversations|77.244.116.211', '2026-09-25 23:54:16', 18),
('global:/messages/conversations|77.244.116.215', '2026-09-26 07:38:36', 9),
('global:/messages/conversations|77.244.118.173', '2026-09-24 08:12:33', 3),
('global:/messages/conversations|77.244.118.48', '2026-09-26 01:20:10', 2),
('global:/messages/list|77.244.116.211', '2026-09-25 21:03:59', 4),
('global:/messages/typing-status|77.244.116.211', '2026-09-25 21:03:59', 4),
('global:/messages/typing|77.244.116.211', '2026-09-25 21:03:59', 2),
('global:/notifications/clear|62.217.156.103', '2026-09-24 10:39:13', 1),
('global:/notifications/list|37.114.176.175', '2026-09-25 21:13:25', 2),
('global:/notifications/list|46.23.103.26', '2026-09-25 10:50:11', 5),
('global:/notifications/list|62.217.139.26', '2026-09-26 07:55:56', 7),
('global:/notifications/list|62.217.156.103', '2026-09-24 20:02:02', 2),
('global:/notifications/list|77.244.116.211', '2026-09-25 23:54:16', 7),
('global:/notifications/list|77.244.116.215', '2026-09-26 07:38:39', 2),
('global:/notifications/list|77.244.118.173', '2026-09-24 08:12:33', 2),
('global:/notifications/list|77.244.118.48', '2026-09-26 01:20:09', 2),
('global:/notifications/read|46.23.103.26', '2026-09-25 10:44:43', 1),
('global:/profile/level|37.114.176.175', '2026-09-25 21:13:30', 6),
('global:/profile/level|46.23.103.26', '2026-09-25 10:50:32', 10),
('global:/profile/level|62.217.139.26', '2026-09-26 07:55:57', 14),
('global:/profile/level|62.217.156.103', '2026-09-24 20:01:28', 12),
('global:/profile/level|77.244.116.211', '2026-09-25 23:54:16', 18),
('global:/profile/level|77.244.116.215', '2026-09-26 07:38:38', 7),
('global:/profile/level|77.244.118.173', '2026-09-24 08:12:55', 1),
('global:/profile/level|77.244.118.48', '2026-09-26 01:20:10', 2),
('global:/profile/visitors|62.217.139.26', '2026-09-25 15:51:53', 1),
('global:/profile/visitors|62.217.156.103', '2026-09-24 10:08:56', 5),
('global:/profile/visitors|77.244.116.211', '2026-09-25 21:03:03', 2),
('global:/settings/privacy|37.114.176.175', '2026-09-25 20:46:40', 1),
('global:/settings/privacy|62.217.156.103', '2026-09-24 16:32:48', 1),
('global:/settings/privacy|77.244.116.211', '2026-09-25 20:49:09', 3),
('global:/settings/push|37.114.176.175', '2026-09-25 20:46:29', 1),
('global:/stories/comments|77.244.118.48', '2026-09-26 00:11:08', 1),
('global:/stories/list|37.114.176.175', '2026-09-25 20:45:54', 3),
('global:/stories/list|46.23.103.26', '2026-09-25 10:44:34', 1),
('global:/stories/list|62.217.139.26', '2026-09-26 07:56:00', 5),
('global:/stories/list|62.217.156.103', '2026-09-24 20:01:55', 3),
('global:/stories/list|77.244.116.211', '2026-09-25 23:54:38', 1),
('global:/stories/list|77.244.116.215', '2026-09-26 07:38:34', 5),
('global:/stories/list|77.244.118.173', '2026-09-24 08:12:33', 1),
('global:/stories/list|77.244.118.48', '2026-09-26 00:11:05', 7),
('global:/stories/media|37.114.176.175', '2026-09-25 20:45:54', 1),
('global:/stories/viewers|77.244.116.211', '2026-09-25 21:04:34', 1),
('global:/stories/viewers|77.244.118.48', '2026-09-26 00:11:12', 1),
('global:/users/public|46.23.103.26', '2026-09-25 10:49:59', 6),
('global:/users/public|62.217.139.26', '2026-09-25 15:53:25', 1),
('global:/users/public|62.217.156.103', '2026-09-24 19:59:49', 1),
('global:/users/public|77.244.116.211', '2026-09-25 23:24:25', 1),
('global:/users/status|37.114.176.175', '2026-09-25 21:13:39', 2),
('global:/users/status|46.23.103.26', '2026-09-25 10:50:57', 1),
('global:/users/status|62.217.139.26', '2026-09-26 07:55:56', 15),
('global:/users/status|62.217.156.103', '2026-09-24 20:01:55', 8),
('global:/users/status|77.244.116.211', '2026-09-25 23:54:16', 17),
('global:/users/status|77.244.116.215', '2026-09-26 07:38:40', 4),
('global:/users/status|77.244.118.173', '2026-09-24 08:12:32', 2),
('global:/users/status|77.244.118.48', '2026-09-26 01:20:09', 8),
('global:/users/stealth|62.217.156.103', '2026-09-24 20:01:12', 1),
('global:/users/stealth|77.244.116.211', '2026-09-25 22:20:04', 1),
('global:/vip/status|37.114.176.175', '2026-09-25 20:46:13', 3),
('global:/vip/status|46.23.103.26', '2026-09-25 10:44:39', 1),
('global:/vip/status|62.217.139.26', '2026-09-26 07:56:22', 2),
('global:/vip/status|62.217.156.103', '2026-09-24 20:01:23', 2),
('global:/vip/status|77.244.116.211', '2026-09-25 23:54:18', 1),
('global:/vip/status|77.244.116.215', '2026-09-26 07:37:37', 4),
('global:/vip/status|77.244.118.48', '2026-09-26 00:11:42', 2),
('global:/wallet/balance|37.114.176.175', '2026-09-25 21:09:24', 2),
('global:/wallet/balance|46.23.103.26', '2026-09-25 10:49:56', 2),
('global:/wallet/balance|62.217.139.26', '2026-09-26 07:55:56', 4),
('global:/wallet/balance|62.217.156.103', '2026-09-24 20:02:07', 1),
('global:/wallet/balance|77.244.116.211', '2026-09-25 23:54:16', 5),
('global:/wallet/balance|77.244.116.215', '2026-09-26 07:38:55', 1),
('global:/wallet/balance|77.244.118.173', '2026-09-24 08:12:33', 1),
('global:/wallet/balance|77.244.118.48', '2026-09-26 01:20:09', 3);

-- --------------------------------------------------------

--
--

--
--

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `settings`
--

CREATE TABLE `settings` (
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `stickers`
--

CREATE TABLE `stickers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sticker_key` varchar(64) NOT NULL,
  `emoji` varchar(32) NOT NULL,
  `label` varchar(190) NOT NULL,
  `image_url` varchar(1000) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `stickers`
--

INSERT INTO `stickers` (`id`, `sticker_key`, `emoji`, `label`, `image_url`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'sticker_001', '🖼️', 'Sticker 1', 'stickers/sticker_001.webp', 0, 1, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(2, 'sticker_002', '🖼️', 'Sticker 2', 'stickers/sticker_002.webp', 0, 2, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(3, 'sticker_003', '🖼️', 'Sticker 3', 'stickers/sticker_003.webp', 0, 3, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(4, 'sticker_004', '🖼️', 'Sticker 4', 'stickers/sticker_004.webp', 0, 4, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(5, 'sticker_005', '🖼️', 'Sticker 5', 'stickers/sticker_005.webp', 0, 5, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(6, 'sticker_006', '🖼️', 'Sticker 6', 'stickers/sticker_006.webp', 0, 6, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(7, 'sticker_007', '🖼️', 'Sticker 7', 'stickers/sticker_007.webp', 0, 7, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(8, 'sticker_008', '🖼️', 'Sticker 8', 'stickers/sticker_008.webp', 0, 8, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(9, 'sticker_009', '🖼️', 'Sticker 9', 'stickers/sticker_009.webp', 0, 9, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(10, 'sticker_010', '🖼️', 'Sticker 10', 'stickers/sticker_010.webp', 0, 10, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(11, 'sticker_011', '🖼️', 'Sticker 11', 'stickers/sticker_011.webp', 0, 11, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(12, 'sticker_012', '🖼️', 'Sticker 12', 'stickers/sticker_012.webp', 0, 12, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(13, 'sticker_013', '🖼️', 'Sticker 13', 'stickers/sticker_013.webp', 0, 13, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(14, 'sticker_014', '🖼️', 'Sticker 14', 'stickers/sticker_014.webp', 0, 14, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(15, 'sticker_015', '🖼️', 'Sticker 15', 'stickers/sticker_015.webp', 0, 15, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(16, 'sticker_016', '🖼️', 'Sticker 16', 'stickers/sticker_016.webp', 0, 16, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(17, 'sticker_017', '🖼️', 'Sticker 17', 'stickers/sticker_017.webp', 0, 17, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(18, 'sticker_018', '🖼️', 'Sticker 18', 'stickers/sticker_018.webp', 0, 18, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(19, 'sticker_019', '🖼️', 'Sticker 19', 'stickers/sticker_019.webp', 0, 19, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(20, 'sticker_020', '🖼️', 'Sticker 20', 'stickers/sticker_020.webp', 0, 20, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(21, 'sticker_021', '🖼️', 'Sticker 21', 'stickers/sticker_021.webp', 0, 21, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(22, 'sticker_022', '🖼️', 'Sticker 22', 'stickers/sticker_022.webp', 0, 22, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(23, 'sticker_023', '🖼️', 'Sticker 23', 'stickers/sticker_023.webp', 0, 23, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(24, 'sticker_024', '🖼️', 'Sticker 24', 'stickers/sticker_024.webp', 0, 24, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(25, 'sticker_025', '🖼️', 'Sticker 25', 'stickers/sticker_025.webp', 0, 25, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(26, 'sticker_026', '🖼️', 'Sticker 26', 'stickers/sticker_026.webp', 0, 26, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(27, 'sticker_027', '🖼️', 'Sticker 27', 'stickers/sticker_027.webp', 0, 27, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(28, 'sticker_028', '🖼️', 'Sticker 28', 'stickers/sticker_028.webp', 0, 28, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(29, 'sticker_029', '🖼️', 'Sticker 29', 'stickers/sticker_029.webp', 0, 29, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(30, 'sticker_030', '🖼️', 'Sticker 30', 'stickers/sticker_030.webp', 0, 30, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(31, 'sticker_031', '🖼️', 'Sticker 31', 'stickers/sticker_031.webp', 0, 31, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(32, 'sticker_032', '🖼️', 'Sticker 32', 'stickers/sticker_032.webp', 0, 32, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(33, 'sticker_033', '🖼️', 'Sticker 33', 'stickers/sticker_033.webp', 0, 33, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(34, 'sticker_034', '🖼️', 'Sticker 34', 'stickers/sticker_034.webp', 0, 34, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(35, 'sticker_035', '🖼️', 'Sticker 35', 'stickers/sticker_035.webp', 0, 35, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(36, 'sticker_036', '🖼️', 'Sticker 36', 'stickers/sticker_036.webp', 0, 36, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(37, 'sticker_037', '🖼️', 'Sticker 37', 'stickers/sticker_037.webp', 0, 37, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(38, 'sticker_038', '🖼️', 'Sticker 38', 'stickers/sticker_038.webp', 0, 38, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(39, 'sticker_039', '🖼️', 'Sticker 39', 'stickers/sticker_039.webp', 0, 39, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(40, 'sticker_040', '🖼️', 'Sticker 40', 'stickers/sticker_040.webp', 0, 40, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(41, 'sticker_041', '🖼️', 'Sticker 41', 'stickers/sticker_041.webp', 0, 41, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(42, 'sticker_042', '🖼️', 'Sticker 42', 'stickers/sticker_042.webp', 0, 42, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(43, 'sticker_043', '🖼️', 'Sticker 43', 'stickers/sticker_043.webp', 0, 43, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(44, 'sticker_044', '🖼️', 'Sticker 44', 'stickers/sticker_044.webp', 0, 44, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(45, 'sticker_045', '🖼️', 'Sticker 45', 'stickers/sticker_045.webp', 0, 45, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(46, 'sticker_046', '🖼️', 'Sticker 46', 'stickers/sticker_046.webp', 0, 46, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(47, 'sticker_047', '🖼️', 'Sticker 47', 'stickers/sticker_047.webp', 0, 47, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(48, 'sticker_048', '🖼️', 'Sticker 48', 'stickers/sticker_048.webp', 0, 48, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(49, 'sticker_049', '🖼️', 'Sticker 49', 'stickers/sticker_049.webp', 0, 49, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(50, 'sticker_050', '🖼️', 'Sticker 50', 'stickers/sticker_050.webp', 0, 50, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(51, 'sticker_051', '🖼️', 'Sticker 51', 'stickers/sticker_051.webp', 0, 51, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(52, 'sticker_052', '🖼️', 'Sticker 52', 'stickers/sticker_052.webp', 0, 52, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(53, 'sticker_053', '🖼️', 'Sticker 53', 'stickers/sticker_053.webp', 0, 53, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(54, 'sticker_054', '🖼️', 'Sticker 54', 'stickers/sticker_054.webp', 0, 54, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(55, 'sticker_055', '🖼️', 'Sticker 55', 'stickers/sticker_055.webp', 0, 55, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(56, 'sticker_056', '🖼️', 'Sticker 56', 'stickers/sticker_056.webp', 0, 56, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(57, 'sticker_057', '🖼️', 'Sticker 57', 'stickers/sticker_057.webp', 0, 57, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(58, 'sticker_058', '🖼️', 'Sticker 58', 'stickers/sticker_058.webp', 0, 58, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(59, 'sticker_059', '🖼️', 'Sticker 59', 'stickers/sticker_059.webp', 0, 59, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(60, 'sticker_060', '🖼️', 'Sticker 60', 'stickers/sticker_060.webp', 0, 60, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(61, 'sticker_061', '🖼️', 'Sticker 61', 'stickers/sticker_061.webp', 0, 61, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(62, 'sticker_062', '🖼️', 'Sticker 62', 'stickers/sticker_062.webp', 0, 62, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(63, 'sticker_063', '🖼️', 'Sticker 63', 'stickers/sticker_063.webp', 0, 63, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(64, 'sticker_064', '🖼️', 'Sticker 64', 'stickers/sticker_064.webp', 0, 64, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(65, 'sticker_065', '🖼️', 'Sticker 65', 'stickers/sticker_065.webp', 0, 65, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(66, 'sticker_066', '🖼️', 'Sticker 66', 'stickers/sticker_066.webp', 0, 66, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(67, 'sticker_067', '🖼️', 'Sticker 67', 'stickers/sticker_067.webp', 0, 67, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(68, 'sticker_068', '🖼️', 'Sticker 68', 'stickers/sticker_068.webp', 0, 68, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(69, 'sticker_069', '🖼️', 'Sticker 69', 'stickers/sticker_069.webp', 0, 69, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(70, 'sticker_070', '🖼️', 'Sticker 70', 'stickers/sticker_070.webp', 0, 70, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(71, 'sticker_071', '🖼️', 'Sticker 71', 'stickers/sticker_071.webp', 0, 71, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(72, 'sticker_072', '🖼️', 'Sticker 72', 'stickers/sticker_072.webp', 0, 72, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(73, 'stk-20260911-wa0525', '🖼️', 'STK 20260911 WA0525', '/stickers/STK-20260911-WA0525.webp', 1, 73, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(74, 'stk-20260911-wa0526', '🖼️', 'STK 20260911 WA0526', '/stickers/STK-20260911-WA0526.webp', 1, 74, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(75, 'stk-20260911-wa0527', '🖼️', 'STK 20260911 WA0527', '/stickers/STK-20260911-WA0527.webp', 1, 75, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(76, 'stk-20260911-wa0528', '🖼️', 'STK 20260911 WA0528', '/stickers/STK-20260911-WA0528.webp', 1, 76, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(77, 'stk-20260911-wa0529', '🖼️', 'STK 20260911 WA0529', '/stickers/STK-20260911-WA0529.webp', 1, 77, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(78, 'stk-20260911-wa0530', '🖼️', 'STK 20260911 WA0530', '/stickers/STK-20260911-WA0530.webp', 1, 78, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(79, 'stk-20260911-wa0531', '🖼️', 'STK 20260911 WA0531', '/stickers/STK-20260911-WA0531.webp', 1, 79, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(80, 'stk-20260911-wa0532', '🖼️', 'STK 20260911 WA0532', '/stickers/STK-20260911-WA0532.webp', 1, 80, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(81, 'stk-20260911-wa0533', '🖼️', 'STK 20260911 WA0533', '/stickers/STK-20260911-WA0533.webp', 1, 81, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(82, 'stk-20260911-wa0534', '🖼️', 'STK 20260911 WA0534', '/stickers/STK-20260911-WA0534.webp', 1, 82, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(83, 'stk-20260911-wa0535', '🖼️', 'STK 20260911 WA0535', '/stickers/STK-20260911-WA0535.webp', 1, 83, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(84, 'stk-20260911-wa0536', '🖼️', 'STK 20260911 WA0536', '/stickers/STK-20260911-WA0536.webp', 1, 84, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(85, 'stk-20260911-wa0537', '🖼️', 'STK 20260911 WA0537', '/stickers/STK-20260911-WA0537.webp', 1, 85, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(86, 'stk-20260911-wa0538', '🖼️', 'STK 20260911 WA0538', '/stickers/STK-20260911-WA0538.webp', 1, 86, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(87, 'stk-20260911-wa0539', '🖼️', 'STK 20260911 WA0539', '/stickers/STK-20260911-WA0539.webp', 1, 87, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(88, 'stk-20260911-wa0540', '🖼️', 'STK 20260911 WA0540', '/stickers/STK-20260911-WA0540.webp', 1, 88, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(89, 'stk-20260911-wa0541', '🖼️', 'STK 20260911 WA0541', '/stickers/STK-20260911-WA0541.webp', 1, 89, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(90, 'stk-20260911-wa0542', '🖼️', 'STK 20260911 WA0542', '/stickers/STK-20260911-WA0542.webp', 1, 90, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(91, 'stk-20260911-wa0543', '🖼️', 'STK 20260911 WA0543', '/stickers/STK-20260911-WA0543.webp', 1, 91, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(92, 'stk-20260911-wa0544', '🖼️', 'STK 20260911 WA0544', '/stickers/STK-20260911-WA0544.webp', 1, 92, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(93, 'stk-20260911-wa0545', '🖼️', 'STK 20260911 WA0545', '/stickers/STK-20260911-WA0545.webp', 1, 93, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(94, 'stk-20260911-wa0546', '🖼️', 'STK 20260911 WA0546', '/stickers/STK-20260911-WA0546.webp', 1, 94, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(95, 'stk-20260911-wa0547', '🖼️', 'STK 20260911 WA0547', '/stickers/STK-20260911-WA0547.webp', 1, 95, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(96, 'stk-20260911-wa0548', '🖼️', 'STK 20260911 WA0548', '/stickers/STK-20260911-WA0548.webp', 1, 96, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(97, 'stk-20260911-wa0549', '🖼️', 'STK 20260911 WA0549', '/stickers/STK-20260911-WA0549.webp', 1, 97, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(98, 'stk-20260911-wa0550', '🖼️', 'STK 20260911 WA0550', '/stickers/STK-20260911-WA0550.webp', 1, 98, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(99, 'stk-20260911-wa0551', '🖼️', 'STK 20260911 WA0551', '/stickers/STK-20260911-WA0551.webp', 1, 99, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(100, 'stk-20260911-wa0553', '🖼️', 'STK 20260911 WA0553', '/stickers/STK-20260911-WA0553.webp', 1, 100, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(101, 'stk-20260911-wa0554', '🖼️', 'STK 20260911 WA0554', '/stickers/STK-20260911-WA0554.webp', 1, 101, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(102, 'stk-20260911-wa0555', '🖼️', 'STK 20260911 WA0555', '/stickers/STK-20260911-WA0555.webp', 1, 102, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(103, 'stk-20260911-wa0556', '🖼️', 'STK 20260911 WA0556', '/stickers/STK-20260911-WA0556.webp', 1, 103, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(104, 'stk-20260911-wa0557', '🖼️', 'STK 20260911 WA0557', '/stickers/STK-20260911-WA0557.webp', 1, 104, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(105, 'stk-20260911-wa0558', '🖼️', 'STK 20260911 WA0558', '/stickers/STK-20260911-WA0558.webp', 1, 105, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(106, 'stk-20260911-wa0559', '🖼️', 'STK 20260911 WA0559', '/stickers/STK-20260911-WA0559.webp', 1, 106, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(107, 'stk-20260911-wa0560', '🖼️', 'STK 20260911 WA0560', '/stickers/STK-20260911-WA0560.webp', 1, 107, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(108, 'stk-20260911-wa0561', '🖼️', 'STK 20260911 WA0561', '/stickers/STK-20260911-WA0561.webp', 1, 108, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(109, 'stk-20260911-wa0562', '🖼️', 'STK 20260911 WA0562', '/stickers/STK-20260911-WA0562.webp', 1, 109, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(110, 'stk-20260911-wa0563', '🖼️', 'STK 20260911 WA0563', '/stickers/STK-20260911-WA0563.webp', 1, 110, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(111, 'stk-20260911-wa0564', '🖼️', 'STK 20260911 WA0564', '/stickers/STK-20260911-WA0564.webp', 1, 111, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(112, 'stk-20260911-wa0565', '🖼️', 'STK 20260911 WA0565', '/stickers/STK-20260911-WA0565.webp', 1, 112, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(113, 'stk-20260911-wa0566', '🖼️', 'STK 20260911 WA0566', '/stickers/STK-20260911-WA0566.webp', 1, 113, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(114, 'stk-20260911-wa0567', '🖼️', 'STK 20260911 WA0567', '/stickers/STK-20260911-WA0567.webp', 1, 114, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(115, 'stk-20260911-wa0568', '🖼️', 'STK 20260911 WA0568', '/stickers/STK-20260911-WA0568.webp', 1, 115, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(116, 'stk-20260911-wa0569', '🖼️', 'STK 20260911 WA0569', '/stickers/STK-20260911-WA0569.webp', 1, 116, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(117, 'stk-20260911-wa0570', '🖼️', 'STK 20260911 WA0570', '/stickers/STK-20260911-WA0570.webp', 1, 117, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(118, 'stk-20260911-wa0571', '🖼️', 'STK 20260911 WA0571', '/stickers/STK-20260911-WA0571.webp', 1, 118, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(119, 'stk-20260911-wa0572', '🖼️', 'STK 20260911 WA0572', '/stickers/STK-20260911-WA0572.webp', 1, 119, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(120, 'stk-20260911-wa0574', '🖼️', 'STK 20260911 WA0574', '/stickers/STK-20260911-WA0574.webp', 1, 120, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(121, 'stk-20260911-wa0575', '🖼️', 'STK 20260911 WA0575', '/stickers/STK-20260911-WA0575.webp', 1, 121, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(122, 'stk-20260911-wa0576', '🖼️', 'STK 20260911 WA0576', '/stickers/STK-20260911-WA0576.webp', 1, 122, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(123, 'stk-20260911-wa0577', '🖼️', 'STK 20260911 WA0577', '/stickers/STK-20260911-WA0577.webp', 1, 123, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(124, 'stk-20260911-wa0578', '🖼️', 'STK 20260911 WA0578', '/stickers/STK-20260911-WA0578.webp', 1, 124, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(125, 'stk-20260911-wa0579', '🖼️', 'STK 20260911 WA0579', '/stickers/STK-20260911-WA0579.webp', 1, 125, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(126, 'stk-20260911-wa0580', '🖼️', 'STK 20260911 WA0580', '/stickers/STK-20260911-WA0580.webp', 1, 126, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(127, 'stk-20260911-wa0581', '🖼️', 'STK 20260911 WA0581', '/stickers/STK-20260911-WA0581.webp', 1, 127, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(128, 'stk-20260911-wa0582', '🖼️', 'STK 20260911 WA0582', '/stickers/STK-20260911-WA0582.webp', 1, 128, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(129, 'stk-20260911-wa0583', '🖼️', 'STK 20260911 WA0583', '/stickers/STK-20260911-WA0583.webp', 1, 129, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(130, 'stk-20260911-wa0584', '🖼️', 'STK 20260911 WA0584', '/stickers/STK-20260911-WA0584.webp', 1, 130, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(131, 'stk-20260911-wa0585', '🖼️', 'STK 20260911 WA0585', '/stickers/STK-20260911-WA0585.webp', 1, 131, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(132, 'stk-20260911-wa0586', '🖼️', 'STK 20260911 WA0586', '/stickers/STK-20260911-WA0586.webp', 1, 132, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(133, 'stk-20260911-wa0587', '🖼️', 'STK 20260911 WA0587', '/stickers/STK-20260911-WA0587.webp', 1, 133, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(134, 'stk-20260911-wa0589', '🖼️', 'STK 20260911 WA0589', '/stickers/STK-20260911-WA0589.webp', 1, 134, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(135, 'stk-20260911-wa0590', '🖼️', 'STK 20260911 WA0590', '/stickers/STK-20260911-WA0590.webp', 1, 135, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(136, 'stk-20260911-wa0592', '🖼️', 'STK 20260911 WA0592', '/stickers/STK-20260911-WA0592.webp', 1, 136, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(137, 'stk-20260911-wa0595', '🖼️', 'STK 20260911 WA0595', '/stickers/STK-20260911-WA0595.webp', 1, 137, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(138, 'stk-20260911-wa0596', '🖼️', 'STK 20260911 WA0596', '/stickers/STK-20260911-WA0596.webp', 1, 138, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(139, 'stk-20260911-wa0597', '🖼️', 'STK 20260911 WA0597', '/stickers/STK-20260911-WA0597.webp', 1, 139, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(140, 'stk-20260911-wa0598', '🖼️', 'STK 20260911 WA0598', '/stickers/STK-20260911-WA0598.webp', 1, 140, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(141, 'stk-20260911-wa0599', '🖼️', 'STK 20260911 WA0599', '/stickers/STK-20260911-WA0599.webp', 1, 141, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(142, 'stk-20260911-wa0600', '🖼️', 'STK 20260911 WA0600', '/stickers/STK-20260911-WA0600.webp', 1, 142, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(143, 'stk-20260911-wa0601', '🖼️', 'STK 20260911 WA0601', '/stickers/STK-20260911-WA0601.webp', 1, 143, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(144, 'stk-20260911-wa0602', '🖼️', 'STK 20260911 WA0602', '/stickers/STK-20260911-WA0602.webp', 1, 144, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(145, 'stk-20260911-wa0603', '🖼️', 'STK 20260911 WA0603', '/stickers/STK-20260911-WA0603.webp', 1, 145, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(146, 'stk-20260911-wa0604', '🖼️', 'STK 20260911 WA0604', '/stickers/STK-20260911-WA0604.webp', 1, 146, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(147, 'stk-20260911-wa0605', '🖼️', 'STK 20260911 WA0605', '/stickers/STK-20260911-WA0605.webp', 1, 147, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(148, 'stk-20260911-wa0606', '🖼️', 'STK 20260911 WA0606', '/stickers/STK-20260911-WA0606.webp', 1, 148, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(149, 'stk-20260911-wa0607', '🖼️', 'STK 20260911 WA0607', '/stickers/STK-20260911-WA0607.webp', 1, 149, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(150, 'stk-20260911-wa0608', '🖼️', 'STK 20260911 WA0608', '/stickers/STK-20260911-WA0608.webp', 1, 150, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(151, 'stk-20260911-wa0610', '🖼️', 'STK 20260911 WA0610', '/stickers/STK-20260911-WA0610.webp', 1, 151, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(152, 'stk-20260911-wa0611', '🖼️', 'STK 20260911 WA0611', '/stickers/STK-20260911-WA0611.webp', 1, 152, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(153, 'stk-20260911-wa0612', '🖼️', 'STK 20260911 WA0612', '/stickers/STK-20260911-WA0612.webp', 1, 153, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(154, 'stk-20260911-wa0614', '🖼️', 'STK 20260911 WA0614', '/stickers/STK-20260911-WA0614.webp', 1, 154, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(155, 'stk-20260911-wa0615', '🖼️', 'STK 20260911 WA0615', '/stickers/STK-20260911-WA0615.webp', 1, 155, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(156, 'stk-20260911-wa0616', '🖼️', 'STK 20260911 WA0616', '/stickers/STK-20260911-WA0616.webp', 1, 156, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(157, 'stk-20260911-wa0617', '🖼️', 'STK 20260911 WA0617', '/stickers/STK-20260911-WA0617.webp', 1, 157, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(158, 'stk-20260911-wa0618', '🖼️', 'STK 20260911 WA0618', '/stickers/STK-20260911-WA0618.webp', 1, 158, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(159, 'stk-20260911-wa0621', '🖼️', 'STK 20260911 WA0621', '/stickers/STK-20260911-WA0621.webp', 1, 159, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(160, 'stk-20260911-wa0623', '🖼️', 'STK 20260911 WA0623', '/stickers/STK-20260911-WA0623.webp', 1, 160, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(161, 'stk-20260911-wa0624', '🖼️', 'STK 20260911 WA0624', '/stickers/STK-20260911-WA0624.webp', 1, 161, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(162, 'stk-20260911-wa0625', '🖼️', 'STK 20260911 WA0625', '/stickers/STK-20260911-WA0625.webp', 1, 162, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(163, 'stk-20260911-wa0626', '🖼️', 'STK 20260911 WA0626', '/stickers/STK-20260911-WA0626.webp', 1, 163, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(164, 'stk-20260911-wa0627', '🖼️', 'STK 20260911 WA0627', '/stickers/STK-20260911-WA0627.webp', 1, 164, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(165, 'stk-20260911-wa0628', '🖼️', 'STK 20260911 WA0628', '/stickers/STK-20260911-WA0628.webp', 1, 165, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(166, 'stk-20260911-wa0629', '🖼️', 'STK 20260911 WA0629', '/stickers/STK-20260911-WA0629.webp', 1, 166, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(167, 'stk-20260911-wa0630', '🖼️', 'STK 20260911 WA0630', '/stickers/STK-20260911-WA0630.webp', 1, 167, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(168, 'stk-20260911-wa0631', '🖼️', 'STK 20260911 WA0631', '/stickers/STK-20260911-WA0631.webp', 1, 168, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(169, 'stk-20260911-wa0632', '🖼️', 'STK 20260911 WA0632', '/stickers/STK-20260911-WA0632.webp', 1, 169, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(170, 'stk-20260911-wa0633', '🖼️', 'STK 20260911 WA0633', '/stickers/STK-20260911-WA0633.webp', 1, 170, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(171, 'stk-20260911-wa0634', '🖼️', 'STK 20260911 WA0634', '/stickers/STK-20260911-WA0634.webp', 1, 171, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(172, 'stk-20260911-wa0635', '🖼️', 'STK 20260911 WA0635', '/stickers/STK-20260911-WA0635.webp', 1, 172, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(173, 'stk-20260911-wa0636', '🖼️', 'STK 20260911 WA0636', '/stickers/STK-20260911-WA0636.webp', 1, 173, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(174, 'stk-20260911-wa0637', '🖼️', 'STK 20260911 WA0637', '/stickers/STK-20260911-WA0637.webp', 1, 174, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(175, 'stk-20260911-wa0638', '🖼️', 'STK 20260911 WA0638', '/stickers/STK-20260911-WA0638.webp', 1, 175, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(176, 'stk-20260911-wa0639', '🖼️', 'STK 20260911 WA0639', '/stickers/STK-20260911-WA0639.webp', 1, 176, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(177, 'stk-20260911-wa0640', '🖼️', 'STK 20260911 WA0640', '/stickers/STK-20260911-WA0640.webp', 1, 177, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(178, 'stk-20260911-wa0641', '🖼️', 'STK 20260911 WA0641', '/stickers/STK-20260911-WA0641.webp', 1, 178, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(179, 'stk-20260911-wa0642', '🖼️', 'STK 20260911 WA0642', '/stickers/STK-20260911-WA0642.webp', 1, 179, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(180, 'stk-20260911-wa0643', '🖼️', 'STK 20260911 WA0643', '/stickers/STK-20260911-WA0643.webp', 1, 180, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(181, 'stk-20260911-wa0644', '🖼️', 'STK 20260911 WA0644', '/stickers/STK-20260911-WA0644.webp', 1, 181, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(182, 'stk-20260911-wa0645', '🖼️', 'STK 20260911 WA0645', '/stickers/STK-20260911-WA0645.webp', 1, 182, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(183, 'stk-20260911-wa0646', '🖼️', 'STK 20260911 WA0646', '/stickers/STK-20260911-WA0646.webp', 1, 183, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(184, 'stk-20260911-wa0647', '🖼️', 'STK 20260911 WA0647', '/stickers/STK-20260911-WA0647.webp', 1, 184, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(185, 'stk-20260911-wa0648', '🖼️', 'STK 20260911 WA0648', '/stickers/STK-20260911-WA0648.webp', 1, 185, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(186, 'stk-20260911-wa0649', '🖼️', 'STK 20260911 WA0649', '/stickers/STK-20260911-WA0649.webp', 1, 186, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(187, 'stk-20260911-wa0650', '🖼️', 'STK 20260911 WA0650', '/stickers/STK-20260911-WA0650.webp', 1, 187, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(188, 'stk-20260911-wa0651', '🖼️', 'STK 20260911 WA0651', '/stickers/STK-20260911-WA0651.webp', 1, 188, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(189, 'stk-20260911-wa0652', '🖼️', 'STK 20260911 WA0652', '/stickers/STK-20260911-WA0652.webp', 1, 189, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(190, 'stk-20260911-wa0653', '🖼️', 'STK 20260911 WA0653', '/stickers/STK-20260911-WA0653.webp', 1, 190, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(191, 'stk-20260911-wa0654', '🖼️', 'STK 20260911 WA0654', '/stickers/STK-20260911-WA0654.webp', 1, 191, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(192, 'stk-20260911-wa0655', '🖼️', 'STK 20260911 WA0655', '/stickers/STK-20260911-WA0655.webp', 1, 192, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(193, 'stk-20260911-wa0656', '🖼️', 'STK 20260911 WA0656', '/stickers/STK-20260911-WA0656.webp', 1, 193, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(194, 'stk-20260911-wa0657', '🖼️', 'STK 20260911 WA0657', '/stickers/STK-20260911-WA0657.webp', 1, 194, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(195, 'stk-20260911-wa0658', '🖼️', 'STK 20260911 WA0658', '/stickers/STK-20260911-WA0658.webp', 1, 195, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(196, 'stk-20260911-wa0659', '🖼️', 'STK 20260911 WA0659', '/stickers/STK-20260911-WA0659.webp', 1, 196, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(197, 'stk-20260911-wa0660', '🖼️', 'STK 20260911 WA0660', '/stickers/STK-20260911-WA0660.webp', 1, 197, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(198, 'stk-20260911-wa0661', '🖼️', 'STK 20260911 WA0661', '/stickers/STK-20260911-WA0661.webp', 1, 198, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(199, 'stk-20260911-wa0662', '🖼️', 'STK 20260911 WA0662', '/stickers/STK-20260911-WA0662.webp', 1, 199, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(200, 'stk-20260911-wa0663', '🖼️', 'STK 20260911 WA0663', '/stickers/STK-20260911-WA0663.webp', 1, 200, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(201, 'stk-20260911-wa0664', '🖼️', 'STK 20260911 WA0664', '/stickers/STK-20260911-WA0664.webp', 1, 201, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(202, 'stk-20260911-wa0665', '🖼️', 'STK 20260911 WA0665', '/stickers/STK-20260911-WA0665.webp', 1, 202, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(203, 'stk-20260911-wa0669', '🖼️', 'STK 20260911 WA0669', '/stickers/STK-20260911-WA0669.webp', 1, 203, '2026-09-24 06:44:18', '2026-09-24 06:44:40'),
(204, 'stk-20260911-wa0670', '🖼️', 'STK 20260911 WA0670', '/stickers/STK-20260911-WA0670.webp', 1, 204, '2026-09-24 06:44:18', '2026-09-24 06:44:40');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `stories`
--

CREATE TABLE `stories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `media_path` varchar(500) NOT NULL,
  `media_type` varchar(80) NOT NULL,
  `created_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `visibility` varchar(16) NOT NULL DEFAULT 'all',
  `caption` varchar(500) NOT NULL DEFAULT '',
  `film_id` bigint(20) UNSIGNED DEFAULT NULL,
  `is_trailer` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `stories`
--

INSERT INTO `stories` (`id`, `user_id`, `media_path`, `media_type`, `created_at`, `expires_at`, `visibility`, `caption`, `film_id`, `is_trailer`) VALUES
(2, 1, 'storage/stories/661154c49bd0c8f2db3be6c001ecc81a1f87622533fc2181.mp4', 'video/mp4', '2026-09-23 17:54:03', '2026-09-30 17:54:03', 'all', '', NULL, 0);

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `story_comments`
--

CREATE TABLE `story_comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `story_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `comment` varchar(500) NOT NULL,
  `parent_comment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `story_follows`
--

CREATE TABLE `story_follows` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `followed_user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `story_gift_transactions`
--

CREATE TABLE `story_gift_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `story_id` bigint(20) UNSIGNED NOT NULL,
  `sender_id` bigint(20) UNSIGNED NOT NULL,
  `receiver_id` bigint(20) UNSIGNED NOT NULL,
  `gift_id` bigint(20) UNSIGNED NOT NULL,
  `coin_cost` bigint(20) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `story_gift_transactions`
--

INSERT INTO `story_gift_transactions` (`id`, `story_id`, `sender_id`, `receiver_id`, `gift_id`, `coin_cost`, `created_at`) VALUES
(1, 2, 2, 1, 11, 1000, '2026-09-24 08:55:42');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `story_likes`
--

CREATE TABLE `story_likes` (
  `story_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `story_likes`
--

INSERT INTO `story_likes` (`story_id`, `user_id`, `created_at`) VALUES
(2, 2, '2026-09-24 06:41:22');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `story_reports`
--

CREATE TABLE `story_reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `story_id` bigint(20) UNSIGNED NOT NULL,
  `reporter_id` bigint(20) UNSIGNED NOT NULL,
  `reason` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `story_views`
--

CREATE TABLE `story_views` (
  `story_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `viewed_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `story_views`
--

INSERT INTO `story_views` (`story_id`, `user_id`, `viewed_at`) VALUES
(2, 2, '2026-09-23 19:25:04'),
(2, 4, '2026-09-25 20:37:01');

-- --------------------------------------------------------

--
--

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `typing_status`
--

CREATE TABLE `typing_status` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `other_user_id` bigint(20) UNSIGNED NOT NULL,
  `expires_at` datetime(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nickname` varchar(32) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `status` enum('active','offline','deleted') NOT NULL DEFAULT 'active',
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `ban_expires_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `is_ghost` tinyint(1) NOT NULL DEFAULT 0,
  `is_vip` tinyint(1) NOT NULL DEFAULT 0,
  `vip_expires_at` datetime DEFAULT NULL,
  `push_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `message_permission` enum('everyone','friends','nobody') NOT NULL DEFAULT 'everyone',
  `friend_permission` enum('everyone','nobody') NOT NULL DEFAULT 'everyone',
  `gender` enum('male','female') DEFAULT NULL,
  `avatar_id` varchar(32) NOT NULL DEFAULT 'ghost',
  `vip_frame_id` varchar(32) NOT NULL DEFAULT 'vip_02',
  `activity_xp` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `users`
--

INSERT INTO `users` (`id`, `nickname`, `email`, `password_hash`, `status`, `is_banned`, `ban_expires_at`, `is_deleted`, `created_at`, `updated_at`, `last_seen_at`, `is_ghost`, `is_vip`, `vip_expires_at`, `push_enabled`, `message_permission`, `friend_permission`, `gender`, `avatar_id`, `vip_frame_id`, `activity_xp`) VALUES
(1, 'Admin', 'vghost.app@gmail.com', '$2y$12$DJI8ahstE7gwWRx9LAU26usRoLcmLmp..zntwHvF.JwaZiibyxlEa', 'offline', 0, NULL, 0, '2026-09-22 00:00:00', '2026-09-26 07:56:36', '2026-09-26 07:56:36', 1, 1, NULL, 1, 'everyone', 'everyone', 'male', 'male_01', 'vip_02', 101748),
(2, 'VGhost', 'az.redmi.not14@gmail.com', '$2y$12$gM.PVLv5ENz3boj/SAxDU.DynpT3h1zZZQguwuLRx4E4RMLgFsqei', 'offline', 0, NULL, 0, '2026-09-22 17:28:08', '2026-09-25 12:17:39', '2026-09-25 12:17:39', 1, 1, NULL, 1, 'everyone', 'everyone', 'female', 'female_02', 'vip_02', 101450),
(4, 'Test', 'test@gmail.com', '$2y$10$xY/mvhVUlbA1kV/u2wTz3edQoP2VTvb.UQYO0TSec9yGopeRLnSQ6', 'offline', 0, NULL, 0, '2026-09-25 20:36:52', '2026-09-25 21:13:44', '2026-09-25 21:13:44', 0, 0, NULL, 1, 'everyone', 'everyone', 'female', 'female_01', 'vip_02', 10);

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `user_devices`
--

CREATE TABLE `user_devices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `device_id` varchar(190) DEFAULT NULL,
  `fcm_token` text NOT NULL,
  `platform` varchar(20) NOT NULL DEFAULT 'android',
  `last_seen_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `user_devices`
--

INSERT INTO `user_devices` (`id`, `user_id`, `device_id`, `fcm_token`, `platform`, `last_seen_at`, `created_at`) VALUES
(7, 2, 'd8844c6c-4733-44f1-aef0-2165b702a1c2', 'dydQ6OQKSVyE3YjIixMDGh:APA91bF3T5K1y97jwXLZG3vsinmPQw90Xt4uVfr_j6S77fGlqs2zqK7VEiQfp91fSc4X5nU2mLwUtFL1Th40EaADnN7BzWvfXMJwlP544IFYEZXIwhtKH8Y', 'android', '2026-09-25 10:50:32', '2026-09-22 20:36:14'),
(26, 1, 'af09c11e-01d8-4bc0-9afe-656ddb82f90f', 'cg0a2ytHRwChuanPB1ev-p:APA91bGgsz1KubrQwjWghG9f9wm8Qw-bxGAhbPuWbov4WEf1zxew1qE_Hup7xKxceUxNUOijqduG3eUvie41eQzUTTekS9qdzPeSDqXYfhLEHGWLKCYbwrQ', 'android', '2026-09-26 07:55:57', '2026-09-25 20:41:44');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `user_profiles`
--

CREATE TABLE `user_profiles` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `display_name` varchar(80) DEFAULT NULL,
  `bio` varchar(1000) DEFAULT NULL,
  `avatar_url` varchar(1000) DEFAULT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `user_profiles`
--

INSERT INTO `user_profiles` (`user_id`, `display_name`, `bio`, `avatar_url`, `updated_at`) VALUES
(1, 'Admin', '', NULL, '2026-09-24 16:34:13'),
(2, 'VGhost', '', NULL, '2026-09-22 15:31:53');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `user_progression`
--

CREATE TABLE `user_progression` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `level` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `xp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `total_xp` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `user_progression`
--

INSERT INTO `user_progression` (`user_id`, `level`, `xp`, `total_xp`, `updated_at`) VALUES
(1, 1000, 0, 0, '2026-09-22 11:09:51'),
(2, 1000, 0, 99900, '2026-09-22 17:28:08');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `last_seen_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `token_hash`, `expires_at`, `created_at`, `last_seen_at`) VALUES
(9, 2, '8e3f6fe75d5a94a57f58d4224be3e141eaaa715bf88f74644204e8463d200004', '2026-10-22 15:31:20', '2026-09-22 15:31:20', '2026-09-22 17:52:02'),
(12, 2, '82fbcdd198a9782a8c90d56a2462cf7bbd3fd36c007ccbf50e2ede2f4120838f', '2026-10-22 20:36:10', '2026-09-22 20:36:10', '2026-09-25 10:51:00'),
(26, 1, '419ea29f2abb4f44adf45cc4330d2de547fe3f2d1216cc8e1bf533b207b9e815', '2026-10-24 10:08:05', '2026-09-24 10:08:05', '2026-09-24 10:09:40'),
(28, 1, '9b5093a4d4bc5745b5b3d531019b8d74f5b0b33fd667cad04046f99688a80e43', '2026-10-24 10:12:47', '2026-09-24 10:12:47', '2026-09-25 12:17:04'),
(29, 2, 'defbf98b77ecec4bcaef88553b063e7b00ad43fcd4eea2aca935e280cf8152e9', '2026-10-25 12:17:28', '2026-09-25 12:17:28', '2026-09-25 12:17:39'),
(30, 1, '14792028107e764f3425a5c692b392223b13dbb508b1ff4bedf18b1aef71f2d6', '2026-10-25 12:18:01', '2026-09-25 12:18:01', '2026-09-25 15:52:00'),
(31, 1, '77bc0686bcfc69ed0675b8f46fd7301d5956cef4908b3a58fd39e8bb915e87b3', '2026-10-25 15:52:14', '2026-09-25 15:52:14', '2026-09-25 19:39:12'),
(32, 1, 'b356df2d62a1254b1075db170dcfa68e04a76506f52d265c913d426aa2763245', '2026-10-25 19:39:05', '2026-09-25 19:39:05', '2026-09-25 20:19:15'),
(33, 4, 'b6625acdad3855a6f5b44d3a3da5dd32d9f602f4f14ce1104ef8f4a718ccdad5', '2026-10-25 20:36:52', '2026-09-25 20:36:52', '2026-09-25 20:37:05'),
(34, 4, 'c8269398f1b29f1c4e68d36cb672c9e9745ea1e088a2f26609d7203387ff5724', '2026-10-25 20:37:30', '2026-09-25 20:37:30', '2026-09-25 20:41:32'),
(35, 1, 'b0f56e909697fb7c5e36e1bcda2b87e5357e50b0965e27117a689da28ac9f60d', '2026-10-25 20:41:43', '2026-09-25 20:41:43', '2026-09-26 07:56:36'),
(36, 4, '7e600538793656d37889100d36568a0e551fd54f56bd20839691b147c38ab8ca', '2026-10-25 20:45:48', '2026-09-25 20:45:48', '2026-09-25 21:13:46');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `user_status`
--

CREATE TABLE `user_status` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `last_seen_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `user_status`
--

INSERT INTO `user_status` (`user_id`, `is_online`, `last_seen_at`) VALUES
(1, 0, '2026-09-26 07:56:36'),
(2, 0, '2026-09-25 12:17:39'),
(4, 0, '2026-09-25 21:13:44');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `vip_purchases`
--

CREATE TABLE `vip_purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(64) NOT NULL,
  `purchase_token` varchar(512) NOT NULL,
  `order_id` varchar(128) DEFAULT NULL,
  `duration_days` int(10) UNSIGNED NOT NULL,
  `purchase_time_ms` bigint(20) UNSIGNED DEFAULT NULL,
  `granted_until` datetime DEFAULT NULL,
  `consumed` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('granted','pending_consume','rejected','refunded') NOT NULL DEFAULT 'granted',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `wallets`
--

CREATE TABLE `wallets` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `balance` bigint(20) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `wallets`
--

INSERT INTO `wallets` (`user_id`, `balance`, `created_at`, `updated_at`) VALUES
(1, 1024064, '2026-09-22 00:00:00', '2026-09-26 00:10:17'),
(2, 977030, '2026-09-22 17:28:08', '2026-09-25 12:17:37'),
(4, 1490, '2026-09-25 20:36:52', '2026-09-25 21:01:47');

-- --------------------------------------------------------

--
-- Cədvəl üçün cədvəl strukturu `wallet_transactions`
--

CREATE TABLE `wallet_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `reference` varchar(190) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Sxemi çıxarılan cedvel `wallet_transactions`
--

INSERT INTO `wallet_transactions` (`id`, `user_id`, `type`, `amount`, `reference`, `created_at`) VALUES
(1, 1, 'daily_login', 500, 'daily:2026-09-22', '2026-09-22 10:40:21'),
(14, 1, 'level_up_reward', 100, 'level:1001', '2026-09-22 14:55:48'),
(15, 2, 'daily_login', 500, 'daily:2026-09-22', '2026-09-22 15:31:21'),
(31, 1, 'level_up_reward', 100, 'level:1002', '2026-09-22 18:18:36'),
(36, 1, 'daily_login', 500, 'daily:2026-09-23', '2026-09-23 03:32:02'),
(50, 1, 'level_up_reward', 100, 'level:1003', '2026-09-23 16:24:22'),
(54, 2, 'daily_login', 500, 'daily:2026-09-23', '2026-09-23 19:25:03'),
(55, 1, 'daily_login', 500, 'daily:2026-09-24', '2026-09-24 04:33:47'),
(56, 2, 'daily_login', 500, 'daily:2026-09-24', '2026-09-24 06:41:09'),
(57, 1, 'gift', -10, 'gift:1', '2026-09-24 06:41:50'),
(58, 1, 'gift', -20, 'gift:2', '2026-09-24 06:41:54'),
(59, 1, 'gift', -50, 'gift:3', '2026-09-24 06:41:58'),
(60, 2, 'gift', -50000, 'gift:20', '2026-09-24 06:41:58'),
(61, 2, 'level_up_reward', 100, 'level:1001', '2026-09-24 06:41:58'),
(62, 1, 'gift', -100, 'gift:4', '2026-09-24 06:42:03'),
(63, 1, 'gift', -150, 'gift:5', '2026-09-24 06:42:06'),
(64, 2, 'gift', -10, 'gift:1', '2026-09-24 06:42:10'),
(65, 1, 'gift', -200, 'gift:6', '2026-09-24 06:42:10'),
(66, 2, 'gift', -200, 'gift:6', '2026-09-24 06:42:14'),
(67, 1, 'gift', -300, 'gift:7', '2026-09-24 06:42:15'),
(68, 2, 'gift', -2000, 'gift:13', '2026-09-24 06:42:20'),
(69, 2, 'level_up_reward', 100, 'level:1002', '2026-09-24 06:42:20'),
(70, 1, 'gift', -400, 'gift:8', '2026-09-24 06:42:22'),
(71, 1, 'level_up_reward', 100, 'level:1004', '2026-09-24 06:42:22'),
(72, 2, 'gift', -500, 'gift:9', '2026-09-24 06:42:25'),
(73, 1, 'gift', -500, 'gift:9', '2026-09-24 06:42:27'),
(74, 2, 'gift', -300, 'gift:7', '2026-09-24 06:42:30'),
(75, 2, 'level_up_reward', 100, 'level:1003', '2026-09-24 06:42:30'),
(76, 1, 'gift', -750, 'gift:10', '2026-09-24 06:42:32'),
(77, 1, 'level_up_reward', 100, 'level:1005', '2026-09-24 06:42:32'),
(78, 2, 'gift', -200, 'gift:6', '2026-09-24 06:42:34'),
(79, 1, 'gift', -1000, 'gift:11', '2026-09-24 06:42:39'),
(80, 1, 'level_up_reward', 100, 'level:1006', '2026-09-24 06:42:39'),
(81, 2, 'gift', -5000, 'gift:15', '2026-09-24 06:42:43'),
(82, 2, 'level_up_reward', 100, 'level:1004', '2026-09-24 06:42:43'),
(83, 1, 'gift', -1500, 'gift:12', '2026-09-24 06:42:44'),
(84, 1, 'level_up_reward', 100, 'level:1007', '2026-09-24 06:42:44'),
(85, 2, 'gift', -10000, 'gift:17', '2026-09-24 06:42:48'),
(86, 2, 'level_up_reward', 100, 'level:1005', '2026-09-24 06:42:48'),
(87, 1, 'gift', -2000, 'gift:13', '2026-09-24 06:42:50'),
(88, 1, 'level_up_reward', 100, 'level:1008', '2026-09-24 06:42:50'),
(89, 2, 'gift', -25000, 'gift:19', '2026-09-24 06:42:53'),
(90, 2, 'level_up_reward', 100, 'level:1006', '2026-09-24 06:42:53'),
(91, 1, 'gift', -3000, 'gift:14', '2026-09-24 06:42:55'),
(92, 1, 'level_up_reward', 100, 'level:1009', '2026-09-24 06:42:55'),
(93, 2, 'gift', -15000, 'gift:18', '2026-09-24 06:42:58'),
(94, 2, 'level_up_reward', 100, 'level:1007', '2026-09-24 06:42:58'),
(95, 1, 'gift', -7500, 'gift:16', '2026-09-24 06:43:03'),
(96, 1, 'level_up_reward', 100, 'level:1010', '2026-09-24 06:43:03'),
(97, 2, 'gift', -25000, 'gift:19', '2026-09-24 06:43:04'),
(98, 2, 'level_up_reward', 100, 'level:1008', '2026-09-24 06:43:04'),
(99, 1, 'gift', -50000, 'gift:20', '2026-09-24 06:43:08'),
(100, 1, 'level_up_reward', 100, 'level:1011', '2026-09-24 06:43:08'),
(101, 2, 'gift', -50000, 'gift:20', '2026-09-24 06:43:09'),
(102, 2, 'level_up_reward', 100, 'level:1009', '2026-09-24 06:43:09'),
(103, 1, 'gift', -25000, 'gift:19', '2026-09-24 06:43:12'),
(104, 1, 'level_up_reward', 100, 'level:1012', '2026-09-24 06:43:12'),
(105, 2, 'gift', -100, 'gift:4', '2026-09-24 06:43:17'),
(106, 2, 'gift', -50, 'gift:3', '2026-09-24 06:43:20'),
(107, 1, 'coin_transfer', -10349, 'to:2', '2026-09-24 06:43:28'),
(108, 2, 'coin_transfer', 10349, 'from:1', '2026-09-24 06:43:28'),
(109, 2, 'gift', -20, 'gift:2', '2026-09-24 06:43:29'),
(110, 2, 'gift', -150, 'gift:5', '2026-09-24 06:43:39'),
(111, 2, 'gift', -400, 'gift:8', '2026-09-24 06:43:45'),
(112, 2, 'level_up_reward', 100, 'level:1010', '2026-09-24 06:43:45'),
(113, 2, 'gift', -1000, 'gift:11', '2026-09-24 06:43:54'),
(114, 2, 'level_up_reward', 100, 'level:1011', '2026-09-24 06:43:54'),
(115, 2, 'gift', -1500, 'gift:12', '2026-09-24 06:43:59'),
(116, 2, 'level_up_reward', 100, 'level:1012', '2026-09-24 06:43:59'),
(117, 2, 'gift', -3000, 'gift:14', '2026-09-24 06:44:03'),
(118, 2, 'level_up_reward', 100, 'level:1013', '2026-09-24 06:44:03'),
(119, 1, 'gift', -10, 'gift:1', '2026-09-24 06:46:12'),
(120, 1, 'gift', -750, 'gift:10', '2026-09-24 06:46:20'),
(121, 1, 'level_up_reward', 100, 'level:1013', '2026-09-24 06:46:20'),
(128, 2, 'story_gift', -1000, 'story_gift:2:11', '2026-09-24 08:55:42'),
(129, 1, 'story_gift', 1000, 'story_gift:2:11', '2026-09-24 08:55:42'),
(130, 2, 'level_up_reward', 100, 'level:1014', '2026-09-24 08:55:42'),
(131, 1, 'gift', -2000, 'gift:13', '2026-09-24 09:41:09'),
(132, 1, 'level_up_reward', 100, 'level:1014', '2026-09-24 09:41:09'),
(133, 1, 'admin_balance_edit', 101542, 'admin-set:1', '2026-09-24 09:49:03'),
(134, 2, 'admin_balance_edit', 177681, 'admin-set:1', '2026-09-24 09:49:39'),
(136, 1, 'level_up_reward', 100, 'level:1015', '2026-09-24 09:54:57'),
(138, 1, 'daily_login', 500, 'daily:2026-09-25', '2026-09-25 08:01:53'),
(139, 2, 'daily_login', 500, 'daily:2026-09-25', '2026-09-25 10:44:20'),
(140, 2, 'gift', -200, 'gift:6', '2026-09-25 10:50:06'),
(141, 2, 'gift', -50, 'gift:3', '2026-09-25 10:50:10'),
(142, 2, 'gift', -1000, 'gift:11', '2026-09-25 10:50:15'),
(143, 2, 'level_up_reward', 100, 'level:1015', '2026-09-25 10:50:15'),
(144, 2, 'coin_transfer', -12300, 'to:1', '2026-09-25 10:50:43'),
(145, 1, 'coin_transfer', 12300, 'from:2', '2026-09-25 10:50:43'),
(146, 2, 'coin_transfer', -10000, 'to:1', '2026-09-25 10:50:55'),
(147, 1, 'coin_transfer', 10000, 'from:2', '2026-09-25 10:50:55'),
(148, 2, 'gift', -10, 'gift:1', '2026-09-25 12:17:37'),
(165, 1, 'level_up_reward', 100, 'level:1016', '2026-09-25 19:44:55'),
(166, 4, 'welcome_bonus', 1000, 'welcome', '2026-09-25 20:36:52'),
(167, 4, 'daily_login', 500, 'daily:2026-09-25', '2026-09-25 20:36:53'),
(183, 1, 'level_up_reward', 100, 'level:1017', '2026-09-25 20:55:35'),
(204, 1, 'level_up_reward', 100, 'level:1018', '2026-09-25 21:00:57'),
(205, 1, 'gift', -400, 'gift:8', '2026-09-25 21:01:34'),
(207, 1, 'daily_login', 500, 'daily:2026-09-26', '2026-09-26 00:10:17');

--
-- Indexes for dumped tables
--

--
-- Cədvəl üçün indekslər `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`user_id`);

--
-- Cədvəl üçün indekslər `admin_coin_code_reset_tokens`
--
ALTER TABLE `admin_coin_code_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `admin_user_id` (`admin_user_id`),
  ADD KEY `expires_at` (`expires_at`);

--
-- Cədvəl üçün indekslər `admin_coin_security`
--
ALTER TABLE `admin_coin_security`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_user_id` (`admin_user_id`);

--
-- Cədvəl üçün indekslər `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_user_id` (`admin_user_id`,`created_at`);

--
-- Cədvəl üçün indekslər `admin_security_attempts`
--
ALTER TABLE `admin_security_attempts`
  ADD PRIMARY KEY (`admin_user_id`);

--
-- Cədvəl üçün indekslər `api_idempotency_keys`
--
ALTER TABLE `api_idempotency_keys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_idem` (`user_id`,`endpoint`,`idem_key_hash`),
  ADD KEY `idx_idem_exp` (`expires_at`);

--
-- Cədvəl üçün indekslər `app_notifications`
--
ALTER TABLE `app_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`,`is_read`,`created_at`);

--
-- Cədvəl üçün indekslər `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `block_unique` (`blocker_id`,`blocked_id`),
  ADD KEY `blocked_id` (`blocked_id`);

--
-- Cədvəl üçün indekslər `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `conversation_pair` (`user_one_id`,`user_two_id`),
  ADD KEY `updated_at` (`updated_at`),
  ADD KEY `user_two_id` (`user_two_id`);

--
-- Cədvəl üçün indekslər `daily_coin_rewards`
--
ALTER TABLE `daily_coin_rewards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `daily_user_date` (`user_id`,`reward_date`),
  ADD KEY `reward_date` (`reward_date`);

--
-- Cədvəl üçün indekslər `friendships`
--
ALTER TABLE `friendships`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pair_unique` (`user_one_id`,`user_two_id`),
  ADD KEY `user_two_id` (`user_two_id`),
  ADD KEY `requester_id` (`requester_id`);

--
--
--
-- Cədvəl üçün indekslər `gifts`
--
ALTER TABLE `gifts`
  ADD PRIMARY KEY (`id`);

--
-- Cədvəl üçün indekslər `gift_transactions`
--
ALTER TABLE `gift_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`),
  ADD KEY `gift_id` (`gift_id`);

--
-- Cədvəl üçün indekslər `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_id` (`conversation_id`,`id`),
  ADD KEY `expires_at` (`expires_at`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`),
  ADD KEY `sticker_id` (`sticker_id`);

--
-- Cədvəl üçün indekslər `message_reactions`
--
ALTER TABLE `message_reactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `one_reaction_per_user` (`message_id`,`user_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Cədvəl üçün indekslər `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Cədvəl üçün indekslər `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `expires_at` (`expires_at`);

--
-- Cədvəl üçün indekslər `profile_views`
--
ALTER TABLE `profile_views`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile_user_id` (`profile_user_id`,`created_at`),
  ADD KEY `viewer_id` (`viewer_id`);

--
-- Cədvəl üçün indekslər `progression_daily`
--
ALTER TABLE `progression_daily`
  ADD PRIMARY KEY (`user_id`,`reward_date`,`reason`),
  ADD KEY `reward_date` (`reward_date`);

--
-- Cədvəl üçün indekslər `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`rate_key`),
  ADD KEY `window_start` (`window_start`);

--
--
--
-- Cədvəl üçün indekslər `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Cədvəl üçün indekslər `stickers`
--
ALTER TABLE `stickers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sticker_key` (`sticker_key`),
  ADD KEY `is_active` (`is_active`,`sort_order`);

--
-- Cədvəl üçün indekslər `stories`
--
ALTER TABLE `stories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_stories_user_expiry` (`user_id`,`expires_at`),
  ADD KEY `idx_stories_expiry` (`expires_at`);

--
-- Cədvəl üçün indekslər `story_comments`
--
ALTER TABLE `story_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_story_comments_story` (`story_id`,`created_at`),
  ADD KEY `idx_story_comments_user` (`user_id`),
  ADD KEY `idx_story_comments_parent` (`parent_comment_id`);

--
-- Cədvəl üçün indekslər `story_follows`
--
ALTER TABLE `story_follows`
  ADD PRIMARY KEY (`user_id`,`followed_user_id`),
  ADD KEY `idx_story_follows_target` (`followed_user_id`);

--
-- Cədvəl üçün indekslər `story_gift_transactions`
--
ALTER TABLE `story_gift_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_story_gift_story` (`story_id`),
  ADD KEY `idx_story_gift_sender` (`sender_id`),
  ADD KEY `idx_story_gift_receiver` (`receiver_id`),
  ADD KEY `idx_story_gift_created` (`created_at`),
  ADD KEY `gift_id` (`gift_id`);

--
-- Cədvəl üçün indekslər `story_likes`
--
ALTER TABLE `story_likes`
  ADD PRIMARY KEY (`story_id`,`user_id`),
  ADD KEY `idx_story_likes_user` (`user_id`);

--
-- Cədvəl üçün indekslər `story_reports`
--
ALTER TABLE `story_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_story_reports_story` (`story_id`),
  ADD KEY `idx_story_reports_reporter` (`reporter_id`);

--
-- Cədvəl üçün indekslər `story_views`
--
ALTER TABLE `story_views`
  ADD PRIMARY KEY (`story_id`,`user_id`),
  ADD KEY `idx_story_views_user` (`user_id`);

--
--
--
-- Cədvəl üçün indekslər `typing_status`
--
ALTER TABLE `typing_status`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `idx_typing_other` (`other_user_id`,`expires_at`);

--
-- Cədvəl üçün indekslər `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nickname` (`nickname`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Cədvəl üçün indekslər `user_devices`
--
ALTER TABLE `user_devices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `device_id` (`device_id`);

--
-- Cədvəl üçün indekslər `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`user_id`);

--
-- Cədvəl üçün indekslər `user_progression`
--
ALTER TABLE `user_progression`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `level` (`level`);

--
-- Cədvəl üçün indekslər `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `expires_at` (`expires_at`);

--
-- Cədvəl üçün indekslər `user_status`
--
ALTER TABLE `user_status`
  ADD PRIMARY KEY (`user_id`);

--
-- Cədvəl üçün indekslər `vip_purchases`
--
ALTER TABLE `vip_purchases`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_vip_purchase_token` (`purchase_token`),
  ADD KEY `idx_vip_user_status` (`user_id`,`status`,`granted_until`);

--
-- Cədvəl üçün indekslər `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`user_id`);

--
-- Cədvəl üçün indekslər `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`,`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- Cədvəl üçün AUTO_INCREMENT `admin_coin_code_reset_tokens`
--
ALTER TABLE `admin_coin_code_reset_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `admin_logs`
--
ALTER TABLE `admin_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Cədvəl üçün AUTO_INCREMENT `api_idempotency_keys`
--
ALTER TABLE `api_idempotency_keys`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `app_notifications`
--
ALTER TABLE `app_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Cədvəl üçün AUTO_INCREMENT `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Cədvəl üçün AUTO_INCREMENT `daily_coin_rewards`
--
ALTER TABLE `daily_coin_rewards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3147;

--
-- Cədvəl üçün AUTO_INCREMENT `friendships`
--
ALTER TABLE `friendships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
--
--
-- Cədvəl üçün AUTO_INCREMENT `gifts`
--
ALTER TABLE `gifts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Cədvəl üçün AUTO_INCREMENT `gift_transactions`
--
ALTER TABLE `gift_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- Cədvəl üçün AUTO_INCREMENT `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- Cədvəl üçün AUTO_INCREMENT `message_reactions`
--
ALTER TABLE `message_reactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Cədvəl üçün AUTO_INCREMENT `profile_views`
--
ALTER TABLE `profile_views`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- Cədvəl üçün AUTO_INCREMENT `stories`
--
ALTER TABLE `stories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Cədvəl üçün AUTO_INCREMENT `story_comments`
--
ALTER TABLE `story_comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `story_gift_transactions`
--
ALTER TABLE `story_gift_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Cədvəl üçün AUTO_INCREMENT `story_reports`
--
ALTER TABLE `story_reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
--
--
-- Cədvəl üçün AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Cədvəl üçün AUTO_INCREMENT `user_devices`
--
ALTER TABLE `user_devices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Cədvəl üçün AUTO_INCREMENT `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Cədvəl üçün AUTO_INCREMENT `vip_purchases`
--
ALTER TABLE `vip_purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Cədvəl üçün AUTO_INCREMENT `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `admin_coin_code_reset_tokens`
--
ALTER TABLE `admin_coin_code_reset_tokens`
  ADD CONSTRAINT `admin_coin_code_reset_tokens_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `admin_coin_security`
--
ALTER TABLE `admin_coin_security`
  ADD CONSTRAINT `admin_coin_security_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `admin_security_attempts`
--
ALTER TABLE `admin_security_attempts`
  ADD CONSTRAINT `admin_security_attempts_ibfk_1` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `api_idempotency_keys`
--
ALTER TABLE `api_idempotency_keys`
  ADD CONSTRAINT `api_idempotency_keys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `app_notifications`
--
ALTER TABLE `app_notifications`
  ADD CONSTRAINT `app_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blocks`
--
ALTER TABLE `blocks`
  ADD CONSTRAINT `blocks_ibfk_1` FOREIGN KEY (`blocker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `blocks_ibfk_2` FOREIGN KEY (`blocked_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `conversations`
--
ALTER TABLE `conversations`
  ADD CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`user_one_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `conversations_ibfk_2` FOREIGN KEY (`user_two_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `daily_coin_rewards`
--
ALTER TABLE `daily_coin_rewards`
  ADD CONSTRAINT `daily_coin_rewards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `friendships`
--
ALTER TABLE `friendships`
  ADD CONSTRAINT `friendships_ibfk_1` FOREIGN KEY (`user_one_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `friendships_ibfk_2` FOREIGN KEY (`user_two_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `friendships_ibfk_3` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
--
--
-- Constraints for table `gift_transactions`
--
ALTER TABLE `gift_transactions`
  ADD CONSTRAINT `gift_transactions_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `gift_transactions_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `gift_transactions_ibfk_3` FOREIGN KEY (`gift_id`) REFERENCES `gifts` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `message_reactions`
--
ALTER TABLE `message_reactions`
  ADD CONSTRAINT `message_reactions_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `message_reactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `profile_views`
--
ALTER TABLE `profile_views`
  ADD CONSTRAINT `profile_views_ibfk_1` FOREIGN KEY (`viewer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `profile_views_ibfk_2` FOREIGN KEY (`profile_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `progression_daily`
--
ALTER TABLE `progression_daily`
  ADD CONSTRAINT `progression_daily_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
--
--
-- Constraints for table `stories`
--
ALTER TABLE `stories`
  ADD CONSTRAINT `stories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `story_comments`
--
ALTER TABLE `story_comments`
  ADD CONSTRAINT `story_comments_ibfk_1` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `story_follows`
--
ALTER TABLE `story_follows`
  ADD CONSTRAINT `story_follows_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_follows_ibfk_2` FOREIGN KEY (`followed_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `story_gift_transactions`
--
ALTER TABLE `story_gift_transactions`
  ADD CONSTRAINT `story_gift_transactions_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_gift_transactions_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_gift_transactions_ibfk_3` FOREIGN KEY (`gift_id`) REFERENCES `gifts` (`id`);

--
-- Constraints for table `story_likes`
--
ALTER TABLE `story_likes`
  ADD CONSTRAINT `story_likes_ibfk_1` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `story_reports`
--
ALTER TABLE `story_reports`
  ADD CONSTRAINT `story_reports_ibfk_1` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_reports_ibfk_2` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `story_views`
--
ALTER TABLE `story_views`
  ADD CONSTRAINT `story_views_ibfk_1` FOREIGN KEY (`story_id`) REFERENCES `stories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `story_views_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD CONSTRAINT `user_devices_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_progression`
--
ALTER TABLE `user_progression`
  ADD CONSTRAINT `user_progression_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_status`
--
ALTER TABLE `user_status`
  ADD CONSTRAINT `user_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vip_purchases`
--
ALTER TABLE `vip_purchases`
  ADD CONSTRAINT `fk_vip_purchase_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD CONSTRAINT `wallet_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;


-- VGhost Films + Trailer final schema (added to this dump on 2026-09-26)
CREATE TABLE IF NOT EXISTS `films` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `poster_url` varchar(1000) DEFAULT NULL,
  `video_url` varchar(1000) NOT NULL DEFAULT '',
  `poster_path` varchar(500) DEFAULT NULL,
  `video_path` varchar(500) DEFAULT NULL,
  `category` varchar(80) NOT NULL DEFAULT 'Drama',
  `release_year` smallint(5) UNSIGNED DEFAULT NULL,
  `duration_minutes` smallint(5) UNSIGNED DEFAULT NULL,
  `is_vip` tinyint(1) NOT NULL DEFAULT 0,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_films_active_featured` (`is_active`,`is_featured`,`sort_order`,`id`),
  KEY `idx_films_category` (`category`,`is_active`),
  KEY `idx_films_year` (`release_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @db := DATABASE();
SET @has_film_id := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stories' AND COLUMN_NAME='film_id');
SET @sql := IF(@has_film_id=0,'ALTER TABLE stories ADD COLUMN film_id BIGINT UNSIGNED NULL AFTER caption','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @has_is_trailer := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stories' AND COLUMN_NAME='is_trailer');
SET @sql := IF(@has_is_trailer=0,'ALTER TABLE stories ADD COLUMN is_trailer TINYINT(1) NOT NULL DEFAULT 0 AFTER film_id','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @has_idx := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stories' AND INDEX_NAME='idx_stories_trailer');
SET @sql := IF(@has_idx=0,'CREATE INDEX idx_stories_trailer ON stories(is_trailer,film_id,created_at)','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
UPDATE stories SET expires_at='2099-12-31 23:59:59' WHERE is_trailer=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
