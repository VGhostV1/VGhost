-- VGhost Gift + user-to-user Coin transfer schema.
CREATE TABLE IF NOT EXISTS gifts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 coin_cost BIGINT NOT NULL DEFAULT 0,
 is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS gift_transactions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 sender_id BIGINT UNSIGNED NOT NULL,
 receiver_id BIGINT UNSIGNED NOT NULL,
 gift_id BIGINT UNSIGNED NOT NULL,
 coin_cost BIGINT NOT NULL,
 created_at DATETIME NOT NULL,
 INDEX(sender_id), INDEX(receiver_id),
 FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(gift_id) REFERENCES gifts(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO gifts (id,name,coin_cost,is_active) VALUES
(1,'love',10,1),(2,'rose',20,1),(3,'diamond',50,1),(4,'crown',100,1),(5,'cake',150,1),(6,'gift_box',200,1),(7,'money_bag',300,1),(8,'butterfly',400,1),(9,'fire',500,1),(10,'rocket',750,1),(11,'dragon',1000,1),(12,'trophy',1500,1),(13,'thunder',2000,1),(14,'ghost',3000,1),(15,'galaxy',5000,1),(16,'ufo',7500,1),(17,'meteor',10000,1),(18,'castle',15000,1),(19,'volcano',25000,1),(20,'vghost_royal',50000,1);
