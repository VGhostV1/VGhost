-- V43 Film/Trailer hardening. Safe to run on existing VGhost installations.
-- Runtime ensure_* functions in App.php/Story.php also make these changes automatically.

CREATE TABLE IF NOT EXISTS films (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(180) NOT NULL,
  description TEXT NULL,
  poster_url VARCHAR(1000) NULL,
  video_url VARCHAR(1000) NOT NULL DEFAULT '',
  poster_path VARCHAR(500) NULL,
  video_path VARCHAR(500) NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'Drama',
  release_year SMALLINT UNSIGNED NULL,
  duration_minutes SMALLINT UNSIGNED NULL,
  is_vip TINYINT(1) NOT NULL DEFAULT 0,
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(id),
  KEY idx_films_active_featured(is_active,is_featured,sort_order,id),
  KEY idx_films_category(category,is_active),
  KEY idx_films_year(release_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- For pre-v40 installations, apply update_v40_films.sql and update_v41_film_media.sql first.
-- update_v42_trailers.sql adds film_id/is_trailer to Stories.
