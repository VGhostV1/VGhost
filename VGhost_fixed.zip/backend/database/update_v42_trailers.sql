-- VGhost Trailer support: persistent film trailers linked to films
SET @db := DATABASE();
SET @has_film_id := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stories' AND COLUMN_NAME='film_id');
SET @sql := IF(@has_film_id=0,'ALTER TABLE stories ADD COLUMN film_id BIGINT UNSIGNED NULL AFTER caption','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @has_is_trailer := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stories' AND COLUMN_NAME='is_trailer');
SET @sql := IF(@has_is_trailer=0,'ALTER TABLE stories ADD COLUMN is_trailer TINYINT(1) NOT NULL DEFAULT 0 AFTER film_id','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @has_idx := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='stories' AND INDEX_NAME='idx_stories_trailer');
SET @sql := IF(@has_idx=0,'CREATE INDEX idx_stories_trailer ON stories(is_trailer,film_id,created_at)','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
UPDATE stories SET expires_at='2099-12-31 23:59:59' WHERE is_trailer=1;
