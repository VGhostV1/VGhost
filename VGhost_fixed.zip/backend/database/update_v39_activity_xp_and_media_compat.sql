-- VGhost compatibility migration
-- Adds the activity XP column required by user discovery/search/friends endpoints.
SET @has_activity_xp := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='activity_xp');
SET @sql := IF(@has_activity_xp=0, 'ALTER TABLE users ADD COLUMN activity_xp INT UNSIGNED NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
