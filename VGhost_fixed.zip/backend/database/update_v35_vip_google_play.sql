-- VGHOST VIP paid time packs (Google Play consumable one-time products)
-- Safe to run more than once on MySQL/MariaDB installations.

SET @has_vip_expiry := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema=DATABASE() AND table_name='users' AND column_name='vip_expires_at'
);
SET @sql := IF(@has_vip_expiry=0,
  'ALTER TABLE users ADD COLUMN vip_expires_at DATETIME NULL AFTER is_vip',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS vip_purchases (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  product_id VARCHAR(64) NOT NULL,
  purchase_token VARCHAR(512) NOT NULL,
  order_id VARCHAR(128) NULL,
  duration_days INT UNSIGNED NOT NULL,
  purchase_time_ms BIGINT UNSIGNED NULL,
  granted_until DATETIME NULL,
  consumed TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('granted','pending_consume','rejected','refunded') NOT NULL DEFAULT 'granted',
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_vip_purchase_token (purchase_token),
  KEY idx_vip_user_status (user_id,status,granted_until),
  CONSTRAINT fk_vip_purchase_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
