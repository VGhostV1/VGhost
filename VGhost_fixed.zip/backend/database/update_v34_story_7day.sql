-- VGhost Story retention: 7 days.
-- Messages remain governed by their existing 24-hour expiry rules.
-- Extend active stories to exactly 7 days from creation and remove no Story rows here.
UPDATE stories
SET expires_at = DATE_ADD(created_at, INTERVAL 7 DAY)
WHERE expires_at <> DATE_ADD(created_at, INTERVAL 7 DAY);
