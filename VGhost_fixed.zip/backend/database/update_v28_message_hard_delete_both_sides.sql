-- VGHOST Message Deletion v28
-- A private chat has one shared message row for both participants.
-- User/admin deletion therefore HARD-DELETES that shared row instead of only
-- setting is_deleted=1. The API also removes its reactions and private media.
-- Conversation deletion HARD-DELETES the shared conversation and all messages.
-- 24-hour expiry also uses physical DELETE.

-- Clean reaction rows left behind by older databases that did not have ON DELETE CASCADE.
DELETE r
FROM message_reactions r
LEFT JOIN messages m ON m.id = r.message_id
WHERE m.id IS NULL;

-- Keep the existing 24-hour rule authoritative and physically remove expired messages.
UPDATE messages
SET expires_at = DATE_ADD(created_at, INTERVAL 24 HOUR)
WHERE expires_at IS NULL;

DELETE FROM messages
WHERE expires_at <= UTC_TIMESTAMP();

-- No schema change is required. The existing messages/conversations tables are
-- intentionally retained; deletion is implemented as transactional hard DELETE.
