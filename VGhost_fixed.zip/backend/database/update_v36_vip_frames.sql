-- V36: persistent VIP profile-frame selection.
-- Only active VIP users are allowed to change this value through the API.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS vip_frame_id VARCHAR(32) NOT NULL DEFAULT 'vip_02' AFTER avatar_id;

-- Existing accounts using the removed legacy frames are migrated to VIP 1.
UPDATE users
SET vip_frame_id='vip_02'
WHERE vip_frame_id IS NULL OR vip_frame_id='' OR vip_frame_id NOT IN ('vip_02');
