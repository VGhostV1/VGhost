-- VGHOST Message Expiry v27
-- Every message type (text, emoji, sticker, GIF, voice, image/video/audio attachment)
-- lives exactly 24 hours from created_at.
-- The API already writes expires_at for new messages; this migration repairs any
-- legacy NULL values and removes rows whose 24-hour lifetime has already ended.

UPDATE messages
SET expires_at = DATE_ADD(created_at, INTERVAL 24 HOUR)
WHERE expires_at IS NULL;

DELETE FROM messages
WHERE expires_at <= UTC_TIMESTAMP();
