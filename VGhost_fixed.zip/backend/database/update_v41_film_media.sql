-- VGhost Films media storage. The runtime migration in api/core/App.php is idempotent.
ALTER TABLE films ADD COLUMN poster_path VARCHAR(500) NULL;
ALTER TABLE films ADD COLUMN video_path VARCHAR(500) NULL;
