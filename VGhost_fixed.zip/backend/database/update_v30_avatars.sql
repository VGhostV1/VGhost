ALTER TABLE users
  ADD COLUMN IF NOT EXISTS gender ENUM('male','female') NULL AFTER friend_permission,
  ADD COLUMN IF NOT EXISTS avatar_id VARCHAR(32) NOT NULL DEFAULT 'ghost' AFTER gender;

UPDATE users SET avatar_id = CASE WHEN gender='female' THEN 'female' WHEN gender='male' THEN 'male' ELSE avatar_id END;
