-- V45: allow guest devices to receive public/broadcast push notifications.
CREATE TABLE IF NOT EXISTS `guest_devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `device_id` varchar(255) DEFAULT NULL,
  `fcm_token` text NOT NULL,
  `token_hash` char(64) NOT NULL,
  `language` varchar(16) NOT NULL DEFAULT 'en',
  `last_seen_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_guest_token_hash` (`token_hash`),
  KEY `idx_guest_device` (`device_id`),
  KEY `idx_guest_last_seen` (`last_seen_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `public_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(190) NOT NULL,
  `body` text NOT NULL,
  `target` varchar(32) NOT NULL DEFAULT 'home',
  `target_value` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_public_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
