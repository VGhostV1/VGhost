-- VGHOST link previews v23
-- Safe additive migration. The API also self-heals older production databases.
ALTER TABLE messages ADD COLUMN IF NOT EXISTS link_preview_url VARCHAR(2048) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS link_preview_title VARCHAR(500) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS link_preview_description TEXT NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS link_preview_image VARCHAR(2048) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS link_preview_site VARCHAR(190) NULL;
ALTER TABLE messages ADD COLUMN IF NOT EXISTS link_preview_type VARCHAR(30) NULL;
