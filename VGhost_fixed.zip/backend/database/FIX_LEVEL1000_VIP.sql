START TRANSACTION;

-- Admin (id=1) and VGhost (id=2): keep the visible 70/100 XP progress,
-- while making their calculated activity level exactly 1000.
UPDATE `users`
SET `activity_xp` = 99970,
    `is_vip` = 1,
    `vip_expires_at` = NULL
WHERE `id` IN (1, 2);

-- Keep the separate progression table consistent too.
UPDATE `user_progression`
SET `level` = 1000,
    `updated_at` = UTC_TIMESTAMP()
WHERE `user_id` IN (1, 2);

COMMIT;

SELECT id, nickname, activity_xp, is_vip, vip_expires_at
FROM users
WHERE id IN (1, 2);
