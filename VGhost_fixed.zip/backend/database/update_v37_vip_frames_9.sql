-- V37: replace the legacy 4 VIP profile frames with the new 9-frame set.
-- Existing users with a removed/unknown frame are migrated to vip_02.

ALTER TABLE users
  MODIFY COLUMN vip_frame_id VARCHAR(32) NOT NULL DEFAULT 'vip_02';

UPDATE users
SET vip_frame_id='vip_02'
WHERE vip_frame_id IS NULL
   OR vip_frame_id=''
   OR vip_frame_id NOT IN ('vip_02');
