-- VGHOST v29: true account purge / zero-trace cleanup
--
-- Panic, Delete Account and Super Admin Delete now physically remove the user
-- and every account-owned row through permanently_delete_user(). The existing
-- schema already uses ON DELETE CASCADE for most account tables.
--
-- This migration also purges legacy soft-deleted users from the live database.

-- Legacy typing rows have no FK in older installations.
DELETE ts FROM typing_status ts
JOIN users u ON u.id = ts.user_id OR u.id = ts.other_user_id
WHERE u.is_deleted = 1;

-- Legacy admin-log target references have no FK. Remove them before users.
DELETE al
FROM admin_logs al
JOIN users u ON u.id = al.target_user_id
WHERE u.is_deleted = 1;

-- backup_import_tokens may exist on installations without an FK.
DELETE bit
FROM backup_import_tokens bit
JOIN users u ON u.id = bit.admin_user_id
WHERE u.is_deleted = 1;

-- Existing FK relationships then cascade all remaining account-owned rows.
DELETE FROM users WHERE is_deleted = 1;

-- Future account deletion must use the transactional hard-purge path in
-- api/core/App.php; no soft-delete fallback is permitted.
