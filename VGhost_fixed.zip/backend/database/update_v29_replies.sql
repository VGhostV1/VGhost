-- V29: threaded replies for Story comments and Chat messages
ALTER TABLE story_comments ADD COLUMN parent_comment_id BIGINT UNSIGNED NULL AFTER comment;
ALTER TABLE story_comments ADD INDEX idx_story_comments_parent(parent_comment_id);
ALTER TABLE messages ADD COLUMN reply_to_message_id BIGINT UNSIGNED NULL AFTER sticker_id;
ALTER TABLE messages ADD INDEX idx_messages_reply_to(reply_to_message_id);
