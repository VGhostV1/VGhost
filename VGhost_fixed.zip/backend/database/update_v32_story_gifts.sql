-- VGhost Story/Reels gifts: separate transaction ledger.
-- This does NOT modify /coins/send or gift_transactions.
-- story_id intentionally has no FK: expired/deleted Stories must not erase gift history.
CREATE TABLE IF NOT EXISTS story_gift_transactions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    story_id BIGINT UNSIGNED NOT NULL,
    sender_id BIGINT UNSIGNED NOT NULL,
    receiver_id BIGINT UNSIGNED NOT NULL,
    gift_id BIGINT UNSIGNED NOT NULL,
    coin_cost BIGINT NOT NULL,
    created_at DATETIME NOT NULL,
    INDEX idx_story_gift_story(story_id),
    INDEX idx_story_gift_sender(sender_id),
    INDEX idx_story_gift_receiver(receiver_id),
    INDEX idx_story_gift_created(created_at),
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (gift_id) REFERENCES gifts(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
