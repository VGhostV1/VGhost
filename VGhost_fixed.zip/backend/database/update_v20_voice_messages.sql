-- VGhost voice-message storage columns. Run once on existing installations that were created before voice support.
-- If your messages table already has these columns, do not run this file again.
ALTER TABLE messages ADD COLUMN audio_path VARCHAR(500) NULL AFTER is_deleted;
ALTER TABLE messages ADD COLUMN audio_duration INT UNSIGNED NULL AFTER audio_path;
CREATE INDEX idx_messages_voice ON messages(message_type,id);
