<?php declare(strict_types=1);
require_once __DIR__.'/../api/core/App.php';
require_once __DIR__.'/../api/core/MessageCleanup.php';

$pdo = db();
$deleted = cleanup_expired_messages($pdo);
printf("VGHOST cleanup OK | UTC=%s | messages_deleted=%d\n", gmdate('Y-m-d H:i:s'), $deleted);
