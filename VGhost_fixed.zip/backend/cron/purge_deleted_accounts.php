<?php
declare(strict_types=1);
require_once __DIR__.'/../api/core/App.php';

// Run from a trusted cron job only. Set VGHOST_CRON_KEY in the server
// environment and pass the same value in X-VGHOST-CRON-KEY.
$expected=(string)(getenv('VGHOST_CRON_KEY') ?: '');
$provided=(string)($_SERVER['HTTP_X_VGHOST_CRON_KEY'] ?? '');
if($expected==='' || $provided==='' || !hash_equals($expected,$provided)) {
    http_response_code(403); exit('FORBIDDEN');
}

$pdo=db();
$rows=$pdo->query('SELECT id FROM users WHERE is_deleted=1 ORDER BY id ASC LIMIT 100')->fetchAll(PDO::FETCH_COLUMN);
$count=0;
foreach($rows as $id){
    $id=(int)$id;
    if($id<1) continue;
    $pdo->beginTransaction();
    try {
        permanently_delete_user($pdo,$id);
        $pdo->commit();
        $count++;
    } catch(Throwable $e) {
        if($pdo->inTransaction()) $pdo->rollBack();
        error_log('legacy account purge failed for '.$id.': '.$e->getMessage());
    }
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok'=>true,'purged'=>$count],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
