VGHOST MESSAGE AUTO-CLEANUP
===========================

Messages are created with a 24-hour expires_at timestamp.
The cleanup script deletes rows where expires_at <= UTC_TIMESTAMP().

IMPORTANT
---------
This backend also runs the same cleanup automatically during normal API
requests, so expired messages are removed even when the hosting provider has
not configured a cron job.

For best reliability, ALSO configure a server cron job to run every 5 minutes:

PHP CLI example:
*/5 * * * * /usr/bin/php /FULL/PATH/TO/Backend/cron/cleanup_messages.php >/dev/null 2>&1

cPanel Cron example:
*/5 * * * * php /home/USERNAME/public_html/Backend/cron/cleanup_messages.php >/dev/null 2>&1

Replace the PHP path and project path with the real paths on the server.

Do NOT make cron/cleanup_messages.php publicly accessible. The cron folder is
protected by .htaccess in this package.
