<?php
declare(strict_types=1);
session_name('vghost_admin');
// Secure cookie settings; works on standard Apache/PHP hosting.
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
require_once __DIR__.'/api/core/RateLimit.php';
require_once __DIR__.'/api/config/database.php';
require_once __DIR__.'/api/core/App.php';
function admin_require(): array {
    if (empty($_SESSION['admin_user_id'])) { header('Location: /'); exit; }
    $st=db()->prepare('SELECT u.id,u.nickname,u.email,u.is_banned,a.role FROM admins a JOIN users u ON u.id=a.user_id WHERE u.id=? AND u.is_deleted=0 LIMIT 1');
    $st->execute([(int)$_SESSION['admin_user_id']]); $u=$st->fetch();
    if (!$u) { session_destroy(); header('Location: /'); exit; }
    return $u;
}
function csrf_token(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_check(): void { if(!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['csrf'] ?? ''))) { http_response_code(403); exit('Invalid CSRF token'); } }
function h(?string $v): string { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }
function admin_security_verify_web(array $admin, string $provided): bool {
    $pdo=db();
    $provided=trim($provided);
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_security (id TINYINT UNSIGNED PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, code_hash VARCHAR(255) NOT NULL, locked TINYINT(1) NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL, FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $sec=$pdo->query('SELECT * FROM admin_coin_security WHERE id=1 LIMIT 1')->fetch();
    if(!$sec){
        $cfg=require __DIR__.'/api/config/config.php';
        $hash=(string)($cfg['security']['admin_operation_code_hash']??'');
        if($hash==='') return false;
        $pdo->prepare('INSERT INTO admin_coin_security(id,admin_user_id,code_hash,locked,updated_at) VALUES(1,?,?,0,UTC_TIMESTAMP())')->execute([(int)$admin['id'],$hash]);
        $sec=['admin_user_id'=>(int)$admin['id'],'code_hash'=>$hash,'locked'=>0];
    } elseif((int)$sec['admin_user_id'] !== (int)$admin['id']) {
        $pdo->prepare('UPDATE admin_coin_security SET admin_user_id=?,updated_at=UTC_TIMESTAMP() WHERE id=1')->execute([(int)$admin['id']]);
        $sec['admin_user_id']=(int)$admin['id'];
    }
    if((int)$sec['locked']===1 || $provided==='') return false;
    return password_verify($provided,(string)$sec['code_hash']);
}

