<?php
/**
 * VGHOST production configuration.
 *
 * Secrets MUST live outside public_html, preferably:
 *   /home/vghostsite/vg-secret/secrets.php
 *
 * Environment variables override values from secrets.php.
 */
declare(strict_types=1);

$secretFile = '/home/vghostsite/vg-secret/secrets.php';
$secrets = is_file($secretFile) ? require $secretFile : [];
if (!is_array($secrets)) $secrets = [];

$env = static function(string $name, $fallback = '') {
    $v = getenv($name);
    return ($v !== false && $v !== '') ? $v : $fallback;
};

return [
  'db' => [
    'host' => (string)$env('VGHOST_DB_HOST', $secrets['db']['host'] ?? 'localhost'),
    'port' => (int)$env('VGHOST_DB_PORT', $secrets['db']['port'] ?? 3306),
    'name' => (string)$env('VGHOST_DB_NAME', $secrets['db']['name'] ?? ''),
    'user' => (string)$env('VGHOST_DB_USER', $secrets['db']['user'] ?? ''),
    'pass' => (string)$env('VGHOST_DB_PASS', $secrets['db']['pass'] ?? ''),
    'charset' => 'utf8mb4',
  ],
  'app' => [
    'base_url' => (string)$env('VGHOST_BASE_URL', 'https://vghost.site/api'),
    'timezone' => (string)$env('VGHOST_TIMEZONE', 'UTC'),
  ],
  'smtp' => [
    'enabled' => filter_var($env('VGHOST_SMTP_ENABLED', $secrets['smtp']['enabled'] ?? false), FILTER_VALIDATE_BOOLEAN),
    'host' => (string)$env('VGHOST_SMTP_HOST', $secrets['smtp']['host'] ?? ''),
    'port' => (int)$env('VGHOST_SMTP_PORT', $secrets['smtp']['port'] ?? 465),
    'encryption' => (string)$env('VGHOST_SMTP_ENCRYPTION', $secrets['smtp']['encryption'] ?? 'ssl'),
    'username' => (string)$env('VGHOST_SMTP_USERNAME', $secrets['smtp']['username'] ?? ''),
    'password' => (string)$env('VGHOST_SMTP_PASSWORD', $secrets['smtp']['password'] ?? ''),
    'from_email' => (string)$env('VGHOST_SMTP_FROM_EMAIL', $secrets['smtp']['from_email'] ?? ''),
    'from_name' => (string)$env('VGHOST_SMTP_FROM_NAME', $secrets['smtp']['from_name'] ?? 'VGHOST'),
  ],
  'security' => [
    'force_https' => true,
    'session_ttl_days' => 30,
    'max_body_bytes' => 1048576,
    // Keep this hash here only if it is intentionally non-secret. The plaintext code is never stored.
    'admin_operation_code_hash' => (string)$env('VGHOST_ADMIN_OPERATION_CODE_HASH', $secrets['security']['admin_operation_code_hash'] ?? ''),
  ],
  'google_play' => [
    'package_name' => (string)$env('VGHOST_GOOGLE_PLAY_PACKAGE', $secrets['google_play']['package_name'] ?? 'com.vghost.app'),
    'service_account_json' => (string)$env('VGHOST_GOOGLE_PLAY_SERVICE_ACCOUNT_JSON', $secrets['google_play']['service_account_json'] ?? '/home/vghostsite/vg-secret/google-play-service-account.json'),
  ],
  // Temporary local/testing mode. Disabled by default in production; enable explicitly with VGHOST_VIP_TEST_MODE=1 only for testing.
  'vip' => [
    'test_mode' => in_array(strtolower((string)$env('VGHOST_VIP_TEST_MODE', '0')), ['1','true','yes','on'], true),
  ],
  'fcm' => [
    'enabled' => filter_var($env('FCM_ENABLED', $secrets['fcm']['enabled'] ?? true), FILTER_VALIDATE_BOOLEAN),
    'service_account_json' => (string)$env('FCM_SERVICE_ACCOUNT_JSON', $secrets['fcm']['service_account_json'] ?? '/home/vghostsite/vg-secret/firebase-service-account.json'),
  ],
];
