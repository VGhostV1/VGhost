<?php
declare(strict_types=1);
require_once __DIR__.'/core/Response.php';
require_once __DIR__.'/core/Request.php';
require_once __DIR__.'/core/RateLimit.php';
require_once __DIR__.'/core/Migrations.php';
// App.php contains the film runtime migration used by ensure_films_schema().
// Load it before the startup schema checks; otherwise PHP raises an undefined-function
// fatal and every routed API request is returned as HTTP 500.
require_once __DIR__.'/core/App.php';
require_once __DIR__.'/core/Film.php';

// Keep API responses JSON even when PHP hits a fatal error.
register_shutdown_function(function (): void {
    $e = error_get_last();
    if (!$e || !in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) return;
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; style-src 'unsafe-inline'");
header('Cross-Origin-Resource-Policy: same-origin');
header('Cross-Origin-Opener-Policy: same-origin');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    echo json_encode(['ok'=>false,'error'=>'SERVER_ERROR'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
});

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Frame-Options: DENY');
header('Permissions-Policy: geolocation=(), camera=()');
header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; style-src 'unsafe-inline'");
header('Cross-Origin-Resource-Policy: same-origin');
header('Cross-Origin-Opener-Policy: same-origin');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

$configFile = __DIR__.'/config/config.php';
if (!is_file($configFile)) fail('SERVER_NOT_CONFIGURED',500);
$config = require $configFile;

// Keep legacy production databases compatible with the current runtime schema.
// This is idempotent and runs once per PHP request.
try { ensure_storage_directories(); ensure_runtime_schema(); ensure_ugc_reports_schema(); ensure_idempotency_schema(); ensure_avatar_schema(); ensure_vip_frame_schema(); ensure_vip_schema(); ensure_admin_ban_schema(); ensure_gift_catalog(); ensure_message_attachment_schema(); ensure_activity_level_schema(); ensure_films_schema(); } catch (Throwable $e) {
    // Never turn an otherwise healthy API into a 500 because an optional migration
    // cannot run; the endpoint will return its normal database error if required.
}

$forceHttps = (bool)($config['security']['force_https'] ?? true);
$https = strtolower((string)($_SERVER['HTTPS'] ?? ''));
$trustedProxy = (bool)($config['security']['trust_forwarded_proto'] ?? false);
$forwardedProto = $trustedProxy ? strtolower(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0] ?? '')) : '';
$isHttps = ($https !== '' && $https !== 'off') || $forwardedProto === 'https';
if ($forceHttps && !$isHttps) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'HTTPS_REQUIRED'], JSON_UNESCAPED_UNICODE);
    exit;
}

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/api/index.php'), '/');
$route = '/' . ltrim(substr($path, strlen($base)), '/');
// Support both clean /api/<route> URLs and direct /api/index.php/<route> URLs.
// The external account-deletion page uses the latter form.
if (str_starts_with($route, '/index.php/')) {
    $route = substr($route, strlen('/index.php'));
}
$map = [
 '/stories/list'=>'endpoints/stories/list.php','/stories/create'=>'endpoints/stories/create.php','/stories/upload-chunk'=>'endpoints/stories/upload_chunk.php','/stories/upload-finalize'=>'endpoints/stories/upload_finalize.php','/stories/delete'=>'endpoints/stories/delete.php','/stories/view'=>'endpoints/stories/view.php','/stories/like'=>'endpoints/stories/like.php','/stories/comment'=>'endpoints/stories/comment.php','/stories/comments'=>'endpoints/stories/comments.php','/stories/comment-delete'=>'endpoints/stories/comment-delete.php','/stories/viewers'=>'endpoints/stories/viewers.php','/stories/report'=>'endpoints/stories/report.php','/stories/follow'=>'endpoints/stories/follow.php','/stories/media'=>'endpoints/stories/media.php','/stories/gift'=>'endpoints/stories/gift.php','/stories/gifts/history'=>'endpoints/stories/gifts_history.php', '/auth/register'=>'endpoints/auth/register.php','/auth/login'=>'endpoints/auth/login.php','/auth/logout'=>'endpoints/auth/logout.php','/auth/me'=>'endpoints/auth/me.php','/auth/reset'=>'endpoints/auth/reset.php','/auth/reset-confirm'=>'endpoints/auth/reset_confirm.php','/auth/web-delete-account'=>'endpoints/auth/web_delete_account.php','/auth/change-password'=>'endpoints/auth/change_password.php','/auth/change-email'=>'endpoints/auth/change_email.php','/auth/panic'=>'endpoints/auth/panic.php','/users/profile'=>'endpoints/users/profile.php','/users/avatar'=>'endpoints/users/avatar.php','/users/vip-frame'=>'endpoints/users/vip_frame.php','/users/avatar_media'=>'endpoints/users/avatar_media.php','/users/status'=>'endpoints/users/status.php','/users/stealth'=>'endpoints/users/stealth.php','/users/public'=>'endpoints/users/public.php','/users/search'=>'endpoints/users/search.php','/users/directory'=>'endpoints/users/directory.php','/users/list'=>'endpoints/users/list.php','/vip/status'=>'endpoints/vip/status.php','/vip/google/verify'=>'endpoints/vip/google_verify.php','/vip/test/activate'=>'endpoints/vip/test_activate.php','/users/online'=>'endpoints/users/online.php','/devices/fcm'=>'endpoints/devices/fcm.php','/devices/guest-fcm'=>'endpoints/devices/guest_fcm.php','/settings/push'=>'endpoints/settings/push.php','/settings/privacy'=>'endpoints/settings/privacy.php','/notifications/list'=>'endpoints/notifications/list.php','/notifications/public'=>'endpoints/notifications/public.php','/notifications/read'=>'endpoints/notifications/read.php','/notifications/clear'=>'endpoints/notifications/clear.php','/messages/report'=>'endpoints/messages/report.php','/users/report'=>'endpoints/users/report.php','/messages/send'=>'endpoints/messages/send.php','/messages/list'=>'endpoints/messages/list.php','/messages/conversations'=>'endpoints/messages/conversations.php','/messages/read'=>'endpoints/messages/read.php','/messages/conversation-delete'=>'endpoints/messages/conversation_delete.php','/messages/delete'=>'endpoints/messages/delete.php','/messages/edit'=>'endpoints/messages/edit.php','/messages/typing'=>'endpoints/messages/typing.php','/messages/typing-status'=>'endpoints/messages/typing_status.php','/messages/voice'=>'endpoints/messages/voice.php','/messages/voice-file'=>'endpoints/messages/voice_file.php','/messages/attachment'=>'endpoints/messages/attachment.php','/messages/attachment-file'=>'endpoints/messages/attachment-file.php','/messages/attachment-chunk'=>'endpoints/messages/attachment-chunk.php','/messages/attachment-finalize'=>'endpoints/messages/attachment-finalize.php','/messages/link-preview-image'=>'endpoints/messages/link-preview-image.php','/messages/react'=>'endpoints/messages/react.php','/stickers/list'=>'endpoints/stickers/list.php','/gifs/list'=>'endpoints/gifs/list.php','/friends/list'=>'endpoints/friends/list.php','/friends/add'=>'endpoints/friends/add.php','/friends/accept'=>'endpoints/friends/accept.php','/friends/reject'=>'endpoints/friends/reject.php','/friends/remove'=>'endpoints/friends/remove.php','/blocks/list'=>'endpoints/blocks/list.php','/blocks/add'=>'endpoints/blocks/add.php','/blocks/remove'=>'endpoints/blocks/remove.php','/profile/view'=>'endpoints/profile/view.php','/profile/level'=>'endpoints/profile/level.php','/profile/visitors'=>'endpoints/profile/visitors.php','/wallet/balance'=>'endpoints/wallet/balance.php','/wallet/transactions'=>'endpoints/wallet/transactions.php','/wallet/coins'=>'endpoints/wallet/coins.php','/gifts/profile'=>'endpoints/gifts/profile.php','/gifts/send'=>'endpoints/gifts/send.php','/coins/send'=>'endpoints/coins/send.php','/admin/dashboard'=>'endpoints/admin/dashboard.php','/admin/security/verify'=>'endpoints/admin/security_verify.php','/admin/user-action'=>'endpoints/admin/user_action.php','/admin/delete-message'=>'endpoints/admin/delete_message.php','/admin/logs'=>'endpoints/admin/logs.php','/admin/coins'=>'endpoints/admin/coins.php','/admin/coins-set'=>'endpoints/admin/coins-set.php','/admin/coins-overview'=>'endpoints/admin/coins-overview.php','/admin/coins-all'=>'endpoints/admin/coins-all.php','/admin/coins-code-reset'=>'endpoints/admin/coins_code_reset.php','/admin/coins-code-reset-request'=>'endpoints/admin/coins_code_reset_request.php','/admin/broadcast'=>'endpoints/admin/broadcast.php','/admin/users'=>'endpoints/admin/users.php','/admin/messages'=>'endpoints/admin/messages.php','/admin/reports'=>'endpoints/admin/reports.php','/admin/activity'=>'endpoints/admin/activity.php','/admin/report-action'=>'endpoints/admin/report-action.php','/admin/push-test'=>'endpoints/admin/push_test.php','/admin/backup/export'=>'endpoints/admin/backup/export.php','/admin/backup/validate'=>'endpoints/admin/backup/validate.php','/admin/backup/import'=>'endpoints/admin/backup/import.php',

 '/films/list'=>'endpoints/films/list.php','/films/get'=>'endpoints/films/get.php','/films/track'=>'endpoints/films/track.php','/films/rate'=>'endpoints/films/rate.php','/films/like'=>'endpoints/films/like.php','/films/categories'=>'endpoints/films/categories.php','/admin/films/categories'=>'endpoints/admin/films/categories.php','/films/poster'=>'endpoints/films/poster.php','/films/stream'=>'endpoints/films/stream.php','/admin/films/list'=>'endpoints/admin/films/list.php','/admin/films/save'=>'endpoints/admin/films/save.php','/admin/films/delete'=>'endpoints/admin/films/delete.php','/admin/films/upload'=>'endpoints/admin/films/upload.php','/admin/films/upload-chunk'=>'endpoints/admin/films/upload-chunk.php','/admin/films/upload-finalize'=>'endpoints/admin/films/upload-finalize.php',
 '/admin/coins_code_reset'=>'endpoints/admin/coins_code_reset.php',
 '/admin/coins_code_reset_request'=>'endpoints/admin/coins_code_reset_request.php',
 '/admin/delete_message'=>'endpoints/admin/delete_message.php',
 '/admin/push_test'=>'endpoints/admin/push_test.php',
 '/admin/security_verify'=>'endpoints/admin/security_verify.php',
 '/admin/user_action'=>'endpoints/admin/user_action.php',
 '/auth/change_password'=>'endpoints/auth/change_password.php',
 '/auth/delete-account'=>'endpoints/auth/delete-account.php',
 '/auth/reset_confirm'=>'endpoints/auth/reset_confirm.php',
 '/auth/web_delete_account'=>'endpoints/auth/web_delete_account.php',
 '/messages/conversation_delete'=>'endpoints/messages/conversation_delete.php',
 '/messages/typing_status'=>'endpoints/messages/typing_status.php',
 '/messages/voice_file'=>'endpoints/messages/voice_file.php',
 '/progression/profile'=>'endpoints/progression/profile.php',
 '/progression/xp'=>'endpoints/progression/xp.php',
 '/settings/get'=>'endpoints/settings/get.php',
 '/settings/update'=>'endpoints/settings/update.php'
];
if ($route === '/' || $route === '') ok(['service'=>'VGHOST PHP + MySQL API','version'=>'simple-php-mysql']);
if (!isset($map[$route])) fail('NOT_FOUND',404);

$limits = [
 '/auth/login'=>[20,300],
 '/auth/register'=>[10,3600],
 '/auth/reset'=>[30,900],
 '/auth/reset-confirm'=>[10,900],
 '/auth/web-delete-account'=>[5,900],
 '/admin/security/verify'=>[10,300],
 '/admin/coins'=>[10,300], '/admin/coins-set'=>[10,300], '/admin/coins-overview'=>[30,60], '/admin/coins-all'=>[3,300],
 '/admin/broadcast'=>[10,300],
 '/admin/push-test'=>[10,300], '/admin/report-action'=>[60,300],
 '/admin/backup/export'=>[3,3600],
 '/admin/backup/validate'=>[5,3600],
 '/admin/backup/import'=>[2,3600],
 '/admin/coins-code-reset-request'=>[3,900], '/admin/coins-code-reset'=>[10,900],
   '/messages/voice'=>[20,60], '/messages/attachment'=>[20,60], '/messages/attachment-file'=>[240,60], '/messages/attachment-chunk'=>[2400,3600], '/messages/attachment-finalize'=>[30,300], '/messages/link-preview-image'=>[120,60], '/stickers/list'=>[30,60], '/gifs/list'=>[30,60],  '/messages/send'=>[120,60], '/messages/report'=>[10,3600], '/users/report'=>[10,3600], '/messages/react'=>[60,60],
 '/stories/create'=>[10,300], '/stories/upload-chunk'=>[1800,3600], '/stories/upload-finalize'=>[30,300], '/stories/delete'=>[20,60], '/stories/comment'=>[60,60], '/stories/comment-delete'=>[60,60], '/stories/like'=>[120,60], '/stories/view'=>[240,60],  '/stories/report'=>[10,3600], '/stories/gift'=>[30,60], '/stories/gifts/history'=>[60,60],

 '/films/list'=>[60,60], '/films/get'=>[120,60], '/films/track'=>[120,60], '/films/rate'=>[30,60], '/films/like'=>[120,60], '/films/categories'=>[30,60], '/admin/films/categories'=>[30,60], '/films/poster'=>[120,60], '/films/stream'=>[60,60], '/admin/films/list'=>[30,60], '/admin/films/save'=>[30,300], '/admin/films/delete'=>[20,300], '/admin/films/upload'=>[10,3600], '/admin/films/upload-chunk'=>[2400,3600], '/admin/films/upload-finalize'=>[10,3600],
 '/vip/google/verify'=>[6,300], '/vip/test/activate'=>[20,300], '/users/directory'=>[60,60], '/users/search'=>[60,60],
 '/gifts/send'=>[30,60], '/coins/send'=>[30,60], '/auth/change-password'=>[10,900], '/auth/change-email'=>[10,900],'/users/avatar'=>[120,60], '/users/vip-frame'=>[60,60], '/auth/panic'=>[5,900], '/devices/fcm'=>[20,300], '/devices/guest-fcm'=>[20,300],
];
if (isset($limits[$route])) {
    [$max,$window] = $limits[$route];
    rate_limit($route, $max, $window);
    rate_limit_cleanup();
}
// Every authenticated/public route is rate-limited; sensitive routes above have stricter caps.
if (!isset($limits[$route])) { rate_limit('global:'.$route, 120, 60); }
require __DIR__.'/'.$map[$route];