<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
current_user();

// GIF picker source: public /gifs folder.
// GIFs are stored as .webp files by design; the folder determines the picker.
$root=dirname(__DIR__,3).'/gifs';
$items=[];
if(is_dir($root)){
  foreach(scandir($root) ?: [] as $name){
    if($name==='.'||$name==='..'||!is_file($root.'/'.$name)) continue;
    if(!preg_match('/^[A-Za-z0-9._-]+\.webp$/i',$name)) continue;
    $key=pathinfo($name,PATHINFO_FILENAME);
    $items[]=[
      'id'=>$key,
      'key'=>$key,
      'label'=>$key,
      'image_url'=>'gifs/'.rawurlencode($name)
    ];
  }
}
usort($items,static fn($a,$b)=>strnatcasecmp($a['label'],$b['label']));
ok(['gifs'=>$items]);
