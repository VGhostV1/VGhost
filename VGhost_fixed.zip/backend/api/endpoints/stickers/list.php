<?php
declare(strict_types=1); require_once __DIR__.'/../../core/App.php'; require_method('GET'); current_user();

// Sticker picker source: public /stickers folder.
// Both normal and animated stickers use .webp; folder determines the picker.
$root=dirname(__DIR__,3).'/stickers';
$items=[];
if(is_dir($root)){
  foreach(scandir($root) ?: [] as $name){
    if($name==='.'||$name==='..'||!is_file($root.'/'.$name)) continue;
    if(!preg_match('/^[A-Za-z0-9._-]+\.webp$/i',$name)) continue;
    $key=pathinfo($name,PATHINFO_FILENAME);
    $items[]=[
      'id'=>$key,
      'key'=>$key,
      'label'=>$key,
      'emoji'=>'',
      'is_active'=>true,
      'sort_order'=>count($items),
      'image_url'=>'stickers/'.rawurlencode($name)
    ];
  }
}
usort($items,static fn($a,$b)=>strnatcasecmp($a['label'],$b['label']));
foreach($items as $i=>&$item){$item['sort_order']=$i;}
unset($item);
ok(['stickers'=>$items]);
