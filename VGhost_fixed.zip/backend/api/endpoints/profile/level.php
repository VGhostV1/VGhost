<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Level.php';
require_method('GET');
$u=current_user();
$pdo=db();
$q=$pdo->prepare('SELECT COALESCE(activity_xp,0) AS xp FROM users u WHERE u.id=? LIMIT 1');
$q->execute([$u['id']]); $r=$q->fetch() ?: ['xp'=>0];
$xp=(int)$r['xp'];
$level=activity_level($xp);
ok(['xp'=>$xp,'level'=>$level,'currentLevelXp'=>($level-1)*100,'nextLevelXp'=>$level*100,'progress'=>$xp-(($level-1)*100),'needed'=>100-($xp-(($level-1)*100))]);
