<?php
// Records profile visitors and notifies the profile owner about new guests.
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Notifications.php';

require_method('POST');
$viewer=current_user();
// Stealth/Ghost mode: viewing another profile leaves no visitor record and sends no notification.
if((int)($viewer['is_ghost']??0)===1) ok(['recorded'=>false,'notified'=>false,'stealth'=>true]);
$in=body();
$profileUserId=(int)($in['uid']??0);

if(!$profileUserId || $profileUserId===(int)$viewer['id']) ok(['recorded'=>false,'notified'=>false]);

$pdo=db();
$exists=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 LIMIT 1');
$exists->execute([$profileUserId]);
if(!$exists->fetchColumn()) fail('USER_NOT_FOUND',404);

// Always keep visitor history. The notification itself is throttled so opening a
// profile repeatedly does not spam the owner with dozens of pushes.
$pdo->prepare('INSERT INTO profile_views(viewer_id,profile_user_id,created_at) VALUES(?,?,UTC_TIMESTAMP())')
    ->execute([(int)$viewer['id'],$profileUserId]);

$recent=$pdo->prepare("SELECT id FROM app_notifications WHERE user_id=? AND type='profile_visit' AND data_json LIKE ? AND created_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) ORDER BY id DESC LIMIT 1");
$recent->execute([$profileUserId,'%\"viewerId\":\"'.(int)$viewer['id'].'\"%']);
$alreadyNotified=(bool)$recent->fetchColumn();

$notificationId=0;
if(!$alreadyNotified){
    $nickname=trim((string)($viewer['nickname']??''));
    if($nickname==='') $nickname='Bir istifadəçi';
    $notificationId=notify_localized(
        $profileUserId,
        'profile_visit',
        ['name'=>$nickname],
        [
            'viewerId'=>(string)(int)$viewer['id'],
            'userId'=>(string)(int)$viewer['id'],
            'nickname'=>$nickname,
            'senderNickname'=>$nickname,
            'target'=>'profile',
            'targetValue'=>$nickname
        ]
    );
}

ok(['recorded'=>true,'notified'=>!$alreadyNotified,'notificationId'=>$notificationId]);
