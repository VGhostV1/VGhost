<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$viewerToken = bearer_token();
$viewer = null;
if ($viewerToken) { try { $viewer = current_user(); } catch (Throwable $e) { $viewer = null; } }
$id=(int)($_GET['id']??0);
if($id<1) fail('FILM_NOT_FOUND',404);
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS film_ratings (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, film_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, rating TINYINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY uq_film_user(film_id,user_id), KEY idx_film_rating(film_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$pdo->exec("CREATE TABLE IF NOT EXISTS film_likes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, film_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_film_user(film_id,user_id), KEY idx_film_like(film_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$s=$pdo->prepare('SELECT f.id,f.title,f.description,f.poster_url,f.video_url,f.category,f.release_year,f.duration_minutes,f.is_vip,f.is_featured,f.view_count,COALESCE(AVG(fr.rating),0) AS rating_average,COUNT(fr.id) AS rating_count,(SELECT COUNT(*) FROM film_likes fl WHERE fl.film_id=f.id) AS like_count FROM films f LEFT JOIN film_ratings fr ON fr.film_id=f.id WHERE f.id=? AND f.is_active=1 GROUP BY f.id LIMIT 1');
$s->execute([$id]); $film=$s->fetch();
if(!$film) fail('FILM_NOT_FOUND',404);
$film['id']=(int)($film['id']??0);
$film['title']=(string)($film['title']??'');
$film['description']=(string)($film['description']??'');
$film['category']=(string)($film['category']??'');
$film['release_year']=isset($film['release_year']) && $film['release_year']!==null ? (int)$film['release_year'] : null;
$film['duration_minutes']=isset($film['duration_minutes']) && $film['duration_minutes']!==null ? (int)$film['duration_minutes'] : null;
$film['is_vip']=(int)($film['is_vip']??0);
$film['is_featured']=(int)($film['is_featured']??0);
$film['view_count']=(int)($film['view_count']??0);
$film['rating_average']=round((float)($film['rating_average']??0),1);
$film['rating_count']=(int)($film['rating_count']??0); $film['my_rating']=0; $film['like_count']=(int)($film['like_count']??0); $film['liked_by_me']=false; if($viewer){ $mr=$pdo->prepare('SELECT rating FROM film_ratings WHERE film_id=? AND user_id=? LIMIT 1'); $mr->execute([$id,(int)$viewer['id']]); $film['my_rating']=(int)($mr->fetchColumn()?:0); $lk=$pdo->prepare('SELECT 1 FROM film_likes WHERE film_id=? AND user_id=? LIMIT 1'); $lk->execute([$id,(int)$viewer['id']]); $film['liked_by_me']=(bool)$lk->fetchColumn(); }
// Prefer the server-managed media paths over stale/absolute legacy URLs.
$q2=$pdo->prepare('SELECT poster_path,video_path FROM films WHERE id=? LIMIT 1'); $q2->execute([$id]); $paths=$q2->fetch(PDO::FETCH_ASSOC) ?: [];
if(!empty($paths['poster_path'])) $film['poster_url']='/films/poster?id='.$id;
if(!empty($paths['video_path'])) $film['video_url']='/films/stream?id='.$id;
ok(['film'=>$film]);
