<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Film.php';
require_method('GET');
// Public catalogue metadata.

// Return the same canonical genre list used by the Admin Film form.
// Existing legacy/custom categories are appended so old films remain filterable.
ok(['categories'=>film_genres_with_existing(db())]);
