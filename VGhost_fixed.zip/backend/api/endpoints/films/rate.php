<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
// Accept both application/x-www-form-urlencoded and the Android client's JSON body.
$input=$_POST;
if(!$input){
    $raw=file_get_contents('php://input');
    $json=json_decode($raw,true);
    if(is_array($json)) $input=$json;
}
$id=(int)($input['film_id']??0);
$rating=(int)($input['rating']??0);
if($id<1 || $rating<1 || $rating>5) fail('FILM_RATING_INVALID',422);
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS film_ratings (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, film_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, rating TINYINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY uq_film_user(film_id,user_id), KEY idx_film_rating(film_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$check=$pdo->prepare('SELECT id FROM films WHERE id=? AND is_active=1 LIMIT 1'); $check->execute([$id]); if(!$check->fetch()) fail('FILM_NOT_FOUND',404);
$q=$pdo->prepare('INSERT INTO film_ratings(film_id,user_id,rating) VALUES(?,?,?) ON DUPLICATE KEY UPDATE rating=VALUES(rating),updated_at=CURRENT_TIMESTAMP');
$q->execute([$id,(int)$u['id'],$rating]);
$s=$pdo->prepare('SELECT ROUND(AVG(rating),1) rating_average,COUNT(*) rating_count FROM film_ratings WHERE film_id=?'); $s->execute([$id]); $r=$s->fetch(PDO::FETCH_ASSOC) ?: [];
ok(['rating_average'=>(float)($r['rating_average']??0),'rating_count'=>(int)($r['rating_count']??0),'my_rating'=>$rating]);
