<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$u=null;
$token=bearer_token();
if($token){ try { $u=current_user(); } catch(Throwable $e){ $u=null; } }
$id=(int)($_GET['id']??0); if($id<1) fail('FILM_NOT_FOUND',404);
$q=db()->prepare('SELECT id,title,video_path,is_vip,is_active FROM films WHERE id=? LIMIT 1'); $q->execute([$id]); $film=$q->fetch(PDO::FETCH_ASSOC);
if(!$film || (int)$film['is_active']!==1 || empty($film['video_path'])) fail('FILM_NOT_FOUND',404);
if((int)$film['is_vip']===1) {
  if(!$u) fail('VIP_FILM_REQUIRED',403);
  $vq=db()->prepare('SELECT is_vip,vip_expires_at FROM users WHERE id=? LIMIT 1'); $vq->execute([(int)$u['id']]); $v=$vq->fetch(PDO::FETCH_ASSOC) ?: [];
  $active=(int)($v['is_vip']??0)===1 && (empty($v['vip_expires_at']) || strtotime((string)$v['vip_expires_at'])>time());
  if(!$active) fail('VIP_FILM_REQUIRED',403);
}
$path=dirname(__DIR__,3).'/storage/'.$film['video_path'];
if(!is_file($path) || !is_readable($path)) fail('FILM_VIDEO_NOT_FOUND',404);
$size=(int)filesize($path); $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION)); $mime=[
 'mp4'=>'video/mp4','webm'=>'video/webm','m4v'=>'video/mp4','mov'=>'video/quicktime',
 '3gp'=>'video/3gpp','3g2'=>'video/3gpp2','mpeg'=>'video/mpeg','mpg'=>'video/mpeg','mkv'=>'video/x-matroska','ogv'=>'video/ogg','ts'=>'video/mp2t','m2ts'=>'video/mp2t','flv'=>'video/x-flv'
][$ext]??'application/octet-stream';
header('Content-Type: '.$mime); header('Accept-Ranges: bytes'); header('Cache-Control: private, no-store'); header('Content-Disposition: inline; filename="'.preg_replace('/[^A-Za-z0-9._-]+/','_',($film['title']??'film')).'.'.$ext.'"'); header('X-Content-Type-Options: nosniff');
$start=0; $end=$size-1; $status=200;
$range=(string)($_SERVER['HTTP_RANGE']??'');
if($range!=='' && preg_match('/bytes=(\d*)-(\d*)/',$range,$m)) {
  if($m[1]==='' && $m[2]!=='') { $suffix=(int)$m[2]; if($suffix>0){$start=max(0,$size-$suffix);} }
  else { $start=(int)$m[1]; if($m[2]!=='') $end=(int)$m[2]; }
  if($start<0 || $start>=$size || $end<$start) { http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
  $end=min($end,$size-1); $status=206; http_response_code(206); header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
}
$length=$end-$start+1; header('Content-Length: '.$length);
$fp=fopen($path,'rb'); if(!$fp) fail('FILM_VIDEO_NOT_FOUND',404); fseek($fp,$start);
$remaining=$length; while($remaining>0 && !feof($fp)){ $chunk=fread($fp,min(1024*1024,$remaining)); if($chunk===false || $chunk==='') break; echo $chunk; $remaining-=strlen($chunk); if(function_exists('ob_flush')) @ob_flush(); flush(); }
fclose($fp); exit;
