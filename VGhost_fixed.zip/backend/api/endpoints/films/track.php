<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
$b=body();
$id=(int)($b['film_id']??0);
$event=trim((string)($b['event']??''));
if($id<1 || !in_array($event,['view','play','watch'],true)) fail('FILM_TRACK_INVALID',422);
$pdo=db();
$q=$pdo->prepare('SELECT id,is_active FROM films WHERE id=? LIMIT 1'); $q->execute([$id]);
$film=$q->fetch(); if(!$film || (int)$film['is_active']!==1) fail('FILM_NOT_FOUND',404);
if($event==='view') {
    // Count at most one homepage/detail view per user for the same film in a
    // 30-minute window, preventing refreshes from artificially inflating rank.
    $pdo->exec("CREATE TABLE IF NOT EXISTS film_view_events (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, film_id BIGINT UNSIGNED NOT NULL,
      user_id BIGINT UNSIGNED NOT NULL, viewed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(id), KEY idx_fve_lookup(film_id,user_id,viewed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $q=$pdo->prepare('SELECT id FROM film_view_events WHERE film_id=? AND user_id=? AND viewed_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 30 MINUTE) LIMIT 1');
    $q->execute([$id,(int)$u['id']]);
    if(!$q->fetchColumn()) {
        $pdo->prepare('INSERT INTO film_view_events(film_id,user_id,viewed_at) VALUES(?,?,UTC_TIMESTAMP())')->execute([$id,(int)$u['id']]);
        $pdo->prepare('UPDATE films SET view_count=view_count+1,last_view_at=UTC_TIMESTAMP() WHERE id=?')->execute([$id]);
    }
} elseif($event==='play') {
    $pdo->prepare('UPDATE films SET play_count=play_count+1,last_view_at=UTC_TIMESTAMP() WHERE id=?')->execute([$id]);
} else {
    $seconds=max(0,min(300,(int)($b['seconds']??0)));
    if($seconds>0) $pdo->prepare('UPDATE films SET watch_seconds=watch_seconds+?,last_view_at=UTC_TIMESTAMP() WHERE id=?')->execute([$seconds,$id]);
}
ok(['tracked'=>true]);
