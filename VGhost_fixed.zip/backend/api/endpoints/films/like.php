<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
$input=$_POST; if(!$input){ $raw=file_get_contents('php://input'); $j=json_decode($raw,true); if(is_array($j)) $input=$j; }
$id=(int)($input['film_id']??0); if($id<1) fail('FILM_NOT_FOUND',404);
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS film_likes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, film_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_film_user(film_id,user_id), KEY idx_film_like(film_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$check=$pdo->prepare('SELECT id FROM films WHERE id=? AND is_active=1 LIMIT 1'); $check->execute([$id]); if(!$check->fetch()) fail('FILM_NOT_FOUND',404);
$q=$pdo->prepare('SELECT id FROM film_likes WHERE film_id=? AND user_id=? LIMIT 1'); $q->execute([$id,(int)$u['id']]); $existing=$q->fetchColumn();
if($existing){ $d=$pdo->prepare('DELETE FROM film_likes WHERE id=?'); $d->execute([$existing]); $liked=false; } else { $i=$pdo->prepare('INSERT INTO film_likes(film_id,user_id) VALUES(?,?)'); $i->execute([$id,(int)$u['id']]); $liked=true; }
$c=$pdo->prepare('SELECT COUNT(*) FROM film_likes WHERE film_id=?'); $c->execute([$id]);
ok(['liked_by_me'=>$liked,'like_count'=>(int)$c->fetchColumn()]);
