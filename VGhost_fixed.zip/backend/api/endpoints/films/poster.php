<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$id=(int)($_GET['id']??0); if($id<1) fail('FILM_NOT_FOUND',404);
$q=db()->prepare('SELECT poster_path FROM films WHERE id=? AND is_active=1 LIMIT 1'); $q->execute([$id]); $row=$q->fetch(PDO::FETCH_ASSOC);
if(!$row || empty($row['poster_path'])) fail('FILM_POSTER_NOT_FOUND',404);
$path=dirname(__DIR__,3).'/storage/'.$row['poster_path'];
if(!is_file($path) || !is_readable($path)) fail('FILM_POSTER_NOT_FOUND',404);
$ext=strtolower(pathinfo($path,PATHINFO_EXTENSION)); $mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif','bmp'=>'image/bmp','heic'=>'image/heic','heif'=>'image/heif','avif'=>'image/avif'][$ext]??'application/octet-stream';
header('Content-Type: '.$mime); header('Content-Length: '.filesize($path)); header('Cache-Control: public, max-age=86400'); header('Cross-Origin-Resource-Policy: cross-origin');
readfile($path); exit;
