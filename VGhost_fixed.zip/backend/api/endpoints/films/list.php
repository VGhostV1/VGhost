<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
// Public catalogue endpoint: browsing does not require an account.
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS film_ratings (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, film_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, rating TINYINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY uq_film_user(film_id,user_id), KEY idx_film_rating(film_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$pdo->exec("CREATE TABLE IF NOT EXISTS film_likes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, film_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_film_user(film_id,user_id), KEY idx_film_like(film_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$q=trim((string)($_GET['q']??''));
$category=trim((string)($_GET['category']??''));
$featured=(string)($_GET['featured']??''); $year=(int)($_GET['year']??0);
$where=['f.is_active=1']; $args=[];
if($q!==''){ $where[]='(f.title LIKE ? OR f.description LIKE ?)'; $like='%'.$q.'%'; $args=[$like,$like]; }
if($category!==''){ $where[]='f.category=?'; $args[]=$category; }
if($featured==='1'){ $where[]='f.is_featured=1'; }
if($year>=2000 && $year<=2026){ $where[]='f.release_year=?'; $args[]=$year; }
$sql='SELECT f.id,f.title,f.description,f.poster_url,f.video_url,f.poster_path,f.video_path,f.category,f.release_year,f.duration_minutes,f.is_vip,f.is_featured,f.created_at,f.view_count,f.play_count,f.watch_seconds,f.last_view_at,COALESCE(AVG(fr.rating),0) AS rating_average,COUNT(fr.id) AS rating_count, (SELECT COUNT(*) FROM film_likes fl WHERE fl.film_id=f.id) AS like_count FROM films f LEFT JOIN film_ratings fr ON fr.film_id=f.id WHERE '.implode(' AND ',$where).' GROUP BY f.id ORDER BY f.is_featured DESC,f.sort_order ASC,f.id DESC';
$s=$pdo->prepare($sql); $s->execute($args);
$rows=$s->fetchAll();

// "Yeni Filmlər" uses created_at. "Populyar Filmlər" is a separate ranking
// based on real engagement rather than insertion order. Scores are normalized
// within the current result set so one huge title cannot permanently dominate.
$maxViews=0.0; $maxPlays=0.0; $maxLikes=0.0;
foreach($rows as $r){
    $maxViews=max($maxViews,log1p((float)($r['view_count']??0)));
    $maxPlays=max($maxPlays,log1p((float)($r['play_count']??0)));
    $maxLikes=max($maxLikes,log1p((float)($r['like_count']??0)));
}
$films=array_map(function($r){
    $r['id']=(int)($r['id']??0);
    $r['title']=(string)($r['title']??'');
    $r['description']=(string)($r['description']??'');
    $r['category']=(string)($r['category']??'');
    $r['release_year']=isset($r['release_year']) && $r['release_year']!==null ? (int)$r['release_year'] : null;
    $r['duration_minutes']=isset($r['duration_minutes']) && $r['duration_minutes']!==null ? (int)$r['duration_minutes'] : null;
    $r['is_vip']=(int)($r['is_vip']??0);
    $r['is_featured']=(int)($r['is_featured']??0);
    $r['view_count']=(int)($r['view_count']??0);
    $r['play_count']=(int)($r['play_count']??0);
    $r['watch_seconds']=(int)($r['watch_seconds']??0);
    $r['like_count']=(int)($r['like_count']??0);
    $r['rating_average']=round((float)($r['rating_average']??0),1);
    $r['rating_count']=(int)($r['rating_count']??0); $r['my_rating']=0; $r['liked_by_me']=false;
    $r['created_at']=(string)($r['created_at']??'');
    $r['last_view_at']=(string)($r['last_view_at']??'');
    if(!empty($r['poster_path'])) $r['poster_url']='/films/poster?id='.(int)$r['id'];
    if(!empty($r['video_path'])) $r['video_url']='/films/stream?id='.(int)$r['id'];
    unset($r['poster_path'],$r['video_path']);
    return $r;
},$rows);

$maxCompletion=0.0; $maxRecent=0.0;
foreach($films as $r){
    $plays=max(1,(int)$r['play_count']);
    $duration=max(1,(int)($r['duration_minutes']??0))*60;
    $completion=min(1.0,(float)$r['watch_seconds']/($plays*$duration));
    $ageDays=max(0.0,(time()-strtotime((string)($r['last_view_at'] ?: $r['created_at'])))/86400.0);
    $recent=exp(-$ageDays/7.0);
    $maxCompletion=max($maxCompletion,$completion);
    $maxRecent=max($maxRecent,$recent);
}
foreach($films as &$r){
    $viewsNorm=$maxViews>0 ? log1p((float)$r['view_count'])/$maxViews : 0.0;
    $playsNorm=$maxPlays>0 ? log1p((float)$r['play_count'])/$maxPlays : 0.0;
    $likesNorm=$maxLikes>0 ? log1p((float)$r['like_count'])/$maxLikes : 0.0;
    $plays=max(1,(int)$r['play_count']);
    $duration=max(1,(int)($r['duration_minutes']??0))*60;
    $completion=min(1.0,(float)$r['watch_seconds']/($plays*$duration));
    $ageDays=max(0.0,(time()-strtotime((string)($r['last_view_at'] ?: $r['created_at'])))/86400.0);
    $recent=exp(-$ageDays/7.0);
    // 40% views, 25% plays, 15% likes, 10% completion, 10% freshness.
    $r['popularity_score']=round(($viewsNorm*.40+$playsNorm*.25+$likesNorm*.15+$completion*.10+$recent*.10)*100,2);
}
unset($r);

// Preserve the API's existing default order for clients that only need the
// raw list; the Android home screen requests the explicit ranking below.
$sort=(string)($_GET['sort']??'');
if($sort==='popular') usort($films,fn($a,$b)=>($b['popularity_score']<=>$a['popularity_score']) ?: ($b['id']<=>$a['id']));
elseif($sort==='new') usort($films,fn($a,$b)=>strcmp($b['created_at'],$a['created_at']) ?: ($b['id']<=>$a['id']));

foreach($films as &$r){ unset($r['created_at'],$r['last_view_at']); }
unset($r);
ok(['films'=>$films]);
