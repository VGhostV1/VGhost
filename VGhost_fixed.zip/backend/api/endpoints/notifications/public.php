<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Response.php';
require_method('GET');
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS public_notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(190) NOT NULL,
    body TEXT NOT NULL,
    target VARCHAR(32) NOT NULL DEFAULT 'home',
    target_value TEXT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_public_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$limit=max(1,min(50,(int)($_GET['limit']??30)));
$q=$pdo->query('SELECT id,title,body,target,target_value,created_at FROM public_notifications ORDER BY id DESC LIMIT '.$limit);
$rows=$q->fetchAll(PDO::FETCH_ASSOC)?:[];
$out=[];
foreach($rows as $r){
    $out[]=[
        'id'=>(string)$r['id'],
        'type'=>'broadcast',
        'title'=>(string)$r['title'],
        'body'=>(string)$r['body'],
        'data'=>['target'=>(string)$r['target'],'targetValue'=>(string)($r['target_value']??'')],
        'isRead'=>false,
        'is_read'=>false,
        'created_at'=>(string)$r['created_at'],
    ];
}
ok(['notifications'=>$out,'unread'=>count($out)]);
