<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php';
require_method('GET'); $u=current_user(); $limit=max(1,min(100,(int)($_GET['limit']??50)));
$s=db()->prepare('SELECT id,type,title,body,data_json,is_read,created_at FROM app_notifications WHERE user_id=? ORDER BY id DESC LIMIT '.$limit); $s->execute([$u['id']]); $rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
foreach($rows as &$r){$r['id']=(string)$r['id'];$r['isRead']=(bool)$r['is_read'];$decoded=$r['data_json']?json_decode($r['data_json'],true):null;$r['data']=$decoded;$r['is_read']=$r['isRead'];} unset($r);
$un=db()->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id=? AND is_read=0');$un->execute([$u['id']]); ok(['notifications'=>$rows,'unread'=>(int)$un->fetchColumn()]);
