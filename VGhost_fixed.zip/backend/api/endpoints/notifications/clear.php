<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php';
require_method('POST'); $u=current_user(); db()->prepare('DELETE FROM app_notifications WHERE user_id=?')->execute([$u['id']]); ok(['cleared'=>true]);
