<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php';
require_method('POST'); $u=current_user(); $in=request_json(); $id=(int)($in['id']??0); if($id>0) db()->prepare('UPDATE app_notifications SET is_read=1,read_at=UTC_TIMESTAMP() WHERE id=? AND user_id=?')->execute([$id,$u['id']]); else db()->prepare('UPDATE app_notifications SET is_read=1,read_at=UTC_TIMESTAMP() WHERE user_id=? AND is_read=0')->execute([$u['id']]); ok(['ok'=>true]);
