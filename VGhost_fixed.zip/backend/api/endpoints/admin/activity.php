<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
require_admin_user();
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS activity_sessions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,started_at DATETIME NOT NULL,last_seen_at DATETIME NOT NULL,ended_at DATETIME NULL,INDEX idx_activity_user_time(user_id,started_at),INDEX idx_activity_active(user_id,ended_at),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$date=(string)($_GET['date']??gmdate('Y-m-d'));
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) $date=gmdate('Y-m-d');
$q=(string)($_GET['q']??'');
$start=$date.' 00:00:00'; $end=date('Y-m-d H:i:s',strtotime($date.' +1 day'));
$sql="SELECT u.id,u.nickname,
COALESCE(SUM(GREATEST(0,TIMESTAMPDIFF(SECOND,GREATEST(a.started_at,?),LEAST(COALESCE(a.ended_at,a.last_seen_at),?)))),0) AS active_seconds,
MAX(a.last_seen_at) AS last_seen_at
FROM users u LEFT JOIN activity_sessions a ON a.user_id=u.id AND a.started_at<? AND COALESCE(a.ended_at,a.last_seen_at)>?
WHERE u.is_deleted=0";
$args=[$start,$end,$end,$start];
if($q!==''){ $sql.=" AND (u.nickname LIKE ? OR CAST(u.id AS CHAR) LIKE ?)"; $args[]='%'.$q.'%'; $args[]='%'.$q.'%'; }
$sql.=" GROUP BY u.id,u.nickname ORDER BY active_seconds DESC,u.nickname ASC LIMIT 500";
$s=$pdo->prepare($sql); $s->execute($args);
$rows=[]; foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r){ $sec=(int)$r['active_seconds']; $rows[]=['uid'=>(string)$r['id'],'nickname'=>(string)$r['nickname'],'activeSeconds'=>$sec,'activeMinutes'=>(int)floor($sec/60),'activeHours'=>round($sec/3600,2),'lastSeenAt'=>$r['last_seen_at']]; }
ok(['date'=>$date,'users'=>$rows]);
