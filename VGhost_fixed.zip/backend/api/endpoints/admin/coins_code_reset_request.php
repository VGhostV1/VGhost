<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/SmtpMailer.php';
require_method('POST');
$in=body();
$login=trim((string)($in['login']??$in['email']??$in['nickname']??''));
if($login==='') fail('INVALID_INPUT',422);
$pdo=db();
$q=$pdo->prepare("SELECT u.* FROM users u JOIN admins ad ON ad.user_id=u.id WHERE (LOWER(u.email)=LOWER(?) OR LOWER(u.nickname)=LOWER(?)) AND ad.role='super_admin' AND u.is_deleted=0 LIMIT 1");
$q->execute([$login,ltrim(strtolower($login),'@')]);
$a=$q->fetch();
if(!$a){ json_response(['ok'=>true,'sent'=>false,'message'=>'If the super-admin account exists, a recovery email has been processed.']); exit; }
$email=trim((string)$a['email']);
if($email==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)) fail('ADMIN_RECOVERY_EMAIL_MISSING',422);
$pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_code_reset_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL, used_at DATETIME NULL, created_at DATETIME NOT NULL, INDEX(admin_user_id), INDEX(expires_at), FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$token=bin2hex(random_bytes(32));
$hash=hash('sha256',$token);
$pdo->prepare('DELETE FROM admin_coin_code_reset_tokens WHERE admin_user_id=? OR expires_at<=UTC_TIMESTAMP()')->execute([(int)$a['id']]);
$pdo->prepare('INSERT INTO admin_coin_code_reset_tokens(admin_user_id,token_hash,expires_at,created_at) VALUES(?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 MINUTE),UTC_TIMESTAMP())')->execute([(int)$a['id'],$hash]);
$base=rtrim((string)($config['app']['base_url']??''),'/');
if($base==='') fail('RESET_URL_NOT_CONFIGURED',500);
$link=$base.(preg_match('#/api$#i',$base)?'':'/api').'/admin/coins-code-reset?token='.rawurlencode($token);
$safe=htmlspecialchars($link,ENT_QUOTES,'UTF-8');
$subject='VGHOST Admin security recovery';
$text="VGHOST Admin security recovery\n\nUse this link within 30 minutes to set a new admin password and coin confirmation code:\n\n{$link}\n\nIf you did not request this, ignore this email.";
$html='<!doctype html><html><body style="font-family:Arial,sans-serif;background:#090909;color:#eee;padding:30px"><div style="max-width:600px;margin:auto;background:#121212;border:1px solid #333;border-radius:16px;padding:28px"><h2 style="color:#ff2445">VGHOST Admin Security</h2><p>A recovery request was made for your admin security settings.</p><p><a href="'.$safe.'" style="display:inline-block;background:#ff2445;color:#fff;text-decoration:none;padding:13px 20px;border-radius:9px;font-weight:bold">SECURITY RECOVERY</a></p><p>This link expires in 30 minutes.</p><p>If you did not request this, ignore this email.</p></div></body></html>';
$r=smtp_send_detailed((array)($config['smtp']??[]),$email,$subject,$html,$text);
if(!$r['ok']) { error_log('VGHOST admin security recovery SMTP error: '.$r['error']); fail('SMTP_SEND_FAILED',502); }
admin_log((int)$a['id'],'request_coin_security_recovery',null,['email'=>$email]);
ok(['sent'=>true]);
