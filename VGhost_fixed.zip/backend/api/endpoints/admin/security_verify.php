<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$a=require_super_admin();
$in=body();
$code=trim((string)($in['code']??''));
if($code==='') fail('INVALID_SECURITY_CODE',403);

// The configured super-admin code is the canonical bootstrap/recovery code.
// Older deployments may already have an admin_coin_security row containing a
// stale hash (or a locked row), which made a valid configured code appear to
// do nothing. Verify against the configured hash first; when it matches,
// synchronize the DB security record so every protected admin endpoint uses
// the same working code.
$cfg=require __DIR__.'/../../config/config.php';
$configHash=(string)($cfg['security']['admin_operation_code_hash']??'');
if($configHash!=='' && password_verify($code,$configHash)) {
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_security (id TINYINT UNSIGNED PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, code_hash VARCHAR(255) NOT NULL, locked TINYINT(1) NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL, FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->prepare('INSERT INTO admin_coin_security(id,admin_user_id,code_hash,locked,updated_at) VALUES(1,?,?,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE admin_user_id=VALUES(admin_user_id),code_hash=VALUES(code_hash),locked=0,updated_at=UTC_TIMESTAMP()')
        ->execute([(int)$a['id'],$configHash]);
    ok(['verified'=>true,'source'=>'configured']);
}

require_admin_security($a,$code);
ok(['verified'=>true]);
