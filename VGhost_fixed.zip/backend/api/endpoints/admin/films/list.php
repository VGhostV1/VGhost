<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_method('GET');
require_super_admin();

// Admin only: return the real film fields. Do not use json_row() here because
// that helper is intentionally user-profile shaped and would strip title,
// category, media URLs, etc. from film rows.
$rows=db()->query('SELECT id,title,description,poster_url,video_url,poster_path,video_path,category,release_year,duration_minutes,is_vip,is_featured,is_active,sort_order,created_at,updated_at FROM films WHERE is_active=1 ORDER BY sort_order ASC,id DESC')->fetchAll(PDO::FETCH_ASSOC);
$rows=array_map(function($r){
    $r['id']=(int)$r['id'];
    $r['title']=(string)($r['title']??'');
    $r['description']=$r['description']??null;
    $r['category']=(string)($r['category']??'');
    $r['release_year']=isset($r['release_year']) ? (int)$r['release_year'] : null;
    $r['duration_minutes']=isset($r['duration_minutes']) ? (int)$r['duration_minutes'] : null;
    $r['is_vip']=(int)($r['is_vip']??0);
    $r['is_featured']=(int)($r['is_featured']??0);
    $r['is_active']=(int)($r['is_active']??0);
    $r['sort_order']=(int)($r['sort_order']??0);
    if(!empty($r['poster_path'])) $r['poster_url']='/films/poster?id='.(int)$r['id'];
    if(!empty($r['video_path'])) $r['video_url']='/films/stream?id='.(int)$r['id'];
    unset($r['poster_path'],$r['video_path']);
    return $r;
},$rows);
ok(['films'=>$rows]);
