<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_method('POST');
$admin=require_super_admin();
require_admin_security($admin,(string)($_POST['confirmCode'] ?? $_SERVER['HTTP_X_ADMIN_SECURITY_CODE'] ?? ''));
// PHP clears $_POST/$_FILES when a multipart body exceeds post_max_size.
// Keep the legacy multipart endpoint for small files, but return a precise
// error instead of the misleading FILM_MEDIA_INVALID in that case.
$id=(int)($_POST['id'] ?? 0);
$kind=strtolower(trim((string)($_POST['kind'] ?? '')));
if($id<1 || !in_array($kind,['poster','video'],true)) {
  if(empty($_POST) && empty($_FILES) && !empty($_SERVER['CONTENT_LENGTH'])) fail('FILM_MEDIA_MULTIPART_LIMIT',413);
  fail('FILM_MEDIA_INVALID',422);
}
if(empty($_FILES['media'])) fail('FILM_MEDIA_UPLOAD_FAILED',422);
$f=$_FILES['media'];
$uploadError=(int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
if($uploadError!==UPLOAD_ERR_OK){
  $map=[UPLOAD_ERR_INI_SIZE=>'FILM_MEDIA_TOO_LARGE_SERVER',UPLOAD_ERR_FORM_SIZE=>'FILM_MEDIA_TOO_LARGE_FORM',UPLOAD_ERR_PARTIAL=>'FILM_MEDIA_PARTIAL',UPLOAD_ERR_NO_FILE=>'FILM_MEDIA_NO_FILE',UPLOAD_ERR_NO_TMP_DIR=>'FILM_MEDIA_NO_TMP_DIR',UPLOAD_ERR_CANT_WRITE=>'FILM_MEDIA_CANNOT_WRITE',UPLOAD_ERR_EXTENSION=>'FILM_MEDIA_BLOCKED'];
  fail($map[$uploadError] ?? 'FILM_MEDIA_UPLOAD_FAILED',422,['uploadError'=>$uploadError]);
}
if(!is_uploaded_file((string)$f['tmp_name']) || (int)$f['size']<=0) fail('FILM_MEDIA_UPLOAD_FAILED',422);
$pdo=db();
$q=$pdo->prepare('SELECT id FROM films WHERE id=? LIMIT 1'); $q->execute([$id]); if(!$q->fetch()) fail('FILM_NOT_FOUND',404);
$mime=upload_mime_type((string)$f['tmp_name'],(string)($f['name']??''));
$allowedPoster=[
  'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif',
  'image/bmp'=>'bmp','image/heic'=>'heic','image/heif'=>'heif','image/avif'=>'avif'
];
$allowedVideo=[
  'video/mp4'=>'mp4','video/webm'=>'webm','video/x-m4v'=>'m4v','video/quicktime'=>'mov',
  'video/3gpp'=>'3gp','video/3gpp2'=>'3g2','video/mpeg'=>'mpeg','video/x-matroska'=>'mkv',
  'video/ogg'=>'ogv','video/mp2t'=>'ts','video/x-flv'=>'flv',
  'video/hevc'=>'mp4','video/h265'=>'mp4','video/x-h265'=>'mp4'
];
if($kind==='poster') { if((int)$f['size']>50*1024*1024) fail('FILM_POSTER_TOO_LARGE',422); $allowed=$allowedPoster; $dir=dirname(__DIR__,4).'/storage/films/posters'; }
else { if((int)$f['size']>5*1024*1024*1024) fail('FILM_VIDEO_TOO_LARGE',422); $allowed=$allowedVideo; $dir=dirname(__DIR__,4).'/storage/films/videos'; }
if(!isset($allowed[$mime])) fail('FILM_MEDIA_TYPE_UNSUPPORTED',422);
if(is_link($dir)) fail('STORAGE_UNAVAILABLE',500);
if(!is_dir($dir) && !mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
if(!is_writable($dir)){ @chmod($dir,0750); }
if(!is_writable($dir)) fail('STORAGE_UNWRITABLE',500);
$ext=$allowed[$mime]; $name=bin2hex(random_bytes(28)).'.'.$ext; $dest=$dir.'/'.$name;
if(!move_uploaded_file((string)$f['tmp_name'],$dest)) fail('FILM_MEDIA_STORE_FAILED',500);
$relative='films/'.($kind==='poster'?'posters/':'videos/').$name;
try {
  if($kind==='poster') {
    $url='/films/poster?id='.$id;
    $pdo->prepare('UPDATE films SET poster_path=?,poster_url=? WHERE id=?')->execute([$relative,$url,$id]);
  } else {
    $url='/films/stream?id='.$id;
    $pdo->prepare('UPDATE films SET video_path=?,video_url=?,is_active=1 WHERE id=?')->execute([$relative,$url,$id]);
  }
  admin_log((int)$admin['id'],'film_media_upload',null,['film_id'=>$id,'kind'=>$kind,'size'=>(int)$f['size'],'mime'=>$mime]);
} catch(Throwable $e) { @unlink($dest); throw $e; }
ok(['id'=>$id,'kind'=>$kind,'url'=>$url,'path'=>$relative,'mime'=>$mime,'size'=>(int)$f['size']]);
