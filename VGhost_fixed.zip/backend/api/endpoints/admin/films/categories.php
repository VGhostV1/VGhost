<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_once __DIR__.'/../../../core/Film.php';
require_method('GET');
require_super_admin();
ok(['categories'=>film_genres_with_existing(db())]);
