<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_method('POST');
$admin=require_super_admin();
$b=body();
require_admin_security($admin,(string)($b['confirmCode']??($_SERVER['HTTP_X_ADMIN_SECURITY_CODE']??'')));
$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($b['uploadId']??($_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??'')));
if($uploadId==='' || strlen($uploadId)>80) fail('UPLOAD_NOT_FOUND',404);
$root=realpath(dirname(__DIR__,4)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$dir=$root.'/storage/films/.chunks/'.$uploadId;
$metaFile=$dir.'/meta.json';
$meta=is_file($metaFile)?json_decode((string)@file_get_contents($metaFile),true):null;
if(!is_array($meta) || (int)($meta['admin_user_id']??0)!==(int)$admin['id']) fail('UPLOAD_NOT_FOUND',404);
function remove_upload_dir(string $dir): void {
    if(!is_dir($dir)) return;
    foreach(@scandir($dir)?:[] as $f){ if($f!=='.'&&$f!=='..'){ $p=$dir.'/'.$f; if(is_dir($p)) remove_upload_dir($p); else @unlink($p); } }
    @rmdir($dir);
}
remove_upload_dir($dir);
admin_log((int)$admin['id'],'film_media_upload_cancel',null,['upload_id'=>$uploadId,'film_id'=>(int)($meta['film_id']??0),'kind'=>(string)($meta['kind']??'')]);
ok(['cancelled'=>true,'uploadId'=>$uploadId]);
