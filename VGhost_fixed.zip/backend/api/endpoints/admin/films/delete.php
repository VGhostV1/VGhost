<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_once __DIR__.'/../../../core/Story.php';
require_method('POST');
$admin=require_super_admin(); $b=body();
require_admin_security($admin,(string)($b['confirmCode']??''));
$id=(int)($b['id']??0); if($id<1) fail('FILM_NOT_FOUND',404);

$pdo=db();
$q=$pdo->prepare('SELECT poster_path,video_path FROM films WHERE id=? LIMIT 1');
$q->execute([$id]);
$row=$q->fetch(PDO::FETCH_ASSOC);
if(!$row) fail('FILM_NOT_FOUND',404);

/*
 * A film owns more than the films row: its poster/video files, public trailer
 * story rows and their media, reactions/comments/views/reports/gifts, plus
 * film-specific ratings/likes/view events. Delete the complete dependency set
 * so removing a film cannot leave a visible trailer or orphaned media behind.
 */
ensure_story_schema();
$storageRoot=realpath(dirname(__DIR__,4).'/storage');
$files=[];
$addFile=function(string $rel) use (&$files,$storageRoot): void {
    $rel=trim($rel);
    if($rel==='' || !$storageRoot || str_contains($rel,'..')) return;
    $candidate=realpath($storageRoot.'/'.ltrim($rel,'/'));
    if($candidate && str_starts_with($candidate,$storageRoot.DIRECTORY_SEPARATOR) && is_file($candidate)) $files[$candidate]=true;
};
$addFile((string)($row['poster_path']??''));
$addFile((string)($row['video_path']??''));

// Collect every trailer/story media path linked to this film before rows vanish.
$stories=[];
$sq=$pdo->prepare('SELECT id,media_path FROM stories WHERE film_id=?');
$sq->execute([$id]);
foreach($sq->fetchAll(PDO::FETCH_ASSOC) as $sr){
    $sid=(int)($sr['id']??0);
    if($sid>0) $stories[]=$sid;
    $addFile((string)($sr['media_path']??''));
}

$pdo->beginTransaction();
try {
    if($stories){
        $ph=implode(',',array_fill(0,count($stories),'?'));
        // Optional legacy tables may not exist on every installation.
        foreach(['story_gift_transactions','story_reports','story_views','story_likes','story_comments'] as $tbl){
            try { $pdo->prepare("DELETE FROM {$tbl} WHERE story_id IN ($ph)")->execute($stories); } catch(Throwable $e) {}
        }
        $pdo->prepare("DELETE FROM stories WHERE id IN ($ph)")->execute($stories);
    }

    foreach(['film_ratings','film_likes','film_view_events'] as $tbl){
        try { $pdo->prepare("DELETE FROM {$tbl} WHERE film_id=?")->execute([$id]); } catch(Throwable $e) {}
    }

    $pdo->prepare('DELETE FROM films WHERE id=?')->execute([$id]);
    $pdo->commit();
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}

// Remove physical film + trailer media only after the DB transaction commits.
$cleanupFailed=[];
foreach(array_keys($files) as $file){
    if(is_file($file) && !@unlink($file)) $cleanupFailed[]=$file;
}

// Remove unfinished chunk uploads that belong to this film.
$chunkRoot=($storageRoot?:dirname(__DIR__,4).'/storage').'/films/.chunks';
if(is_dir($chunkRoot)){
    foreach(@scandir($chunkRoot)?:[] as $d){
        if($d==='.'||$d==='..') continue;
        $dir=$chunkRoot.'/'.$d; $metaFile=$dir.'/meta.json';
        if(!is_dir($dir)||!is_file($metaFile)) continue;
        $meta=json_decode((string)@file_get_contents($metaFile),true);
        if(is_array($meta) && (int)($meta['film_id']??0)===$id){
            foreach(@scandir($dir)?:[] as $f){if($f!=='.'&&$f!=='..') @unlink($dir.'/'.$f);}
            @rmdir($dir);
        }
    }
}

admin_log((int)$admin['id'],'film_delete',null,['film_id'=>$id,'trailer_story_count'=>count($stories),'media_cleanup_failed'=>count($cleanupFailed)]);
if($cleanupFailed) fail('FILM_DELETE_MEDIA_CLEANUP_FAILED',500,['remaining_files'=>count($cleanupFailed)]);
ok(['deleted'=>true,'id'=>$id,'deletedTrailerCount'=>count($stories)]);
