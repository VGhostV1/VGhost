<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_once __DIR__.'/../../../core/Film.php';
require_method('POST');
$admin=require_super_admin();
$b=body();
require_admin_security($admin,(string)($b['confirmCode']??''));
$id=(int)($b['id']??0);
$title=trim((string)($b['title']??''));
$video=trim((string)($b['videoUrl']??''));
if($title==='') fail('FILM_TITLE_REQUIRED',422);
if($video!=='') {
  // Film playback must always go through the authenticated VGhost stream endpoint.
  // Accept relative URLs and absolute URLs only when they point back to this API host.
  // Never persist a third-party video URL that could receive the VGhost Bearer token.
  $validInternal=false;
  if(preg_match('#^(?:/films|/api/films)/stream\?id=[1-9][0-9]*$#', $video)) {
      $validInternal=true;
  } elseif(filter_var($video,FILTER_VALIDATE_URL)) {
      $parts=parse_url($video);
      $requestHost=(string)($_SERVER['HTTP_HOST']??'');
      $host=(string)($parts['host']??'');
      $path=(string)($parts['path']??'');
      $query=(string)($parts['query']??'');
      $validInternal = $host!=='' && $requestHost!=='' && strcasecmp($host,preg_replace('/:\d+$/','',$requestHost))===0
          && preg_match('#(?:^|/)films/stream$#',$path) && preg_match('/(?:^|&)id=[1-9][0-9]*(?:&|$)/',$query);
  }
  if(!$validInternal) fail('FILM_VIDEO_URL_INVALID',422);
}
$poster=trim((string)($b['posterUrl']??''));
if($poster!=='' && !filter_var($poster,FILTER_VALIDATE_URL) && !preg_match('#^(?:/films|/api/films)/poster\?id=[1-9][0-9]*$#',$poster)) fail('FILM_POSTER_URL_INVALID',422);
if(filter_var($poster,FILTER_VALIDATE_URL)) { $pu=parse_url($poster); $cfgBase=(string)($GLOBALS['config']['app']['base_url']??''); if($cfgBase!=='' && isset($pu['host']) && !str_contains($cfgBase,(string)$pu['host'])) fail('FILM_POSTER_URL_EXTERNAL',422); }
$category=trim((string)($b['category']??'Drama'));
if($category==='') $category='Drama';
if(mb_strlen($category,'UTF-8')>80) fail('FILM_CATEGORY_TOO_LONG',422);
$description=trim((string)($b['description']??''));
$year=(int)($b['releaseYear']??0);
$duration=(int)($b['durationMinutes']??0);
$isVip=!empty($b['isVip'])?1:0; $featured=!empty($b['isFeatured'])?1:0; $active=array_key_exists('isActive',$b)?(!empty($b['isActive'])?1:0):1; $sort=(int)($b['sortOrder']??0);
$pdo=db();
if($id>0){
  $old=$pdo->prepare('SELECT video_url,poster_url,video_path,poster_path FROM films WHERE id=? LIMIT 1'); $old->execute([$id]); $current=$old->fetch(); if(!$current) fail('FILM_NOT_FOUND',404);
  $video=$video!==''?$video:(string)($current['video_url']??'');
  $poster=$poster!==''?$poster:(string)($current['poster_url']??'');
  if(!array_key_exists('isActive',$b)) $active = !empty($current['video_path']) || $video!=='' ? 1 : 0;
  $s=$pdo->prepare('UPDATE films SET title=?,description=?,poster_url=?,video_url=?,category=?,release_year=?,duration_minutes=?,is_vip=?,is_featured=?,is_active=?,sort_order=? WHERE id=?');
  $s->execute([$title,$description?:null,$poster?:null,$video,$category,$year>0?$year:null,$duration>0?$duration:null,$isVip,$featured,$active,$sort,$id]);
  admin_log((int)$admin['id'],'film_update',null,['film_id'=>$id,'title'=>$title]);
}else{
  $s=$pdo->prepare('INSERT INTO films(title,description,poster_url,video_url,category,release_year,duration_minutes,is_vip,is_featured,is_active,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  $s->execute([$title,$description?:null,$poster?:null,$video,$category,$year>0?$year:null,$duration>0?$duration:null,$isVip,$featured,$active,$sort]);
  $id=(int)$pdo->lastInsertId(); admin_log((int)$admin['id'],'film_create',null,['film_id'=>$id,'title'=>$title]);
}
ok(['id'=>$id]);
