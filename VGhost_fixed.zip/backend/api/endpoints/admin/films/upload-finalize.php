<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_method('POST');
$admin=require_super_admin();
require_admin_security($admin,(string)($_SERVER['HTTP_X_ADMIN_SECURITY_CODE'] ?? ''));

$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??''));
if($uploadId==='' || strlen($uploadId)>80) fail('FILM_MEDIA_INVALID',422);
$root=realpath(dirname(__DIR__,4)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$dir=$root.'/storage/films/.chunks/'.$uploadId;
$metaFile=$dir.'/meta.json';
$meta=is_file($metaFile)?json_decode((string)@file_get_contents($metaFile),true):null;
if(!is_array($meta)) fail('UPLOAD_NOT_FOUND',404);
if((int)($meta['admin_user_id']??0)!==(int)$admin['id']) fail('UPLOAD_NOT_FOUND',404);
$id=(int)($meta['film_id']??0); $kind=(string)($meta['kind']??''); $total=(int)($meta['total_chunks']??0); $expectedSize=(int)($meta['total_size']??0); $fileName=(string)($meta['file_name']??''); $mimeHint=strtolower((string)($meta['mime_hint']??''));
if($id<1 || !in_array($kind,['poster','video'],true) || $total<1 || $expectedSize<1) fail('FILM_MEDIA_INVALID',422);
$q=db()->prepare('SELECT id FROM films WHERE id=? LIMIT 1'); $q->execute([$id]); if(!$q->fetch()) fail('FILM_NOT_FOUND',404);
if($kind==='poster' && $expectedSize>50*1024*1024) fail('FILM_POSTER_TOO_LARGE',422);
if($kind==='video' && $expectedSize>5*1024*1024*1024) fail('FILM_VIDEO_TOO_LARGE',422);

$tmp=$dir.'/assembled.part';
if(!is_file($tmp)){ fail('UPLOAD_INCOMPLETE',422); }
for($i=0;$i<$total;$i++){
  $marker=$dir.'/chunk_'.$i.'.ok';
  if(!is_file($marker)) fail('UPLOAD_INCOMPLETE',422,['missingChunk'=>$i]);
}
$actualSize=@filesize($tmp);
if($actualSize===false || (int)$actualSize!==$expectedSize){ @unlink($tmp); fail('INVALID_MEDIA_SIZE',422,['receivedSize'=>$actualSize===false?0:(int)$actualSize,'expectedSize'=>$expectedSize]); }

$mime=upload_mime_type($tmp,$fileName);
if(($mime==='' || $mime==='application/octet-stream') && $mimeHint!=='') $mime=$mimeHint;
$allowedPoster=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','image/bmp'=>'bmp','image/heic'=>'heic','image/heif'=>'heif','image/avif'=>'avif'];
$allowedVideo=['video/mp4'=>'mp4','video/webm'=>'webm','video/x-m4v'=>'m4v','video/quicktime'=>'mov','video/3gpp'=>'3gp','video/3gpp2'=>'3g2','video/mpeg'=>'mpeg','video/x-matroska'=>'mkv','video/ogg'=>'ogv','video/mp2t'=>'ts','video/x-flv'=>'flv','video/hevc'=>'mp4','video/h265'=>'mp4','video/x-h265'=>'mp4'];
$allowed=$kind==='poster'?$allowedPoster:$allowedVideo;
if(!isset($allowed[$mime])){ @unlink($tmp); fail('FILM_MEDIA_TYPE_UNSUPPORTED',422,['mime'=>$mime,'fileName'=>$fileName]); }
$sub=$kind==='poster'?'posters':'videos'; $dirFinal=$root.'/storage/films/'.$sub;
if(!is_dir($dirFinal) && !mkdir($dirFinal,0750,true)){@unlink($tmp);fail('STORAGE_UNAVAILABLE',500);}
if(!is_writable($dirFinal)){@chmod($dirFinal,0750);}
if(!is_writable($dirFinal)){@unlink($tmp);fail('STORAGE_UNWRITABLE',500);}
$ext=$allowed[$mime]; $name=bin2hex(random_bytes(28)).'.'.$ext; $dest=$dirFinal.'/'.$name;
if(!rename($tmp,$dest)){@unlink($tmp);fail('FILM_MEDIA_STORE_FAILED',500);}
$relative='films/'.$sub.'/'.$name; $url=$kind==='poster'?'/films/poster?id='.$id:'/films/stream?id='.$id;
try{
  if($kind==='poster') $q=db()->prepare('UPDATE films SET poster_path=?,poster_url=? WHERE id=?');
  else $q=db()->prepare('UPDATE films SET video_path=?,video_url=?,is_active=1 WHERE id=?');
  $q->execute($kind==='poster'?[$relative,$url,$id]:[$relative,$url,$id]);
  admin_log((int)$admin['id'],'film_media_upload',null,['film_id'=>$id,'kind'=>$kind,'size'=>$expectedSize,'mime'=>$mime,'chunked'=>true]);
}catch(Throwable $e){@unlink($dest);throw $e;}
foreach(@scandir($dir)?:[] as $f){if($f!=='.'&&$f!=='..')@unlink($dir.'/'.$f);} @rmdir($dir);
ok(['id'=>$id,'kind'=>$kind,'url'=>$url,'path'=>$relative,'mime'=>$mime,'size'=>$expectedSize]);
