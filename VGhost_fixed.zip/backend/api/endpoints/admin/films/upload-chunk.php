<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php';
require_method('POST');
$admin=require_super_admin();
require_admin_security($admin,(string)($_SERVER['HTTP_X_ADMIN_SECURITY_CODE'] ?? ''));

$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??''));
$index=(int)($_SERVER['HTTP_X_VGHOST_CHUNK_INDEX']??-1);
$total=(int)($_SERVER['HTTP_X_VGHOST_TOTAL_CHUNKS']??0);
$totalSize=(int)($_SERVER['HTTP_X_VGHOST_TOTAL_SIZE']??0);
$id=(int)($_SERVER['HTTP_X_VGHOST_FILM_ID']??0);
$kind=strtolower(trim((string)($_SERVER['HTTP_X_VGHOST_KIND']??'')));
$fileName=trim((string)($_SERVER['HTTP_X_VGHOST_FILE_NAME']??''));
$mimeHint=strtolower(trim((string)($_SERVER['HTTP_X_VGHOST_MIME_TYPE']??'')));
$chunkSize=(int)($_SERVER['HTTP_X_VGHOST_CHUNK_SIZE']??(10*1024*1024));

if($uploadId==='' || strlen($uploadId)>80 || $index<0 || $total<1 || $index>=$total || $totalSize<1 || $totalSize>5*1024*1024*1024 || $id<1 || !in_array($kind,['poster','video'],true)) fail('FILM_MEDIA_INVALID',422);
if($chunkSize<256*1024 || $chunkSize>10*1024*1024) fail('CHUNK_SIZE_INVALID',422);
if($kind==='poster' && $totalSize>50*1024*1024) fail('FILM_POSTER_TOO_LARGE',422);

$q=db()->prepare('SELECT id FROM films WHERE id=? LIMIT 1'); $q->execute([$id]); if(!$q->fetch()) fail('FILM_NOT_FOUND',404);

$root=realpath(dirname(__DIR__,4)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$base=$root.'/storage/films/.chunks';
if(!is_dir($base) && !mkdir($base,0750,true)) fail('STORAGE_UNAVAILABLE',500);
foreach(@scandir($base) ?: [] as $d){
  if($d==='.'||$d==='..') continue;
  $dirOld=$base.'/'.$d;
  if(is_dir($dirOld) && @filemtime($dirOld)!==false && filemtime($dirOld)<time()-86400){
    foreach(@scandir($dirOld) ?: [] as $f){ if($f!=='.'&&$f!=='..') @unlink($dirOld.'/'.$f); }
    @rmdir($dirOld);
  }
}
$dir=$base.'/'.$uploadId;
if(!is_dir($dir) && !mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
$metaFile=$dir.'/meta.json';
$meta=is_file($metaFile)?json_decode((string)@file_get_contents($metaFile),true):null;
if(!is_array($meta)){
  $meta=['admin_user_id'=>(int)$admin['id'],'film_id'=>$id,'kind'=>$kind,'total_chunks'=>$total,'total_size'=>$totalSize,'chunk_size'=>$chunkSize,'file_name'=>$fileName,'mime_hint'=>$mimeHint,'created_at'=>time()];
  file_put_contents($metaFile,json_encode($meta,JSON_UNESCAPED_SLASHES),LOCK_EX);
} else if((int)($meta['admin_user_id']??0)!==(int)$admin['id'] || (int)($meta['film_id']??0)!==$id || (string)($meta['kind']??'')!==$kind || (int)($meta['total_chunks']??0)!==$total || (int)($meta['total_size']??0)!==$totalSize){
  fail('UPLOAD_MISMATCH',409);
}

$body=file_get_contents('php://input');
if($body===false || $body==='') fail('EMPTY_CHUNK',422);
$bodyLen=strlen($body);
if($bodyLen>10*1024*1024) fail('CHUNK_TOO_LARGE',413);
$expectedChunk=($index < $total-1) ? $chunkSize : ($totalSize - (($total-1)*$chunkSize));
if($expectedChunk<1 || $bodyLen!==$expectedChunk) fail('CHUNK_SIZE_MISMATCH',422,['expected'=>$expectedChunk,'received'=>$bodyLen]);
$marker=$dir.'/chunk_'.$index.'.ok';
if(is_file($marker)){
  ok(['uploadId'=>$uploadId,'chunkIndex'=>$index,'receivedBytes'=>$bodyLen,'alreadyReceived'=>true]);
}
$dataFile=$dir.'/assembled.part';
$fh=@fopen($dataFile,'c+b');
if(!$fh) fail('FILM_MEDIA_STORE_FAILED',500);
if(!@flock($fh,LOCK_EX)){fclose($fh);fail('FILM_MEDIA_STORE_FAILED',500);}
$offset=$index*$chunkSize;
if(fseek($fh,$offset,SEEK_SET)!==0){flock($fh,LOCK_UN);fclose($fh);fail('FILM_MEDIA_STORE_FAILED',500);}
$written=0;
while($written<$bodyLen){
  $n=fwrite($fh,substr($body,$written));
  if($n===false || $n===0){flock($fh,LOCK_UN);fclose($fh);fail('FILM_MEDIA_STORE_FAILED',500);}
  $written+=$n;
}
fflush($fh);
flock($fh,LOCK_UN);
fclose($fh);
if(@file_put_contents($marker,(string)$bodyLen,LOCK_EX)===false) fail('FILM_MEDIA_STORE_FAILED',500);
ok(['uploadId'=>$uploadId,'chunkIndex'=>$index,'receivedBytes'=>$bodyLen]);
