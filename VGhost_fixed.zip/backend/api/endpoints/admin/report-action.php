<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$a=require_super_admin();
$in=body();
require_admin_security($a,(string)($in['confirmCode']??''));
$id=(int)($in['report_id']??0);
$action=(string)($in['action']??'');
if($id<1) fail('INVALID_REPORT_ID',422);
if(!in_array($action,['dismiss','resolve','delete_content','ban_user'],true)) fail('INVALID_REPORT_ACTION',422);
$pdo=db();
$q=$pdo->prepare("SELECT * FROM content_reports WHERE id=? AND status='pending' LIMIT 1");
$q->execute([$id]); $r=$q->fetch(PDO::FETCH_ASSOC);
if(!$r) fail('REPORT_NOT_FOUND',404);
$target=(int)$r['target_id']; $type=(string)$r['target_type'];
if($action==='ban_user') {
    $uid=$type==='user' ? $target : 0;
    if($type==='message'){ $s=$pdo->prepare('SELECT sender_id FROM messages WHERE id=? LIMIT 1'); $s->execute([$target]); $uid=(int)$s->fetchColumn(); }
    if($type==='story'){ $s=$pdo->prepare('SELECT user_id FROM stories WHERE id=? LIMIT 1'); $s->execute([$target]); $uid=(int)$s->fetchColumn(); }
    if($uid<1 || $uid===(int)$a['id']) fail('INVALID_BAN_TARGET',422);
    $days=max(1,min(365,(int)($in['durationDays']??7)));
    $pdo->prepare("UPDATE users SET is_banned=1, ban_expires_at=DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY), status='offline', updated_at=UTC_TIMESTAMP() WHERE id=?")->execute([$days,$uid]);
    $pdo->prepare("UPDATE content_reports SET status='actioned', reviewed_at=UTC_TIMESTAMP(), reviewed_by=? WHERE id=?")->execute([(int)$a['id'],$id]);
    admin_log((int)$a['id'],'report_ban_user',$uid,['report_id'=>$id,'days'=>$days,'target_type'=>$type,'target_id'=>$target]);
    ok(['success'=>true,'action'=>$action]);
}
if($action==='delete_content') {
    if($type==='message') {
        $m=$pdo->prepare('SELECT audio_path,attachment_path FROM messages WHERE id=? LIMIT 1'); $m->execute([$target]); $row=$m->fetch(PDO::FETCH_ASSOC);
        if(!$row) fail('MESSAGE_NOT_FOUND',404);
        try { $pdo->beginTransaction(); try{$pdo->prepare('DELETE FROM message_reactions WHERE message_id=?')->execute([$target]);}catch(Throwable $e){} $pdo->prepare('DELETE FROM messages WHERE id=?')->execute([$target]); $pdo->commit(); } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        foreach ([['voice',$row['audio_path']??null],['media',$row['attachment_path']??null]] as [$kind,$rel]) { if(!$rel)continue; $root=realpath(dirname(__DIR__,3).'/storage/'.$kind); $file=realpath(dirname(__DIR__,3).'/storage/'.ltrim((string)$rel,'/')); if($root&&$file&&str_starts_with($file,$root.DIRECTORY_SEPARATOR)&&is_file($file))@unlink($file); }
    } elseif($type==='story') {
        $s=$pdo->prepare('SELECT media_path FROM stories WHERE id=? LIMIT 1'); $s->execute([$target]); $row=$s->fetch(PDO::FETCH_ASSOC); if(!$row)fail('STORY_NOT_FOUND',404);
        try{$pdo->beginTransaction(); foreach(['story_views','story_likes','story_comments'] as $tbl){$pdo->prepare("DELETE FROM {$tbl} WHERE story_id=?")->execute([$target]);} $pdo->prepare('DELETE FROM stories WHERE id=?')->execute([$target]); $pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        $root=realpath(dirname(__DIR__,3).'/storage'); $file=realpath($root.'/'.ltrim((string)$row['media_path'],'/')); if($file&&str_starts_with($file,$root.DIRECTORY_SEPARATOR)&&is_file($file))@unlink($file);
    } elseif($type==='user') {
        if($target<1 || $target===(int)$a['id']) fail('INVALID_USER_DELETE_TARGET',422);
        $pdo->beginTransaction();
        try {
            permanently_delete_user($pdo,$target);
            $pdo->commit();
        } catch(Throwable $e) {
            if($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}
if($action==='delete_content') {
    // Deleting reported content also removes the report itself, so it cannot remain
    // as a stale item pointing at content that no longer exists.
    $pdo->prepare('DELETE FROM content_reports WHERE id=?')->execute([$id]);
    admin_log((int)$a['id'],'report_delete_content',$type==='user'?$target:null,['report_id'=>$id,'target_type'=>$type,'target_id'=>$target,'report_deleted'=>true]);
    ok(['success'=>true,'action'=>$action,'status'=>'deleted','report_deleted'=>true]);
}
$status=$action==='dismiss'?'dismissed':'actioned';
$pdo->prepare("UPDATE content_reports SET status=?, reviewed_at=UTC_TIMESTAMP(), reviewed_by=? WHERE id=?")->execute([$status,(int)$a['id'],$id]);
admin_log((int)$a['id'],'report_'.$action,$type==='user'?$target:null,['report_id'=>$id,'target_type'=>$type,'target_id'=>$target]);
ok(['success'=>true,'action'=>$action,'status'=>$status]);
