<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Fcm.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$a=require_super_admin();
$b=body(); require_admin_security($a,(string)($b['confirmCode']??''));
$title=trim((string)($b['title']??'VGHOST'));
$bodyText=trim((string)($b['body']??''));
if($bodyText==='') fail('INVALID_INPUT',422);
if(strlen($title)>120 || strlen($bodyText)>1000) fail('INVALID_INPUT',422);
$link=trim((string)($b['link']??''));
if($link!=='' && !preg_match('~^https?://~i',$link)) fail('INVALID_LINK',422);
if(strlen($link)>2000) fail('INVALID_LINK',422);

$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS public_notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    title VARCHAR(190) NOT NULL,
    body TEXT NOT NULL,
    target VARCHAR(32) NOT NULL DEFAULT 'home',
    target_value TEXT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_public_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$target=$link!==''?'link':'home';
$publicStmt=$pdo->prepare('INSERT INTO public_notifications(title,body,target,target_value,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())');
$publicStmt->execute([$title,$bodyText,$target,$link]);

$users=db()->query("SELECT id FROM users WHERE is_banned=0")->fetchAll(PDO::FETCH_COLUMN) ?: [];
foreach($users as $userId) create_notification((int)$userId,'broadcast',$title,$bodyText,$link!=='' ? ['target'=>'link','targetValue'=>$link,'url'=>$link] : ['target'=>'home']);
$st=db()->query("SELECT DISTINCT d.fcm_token FROM user_devices d JOIN users u ON u.id=d.user_id WHERE u.is_banned=0 AND d.fcm_token IS NOT NULL AND TRIM(d.fcm_token)<>''");
$tokens=$st->fetchAll(PDO::FETCH_COLUMN) ?: [];
$cfg=fcm_config();
$guestTokens=[];
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS guest_devices (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, device_id VARCHAR(255) NULL, fcm_token TEXT NOT NULL,
        token_hash CHAR(64) NOT NULL, language VARCHAR(16) NOT NULL DEFAULT 'en', last_seen_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL, PRIMARY KEY(id), UNIQUE KEY uq_guest_token_hash(token_hash), KEY idx_guest_device(device_id), KEY idx_guest_last_seen(last_seen_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $gs=$pdo->query("SELECT DISTINCT fcm_token FROM guest_devices WHERE fcm_token<>'' AND last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 90 DAY)");
    $guestTokens=$gs->fetchAll(PDO::FETCH_COLUMN)?:[];
} catch(Throwable $ignore) {}
$result=fcm_send_tokens_result(array_values(array_unique(array_merge($tokens,$guestTokens))),(string)($cfg['project_id']??''),$title,$bodyText,['type'=>'broadcast','target'=>$link!==''?'link':'home','targetValue'=>$link,'url'=>$link]);
if($result['invalidTokens']) {
    $del=db()->prepare('DELETE FROM user_devices WHERE fcm_token=?');
    foreach($result['invalidTokens'] as $token) $del->execute([$token]);
}
$delivery=$result['sent']>0 ? 'fcm' : (($cfg['enabled']??false) ? 'fcm_failed' : 'not_configured');
admin_log((int)$a['id'],'broadcast',null,[
    'title'=>$title,'body'=>$bodyText,'link'=>$link,'devices'=>count($tokens),'guestDevices'=>count($guestTokens),'pushSent'=>$result['sent'],'failed'=>$result['failed'],'delivery'=>$delivery,'reason'=>$result['reason']
]);
ok([
    'created'=>true,'title'=>$title,'body'=>$bodyText,'link'=>$link,
    'pushSent'=>$result['sent'],'totalDevices'=>count($tokens),'totalGuestDevices'=>count($guestTokens),'failed'=>$result['failed'],
    'delivery'=>$delivery,'reason'=>$result['reason'],
]);
