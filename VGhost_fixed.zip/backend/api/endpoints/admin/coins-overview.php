<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Wallet.php';
require_method('GET');
require_super_admin();
$pdo=db();
$total=(int)$pdo->query("SELECT COALESCE(SUM(w.balance),0) FROM wallets w JOIN users u ON u.id=w.user_id WHERE u.is_deleted=0")->fetchColumn();
$q=$pdo->query("SELECT u.id,u.nickname,COALESCE(w.balance,0) AS balance FROM users u LEFT JOIN wallets w ON w.user_id=u.id WHERE u.is_deleted=0 ORDER BY COALESCE(w.balance,0) DESC,u.id DESC LIMIT 5000");
$users=[]; foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){$users[]=['uid'=>(string)$r['id'],'nickname'=>(string)$r['nickname'],'balance'=>(int)$r['balance']];}
ok(['totalCoins'=>$total,'users'=>$users,'count'=>count($users)]);
