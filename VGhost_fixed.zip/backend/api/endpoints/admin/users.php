<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Wallet.php';
require_method('GET');
$a=require_super_admin();
$pdo=db();

// Presence is heartbeat based. Clean stale flags so an app that is force-closed
// or killed without an Android lifecycle callback is no longer shown as online.
try {
    $pdo->exec("UPDATE user_status SET is_online=0 WHERE is_online=1 AND last_seen_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE)");
    $pdo->exec("UPDATE users u JOIN user_status us ON us.user_id=u.id SET u.status='offline' WHERE u.is_deleted=0 AND u.status='active' AND (us.is_online=0 OR us.last_seen_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE))");
} catch (Throwable $ignored) {}

$q=trim((string)($_GET['q']??''));
$sql="SELECT u.*, COALESCE(w.balance,0) AS coinBalance, CASE WHEN u.is_ghost=1 THEN 0 WHEN us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) THEN 1 ELSE 0 END AS isOnline FROM users u LEFT JOIN wallets w ON w.user_id=u.id LEFT JOIN user_status us ON us.user_id=u.id WHERE u.is_deleted=0";
$args=[];
if($q!==''){$sql.=' AND (nickname LIKE ? OR CAST(id AS CHAR)=?)';$args=['%'.$q.'%',$q];}
$sql.=' ORDER BY id DESC LIMIT 200';
$s=$pdo->prepare($sql);
$s->execute($args);
$rows=$s->fetchAll();
$users=array_map(function(array $u): array {
    $row=json_row($u);
    $row['coinBalance']=(int)($u['coinBalance']??0);
    $row['isOnline']=(bool)($u['isOnline']??false); $row['banExpiresAt']=$u['ban_expires_at']??null;
    return $row;
},$rows);
ok(['users'=>$users]);
