<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php'; require_once __DIR__.'/../../../core/Backup.php';
require_method('POST'); $a=require_super_admin(); require_admin_security($a); $pdo=db();
$backup=backup_create_file($pdo); admin_log((int)$a['id'],'api_backup_export',null,['file'=>$backup['name'],'tables'=>$backup['tables'],'size'=>$backup['size']]);
header('Content-Type: application/gzip'); header('Content-Disposition: attachment; filename="'.$backup['name'].'"'); header('Content-Length: '.$backup['size']); header('Cache-Control: no-store');
readfile($backup['file']); @unlink($backup['file']); exit;
