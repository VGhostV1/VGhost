<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php'; require_once __DIR__.'/../../../core/Backup.php';
require_method('POST'); $a=require_super_admin(); require_admin_security($a); backup_import_schema(); backup_cleanup_imports();
if(empty($_FILES['backup']['tmp_name']) || ($_FILES['backup']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) fail('BACKUP_UPLOAD_FAILED',422);
$name=(string)($_FILES['backup']['name']??''); if(!preg_match('/\.sql\.gz$/i',$name)) fail('INVALID_BACKUP_EXTENSION',422);
$dir=backup_storage_dir('imports'); $token=bin2hex(random_bytes(32)); $path=$dir.'/'.$token.'.sql.gz';
if(!move_uploaded_file((string)$_FILES['backup']['tmp_name'],$path)) fail('BACKUP_STORE_FAILED',500);
try {$meta=backup_validate_gzip($path,db());} catch(Throwable $e){@unlink($path); fail($e->getMessage() ?: 'INVALID_BACKUP',422);}
$sha=hash_file('sha256',$path); db()->prepare('INSERT INTO backup_import_tokens(token,file_path,sha256,size_bytes,statement_count,admin_user_id,created_at,expires_at) VALUES(?,?,?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 10 MINUTE))')->execute([$token,$path,$sha,$meta['size'],$meta['statements'],(int)$a['id']]);
admin_log((int)$a['id'],'api_backup_validate',null,['file'=>$name,'size'=>$meta['size'],'statements'=>$meta['statements']]);
ok(['valid'=>true,'confirmToken'=>$token,'expiresInSeconds'=>600,'size'=>$meta['size'],'tables'=>$meta['tables'],'statements'=>$meta['statements'],'sha256'=>$sha]);
