<?php
declare(strict_types=1);
require_once __DIR__.'/../../../core/App.php'; require_once __DIR__.'/../../../core/Backup.php';
require_method('POST'); $a=require_super_admin(); backup_import_schema(); backup_cleanup_imports(); $b=body(); require_admin_security($a,(string)($b['confirmCode']??''));
$token=trim((string)($b['confirmToken']??'')); $confirm=(bool)($b['confirm']??false); if(!$confirm || !preg_match('/^[a-f0-9]{64}$/',$token)) fail('CONFIRMATION_REQUIRED',422);
$st=db()->prepare('SELECT * FROM backup_import_tokens WHERE token=? AND admin_user_id=? AND used_at IS NULL AND expires_at>UTC_TIMESTAMP() LIMIT 1'); $st->execute([$token,(int)$a['id']]); $row=$st->fetch(); if(!$row) fail('BACKUP_CONFIRMATION_EXPIRED',422);
if(!is_file((string)$row['file_path']) || hash_file('sha256',(string)$row['file_path'])!==(string)$row['sha256']) fail('BACKUP_FILE_CHANGED',422);
$count=backup_import_file(db(),(string)$row['file_path']); db()->prepare('UPDATE backup_import_tokens SET used_at=UTC_TIMESTAMP() WHERE token=?')->execute([$token]); @unlink((string)$row['file_path']);
admin_log((int)$a['id'],'api_backup_import',null,['statements'=>$count,'size'=>(int)$row['size_bytes']]); ok(['imported'=>true,'statements'=>$count]);
