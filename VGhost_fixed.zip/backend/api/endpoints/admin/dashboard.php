<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$u=require_super_admin();
$p=db();
// Reconcile stale presence on every admin refresh. This covers force-close/process
// kill cases where the Android onStop callback never reaches the server.
try {
    $p->exec("UPDATE user_status SET is_online=0 WHERE is_online=1 AND last_seen_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE)");
    $p->exec("UPDATE users u JOIN user_status us ON us.user_id=u.id SET u.status='offline' WHERE u.is_deleted=0 AND u.status='active' AND (us.is_online=0 OR us.last_seen_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE))");
} catch (Throwable $ignored) {}
ok([
    'email'=>(string)$u['email'],
    'users'=>(int)$p->query('SELECT COUNT(*) FROM users WHERE is_deleted=0')->fetchColumn(),
    'banned'=>(int)$p->query('SELECT COUNT(*) FROM users WHERE is_deleted=0 AND is_banned=1')->fetchColumn(),
    'online'=>(int)$p->query('SELECT COUNT(*) FROM user_status us JOIN users u ON u.id=us.user_id WHERE u.is_deleted=0 AND us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE)')->fetchColumn(),
    'active_messages'=>(int)$p->query('SELECT COUNT(*) FROM messages WHERE is_deleted=0 AND expires_at>UTC_TIMESTAMP()')->fetchColumn(),
    'total_coins'=>(int)$p->query('SELECT COALESCE(SUM(balance),0) FROM wallets w JOIN users u ON u.id=w.user_id WHERE u.is_deleted=0')->fetchColumn()
]);
