<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$a=require_admin_user();
$b=body();
$uid=(int)($b['uid']??0);
$days=(int)($b['days']??0);
$confirmCode=trim((string)($b['confirmCode']??($_SERVER['HTTP_X_ADMIN_SECURITY_CODE']??'')));
if($uid<1 || !in_array($days,[7,30,90,365],true) || $confirmCode==='') fail('INVALID_INPUT',422);
require_admin_security($a,$confirmCode);
$pdo=db();
try {
    $pdo->beginTransaction();
    $s=$pdo->prepare('SELECT id,is_vip,vip_expires_at FROM users WHERE id=? AND is_deleted=0 LIMIT 1 FOR UPDATE');
    $s->execute([$uid]);
    $u=$s->fetch(PDO::FETCH_ASSOC);
    if(!$u) fail('USER_NOT_FOUND',404);
    $current=(string)($u['vip_expires_at']??'');
    $base=time();
    if((int)($u['is_vip']??0)===1 && $current!=='') {
        $ts=strtotime($current);
        if($ts!==false && $ts>$base) $base=$ts;
    }
    $expires=gmdate('Y-m-d H:i:s',$base+($days*86400));
    $pdo->prepare('UPDATE users SET is_vip=1,vip_expires_at=?,updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([$expires,$uid]);
    $pdo->commit();
    try { admin_log((int)$a['id'],'admin_vip_grant',$uid,['days'=>$days,'expiresAt'=>$expires]); } catch(Throwable $ignored) {}
    ok(['uid'=>(string)$uid,'days'=>$days,'vipExpiresAt'=>$expires,'isVip'=>true]);
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    $msg=trim($e->getMessage());
    if(in_array($msg,['USER_NOT_FOUND'],true)) fail($msg,404);
    fail('VIP_GRANT_FAILED',500);
}
