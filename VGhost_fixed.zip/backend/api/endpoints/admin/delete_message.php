<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$a=require_super_admin(); $in=body(); require_admin_security($a,(string)($in['confirmCode']??''));
$id=(int)($in['message_id']??0); if($id<1) fail('INVALID_MESSAGE_ID',422);
$pdo=db();
$q=$pdo->prepare('SELECT message_type,audio_path,attachment_path FROM messages WHERE id=? LIMIT 1'); $q->execute([$id]); $m=$q->fetch(PDO::FETCH_ASSOC);
if(!$m) fail('MESSAGE_NOT_FOUND',404);
try {
    $pdo->beginTransaction();
    try { $pdo->prepare('DELETE FROM message_reactions WHERE message_id=?')->execute([$id]); } catch(Throwable $e) {}
    $pdo->prepare('DELETE FROM messages WHERE id=?')->execute([$id]);
    $pdo->commit();
} catch(Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
foreach ([['voice',$m['audio_path']??null],['media',$m['attachment_path']??null]] as [$kind,$rel]) {
    if(!$rel) continue;
    $root=realpath(dirname(__DIR__,3).'/storage/'.$kind);
    $file=realpath(dirname(__DIR__,3).'/storage/'.ltrim((string)$rel,'/'));
    if($root && $file && str_starts_with($file,$root.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
}
admin_log((int)$a['id'],'delete_message',null,['message_id'=>$id,'hard_deleted'=>true]);
ok(['success'=>true,'deleted'=>true,'hard_deleted'=>true,'both_sides'=>true]);
