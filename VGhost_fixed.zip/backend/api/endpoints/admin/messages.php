<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
require_super_admin();

$pdo = db();
$uid = (int)($_GET['user_id'] ?? 0);
$other = (int)($_GET['other_id'] ?? 0);

// Admin message viewer: use the same canonical columns as the normal message API,
// but build the result in a single safe query. This avoids CASE/GROUP BY issues on
// older MySQL/MariaDB installations.
try {
    if ($uid > 0 && $other > 0) {
        $sql = 'SELECT m.*, a.nickname AS senderNickname, b.nickname AS receiverNickname
                FROM messages m
                LEFT JOIN users a ON a.id=m.sender_id
                LEFT JOIN users b ON b.id=m.receiver_id
                WHERE m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP()
                  AND ((m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?))
                ORDER BY m.id ASC LIMIT 500';
        $s = $pdo->prepare($sql);
        $s->execute([$uid,$other,$other,$uid]);
        ok(['messages'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($uid > 0) {
        $sql = 'SELECT m.*,
                       CASE WHEN m.sender_id=? THEN r.id ELSE s.id END AS uid,
                       CASE WHEN m.sender_id=? THEN r.nickname ELSE s.nickname END AS nickname,
                       m.id AS last_message_id, m.created_at AS last_message_at
                FROM messages m
                LEFT JOIN users s ON s.id=m.sender_id
                LEFT JOIN users r ON r.id=m.receiver_id
                WHERE (m.sender_id=? OR m.receiver_id=?)
                  AND m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP()
                ORDER BY m.id DESC LIMIT 500';
        $s = $pdo->prepare($sql);
        $s->execute([$uid,$uid,$uid,$uid]);
        $raw = $s->fetchAll(PDO::FETCH_ASSOC);
        $seen = []; $contacts = [];
        foreach ($raw as $row) {
            $id = (int)($row['uid'] ?? 0);
            if ($id <= 0 || isset($seen[$id])) continue;
            $seen[$id] = true;
            $contacts[] = [
                'uid'=>(string)$id,
                'nickname'=>(string)($row['nickname'] ?? ''),
                'last_message_id'=>(int)($row['last_message_id'] ?? 0),
                'last_message_at'=>$row['last_message_at'] ?? null,
            ];
            if (count($contacts) >= 200) break;
        }
        ok(['contacts'=>$contacts]);
    }

    $s = $pdo->query('SELECT m.*, a.nickname AS senderNickname, b.nickname AS receiverNickname
                      FROM messages m
                      LEFT JOIN users a ON a.id=m.sender_id
                      LEFT JOIN users b ON b.id=m.receiver_id
                      WHERE m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP()
                      ORDER BY m.id DESC LIMIT 200');
    ok(['messages'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
} catch (PDOException $e) {
    // Keep the response JSON so the Android client never sees a hosting HTML 500 page.
    // The detailed DB message is intentionally omitted from production responses.
    fail('ADMIN_MESSAGES_DB_ERROR',500);
} catch (Throwable $e) {
    fail('ADMIN_MESSAGES_ERROR',500);
}
