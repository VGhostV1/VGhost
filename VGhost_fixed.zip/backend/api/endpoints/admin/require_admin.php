<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Auth.php';
function current_admin(): array {
    $u=current_user();
    $st=db()->prepare('SELECT a.role FROM admins a WHERE a.user_id=? LIMIT 1'); $st->execute([(int)$u['id']]); $a=$st->fetch();
    if(!$a) fail('ADMIN_REQUIRED',403);
    $u['admin_role']=$a['role']; return $u;
}
function write_admin_log(int $adminId,string $action,?int $target,array $details=[]): void { db()->prepare('INSERT INTO admin_logs(admin_user_id,action,target_user_id,details,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')->execute([$adminId,$action,$target,$details?json_encode($details,JSON_UNESCAPED_UNICODE):null]); }
