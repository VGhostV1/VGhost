<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET'); require_super_admin();
$pdo=db();
$q=$pdo->query("SELECT r.*, ru.nickname AS reporter_nickname,
  CASE WHEN r.target_type='user' THEN tu.nickname WHEN r.target_type='message' THEN mu.nickname WHEN r.target_type='story' THEN su.nickname ELSE NULL END AS target_nickname,
  CASE WHEN r.target_type='message' THEN m.message ELSE NULL END AS target_message
  FROM content_reports r
  LEFT JOIN users ru ON ru.id=r.reporter_id
  LEFT JOIN users tu ON r.target_type='user' AND tu.id=r.target_id
  LEFT JOIN messages m ON r.target_type='message' AND m.id=r.target_id
  LEFT JOIN users mu ON r.target_type='message' AND mu.id=m.sender_id
  LEFT JOIN stories s ON r.target_type='story' AND s.id=r.target_id
  LEFT JOIN users su ON r.target_type='story' AND su.id=s.user_id
  WHERE r.status='pending' ORDER BY r.created_at ASC LIMIT 500");
ok(['reports'=>$q->fetchAll(PDO::FETCH_ASSOC)]);
