<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_once __DIR__.'/../../core/Notifications.php';
require_once __DIR__.'/../../core/Wallet.php';
require_method('POST');

$a = require_super_admin();
$b = body();
$uid = (int)($b['uid'] ?? $b['recipientUid'] ?? $b['receiverId'] ?? 0);
$amount = (int)($b['amount'] ?? 0);
$confirmCode = trim((string)($b['confirmCode'] ?? ($_SERVER['HTTP_X_ADMIN_SECURITY_CODE'] ?? '')));

if ($uid < 1 || $amount === 0 || $confirmCode === '') fail('INVALID_INPUT', 422);
require_admin_security($a, $confirmCode);

$pdo = db();

try {
    // Do all wallet work inside ONE transaction. Older versions locked the row
    // before beginTransaction(), which is unsafe on some MySQL configurations.
    $pdo->beginTransaction();
    try {
        $uCheck = $pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 LIMIT 1');
        $uCheck->execute([$uid]);
        if ($uCheck->fetchColumn() === false) fail('USER_NOT_FOUND', 404);

        ensure_wallet($pdo, $uid);
        $s = $pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
        $s->execute([$uid]);
        $raw = $s->fetchColumn();
        if ($raw === false) fail('WALLET_NOT_FOUND', 404);

        $balance = (int)$raw;
        if ($amount < 0 && $balance < abs($amount)) fail('INSUFFICIENT_COINS', 409);
        $newBalance = $balance + $amount;

        $u = $pdo->prepare('UPDATE wallets SET balance=?, updated_at=UTC_TIMESTAMP() WHERE user_id=?');
        $u->execute([$newBalance, $uid]);
        if ($u->rowCount() < 1 && $newBalance !== $balance) throw new RuntimeException('WALLET_UPDATE_FAILED');

        // Ledger entry is useful, but it must not prevent the actual coin
        // balance change on older installations with an incomplete ledger table.
        try {
            $t = $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())');
            $t->execute([$uid, $amount > 0 ? 'admin_credit' : 'admin_debit', $amount, 'admin:' . (int)$a['id']]);
        } catch (Throwable $ledgerError) {
            // Balance remains the source of truth; ignore legacy ledger-schema errors.
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }

    // Notifications are always non-fatal.
    $notified = false;
    try {
        notify_localized($uid, 'coin_bonus', ['name'=>'Admin', 'amount'=>(string)$amount],
            [
                'amount' => (string)$amount,
                'senderId' => (string)$a['id'],
                'senderUid' => (string)$a['id'],
                'senderNickname' => (string)$a['nickname'],
                'target' => 'profile',
                'targetValue' => (string)$uid,
            ]
        );
        $notified = true;
    } catch (Throwable $ignored) {}

    ok([
        'balance' => $newBalance,
        'amount' => $amount,
        'uid' => (string)$uid,
        'notified' => $notified,
        'selfTransfer' => $uid === (int)$a['id']
    ]);
} catch (Throwable $e) {
    $msg = trim($e->getMessage());
    if ($msg === '' || strlen($msg) > 180) $msg = 'UNKNOWN_COIN_DATABASE_ERROR';
    fail('COIN_OPERATION_FAILED',500);
}
