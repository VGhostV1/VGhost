<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_once __DIR__.'/../../core/Wallet.php';
require_method('POST');
$a=require_super_admin(); $b=body();
$uid=(int)($b['uid']??0); $newBalance=(int)($b['balance']??-1); $confirmCode=trim((string)($b['confirmCode']??($_SERVER['HTTP_X_ADMIN_SECURITY_CODE']??'')));
if($uid<1 || $newBalance<0 || $confirmCode==='') fail('INVALID_INPUT',422);
require_admin_security($a,$confirmCode);
$pdo=db();
try{
 $pdo->beginTransaction();
 $uCheck=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 LIMIT 1');
 $uCheck->execute([$uid]);
 if($uCheck->fetchColumn()===false) fail('USER_NOT_FOUND',404);
 ensure_wallet($pdo,$uid);
 $s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE'); $s->execute([$uid]); $old=$s->fetchColumn();
 if($old===false) fail('WALLET_NOT_FOUND',404); $old=(int)$old;
 $pdo->prepare('UPDATE wallets SET balance=?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$newBalance,$uid]);
 $verify=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=?');
 $verify->execute([$uid]);
 $verified=(int)$verify->fetchColumn();
 if($verified!==$newBalance) throw new RuntimeException('WALLET_BALANCE_NOT_UPDATED');
 $delta=$newBalance-$old;
 if($delta!==0){try{$t=$pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())');$t->execute([$uid,'admin_balance_edit',$delta,'admin-set:'.(int)$a['id']]);}catch(Throwable $ignored){}}
 $pdo->commit();
 try { admin_log((int)$a['id'],'admin_coin_balance_edit',$uid,['oldBalance'=>$old,'newBalance'=>$newBalance,'delta'=>$delta]); } catch(Throwable $logIgnored) {}
 ok(['uid'=>(string)$uid,'oldBalance'=>$old,'balance'=>$verified,'delta'=>$delta]);
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$msg=trim($e->getMessage());if($msg===''||strlen($msg)>180)$msg='UNKNOWN_COIN_DATABASE_ERROR';fail('COIN_BALANCE_EDIT_FAILED',500);}
