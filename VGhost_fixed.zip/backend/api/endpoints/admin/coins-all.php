<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_once __DIR__.'/../../core/Notifications.php';
require_once __DIR__.'/../../core/Wallet.php';
require_method('POST');

$a = require_super_admin();
$b = body();
$amount = (int)($b['amount'] ?? 0);
$message = trim((string)($b['message'] ?? ''));
$confirmCode = trim((string)($b['confirmCode'] ?? ($_SERVER['HTTP_X_ADMIN_SECURITY_CODE'] ?? '')));

if ($amount <= 0 || $amount > 1000000000 || $message === '' || $confirmCode === '') fail('INVALID_INPUT', 422);
if (mb_strlen($message) > 1000) fail('MESSAGE_TOO_LONG', 422);
require_admin_security($a, $confirmCode);

$pdo = db();
$q = $pdo->query('SELECT id FROM users WHERE is_deleted=0 ORDER BY id ASC');
$userIds = array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN) ?: []);
if (!$userIds) ok(['usersCredited'=>0,'notificationsCreated'=>0,'amount'=>$amount]);

$credited = 0;
$notifications = 0;
$pdo->beginTransaction();
try {
    foreach ($userIds as $uid) {
        ensure_wallet($pdo, $uid);
        $s = $pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
        $s->execute([$uid]);
        $balance = $s->fetchColumn();
        if ($balance === false) throw new RuntimeException('WALLET_NOT_FOUND');
        $newBalance = (int)$balance + $amount;
        $pdo->prepare('UPDATE wallets SET balance=?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$newBalance,$uid]);
        // The wallet balance is the source of truth. Older installations may
        // have the wallets table but an incomplete/missing transaction ledger,
        // so a ledger write must never roll back the actual coin bonus.
        try {
            $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')
                ->execute([$uid,'admin_bulk_bonus',$amount,'admin:'.(int)$a['id']]);
        } catch (Throwable $ledgerError) {
            // Keep the balance update successful on legacy schemas.
        }
        $credited++;
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    fail('BULK_COIN_OPERATION_FAILED',500);
}

// Persist every recipient's bonus message. Push delivery is non-fatal.
foreach ($userIds as $uid) {
    try {
        $notificationId = create_notification($uid, 'coin_bonus', 'Coin bonussi 🪙', $message, [
            'amount'=>(string)$amount,
            'senderId'=>(string)$a['id'],
            'senderUid'=>(string)$a['id'],
            'senderNickname'=>(string)$a['nickname'],
            'target'=>'profile',
            'targetValue'=>(string)$uid,
            'bulk'=>true,
        ]);
        $notifications++;
    } catch (Throwable $ignored) {}
    try {
        $r = push_notification_to_user($uid, 'coin_bonus', 'Coin bonussi 🪙', $message, [
            'amount'=>(string)$amount,
            'senderId'=>(string)$a['id'],
            'senderUid'=>(string)$a['id'],
            'senderNickname'=>(string)$a['nickname'],
            'notificationId'=>(string)$notificationId,
            'count'=>(string)notification_count($uid, $notificationId),
            'target'=>'profile',
            'targetValue'=>(string)$uid,
            'bulk'=>true,
        ]);
        if (!empty($r['invalidTokens'])) {
            $d=$pdo->prepare('DELETE FROM user_devices WHERE fcm_token=?');
            foreach($r['invalidTokens'] as $t) $d->execute([$t]);
        }
    } catch (Throwable $ignored) {}
}

admin_log((int)$a['id'],'bulk_coin_bonus',null,['amount'=>$amount,'usersCredited'=>$credited,'message'=>$message]);
ok(['usersCredited'=>$credited,'notificationsCreated'=>$notifications,'amount'=>$amount]);
