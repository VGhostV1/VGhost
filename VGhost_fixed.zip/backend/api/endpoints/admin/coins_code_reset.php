<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';

$token=trim((string)($_GET['token']??$_POST['token']??''));
if($token===''){ http_response_code(400); exit('Invalid recovery token.'); }
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_security (id TINYINT UNSIGNED PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, code_hash VARCHAR(255) NOT NULL, locked TINYINT(1) NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL, FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_code_reset_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL, used_at DATETIME NULL, created_at DATETIME NOT NULL, INDEX(admin_user_id), INDEX(expires_at), FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$h=hash('sha256',$token);
$q=$pdo->prepare('SELECT t.id,t.admin_user_id,u.email FROM admin_coin_code_reset_tokens t JOIN users u ON u.id=t.admin_user_id WHERE t.token_hash=? AND t.used_at IS NULL AND t.expires_at>UTC_TIMESTAMP() AND u.is_deleted=0 LIMIT 1');
$q->execute([$h]); $row=$q->fetch();
if(!$row){ http_response_code(400); exit('Recovery link is invalid or expired.'); }
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
    $newPassword=(string)($_POST['new_password']??'');
    $confirmPassword=(string)($_POST['confirm_password']??'');
    $newCode=(string)($_POST['new_code']??'');
    $confirmCode=(string)($_POST['confirm_code']??'');
    if(strlen($newPassword)<8 || $newPassword!==$confirmPassword || strlen($newCode)<8 || $newCode!==$confirmCode) {
        http_response_code(422); exit('Password must be 8+ characters and all confirmation fields must match.');
    }
    $pdo->beginTransaction();
    try {
        $pdo->prepare('UPDATE users SET password_hash=?,status=\'active\',updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([password_hash($newPassword,PASSWORD_DEFAULT),(int)$row['admin_user_id']]);
        $pdo->prepare('INSERT INTO admin_coin_security(id,admin_user_id,code_hash,locked,updated_at) VALUES(1,?,?,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE admin_user_id=VALUES(admin_user_id),code_hash=VALUES(code_hash),locked=0,updated_at=UTC_TIMESTAMP()')->execute([(int)$row['admin_user_id'],password_hash($newCode,PASSWORD_DEFAULT)]);
        $pdo->prepare('UPDATE admin_coin_code_reset_tokens SET used_at=UTC_TIMESTAMP() WHERE id=?')->execute([(int)$row['id']]);
        $pdo->prepare('DELETE FROM user_sessions WHERE user_id=?')->execute([(int)$row['admin_user_id']]);
        $pdo->commit();
        exit('Admin security restored successfully. You can now log in with the new admin password.');
    } catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); http_response_code(500); exit('Recovery failed.'); }
}
?><!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>VGHOST Admin Security</title><style>body{font-family:system-ui;max-width:440px;margin:40px auto;padding:20px;background:#090909;color:#eee}form{display:grid;gap:12px;background:#121212;padding:22px;border-radius:16px;border:1px solid #333}input,button{padding:13px;border-radius:9px;border:1px solid #383838}input{background:#0b0b0b;color:#fff}button{background:#ff2445;color:#fff;font-weight:800;border:0}</style><h1>VGHOST</h1><p>Admin security recovery</p><form method="post"><input type="hidden" name="token" value="<?=htmlspecialchars($token,ENT_QUOTES)?>"><input type="password" name="new_password" minlength="8" placeholder="New admin password" required><input type="password" name="confirm_password" minlength="8" placeholder="Confirm admin password" required><input type="password" name="new_code" placeholder="New coin confirmation code (8+ characters)" required><input type="password" name="confirm_code" placeholder="Confirm coin confirmation code" required><button>RESTORE SECURITY</button></form>
