<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/require_admin.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$admin=current_admin();
$b=body();
require_admin_security($admin,(string)($b['confirmCode']??''));
$uid=(int)($b['userId']??$admin['id']);
$title=trim((string)($b['title']??'VGHOST Push Test'));
$bodyText=trim((string)($b['body']??'Android push notification test uğurludur.'));
$type=trim((string)($b['type']??'general'));
$allowed=['general','message','message_reaction','friend_request','friend_accepted','profile_visit','story_like','story_comment','story_reply','story_view','story_follow','gift','story_gift','coin_transfer','coin_gift','coin_received','coin_bonus','daily_bonus','welcome_bonus','guest','admin_ban','admin_unban','broadcast'];
if(!in_array($type,$allowed,true)) fail('INVALID_TYPE',422);
if($uid<=0||$title===''||$bodyText==='') fail('INVALID_INPUT',422);
$q=db()->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 LIMIT 1');$q->execute([$uid]);
if(!$q->fetchColumn()) fail('USER_NOT_FOUND',404);
if($type==='message') $target='chat';
elseif(in_array($type,['friend_request','friend_accepted','profile_visit','story_follow','coin_bonus','coin_transfer','coin_gift','coin_received','daily_bonus','welcome_bonus','guest','admin_ban','admin_unban'],true)) $target='profile';
elseif(in_array($type,['story_like','story_comment','story_reply','story_view','story_gift'],true)) $target='story';
else $target='home';
$id=create_notification($uid,$type,mb_substr($title,0,190),$bodyText,['target'=>$target,'targetValue'=>(string)$uid,'test'=>'1','senderNickname'=>'VGhost']);
$push=push_notification_to_user($uid,$type,mb_substr($title,0,190),$bodyText,['target'=>$target,'targetValue'=>(string)$uid,'test'=>'1','senderNickname'=>'VGhost','notificationId'=>(string)$id]);
write_admin_log((int)$admin['id'],'push_test',$uid,['notificationId'=>$id,'type'=>$type]);
// Return the actual FCM result so admin testing can distinguish DB persistence from push delivery.
ok(['sent'=>($push['sent']??0)>0,'notificationId'=>$id,'type'=>$type,'push'=>$push]);
