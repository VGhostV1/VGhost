<?php declare(strict_types=1); require_once __DIR__.'/../../core/App.php'; require_once __DIR__.'/../../core/Notifications.php'; require_method('POST'); $a=require_super_admin(); $in=body(); $id=(int)($in['user_id']??0); $action=(string)($in['action']??''); if($id<1)fail('INVALID_USER_ID',422); if($id===(int)$a['id']&&in_array($action,['ban','delete'],true))fail('SELF_ACTION_FORBIDDEN',400); if($action==='ban'){ require_admin_security($a,(string)($in['confirmCode']??'')); $days=max(1,min(365,(int)($in['durationDays']??7))); db()->prepare("UPDATE users SET is_banned=1,ban_expires_at=DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? DAY),status='offline',updated_at=UTC_TIMESTAMP() WHERE id=?")->execute([$days,$id]); notify_localized($id,'admin_ban',[], ['target'=>'profile','targetValue'=>(string)$id,'adminId'=>(string)$a['id'],'banDays'=>(string)$days]); }elseif($action==='unban'){ require_admin_security($a,(string)($in['confirmCode']??'')); db()->prepare("UPDATE users SET is_banned=0,ban_expires_at=NULL,updated_at=UTC_TIMESTAMP() WHERE id=?")->execute([$id]); notify_localized($id,'admin_unban',[], ['target'=>'profile','targetValue'=>(string)$id,'adminId'=>(string)$a['id']]); }elseif($action==='delete'){ require_admin_security($a,(string)($in['confirmCode']??''));
    $pdo=db();
    $pdo->beginTransaction();
    try {
        permanently_delete_user($pdo,$id);
        $pdo->commit();
    } catch(Throwable $e) {
        if($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}else fail('INVALID_ACTION',422);if($action!=='delete') admin_log((int)$a['id'],$action.'_user',$id);
ok(['success'=>true,'banned'=>$action==='ban','deleted'=>$action==='delete']);
