<?php
require_once __DIR__.'/../../core/App.php'; require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$u=current_user(); $b=body();
$rid=(int)($b['recipientUid']??$b['receiverId']??0); $amount=(int)($b['amount']??0);
$isAdmin=is_admin((int)$u['id']);
$isSelf = ($rid === (int)$u['id']);
if($rid<=0||($isSelf && !$isAdmin)||$amount<=0||$amount>100000) fail('INVALID_INPUT',422);
$key=trim((string)($_SERVER['HTTP_IDEMPOTENCY_KEY']??'')); if($key!=='' && strlen($key)>128) fail('INVALID_IDEMPOTENCY_KEY',422);
$pdo=db(); $pdo->beginTransaction();
try{
 $q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1'); $q->execute([$rid]); if(!$q->fetchColumn()) fail('USER_NOT_FOUND',404);
 $bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1'); $bq->execute([(int)$u['id'],$rid,$rid,(int)$u['id']]); if($bq->fetchColumn()) fail('USER_BLOCKED',403);
 foreach([(int)$u['id'],$rid] as $id){$q=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');$q->execute([$id]); if($q->fetchColumn()===false) fail('WALLET_NOT_FOUND',404);}
 $q=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=?');$q->execute([$u['id']]);$bal=(int)$q->fetchColumn(); if($bal<$amount) fail('INSUFFICIENT_COINS',409);
 $pdo->prepare('UPDATE wallets SET balance=balance-?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$amount,$u['id']]);
 $pdo->prepare('UPDATE wallets SET balance=balance+?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$amount,$rid]);
 $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')->execute([$u['id'],'coin_transfer',-$amount,'to:'.$rid]);
 $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')->execute([$rid,'coin_transfer',$amount,'from:'.$u['id']]);
 $pdo->commit(); notify_localized($rid,'coin_transfer',['name'=>(string)$u['nickname'],'amount'=>(string)$amount], ['amount'=>(string)$amount,'senderId'=>(string)$u['id'],'senderUid'=>(string)$u['id'],'senderNickname'=>(string)$u['nickname'],'target'=>'profile','targetValue'=>(string)$u['id']]); ok(['sent'=>true,'amount'=>$amount,'balance'=>$bal-$amount]);
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
