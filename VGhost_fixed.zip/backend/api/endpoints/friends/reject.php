<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php';
require_once __DIR__.'/../../core/Response.php';
require_once __DIR__.'/../../core/Auth.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$u=current_user(); $in=request_json();
$other=(int)($in['user_id']??$in['fromUserId']??0);
if(!$other || $other===(int)$u['id']) fail('INVALID_USER',422);
$a=min((int)$u['id'],$other); $b=max((int)$u['id'],$other);
$s=db()->prepare('DELETE FROM friendships WHERE user_one_id=? AND user_two_id=? AND status="pending" AND requester_id=?');
$s->execute([$a,$b,$other]);
if(!$s->rowCount()) fail('FRIEND_REQUEST_NOT_FOUND',404);
delete_friend_request_notification((int)$u['id'], $other);
ok(['status'=>'rejected']);
