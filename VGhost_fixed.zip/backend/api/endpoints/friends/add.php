<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php';
require_once __DIR__.'/../../core/Response.php';
require_once __DIR__.'/../../core/Auth.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');

$u = current_user();
$in = request_json();
$other = (int)($in['user_id'] ?? 0);
if (!$other || $other === (int)$u['id']) fail('INVALID_USER', 422);

$check = db()->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1');
$check->execute([$other]);
if (!$check->fetchColumn()) fail('USER_NOT_FOUND', 404);

$perm = db()->prepare('SELECT friend_permission FROM users WHERE id=? LIMIT 1');
$perm->execute([$other]);
if ((string)($perm->fetchColumn() ?: 'everyone') === 'nobody') fail('FRIEND_REQUESTS_NOT_ALLOWED', 403);

$a = min((int)$u['id'], $other);
$b = max((int)$u['id'], $other);

// IMPORTANT: pressing + never makes two users friends immediately.
// It only creates/keeps a PENDING request. The recipient must accept it.
$existing = db()->prepare('SELECT status, requester_id FROM friendships WHERE user_one_id=? AND user_two_id=? LIMIT 1');
$existing->execute([$a, $b]);
$row = $existing->fetch();

if ($row) {
    $status = (string)$row['status'];
    $requester = (int)($row['requester_id'] ?? 0);

    if ($status === 'accepted') {
        fail('ALREADY_FRIENDS', 409);
    }

    if ($status === 'pending' && $requester === (int)$u['id']) {
        ok(['status' => 'pending', 'alreadyPending' => true]);
    }

    // If the other user already sent us a request, don't silently accept it.
    // The recipient must explicitly press Accept.
    if ($status === 'pending' && $requester === $other) {
        fail('FRIEND_REQUEST_ALREADY_RECEIVED', 409);
    }
}

$s = db()->prepare('INSERT INTO friendships(user_one_id,user_two_id,status,requester_id,created_at,updated_at)
VALUES(?, ?, "pending", ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())
ON DUPLICATE KEY UPDATE
status="pending", requester_id=VALUES(requester_id), updated_at=UTC_TIMESTAMP()');
$s->execute([$a, $b, (int)$u['id']]);

require_once __DIR__.'/../../core/Level.php';
award_activity_xp(db(), (int)$u['id'], 5, 'friend_request');
notify_localized(
    $other,
    'friend_request',
    ['name'=>(string)$u['nickname']],
    [
        'fromUserId'=>(string)$u['id'],
        'senderId'=>(string)$u['id'],
        'senderUid'=>(string)$u['id'],
        'senderNickname'=>(string)$u['nickname'],
        'target'=>'friend_request',
        'action'=>'show_friend_request',
        'targetValue'=>(string)$u['nickname']
    ]
);

ok(['status'=>'pending']);
