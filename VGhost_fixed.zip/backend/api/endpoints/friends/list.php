<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Response.php';
require_once __DIR__.'/../../core/Request.php';
require_once __DIR__.'/../../core/Auth.php';
require_once __DIR__.'/../../core/Migrations.php';
require_method('GET');
ensure_activity_level_schema();
$u=current_user();
$sql="SELECT u.id,u.nickname,u.email,u.avatar_id AS avatarId,u.vip_frame_id AS vipFrameId,up.avatar_url AS avatarUrl,COALESCE(u.activity_xp,0) AS activityXp,CASE WHEN COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()) THEN 1 ELSE 0 END AS isVip,
 CASE WHEN us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) THEN 'active' ELSE 'offline' END AS status,
 us.last_seen_at, GREATEST(1,FLOOR(COALESCE(u.activity_xp,0)/100)+1) AS level
 FROM friendships f
 JOIN users u ON u.id=IF(f.user_one_id=?,f.user_two_id,f.user_one_id)
 LEFT JOIN user_status us ON us.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id
 WHERE (f.user_one_id=? OR f.user_two_id=?) AND f.status='accepted' AND u.is_deleted=0";
$s=db()->prepare($sql);
$s->execute([$u['id'],$u['id'],$u['id']]);
ok(['friends'=>$s->fetchAll()]);
