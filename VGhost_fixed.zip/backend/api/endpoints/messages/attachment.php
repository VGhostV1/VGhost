<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Fcm.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$u=current_user();
$receiver=(int)($_POST['receiver_id']??0);
if($receiver<=0 || $receiver===(int)$u['id']) fail('INVALID_RECEIVER',422);
if(empty($_FILES['media'])) {
  $cl=(int)($_SERVER['CONTENT_LENGTH']??0);
  if($cl>1024*1024*1024) fail('INVALID_MEDIA_SIZE',422);
  fail('MEDIA_UPLOAD_FAILED',422);
}
$f=$_FILES['media'];
if($f['error']!==UPLOAD_ERR_OK){
  $uploadErrors=[UPLOAD_ERR_INI_SIZE=>'INVALID_MEDIA_SIZE',UPLOAD_ERR_FORM_SIZE=>'INVALID_MEDIA_SIZE',UPLOAD_ERR_PARTIAL=>'MEDIA_UPLOAD_PARTIAL',UPLOAD_ERR_NO_FILE=>'MEDIA_UPLOAD_FAILED',UPLOAD_ERR_NO_TMP_DIR=>'MEDIA_TEMP_UNAVAILABLE',UPLOAD_ERR_CANT_WRITE=>'MEDIA_STORE_FAILED',UPLOAD_ERR_EXTENSION=>'MEDIA_UPLOAD_FAILED'];
  fail($uploadErrors[$f['error']] ?? 'MEDIA_UPLOAD_FAILED',422);
}
if(!is_uploaded_file($f['tmp_name'])) fail('INVALID_UPLOAD',422);
if($f['size']<=0 || $f['size']>1024*1024*1024) fail('INVALID_MEDIA_SIZE',422);

$pdo=db();
// Self-heal production databases that predate media attachments.
try {
  $cols=[
    'attachment_path'=>"ALTER TABLE messages ADD COLUMN attachment_path VARCHAR(500) NULL",
    'attachment_type'=>"ALTER TABLE messages ADD COLUMN attachment_type VARCHAR(80) NULL",
    'attachment_name'=>"ALTER TABLE messages ADD COLUMN attachment_name VARCHAR(255) NULL",
    'attachment_size'=>"ALTER TABLE messages ADD COLUMN attachment_size BIGINT UNSIGNED NULL"
  ];
  foreach($cols as $col=>$sql){
    $q=$pdo->query("SHOW COLUMNS FROM messages LIKE '".$col."'");
    if(!$q->fetch(PDO::FETCH_ASSOC)) $pdo->exec($sql);
  }
} catch(Throwable $e){ fail('MEDIA_SCHEMA_UPDATE_FAILED',500); }

$q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1');
$q->execute([$receiver]); if(!$q->fetch()) fail('RECEIVER_NOT_FOUND',404);
$bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1');
$bq->execute([$u['id'],$receiver,$receiver,$u['id']]); if($bq->fetch()) fail('USER_BLOCKED',403);
$perm=$pdo->prepare('SELECT message_permission FROM users WHERE id=? LIMIT 1'); $perm->execute([$receiver]);
$messagePermission=(string)($perm->fetchColumn() ?: 'everyone');
if($messagePermission==='nobody') fail('MESSAGES_NOT_ALLOWED',403);
if($messagePermission==='friends'){
  $fq=$pdo->prepare('SELECT 1 FROM friendships WHERE user_one_id=? AND user_two_id=? AND status="accepted" LIMIT 1');
  $fq->execute([min((int)$u['id'],$receiver),max((int)$u['id'],$receiver)]); if(!$fq->fetchColumn()) fail('MESSAGES_FRIENDS_ONLY',403);
}

$mime=upload_mime_type((string)$f['tmp_name'], (string)($f['name']??''));
if($mime==='') fail('UNSUPPORTED_MEDIA_TYPE',422);
$allowed=[
 'image/jpeg'=>['image','jpg'],'image/png'=>['image','png'],'image/webp'=>['image','webp'],'image/gif'=>['image','gif'],'image/heic'=>['image','heic'],'image/heif'=>['image','heif'],'image/avif'=>['image','avif'],
 'video/mp4'=>['video','mp4'],'video/webm'=>['video','webm'],'video/quicktime'=>['video','mov'],'video/x-m4v'=>['video','m4v'],'video/hevc'=>['video','mp4'],'video/h265'=>['video','mp4'],'video/x-h265'=>['video','mp4'],'video/3gpp'=>['video','3gp'],'video/3gpp2'=>['video','3g2'],'video/x-matroska'=>['video','mkv'],
 'audio/mpeg'=>['audio','mp3'],'audio/mp3'=>['audio','mp3'],'audio/mpeg3'=>['audio','mp3'],'audio/x-mpeg'=>['audio','mp3'],'audio/x-mp3'=>['audio','mp3'],'audio/mp4'=>['audio','m4a'],'audio/x-m4a'=>['audio','m4a'],'audio/aac'=>['audio','aac'],'audio/ogg'=>['audio','ogg'],'application/ogg'=>['audio','ogg'],'audio/wav'=>['audio','wav'],'audio/x-wav'=>['audio','wav']
];
if(!isset($allowed[$mime])) fail('UNSUPPORTED_MEDIA_TYPE',422);
[$type,$ext]=$allowed[$mime];
$clientExt=strtolower(pathinfo((string)$f['name'],PATHINFO_EXTENSION));
$expected=['jpg','jpeg','png','webp','gif','heic','heif','avif','mp4','webm','mov','m4v','3gp','3gpp','3g2','mkv','mp3','m4a','aac','ogg','oga','wav'];
if($clientExt!=='' && !in_array($clientExt,$expected,true)) fail('INVALID_MEDIA_EXTENSION',422);
$displayName=trim((string)$f['name']);
$displayName=preg_replace('/[^A-Za-z0-9._ -]+/u','_', $displayName) ?: ('file.'.$ext);
$displayName=substr($displayName,0,255);

$dir=dirname(__DIR__,3).'/storage/media';
if(is_link($dir)) fail('STORAGE_UNAVAILABLE',500);
if(!is_dir($dir)&&!mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
$name=bin2hex(random_bytes(24)).'.'.$ext; $dest=$dir.'/'.$name;
if(!move_uploaded_file($f['tmp_name'],$dest)) fail('MEDIA_STORE_FAILED',500);

try{
  $pdo->beginTransaction();
  $one=min((int)$u['id'],$receiver); $two=max((int)$u['id'],$receiver);
  $a=$pdo->prepare('SELECT id FROM conversations WHERE user_one_id=? AND user_two_id=? LIMIT 1'); $a->execute([$one,$two]); $c=$a->fetch();
  if(!$c){$pdo->prepare('INSERT INTO conversations(user_one_id,user_two_id,created_at,updated_at) VALUES(?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([$one,$two]);$cid=(int)$pdo->lastInsertId();}
  else $cid=(int)$c['id'];
  $pdo->prepare('INSERT INTO messages(conversation_id,sender_id,receiver_id,message,message_type,attachment_path,attachment_type,attachment_name,attachment_size,created_at,expires_at,is_read,is_deleted) VALUES(?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),0,0)')
    ->execute([$cid,$u['id'],$receiver,$displayName,'attachment','media/'.$name,$mime,$displayName,$f['size']]);
  $mid=(int)$pdo->lastInsertId();
  $pdo->prepare('UPDATE conversations SET updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([$cid]);
  $pdo->commit();
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();@unlink($dest);throw $e;}

require_once __DIR__.'/../../core/Level.php'; award_activity_xp(db(),(int)$u['id'],2,'message_sent');
$sender=(string)$u['nickname'];
$notificationId=0; try { $notificationId=notify_localized($receiver,'message',['name'=>$sender],['target'=>'chat','targetValue'=>$sender,'senderNickname'=>$sender,'conversationId'=>(string)$cid]); } catch (Throwable $notifyError) { /* media delivery must not fail because push/notification storage is unavailable */ }
ok(['message'=>['id'=>$mid,'conversation_id'=>$cid,'sender_id'=>(int)$u['id'],'receiver_id'=>$receiver,'message'=>$displayName,'message_type'=>'attachment','attachment_type'=>$type,'attachment_name'=>$displayName,'attachment_size'=>(int)$f['size'],'attachment_url'=>'/messages/attachment-file?id='.$mid,'expires_at'=>gmdate('Y-m-d H:i:s',time()+86400)],'notificationId'=>$notificationId]);
