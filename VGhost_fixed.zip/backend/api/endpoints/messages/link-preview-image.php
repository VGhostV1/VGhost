<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/LinkPreview.php';
require_method('GET');
current_user();

$url = trim((string)($_GET['url'] ?? ''));
if ($url === '' || strlen($url) > 2048) fail('INVALID_PREVIEW_URL', 422);
$p = parse_url($url);
$scheme = strtolower((string)($p['scheme'] ?? ''));
$host = (string)($p['host'] ?? '');
if (!in_array($scheme, ['http','https'], true) || $host === '' || !vg_preview_host_allowed($host)) fail('INVALID_PREVIEW_URL', 422);

function preview_image_fetch(string $url): array {
    $current = $url;
    for ($hop=0; $hop<4; $hop++) {
        $parts=parse_url($current); $host=(string)($parts['host']??'');
        $scheme=strtolower((string)($parts['scheme']??''));
        if (!in_array($scheme,['http','https'],true) || !$host || !vg_preview_host_allowed($host)) fail('PREVIEW_FETCH_FAILED',502);
        $ch=curl_init($current);
        if (!$ch) fail('PREVIEW_FETCH_FAILED',502);
        $headers=[]; $body='';
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>false, CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_CONNECTTIMEOUT=>4, CURLOPT_TIMEOUT=>8,
            CURLOPT_USERAGENT=>'Mozilla/5.0 (compatible; VGhostPreview/1.0)',
            CURLOPT_HTTPHEADER=>['Accept: image/avif,image/webp,image/apng,image/*,*/*;q=0.8'],
            CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,
            CURLOPT_ENCODING=>'',
            CURLOPT_HEADERFUNCTION=>static function($ch,string $h)use(&$headers){$headers[]=$h;return strlen($h);},
            CURLOPT_WRITEFUNCTION=>static function($ch,string $chunk)use(&$body):int{
                if(strlen($body)+strlen($chunk)>3145728) return 0;
                $body.=$chunk; return strlen($chunk);
            },
        ]);
        $ok=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $ct=strtolower((string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE)); $location=(string)curl_getinfo($ch,CURLINFO_REDIRECT_URL); curl_close($ch);
        if($ok===false) fail('PREVIEW_FETCH_FAILED',502);
        if($code>=300&&$code<400&&$location!==''){
            $next=vg_preview_abs_url($location,$current); if(!$next) fail('PREVIEW_FETCH_FAILED',502);
            $np=parse_url($next); if(!vg_preview_host_allowed((string)($np['host']??''))) fail('PREVIEW_FETCH_FAILED',502);
            $current=$next; continue;
        }
        if($code<200||$code>=300||$body==='') fail('PREVIEW_FETCH_FAILED',502);
        if(!str_starts_with($ct,'image/')) fail('PREVIEW_NOT_IMAGE',415);
        return [$ct,$body];
    }
    fail('PREVIEW_FETCH_FAILED',502); return ['',''];
}

[$ct,$body]=preview_image_fetch($url);
header('Content-Type: '.$ct);
header('Content-Length: '.strlen($body));
header('Cache-Control: public, max-age=86400');
header('X-Content-Type-Options: nosniff');
echo $body;
