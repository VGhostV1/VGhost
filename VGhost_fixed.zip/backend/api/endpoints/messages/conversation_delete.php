<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user(); $other=(int)(body()['user_id']??0); if(!$other) fail('INVALID_USER_ID',422);
$one=min((int)$u['id'],$other); $two=max((int)$u['id'],$other); $pdo=db();
$q=$pdo->prepare('SELECT id FROM conversations WHERE user_one_id=? AND user_two_id=? LIMIT 1');
$q->execute([$one,$two]); $cid=(int)$q->fetchColumn();
if(!$cid) ok(['deleted'=>true,'hard_deleted'=>true,'both_sides'=>true,'messages_deleted'=>0]);

$voiceFiles=[]; $mediaFiles=[];
try {
    $q=$pdo->prepare("SELECT audio_path,attachment_path FROM messages WHERE conversation_id=?");
    $q->execute([$cid]);
    foreach($q->fetchAll(PDO::FETCH_ASSOC) as $row) {
        if(!empty($row['audio_path'])) $voiceFiles[]=(string)$row['audio_path'];
        if(!empty($row['attachment_path'])) $mediaFiles[]=(string)$row['attachment_path'];
    }
    $pdo->beginTransaction();
    // Explicit reaction deletion keeps this compatible with legacy schemas
    // where message_reactions has no foreign-key cascade.
    try { $pdo->prepare('DELETE r FROM message_reactions r INNER JOIN messages m ON m.id=r.message_id WHERE m.conversation_id=?')->execute([$cid]); } catch(Throwable $e) {}
    $d=$pdo->prepare('DELETE FROM messages WHERE conversation_id=?'); $d->execute([$cid]);
    $messageCount=$d->rowCount();
    $pdo->prepare('DELETE FROM conversations WHERE id=?')->execute([$cid]);
    $pdo->commit();
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}

$rootVoice=realpath(dirname(__DIR__,3).'/storage/voice');
if($rootVoice) foreach($voiceFiles as $rel) {
    $file=realpath(dirname(__DIR__,3).'/storage/'.ltrim($rel,'/'));
    if($file && str_starts_with($file,$rootVoice.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
}
$rootMedia=realpath(dirname(__DIR__,3).'/storage/media');
if($rootMedia) foreach($mediaFiles as $rel) {
    $file=realpath(dirname(__DIR__,3).'/storage/'.ltrim($rel,'/'));
    if($file && str_starts_with($file,$rootMedia.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
}
ok(['deleted'=>true,'hard_deleted'=>true,'both_sides'=>true,'messages_deleted'=>$messageCount]);
