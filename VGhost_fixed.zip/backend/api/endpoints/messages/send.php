<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php'; require_once __DIR__.'/../../core/Fcm.php'; require_once __DIR__.'/../../core/Notifications.php'; require_once __DIR__.'/../../core/LinkPreview.php';
require_method('POST');
$u=current_user(); $in=request_json();
try { $schema=db(); $q=$schema->query("SHOW COLUMNS FROM messages LIKE 'reply_to_message_id'"); if(!$q->fetch(PDO::FETCH_ASSOC)) $schema->exec("ALTER TABLE messages ADD COLUMN reply_to_message_id BIGINT UNSIGNED NULL AFTER sticker_id"); } catch(Throwable $e) {}

$receiver=(int)($in['receiver_id']??$in['receiverId']??0);
$message=input_string($in,'message',4000);
$messageType=(string)($in['message_type']??$in['messageType']??'text');
$replyToMessageId=(int)($in['reply_to_message_id']??$in['replyToMessageId']??0);
$rawStickerId=$in['sticker_id']??$in['stickerId']??null;
$stickerFileName=null;

// Compatibility with both the database sticker pack and the new /stickers/*.webp folder.
// The Android app sends __VG_STICKER__:<id-or-file-key>.
if ($rawStickerId===null && preg_match('/^__VG_STICKER__:([A-Za-z0-9._-]+)$/', $message, $m)) $rawStickerId=$m[1];
// GIFs are now served from /gifs as WebP files. Keep old .gif markers working too.
$isGifMarker = preg_match('/^__VG_GIF__:([A-Za-z0-9._-]+)$/i', $message, $gifMatch) === 1;
if ($rawStickerId!==null && (string)$rawStickerId!=='') $messageType='sticker';
if ($isGifMarker) $messageType='gif';
if(!in_array($messageType,['text','emoji','sticker','gif'],true)) $messageType='text';
if(!$receiver) fail('MISSING_receiver_id'); if($receiver===$u['id']) fail('INVALID_RECEIVER');
if($messageType==='sticker' && ($rawStickerId===null || !preg_match('/^[A-Za-z0-9._-]+$/',(string)$rawStickerId))) fail('INVALID_STICKER',422);
if($messageType==='gif') {
    if(!$isGifMarker) fail('INVALID_GIF',422);
    $gifKey=$gifMatch[1];
    $gifFile=dirname(__DIR__,3).'/gifs/'.$gifKey;
    if(!is_file($gifFile)) {
        // Current picker sends the filename key without extension.
        foreach(['.webp','.gif'] as $ext) {
            $candidate=dirname(__DIR__,3).'/gifs/'.$gifKey.$ext;
            if(is_file($candidate)) { $gifFile=$candidate; $gifKey=$gifKey.$ext; break; }
        }
    }
    if(!is_file($gifFile)) fail('GIF_NOT_FOUND',404);
    $gifMatch[1]=$gifKey;
}
$pdo=db();
if($replyToMessageId>0){
    $rq=$pdo->prepare('SELECT id FROM messages WHERE id=? AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) AND is_deleted=0 LIMIT 1');
    $rq->execute([$replyToMessageId,$u['id'],$receiver,$receiver,$u['id']]);
    if(!$rq->fetchColumn()) fail('INVALID_REPLY_MESSAGE',422);
}
ensure_link_preview_schema($pdo);
if($messageType==='sticker') ensure_sticker_schema();
$q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1'); $q->execute([$receiver]); if(!$q->fetch()) fail('RECEIVER_NOT_FOUND',404);
$bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1'); $bq->execute([$u['id'],$receiver,$receiver,$u['id']]); if($bq->fetch()) fail('USER_BLOCKED',403);
// Authenticated users may message any valid account. Privacy message-permission settings are not used as a send gate.

$sticker=null;
if($messageType==='sticker') {
    $stickerValue=(string)$rawStickerId;
    // Numeric IDs continue to use the existing DB sticker table.
    if(ctype_digit($stickerValue) && (int)$stickerValue>0) {
        $sid=(int)$stickerValue;
        $sq=$pdo->prepare('SELECT id,sticker_key,emoji,label,image_url FROM stickers WHERE id=? AND is_active=1 LIMIT 1');
        $sq->execute([$sid]); $sticker=$sq->fetch(PDO::FETCH_ASSOC);
        if(!$sticker) fail('STICKER_NOT_FOUND',404);
        $message='__VG_STICKER__:'.$sid;
    } else {
        // Folder-based sticker. The normal sticker folder is preferred; GIF-folder
        // stickers are also supported because the Android picker reads that folder.
        $stickerFile=null; $publicFolder='stickers';
        foreach (['stickers'=>['.webp','.gif'], 'gifs'=>['.gif']] as $folder=>$exts) {
            $root=dirname(__DIR__,3).'/'.$folder;
            $candidate=$root.'/'.$stickerValue;
            if(is_file($candidate)) { $stickerFile=$candidate; $publicFolder=$folder; break; }
            foreach($exts as $ext){
                $candidate=$root.'/'.$stickerValue.$ext;
                if(is_file($candidate)) { $stickerFile=$candidate; $publicFolder=$folder; break 2; }
            }
        }
        if(!$stickerFile || !is_file($stickerFile)) fail('STICKER_NOT_FOUND',404);
        $fileName=basename($stickerFile);
        $key=pathinfo($fileName,PATHINFO_FILENAME);
        $message='__VG_STICKER__:'.$key;
        $sticker=['id'=>$key,'key'=>$key,'emoji'=>'','label'=>$key,'image_url'=>$publicFolder.'/'.rawurlencode($fileName)];
    }
}

$gif=null;
if($messageType==='gif') {
    $gifName=$gifMatch[1];
    $gif=['id'=>pathinfo($gifName,PATHINFO_FILENAME),'key'=>pathinfo($gifName,PATHINFO_FILENAME),'label'=>pathinfo($gifName,PATHINFO_FILENAME),'image_url'=>'gifs/'.rawurlencode($gifName)];
    $message='__VG_GIF__:'.$gifName;
}

// Link previews are optional: a site that blocks bots or has no OG metadata must
// never prevent the actual message from being sent.
$linkPreview = null;
if ($messageType === 'text' || $messageType === 'emoji') {
    try { $previewUrl = vg_preview_first_url($message); if ($previewUrl) $linkPreview = vg_link_preview($previewUrl); } catch (Throwable $e) { $linkPreview = null; }
}

$pdo->beginTransaction(); try {
 $one=min((int)$u['id'],$receiver); $two=max((int)$u['id'],$receiver);
 $a=$pdo->prepare('SELECT id FROM conversations WHERE user_one_id=? AND user_two_id=? LIMIT 1'); $a->execute([$one,$two]); $c=$a->fetch();
 if(!$c){$pdo->prepare('INSERT INTO conversations(user_one_id,user_two_id,created_at,updated_at) VALUES(?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([$one,$two]); $cid=(int)$pdo->lastInsertId();} else $cid=(int)$c['id'];
 $sid=$sticker?(int)$sticker['id']:null;
 try {
   try {
   $pdo->prepare('INSERT INTO messages(conversation_id,sender_id,receiver_id,message,message_type,sticker_id,reply_to_message_id,link_preview_url,link_preview_title,link_preview_description,link_preview_image,link_preview_site,link_preview_type,link_preview_video,created_at,expires_at,is_read,is_deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),0,0)')->execute([
     $cid,$u['id'],$receiver,$message,$messageType,$sid,$replyToMessageId>0?$replyToMessageId:null,
     $linkPreview['url']??null,$linkPreview['title']??null,$linkPreview['description']??null,$linkPreview['image']??null,$linkPreview['site']??null,$linkPreview['type']??null,$linkPreview['video']??null
   ]);
 } catch (Throwable $previewSchemaError) {
   // Older production schemas can still send normal messages without preview columns.
   $pdo->prepare('INSERT INTO messages(conversation_id,sender_id,receiver_id,message,message_type,sticker_id,reply_to_message_id,created_at,expires_at,is_read,is_deleted) VALUES(?,?,?,?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),0,0)')->execute([$cid,$u['id'],$receiver,$message,$messageType,$sid,$replyToMessageId>0?$replyToMessageId:null]);
 }
 } catch(Throwable $e) {
   // Old production schemas may not have sticker_id yet; the request remains compatible.
   if(!in_array($messageType,['sticker','gif'],true)) throw $e;
   $pdo->prepare('INSERT INTO messages(conversation_id,sender_id,receiver_id,message,message_type,created_at,expires_at,is_read,is_deleted) VALUES(?,?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),0,0)')->execute([$cid,$u['id'],$receiver,$message,$messageType]);
 }
 $mid=(int)$pdo->lastInsertId(); $pdo->prepare('UPDATE conversations SET updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([$cid]);
$replyOut=null;
if($replyToMessageId>0){
    $rq=$pdo->prepare('SELECT m.id,m.message,m.message_type,m.audio_duration,m.attachment_path,m.attachment_type,m.attachment_name,m.link_preview_url,m.link_preview_title,m.link_preview_description,m.link_preview_image,m.link_preview_site,m.link_preview_type,m.link_preview_video,m.sticker_id,u.nickname,s.image_url AS sticker_image_url FROM messages m JOIN users u ON u.id=m.sender_id LEFT JOIN stickers s ON s.id=m.sticker_id WHERE m.id=? LIMIT 1');
    $rq->execute([$replyToMessageId]);
    if($rr=$rq->fetch(PDO::FETCH_ASSOC)) {
        $replyOut=['id'=>(int)$rr['id'],'text'=>(string)$rr['message'],'message_type'=>(string)$rr['message_type'],'senderNickname'=>(string)$rr['nickname']];
        $rt=(string)$rr['message_type'];
        if($rt==='voice'||$rt==='audio'||!empty($rr['audio_path'])){ $replyOut['message_type']='voice'; $replyOut['audioUrl']='/messages/voice_file?id='.(int)$rr['id']; $replyOut['audioDuration']=(int)($rr['audio_duration']??0); }
        if(($rt==='attachment'||!empty($rr['attachment_path'])) && empty($rr['audio_path'])){ $replyOut['attachmentUrl']=!empty($rr['attachment_path'])?'/messages/attachment-file?id='.(int)$rr['id']:null; $replyOut['attachmentType']=(string)($rr['attachment_type']??''); $replyOut['attachmentName']=(string)($rr['attachment_name']??''); }
        if($rt==='sticker') {
            if(!empty($rr['sticker_image_url'])) $replyOut['stickerImageUrl']=(string)$rr['sticker_image_url'];
            else if(preg_match('/^__VG_STICKER__:([A-Za-z0-9._-]+)$/',(string)$rr['message'],$sm)) {
                $sk=$sm[1];
                $candidate=dirname(__DIR__,3).'/stickers/'.$sk;
                if(!preg_match('/\.webp$/i',$sk)) $candidate.='.webp';
                if(is_file($candidate)) $replyOut['stickerImageUrl']='stickers/'.rawurlencode(basename($candidate));
            }
        }
        if($rt==='gif'){
            $gifName=''; if(preg_match('/^__VG_GIF__:([A-Za-z0-9._-]+)$/i',(string)$rr['message'],$gm)) $gifName=$gm[1];
            $gifFile=dirname(__DIR__,3).'/gifs/'.$gifName;
            if($gifName!==''&&!is_file($gifFile)&&!preg_match('/\.(?:webp|gif)$/i',$gifName)){foreach(['.webp','.gif'] as $ext){$candidate=$gifFile.$ext;if(is_file($candidate)){$gifFile=$candidate;$gifName.=$ext;break;}}}
            if($gifName!==''&&is_file($gifFile)) $replyOut['gifImageUrl']='gifs/'.rawurlencode($gifName);
        }
    }
        if(!empty($rr['link_preview_url'])) {
            $replyOut['linkPreviewUrl']=(string)$rr['link_preview_url'];
            $replyOut['linkPreviewTitle']=(string)($rr['link_preview_title']??'');
            $replyOut['linkPreviewDescription']=(string)($rr['link_preview_description']??'');
            $replyOut['linkPreviewImage']=(string)($rr['link_preview_image']??'');
            $replyOut['linkPreviewSite']=(string)($rr['link_preview_site']??'');
            $replyOut['linkPreviewType']=(string)($rr['link_preview_type']??'website');
            $replyOut['linkPreviewVideo']=(string)($rr['link_preview_video']??'');
        }
} $pdo->commit();
} catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack(); throw $e;}
require_once __DIR__.'/../../core/Level.php'; award_activity_xp(db(),(int)$u['id'],2,'message_sent');
$sender=(string)$u['nickname'];
$notificationId=notify_localized($receiver,'message',['name'=>$sender],['target'=>'chat','targetValue'=>$sender,'senderNickname'=>$sender,'conversationId'=>(string)$cid]);
$out=['id'=>$mid,'conversation_id'=>$cid,'sender_id'=>(int)$u['id'],'receiver_id'=>$receiver,'message'=>$message,'message_type'=>$messageType,'expires_at'=>gmdate('Y-m-d H:i:s',time()+86400)];
if($replyOut) { $out['replyToMessageId']=(string)$replyOut['id']; $out['replyToSenderNickname']=$replyOut['senderNickname']; $out['replyToText']=$replyOut['text']; $out['replyToMessageType']=$replyOut['message_type']; foreach(['audioUrl'=>'replyToAudioUrl','audioDuration'=>'replyToAudioDuration','stickerImageUrl'=>'replyToStickerImageUrl','gifImageUrl'=>'replyToGifImageUrl','attachmentUrl'=>'replyToAttachmentUrl','attachmentType'=>'replyToAttachmentType','attachmentName'=>'replyToAttachmentName','linkPreviewUrl'=>'replyToLinkPreviewUrl','linkPreviewTitle'=>'replyToLinkPreviewTitle','linkPreviewDescription'=>'replyToLinkPreviewDescription','linkPreviewImage'=>'replyToLinkPreviewImage','linkPreviewSite'=>'replyToLinkPreviewSite','linkPreviewType'=>'replyToLinkPreviewType','linkPreviewVideo'=>'replyToLinkPreviewVideo'] as $src=>$dst) if(array_key_exists($src,$replyOut)) $out[$dst]=$replyOut[$src]; }
if($sticker) $out['sticker']=$sticker;
if($gif) $out['gif']=$gif;
if($linkPreview) $out['link_preview']=$linkPreview;
ok(['message'=>$out,'notificationId'=>$notificationId]);
