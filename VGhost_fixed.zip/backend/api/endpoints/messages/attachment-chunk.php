<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??''));
$receiver=(int)($_SERVER['HTTP_X_VGHOST_RECEIVER_ID']??0);
$index=(int)($_SERVER['HTTP_X_VGHOST_CHUNK_INDEX']??-1);
$total=(int)($_SERVER['HTTP_X_VGHOST_TOTAL_CHUNKS']??0);
$totalSize=(int)($_SERVER['HTTP_X_VGHOST_TOTAL_SIZE']??0);
$fileName=urldecode((string)($_SERVER['HTTP_X_VGHOST_FILE_NAME']??''));
$mimeHint=strtolower(trim(urldecode((string)($_SERVER['HTTP_X_VGHOST_MIME_TYPE']??''))));
if($uploadId==='' || strlen($uploadId)>80 || $receiver<=0 || $receiver===(int)$u['id'] || $index<0 || $total<1 || $index>=$total || $totalSize<1 || $totalSize>1024*1024*1024) fail('INVALID_UPLOAD',422);
if($total>2048) fail('INVALID_UPLOAD',422);
if($fileName==='' || mb_strlen($fileName)>255) fail('INVALID_FILE_NAME',422);
$body=file_get_contents('php://input');
if($body===false || $body==='') fail('EMPTY_CHUNK',422);
if(strlen($body)>768*1024) fail('CHUNK_TOO_LARGE',413);
$pdo=db();
$q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1');
$q->execute([$receiver]); if(!$q->fetch()) fail('RECEIVER_NOT_FOUND',404);
$bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1');
$bq->execute([$u['id'],$receiver,$receiver,$u['id']]); if($bq->fetch()) fail('USER_BLOCKED',403);
$perm=$pdo->prepare('SELECT message_permission FROM users WHERE id=? LIMIT 1'); $perm->execute([$receiver]);
$messagePermission=(string)($perm->fetchColumn() ?: 'everyone');
if($messagePermission==='nobody') fail('MESSAGES_NOT_ALLOWED',403);
if($messagePermission==='friends'){
    $fq=$pdo->prepare('SELECT 1 FROM friendships WHERE user_one_id=? AND user_two_id=? AND status="accepted" LIMIT 1');
    $fq->execute([min((int)$u['id'],$receiver),max((int)$u['id'],$receiver)]); if(!$fq->fetchColumn()) fail('MESSAGES_FRIENDS_ONLY',403);
}
$root=realpath(dirname(__DIR__,3)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$base=$root.'/storage/messages/.chunks';
if(!is_dir($base) && !mkdir($base,0750,true)) fail('STORAGE_UNAVAILABLE',500);
// Remove abandoned partial uploads older than 24 hours.
foreach(@scandir($base) ?: [] as $d){
    if($d==='.'||$d==='..') continue;
    $dirOld=$base.'/'.$d;
    if(is_dir($dirOld) && @filemtime($dirOld)!==false && filemtime($dirOld)<time()-86400){
        foreach(@scandir($dirOld) ?: [] as $f){ if($f!=='.'&&$f!=='..') @unlink($dirOld.'/'.$f); }
        @rmdir($dirOld);
    }
}
$dir=$base.'/'.$uploadId;
if(!is_dir($dir) && !mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
$metaFile=$dir.'/meta.json';
$meta=is_file($metaFile)?json_decode((string)@file_get_contents($metaFile),true):null;
if(!is_array($meta)){
    $meta=['user_id'=>(int)$u['id'],'receiver_id'=>$receiver,'file_name'=>$fileName,'mime_hint'=>$mimeHint,'total_chunks'=>$total,'total_size'=>$totalSize,'created_at'=>time()];
    if(@file_put_contents($metaFile,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)===false) fail('STORAGE_UNAVAILABLE',500);
}else if((int)($meta['user_id']??0)!==(int)$u['id'] || (int)($meta['receiver_id']??0)!==$receiver || (int)($meta['total_chunks']??0)!==$total || (int)($meta['total_size']??0)!==$totalSize || (string)($meta['file_name']??'')!==$fileName){
    fail('UPLOAD_MISMATCH',409);
}
$part=$dir.'/'.sprintf('%06d.part',$index);
if(@file_put_contents($part,$body,LOCK_EX)===false) fail('MEDIA_STORE_FAILED',500);
ok(['uploadId'=>$uploadId,'chunkIndex'=>$index,'receivedBytes'=>filesize($part)]);
