<?php
declare(strict_types=1); require_once __DIR__.'/../../core/App.php'; require_once __DIR__.'/../../core/LinkPreview.php'; require_method('GET'); $u=current_user();
try { $schema=db(); $q=$schema->query("SHOW COLUMNS FROM messages LIKE 'reply_to_message_id'"); if(!$q->fetch(PDO::FETCH_ASSOC)) $schema->exec("ALTER TABLE messages ADD COLUMN reply_to_message_id BIGINT UNSIGNED NULL AFTER sticker_id"); } catch(Throwable $e) {}
// Add attachment columns once for older production databases.
try {
    $schema=db();
    foreach ([
        'attachment_path'=>"ALTER TABLE messages ADD COLUMN attachment_path VARCHAR(500) NULL",
        'attachment_type'=>"ALTER TABLE messages ADD COLUMN attachment_type VARCHAR(80) NULL",
        'attachment_name'=>"ALTER TABLE messages ADD COLUMN attachment_name VARCHAR(255) NULL",
        'attachment_size'=>"ALTER TABLE messages ADD COLUMN attachment_size BIGINT UNSIGNED NULL",
        'link_preview_url'=>"ALTER TABLE messages ADD COLUMN link_preview_url VARCHAR(2048) NULL",
        'link_preview_title'=>"ALTER TABLE messages ADD COLUMN link_preview_title VARCHAR(500) NULL",
        'link_preview_description'=>"ALTER TABLE messages ADD COLUMN link_preview_description TEXT NULL",
        'link_preview_image'=>"ALTER TABLE messages ADD COLUMN link_preview_image VARCHAR(2048) NULL",
        'link_preview_site'=>"ALTER TABLE messages ADD COLUMN link_preview_site VARCHAR(190) NULL",
        'link_preview_type'=>"ALTER TABLE messages ADD COLUMN link_preview_type VARCHAR(30) NULL",
        'link_preview_video'=>"ALTER TABLE messages ADD COLUMN link_preview_video VARCHAR(2048) NULL"
    ] as $col=>$sql) {
        $q=$schema->query("SHOW COLUMNS FROM messages LIKE '$col'");
        if(!$q->fetch(PDO::FETCH_ASSOC)) $schema->exec($sql);
    }
} catch(Throwable $e) { /* query fallback below preserves legacy reads */ }
try { ensure_link_preview_schema(db()); } catch(Throwable $e) {} try { db()->exec("UPDATE messages SET expires_at=DATE_ADD(created_at, INTERVAL 24 HOUR) WHERE expires_at IS NULL"); } catch(Throwable $e) {} $other=(int)($_GET['user_id']??$_GET['userId']??0); if(!$other) fail('MISSING_user_id');
$stmt=db()->prepare('SELECT m.id,m.conversation_id,m.sender_id,m.receiver_id,m.message,m.message_type,m.sticker_id,m.reply_to_message_id,m.audio_path,m.audio_duration,m.attachment_path,m.attachment_type,m.attachment_name,m.attachment_size,m.link_preview_url,m.link_preview_title,m.link_preview_description,m.link_preview_image,m.link_preview_site,m.link_preview_type,m.link_preview_video,m.created_at,m.expires_at,m.is_read,s.nickname AS senderNickname,r.nickname AS receiverNickname,ru.nickname AS replyToSenderNickname,rm.message AS replyToText,rm.message_type AS replyToMessageType,rm.audio_path AS replyAudioPath,rm.audio_duration AS replyAudioDuration,rm.attachment_path AS replyAttachmentPath,rm.attachment_type AS replyAttachmentType,rm.attachment_name AS replyAttachmentName,rm.link_preview_url AS replyLinkPreviewUrl,rm.link_preview_title AS replyLinkPreviewTitle,rm.link_preview_description AS replyLinkPreviewDescription,rm.link_preview_image AS replyLinkPreviewImage,rm.link_preview_site AS replyLinkPreviewSite,rm.link_preview_type AS replyLinkPreviewType,rm.link_preview_video AS replyLinkPreviewVideo,rst.image_url AS replyStickerImageUrl,st.sticker_key,st.emoji AS sticker_emoji,st.label AS sticker_label,st.image_url AS sticker_image_url FROM messages m JOIN conversations c ON c.id=m.conversation_id JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.receiver_id LEFT JOIN stickers st ON st.id=m.sticker_id LEFT JOIN messages rm ON rm.id=m.reply_to_message_id LEFT JOIN users ru ON ru.id=rm.sender_id LEFT JOIN stickers rst ON rst.id=rm.sticker_id WHERE ((c.user_one_id=? AND c.user_two_id=?) OR (c.user_one_id=? AND c.user_two_id=?)) AND m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP() ORDER BY m.id DESC LIMIT 100');
try { $stmt->execute([$u['id'],$other,$other,$u['id']]); $rows=$stmt->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e) {
    try {
        $stmt=db()->prepare('SELECT m.id,m.conversation_id,m.sender_id,m.receiver_id,m.message,m.message_type,m.reply_to_message_id,m.attachment_path,m.attachment_type,m.attachment_name,m.attachment_size,m.link_preview_url,m.link_preview_title,m.link_preview_description,m.link_preview_image,m.link_preview_site,m.link_preview_type,m.link_preview_video,m.created_at,m.expires_at,m.is_read,s.nickname AS senderNickname,r.nickname AS receiverNickname,ru.nickname AS replyToSenderNickname,rm.message AS replyToText,rm.message_type AS replyToMessageType,rm.link_preview_url AS replyLinkPreviewUrl,rm.link_preview_title AS replyLinkPreviewTitle,rm.link_preview_description AS replyLinkPreviewDescription,rm.link_preview_image AS replyLinkPreviewImage,rm.link_preview_site AS replyLinkPreviewSite,rm.link_preview_type AS replyLinkPreviewType,rm.link_preview_video AS replyLinkPreviewVideo FROM messages m JOIN conversations c ON c.id=m.conversation_id JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.receiver_id LEFT JOIN messages rm ON rm.id=m.reply_to_message_id LEFT JOIN users ru ON ru.id=rm.sender_id WHERE ((c.user_one_id=? AND c.user_two_id=?) OR (c.user_one_id=? AND c.user_two_id=?)) AND m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP() ORDER BY m.id DESC LIMIT 100');
        $stmt->execute([$u['id'],$other,$other,$u['id']]); $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(Throwable $e2) {
        $stmt=db()->prepare('SELECT m.id,m.conversation_id,m.sender_id,m.receiver_id,m.message,m.message_type,m.created_at,m.expires_at,m.is_read,s.nickname AS senderNickname,r.nickname AS receiverNickname,ru.nickname AS replyToSenderNickname,rm.message AS replyToText,rm.message_type AS replyToMessageType,rm.link_preview_url AS replyLinkPreviewUrl,rm.link_preview_title AS replyLinkPreviewTitle,rm.link_preview_description AS replyLinkPreviewDescription,rm.link_preview_image AS replyLinkPreviewImage,rm.link_preview_site AS replyLinkPreviewSite,rm.link_preview_type AS replyLinkPreviewType,rm.link_preview_video AS replyLinkPreviewVideo FROM messages m JOIN conversations c ON c.id=m.conversation_id JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.receiver_id LEFT JOIN messages rm ON rm.id=m.reply_to_message_id LEFT JOIN users ru ON ru.id=rm.sender_id WHERE ((c.user_one_id=? AND c.user_two_id=?) OR (c.user_one_id=? AND c.user_two_id=?)) AND m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP() ORDER BY m.id DESC LIMIT 100');
        $stmt->execute([$u['id'],$other,$other,$u['id']]); $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
// Attach reaction counts and the current user's reaction to every message.
// The chat UI can therefore restore reactions after refresh/re-login instead of
// only showing the optimistic local state from the current screen.
if ($rows) {
    $messageIds = array_values(array_filter(array_map(static fn($r) => (int)($r['id'] ?? 0), $rows)));
    if ($messageIds) {
        $placeholders = implode(',', array_fill(0, count($messageIds), '?'));
        $rq = db()->prepare(
            "SELECT message_id,user_id,reaction FROM message_reactions WHERE message_id IN ($placeholders)"
        );
        try {
            $rq->execute($messageIds);
            $reactionRows = $rq->fetchAll(PDO::FETCH_ASSOC);
            $reactionMap = [];
            $myReactionMap = [];
            foreach ($reactionRows as $rr) {
                $mid = (int)$rr['message_id'];
                $emoji = (string)$rr['reaction'];
                if ($emoji === '') continue;
                if (!isset($reactionMap[$mid])) $reactionMap[$mid] = [];
                $reactionMap[$mid][$emoji] = ($reactionMap[$mid][$emoji] ?? 0) + 1;
                if ((int)$rr['user_id'] === (int)$u['id']) $myReactionMap[$mid] = $emoji;
            }
            foreach ($rows as &$reactionRow) {
                $mid = (int)$reactionRow['id'];
                $reactionRow['reactions'] = $reactionMap[$mid] ?? new stdClass();
                $reactionRow['myReaction'] = $myReactionMap[$mid] ?? null;
            }
            unset($reactionRow);
        } catch (Throwable $e) {
            // Reactions are optional for legacy databases; keep messages available.
            foreach ($rows as &$reactionRow) {
                $reactionRow['reactions'] = new stdClass();
                $reactionRow['myReaction'] = null;
            }
            unset($reactionRow);
        }
    }
}
foreach($rows as &$row){
    if(!empty($row['reply_to_message_id'])){
        $row['replyToMessageId']=(string)$row['reply_to_message_id'];
        $row['replyToSenderNickname']=(string)($row['replyToSenderNickname']??'');
        $row['replyToText']=(string)($row['replyToText']??'');
        $row['replyToMessageType']=(string)($row['replyToMessageType']??'text');
        // Preserve the original media when this message is a reply. Reply cards
        // must show sticker/GIF/image/video/audio, not only the original text.
        try {
            $rmq=db()->prepare('SELECT m.id,m.message,m.message_type,m.audio_path,m.audio_duration,m.attachment_path,m.attachment_type,m.attachment_name,m.link_preview_url,m.link_preview_title,m.link_preview_description,m.link_preview_image,m.link_preview_site,m.link_preview_type,m.link_preview_video,m.sticker_id,s.image_url AS sticker_image_url FROM messages m LEFT JOIN stickers s ON s.id=m.sticker_id WHERE m.id=? LIMIT 1');
            $rmq->execute([(int)$row['reply_to_message_id']]);
            if($rm=$rmq->fetch(PDO::FETCH_ASSOC)){
                $rType=(string)($rm['message_type']??'text');
                $row['replyToMessageType']=$rType;
                $row['replyToText']=(string)($rm['message']??'');
                if($rType==='voice' || $rType==='audio' || !empty($rm['audio_path'])){ $row['replyToMessageType']='voice'; $row['replyToAudioUrl']='/messages/voice_file?id='.(int)$rm['id']; $row['replyToAudioDuration']=(int)($rm['audio_duration']??0); }
                if(($rType==='attachment' || !empty($rm['attachment_path'])) && empty($rm['audio_path'])){ $row['replyToAttachmentUrl']=!empty($rm['attachment_path'])?'/messages/attachment-file?id='.(int)$rm['id']:null; $row['replyToAttachmentType']=(string)($rm['attachment_type']??''); $row['replyToAttachmentName']=(string)($rm['attachment_name']??''); }
                if($rType==='sticker' && !empty($rm['sticker_image_url'])) $row['replyToStickerImageUrl']=(string)$rm['sticker_image_url'];
                if($rType==='gif'){
                    $marker=(string)($rm['message']??''); $gifName='';
                    if(preg_match('/^__VG_GIF__:([A-Za-z0-9._-]+)$/i',$marker,$gm)) $gifName=$gm[1];
                    $gifFile=dirname(__DIR__,3).'/gifs/'.$gifName;
                    if($gifName!=='' && !is_file($gifFile) && !preg_match('/\.(?:webp|gif)$/i',$gifName)){ foreach(['.webp','.gif'] as $ext){$candidate=$gifFile.$ext;if(is_file($candidate)){$gifFile=$candidate;$gifName.=$ext;break;}} }
                    if($gifName!=='' && is_file($gifFile)) $row['replyToGifImageUrl']='gifs/'.rawurlencode($gifName);
                }
            }
        } catch(Throwable $ignored) {}
    }
    if(!empty($rm['replyLinkPreviewUrl']) || !empty($rm['link_preview_url'])) {
        $row['replyToLinkPreviewUrl']=(string)($rm['replyLinkPreviewUrl'] ?? $rm['link_preview_url'] ?? '');
        $row['replyToLinkPreviewTitle']=(string)($rm['replyLinkPreviewTitle'] ?? $rm['link_preview_title'] ?? '');
        $row['replyToLinkPreviewDescription']=(string)($rm['replyLinkPreviewDescription'] ?? $rm['link_preview_description'] ?? '');
        $row['replyToLinkPreviewImage']=(string)($rm['replyLinkPreviewImage'] ?? $rm['link_preview_image'] ?? '');
        $row['replyToLinkPreviewSite']=(string)($rm['replyLinkPreviewSite'] ?? $rm['link_preview_site'] ?? '');
        $row['replyToLinkPreviewType']=(string)($rm['replyLinkPreviewType'] ?? $rm['link_preview_type'] ?? 'website');
        $row['replyToLinkPreviewVideo']=(string)($rm['replyLinkPreviewVideo'] ?? $rm['link_preview_video'] ?? '');
    }
    if(($row['message_type']??'')==='sticker'){
    } elseif (($row['message_type']??'')==='voice') {
        $row['audio_url']='/messages/voice_file?id='.(int)$row['id'];
        $row['audio_duration']=(int)($row['audio_duration']??0);
        $row['message']='🎤 Voice message';
    }
    if(($row['message_type']??'')==='sticker'){
        $sid=isset($row['sticker_id'])?(int)$row['sticker_id']:0;
        $marker=(string)$row['message'];
        if(!$sid && preg_match('/^__VG_STICKER__:(\d+)$/',$marker,$m)) $sid=(int)$m[1];
        if($sid && empty($row['sticker_key'])) { $sq=db()->prepare('SELECT id,sticker_key,emoji,label,image_url FROM stickers WHERE id=? LIMIT 1'); $sq->execute([$sid]); $st=$sq->fetch(PDO::FETCH_ASSOC); if($st){$row['sticker_id']=(int)$st['id'];$row['sticker_key']=$st['sticker_key'];$row['sticker_emoji']=$st['emoji'];$row['sticker_label']=$st['label'];$row['sticker_image_url']=$st['image_url'];} }
        // Folder-based WebP sticker markers: __VG_STICKER__:<key>.
        if(empty($row['sticker_image_url']) && preg_match('/^__VG_STICKER__:([A-Za-z0-9._-]+)$/',$marker,$m)) {
            $key=$m[1];
            if(!ctype_digit($key)) {
                $candidate=dirname(__DIR__,3).'/stickers/'.$key;
                if(!preg_match('/\.webp$/i',$key)) $candidate.='.webp';
                if(is_file($candidate)) {
                    $fileName=basename($candidate);
                    $row['sticker_key']=pathinfo($fileName,PATHINFO_FILENAME);
                    $row['sticker_label']=$row['sticker_key'];
                    $row['sticker_image_url']='stickers/'.rawurlencode($fileName);
                }
            }
        }
        $row['sticker']=['id'=>$row['sticker_id']??($row['sticker_key']??null),'key'=>$row['sticker_key']??null,'emoji'=>$row['sticker_emoji']??null,'label'=>$row['sticker_label']??null,'image_url'=>$row['sticker_image_url']??null];
    }
    if(($row['message_type']??'')==='gif') {
        $gifName='';
        if(preg_match('/^__VG_GIF__:([A-Za-z0-9._-]+)$/i',(string)$row['message'],$gm)) $gifName=$gm[1];
        $gifFile=dirname(__DIR__,3).'/gifs/'.$gifName;
        if($gifName!=='' && !is_file($gifFile) && !preg_match('/\.(?:webp|gif)$/i',$gifName)) {
            foreach(['.webp','.gif'] as $ext) { $candidate=$gifFile.$ext; if(is_file($candidate)) { $gifFile=$candidate; $gifName.=$ext; break; } }
        }
        $row['gif']=($gifName!=='' && is_file($gifFile)) ? ['id'=>pathinfo($gifName,PATHINFO_FILENAME),'key'=>pathinfo($gifName,PATHINFO_FILENAME),'label'=>pathinfo($gifName,PATHINFO_FILENAME),'image_url'=>'gifs/'.rawurlencode($gifName)] : ['id'=>null,'key'=>null,'label'=>null,'image_url'=>null];
    }
    if(($row['message_type']??'')==='attachment') {
        $path=(string)($row['attachment_path']??'');
        $row['attachment_url']= $path!=='' ? '/messages/attachment-file?id='.(int)$row['id'] : null;
        $row['attachment_type']=(string)($row['attachment_type']??'');
        $row['attachment_name']=(string)($row['attachment_name']??'');
        $row['attachment_size']=(int)($row['attachment_size']??0);
    }
    if (!empty($row['link_preview_url'])) {
        $row['link_preview'] = [
            'url'=>(string)$row['link_preview_url'],
            'title'=>(string)($row['link_preview_title']??''),
            'description'=>(string)($row['link_preview_description']??''),
            'image'=>(string)($row['link_preview_image']??''),
            'site'=>(string)($row['link_preview_site']??''),
            'type'=>(string)($row['link_preview_type']??'website'),
            'video'=>(string)($row['link_preview_video']??'')
        ];
    }
}
unset($row); ok(['messages'=>$rows]);
