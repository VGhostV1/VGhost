<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$u=current_user();
$id=(int)($_GET['id']??0); if($id<=0) fail('INVALID_MESSAGE',422);
$q=db()->prepare('SELECT sender_id,receiver_id,audio_path,message_type,is_deleted,expires_at FROM messages WHERE id=? LIMIT 1');
$q->execute([$id]); $m=$q->fetch(PDO::FETCH_ASSOC);
if(!$m || ($m['message_type']??'')!=='voice' || (int)$m['is_deleted']===1 || strtotime((string)$m['expires_at'])<=time()) fail('VOICE_NOT_FOUND',404);
if((int)$m['sender_id']!==(int)$u['id'] && (int)$m['receiver_id']!==(int)$u['id']) fail('FORBIDDEN',403);
$root=realpath(dirname(__DIR__,3).'/storage/voice');
$file=realpath(dirname(__DIR__,3).'/storage/'.ltrim((string)$m['audio_path'],'/'));
if(!$root || !$file || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file)) fail('VOICE_FILE_NOT_FOUND',404);
$mime=upload_mime_type($file, basename($file));
if($mime==='') $mime='audio/mp4';
header('Content-Type: '.$mime);
header('Content-Disposition: inline');
header('Cache-Control: private, no-store');
header('Accept-Ranges: bytes');
header('X-Content-Type-Options: nosniff');
$size=(int)filesize($file);
$start=0; $end=$size-1;
if(isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/i', (string)$_SERVER['HTTP_RANGE'], $rm)) {
    $start=$rm[1]!=='' ? max(0,(int)$rm[1]) : 0;
    $end=$rm[2]!=='' ? min($end,(int)$rm[2]) : $end;
    if($start>$end || $start >= $size) { header('Content-Range: bytes */'.$size); http_response_code(416); exit; }
    http_response_code(206);
    header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
}
$length=$end-$start+1; header('Content-Length: '.$length);
$fh=fopen($file,'rb'); if(!$fh) fail('VOICE_FILE_NOT_FOUND',404);
fseek($fh,$start); $remaining=$length;
while($remaining>0 && !feof($fh)) { $chunk=fread($fh,min(65536,$remaining)); if($chunk===false || $chunk==='') break; echo $chunk; $remaining-=strlen($chunk); }
fclose($fh); exit;
