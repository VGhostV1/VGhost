<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user(); $b=body();
$id=(int)($b['message_id']??0); $reason=trim((string)($b['reason']??''));
if($id<1) fail('INVALID_MESSAGE_ID',422);
if($reason==='') $reason='Inappropriate content';
$reason=mb_substr($reason,0,255);
$pdo=db();
$q=$pdo->prepare('SELECT sender_id,receiver_id FROM messages WHERE id=? AND expires_at>UTC_TIMESTAMP() LIMIT 1');
$q->execute([$id]); $m=$q->fetch(PDO::FETCH_ASSOC);
if(!$m) fail('MESSAGE_NOT_FOUND',404);
if((int)$m['sender_id']!==(int)$u['id'] && (int)$m['receiver_id']!==(int)$u['id']) fail('FORBIDDEN',403);
try {
  $q=$pdo->prepare("SELECT id FROM content_reports WHERE reporter_id=? AND target_type='message' AND target_id=? AND status='pending' LIMIT 1");
  $q->execute([(int)$u['id'],$id]);
  if($q->fetch()) ok(['reported'=>true,'duplicate'=>true]);
  $q=$pdo->prepare("INSERT INTO content_reports(reporter_id,target_type,target_id,reason,status,created_at) VALUES(?,'message',?,?, 'pending',UTC_TIMESTAMP())");
  $q->execute([(int)$u['id'],$id,$reason]);
  ok(['reported'=>true,'report_id'=>(int)$pdo->lastInsertId()]);
} catch(Throwable $e) { fail('REPORT_SAVE_FAILED',500); }
