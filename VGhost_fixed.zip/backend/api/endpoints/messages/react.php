<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$u=current_user(); $in=request_json();
$messageId=(int)($in['message_id']??0); $reaction=trim((string)($in['reaction']??''));
if(!$messageId) fail('MISSING_message_id');
// Reactions are supplied by the app's emoji picker. Keep the API forward-compatible
// with the full picker instead of maintaining a short, hard-coded allow-list.
if($reaction==='' || strlen($reaction)>32 || preg_match('//u',$reaction)!==1 || preg_match('/[\x00-\x1F\x7F]/u',$reaction)) fail('INVALID_REACTION',422);
$pdo=db();
// Make reactions self-healing on older databases where the startup migration
// could not create the table because of legacy foreign-key definitions.
ensure_message_reactions_schema();
$q=$pdo->prepare('SELECT id,sender_id,receiver_id,is_deleted,expires_at FROM messages WHERE id=? LIMIT 1'); $q->execute([$messageId]); $m=$q->fetch();
if(!$m || (int)$m['is_deleted']===1 || strtotime((string)$m['expires_at'])<=time()) fail('MESSAGE_NOT_FOUND',404);
if((int)$m['sender_id']!==(int)$u['id'] && (int)$m['receiver_id']!==(int)$u['id']) fail('FORBIDDEN',403);
$other=(int)$m['sender_id']===(int)$u['id']?(int)$m['receiver_id']:(int)$m['sender_id'];
try {
    $pdo->prepare('INSERT INTO message_reactions(message_id,user_id,reaction,created_at,updated_at) VALUES(?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE reaction=VALUES(reaction),updated_at=UTC_TIMESTAMP()')->execute([$messageId,$u['id'],$reaction]);
} catch (Throwable $e) {
    // One last compatibility path for legacy hosts: create the minimal table
    // without foreign keys and retry the exact same reaction operation.
    try {
        $pdo->exec('CREATE TABLE IF NOT EXISTS message_reactions (id BIGINT AUTO_INCREMENT PRIMARY KEY,message_id BIGINT NOT NULL,user_id BIGINT NOT NULL,reaction VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,UNIQUE KEY one_reaction_per_user(message_id,user_id),INDEX(message_id),INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
        $pdo->prepare('INSERT INTO message_reactions(message_id,user_id,reaction,created_at,updated_at) VALUES(?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE reaction=VALUES(reaction),updated_at=UTC_TIMESTAMP()')->execute([$messageId,$u['id'],$reaction]);
    } catch (Throwable $retry) {
        fail('REACTION_SAVE_FAILED',500);
    }
}
$nickname=(string)$u['nickname'];
$notificationId=null;
try {
    $notificationId=notify_localized($other,'message_reaction',['name'=>$nickname,'reaction'=>$reaction],[
        'target'=>'chat','targetValue'=>$nickname,'senderNickname'=>$nickname,'conversationId'=>'','messageId'=>(string)$messageId,'reaction'=>$reaction
    ]);
} catch (Throwable $e) {
    // Notification/push is optional; the reaction itself is already stored.
}
ok(['messageId'=>$messageId,'reaction'=>$reaction,'notificationId'=>$notificationId]);
