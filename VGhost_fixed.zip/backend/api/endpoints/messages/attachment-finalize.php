<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Fcm.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');
$u=current_user();
$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??''));
if($uploadId==='' || strlen($uploadId)>80) fail('INVALID_UPLOAD',422);
$root=realpath(dirname(__DIR__,3)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$dir=$root.'/storage/messages/.chunks/'.$uploadId;
$metaFile=$dir.'/meta.json';
$meta=is_file($metaFile)?json_decode((string)@file_get_contents($metaFile),true):null;
if(!is_array($meta) || (int)($meta['user_id']??0)!==(int)$u['id']) fail('UPLOAD_NOT_FOUND',404);
$receiver=(int)($meta['receiver_id']??0); $total=(int)($meta['total_chunks']??0); $expectedSize=(int)($meta['total_size']??0);
$fileName=trim((string)($meta['file_name']??'')); $mimeHint=strtolower(trim((string)($meta['mime_hint']??'')));
if($receiver<=0 || $total<1 || $total>2048 || $expectedSize<1 || $expectedSize>1024*1024*1024 || $fileName==='') fail('INVALID_UPLOAD',422);
$pdo=db();
$q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1'); $q->execute([$receiver]); if(!$q->fetch()) fail('RECEIVER_NOT_FOUND',404);
$bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1'); $bq->execute([$u['id'],$receiver,$receiver,$u['id']]); if($bq->fetch()) fail('USER_BLOCKED',403);
$perm=$pdo->prepare('SELECT message_permission FROM users WHERE id=? LIMIT 1'); $perm->execute([$receiver]);
$messagePermission=(string)($perm->fetchColumn() ?: 'everyone'); if($messagePermission==='nobody') fail('MESSAGES_NOT_ALLOWED',403);
if($messagePermission==='friends'){
    $fq=$pdo->prepare('SELECT 1 FROM friendships WHERE user_one_id=? AND user_two_id=? AND status="accepted" LIMIT 1'); $fq->execute([min((int)$u['id'],$receiver),max((int)$u['id'],$receiver)]); if(!$fq->fetchColumn()) fail('MESSAGES_FRIENDS_ONLY',403);
}
$tmp=$dir.'/assembled.part'; $out=@fopen($tmp,'wb'); if(!$out) fail('STORAGE_UNWRITABLE',500);
$sum=0;
for($i=0;$i<$total;$i++){
    $part=$dir.'/'.sprintf('%06d.part',$i);
    if(!is_file($part)){fclose($out);@unlink($tmp);fail('UPLOAD_INCOMPLETE',422,['chunkIndex'=>$i]);}
    $in=@fopen($part,'rb'); if(!$in){fclose($out);@unlink($tmp);fail('MEDIA_READ_FAILED',500);}
    while(!feof($in)){
        $buf=fread($in,1024*1024); if($buf===false){fclose($in);fclose($out);@unlink($tmp);fail('MEDIA_READ_FAILED',500);}
        if($buf==='') break;
        $sum+=strlen($buf); if($sum>1024*1024*1024){fclose($in);fclose($out);@unlink($tmp);fail('INVALID_MEDIA_SIZE',422);}
        if(fwrite($out,$buf)!==strlen($buf)){fclose($in);fclose($out);@unlink($tmp);fail('MEDIA_STORE_FAILED',500);}
    }
    fclose($in);
}
fclose($out);
if($sum!==$expectedSize){@unlink($tmp);fail('INVALID_MEDIA_SIZE',422,['receivedSize'=>$sum,'expectedSize'=>$expectedSize]);}

$ext=strtolower(pathinfo($fileName,PATHINFO_EXTENSION));
$byExt=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif','heic'=>'image/heic','heif'=>'image/heif','avif'=>'image/avif','mp4'=>'video/mp4','webm'=>'video/webm','mov'=>'video/quicktime','m4v'=>'video/x-m4v','3gp'=>'video/3gpp','3gpp'=>'video/3gpp','3g2'=>'video/3gpp2','mkv'=>'video/x-matroska','mp3'=>'audio/mpeg','m4a'=>'audio/mp4','aac'=>'audio/aac','ogg'=>'audio/ogg','oga'=>'audio/ogg','wav'=>'audio/wav'];
$mime=upload_mime_type($tmp,$fileName);
if($mime==='' || $mime==='application/octet-stream') $mime=$byExt[$ext]??$mimeHint;
$mime=strtolower(trim($mime));
$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','image/heic'=>'heic','image/heif'=>'heif','image/avif'=>'avif','video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov','video/x-m4v'=>'m4v','video/hevc'=>'mp4','video/h265'=>'mp4','video/x-h265'=>'mp4','video/3gpp'=>'3gp','video/3gpp2'=>'3g2','video/x-matroska'=>'mkv','audio/mpeg'=>'mp3','audio/mp3'=>'mp3','audio/mpeg3'=>'mp3','audio/x-mpeg'=>'mp3','audio/x-mp3'=>'mp3','audio/mp4'=>'m4a','audio/x-m4a'=>'m4a','audio/aac'=>'aac','audio/ogg'=>'ogg','application/ogg'=>'ogg','audio/wav'=>'wav','audio/x-wav'=>'wav'];
if(!isset($allowed[$mime])){@unlink($tmp);fail('UNSUPPORTED_MEDIA_TYPE',422,['mime'=>$mime,'extension'=>$ext]);}
[$type,$storedExt]=[str_starts_with($mime,'image/')?'image':(str_starts_with($mime,'video/')?'video':'audio'),$allowed[$mime]];
$displayName=preg_replace('/[^A-Za-z0-9._ -]+/u','_', $fileName) ?: ('file.'.$storedExt); $displayName=substr($displayName,0,255);
$dirFinal=$root.'/storage/media'; if(!is_dir($dirFinal)&&!mkdir($dirFinal,0750,true)){@unlink($tmp);fail('STORAGE_UNAVAILABLE',500);} if(!is_writable($dirFinal)){@chmod($dirFinal,0750);} if(!is_writable($dirFinal)){@unlink($tmp);fail('STORAGE_UNWRITABLE',500);}
$name=bin2hex(random_bytes(24)).'.'.$storedExt; $dest=$dirFinal.'/'.$name; if(!rename($tmp,$dest)){@unlink($tmp);fail('MEDIA_STORE_FAILED',500);}
try{
    $pdo->beginTransaction();
    $one=min((int)$u['id'],$receiver); $two=max((int)$u['id'],$receiver);
    $a=$pdo->prepare('SELECT id FROM conversations WHERE user_one_id=? AND user_two_id=? LIMIT 1'); $a->execute([$one,$two]); $c=$a->fetch();
    if(!$c){$pdo->prepare('INSERT INTO conversations(user_one_id,user_two_id,created_at,updated_at) VALUES(?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([$one,$two]);$cid=(int)$pdo->lastInsertId();} else $cid=(int)$c['id'];
    $pdo->prepare('INSERT INTO messages(conversation_id,sender_id,receiver_id,message,message_type,attachment_path,attachment_type,attachment_name,attachment_size,created_at,expires_at,is_read,is_deleted) VALUES(?,?,?,?,?,?,?,?,?,UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),0,0)')->execute([$cid,$u['id'],$receiver,$displayName,'attachment','media/'.$name,$mime,$displayName,$expectedSize]);
    $mid=(int)$pdo->lastInsertId(); $pdo->prepare('UPDATE conversations SET updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([$cid]); $pdo->commit();
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();@unlink($dest);throw $e;}
require_once __DIR__.'/../../core/Level.php'; award_activity_xp(db(),(int)$u['id'],2,'message_sent');
$sender=(string)$u['nickname']; $notificationId=0; try{$notificationId=notify_localized($receiver,'message',['name'=>$sender],['target'=>'chat','targetValue'=>$sender,'senderNickname'=>$sender,'conversationId'=>(string)$cid]);}catch(Throwable $e){}
foreach(@scandir($dir) ?: [] as $f){if($f!=='.'&&$f!=='..')@unlink($dir.'/'.$f);} @rmdir($dir);
ok(['message'=>['id'=>$mid,'conversation_id'=>$cid,'sender_id'=>(int)$u['id'],'receiver_id'=>$receiver,'message'=>$displayName,'message_type'=>'attachment','attachment_type'=>$type,'attachment_name'=>$displayName,'attachment_size'=>$expectedSize,'attachment_url'=>'/messages/attachment-file?id='.$mid,'expires_at'=>gmdate('Y-m-d H:i:s',time()+86400)],'notificationId'=>$notificationId]);
