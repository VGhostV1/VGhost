<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$u=current_user();
$id=(int)($_GET['id']??0); if($id<=0) fail('INVALID_MESSAGE_ID',422);
$pdo=db();
try{
  $q=$pdo->prepare('SELECT m.attachment_path,m.attachment_type,m.attachment_name,m.attachment_size FROM messages m WHERE m.id=? AND m.is_deleted=0 AND m.expires_at>UTC_TIMESTAMP() AND (m.sender_id=? OR m.receiver_id=?) LIMIT 1');
  $q->execute([$id,$u['id'],$u['id']]);
}catch(Throwable $e){ fail('MEDIA_NOT_AVAILABLE',404); }
$r=$q->fetch(PDO::FETCH_ASSOC); if(!$r || empty($r['attachment_path'])) fail('MEDIA_NOT_FOUND',404);
$root=realpath(dirname(__DIR__,3).'/storage/media');
$file=realpath(dirname(__DIR__,3).'/storage/'.ltrim((string)$r['attachment_path'],'/'));
if(!$root || !$file || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file)) fail('MEDIA_NOT_FOUND',404);
$size=(int)filesize($file); $mime=(string)$r['attachment_type'];
$contentType=$mime !== '' ? $mime : 'application/octet-stream';
header('Content-Type: '.$contentType); header('Content-Length: '.$size); header('Content-Disposition: inline; filename="'.str_replace('"','',basename((string)$r['attachment_name'])).'"'); header('Accept-Ranges: bytes');
$start=0;$end=$size-1;
if(isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/',$_SERVER['HTTP_RANGE'],$m)){
  if($m[1]==='' && $m[2]!==''){ $len=(int)$m[2]; $start=max(0,$size-$len); }
  else { $start=(int)($m[1]??0); if($m[2]!=='')$end=(int)$m[2]; }
  $start=min($start,$size-1); $end=min(max($start,$end),$size-1); $len=$end-$start+1;
  http_response_code(206); header("Content-Range: bytes $start-$end/$size"); header('Content-Length: '.$len);
}
$fp=fopen($file,'rb'); if(!$fp) fail('MEDIA_READ_FAILED',500); fseek($fp,$start); $remaining=$end-$start+1; while($remaining>0 && !feof($fp)){ $chunk=fread($fp,min(1048576,$remaining)); if($chunk===false||$chunk==='')break; echo $chunk; $remaining-=strlen($chunk); } fclose($fp); exit;
