<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user(); $b=body();
$id=(int)($b['message_id']??0); if(!$id) fail('INVALID_MESSAGE_ID',422);
$pdo=db();
$q=$pdo->prepare('SELECT sender_id,receiver_id,message_type,audio_path,attachment_path FROM messages WHERE id=? LIMIT 1');
$q->execute([$id]); $m=$q->fetch(PDO::FETCH_ASSOC);
if(!$m) fail('MESSAGE_NOT_FOUND',404);
if((int)$m['sender_id']!==(int)$u['id'] && (int)$m['receiver_id']!==(int)$u['id']) fail('FORBIDDEN',403);

// A message deletion is a real two-sided deletion: there is one shared DB row
// for both participants, so hard-delete it instead of merely hiding it with
// is_deleted. Remove reactions first for legacy databases without CASCADE.
try {
    $pdo->beginTransaction();
    try { $pdo->prepare('DELETE FROM message_reactions WHERE message_id=?')->execute([$id]); } catch(Throwable $e) {}
    $pdo->prepare('DELETE FROM messages WHERE id=?')->execute([$id]);
    $pdo->commit();
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}

// Private media belongs to the message. Remove it only after the DB deletion
// succeeds, and guard the path so arbitrary files can never be deleted.
$rootVoice=realpath(dirname(__DIR__,3).'/storage/voice');
if($rootVoice && !empty($m['audio_path'])) {
    $file=realpath(dirname(__DIR__,3).'/storage/'.ltrim((string)$m['audio_path'],'/'));
    if($file && str_starts_with($file,$rootVoice.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
}
$rootMedia=realpath(dirname(__DIR__,3).'/storage/media');
if($rootMedia && !empty($m['attachment_path'])) {
    $file=realpath(dirname(__DIR__,3).'/storage/'.ltrim((string)$m['attachment_path'],'/'));
    if($file && str_starts_with($file,$rootMedia.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
}
ok(['deleted'=>true,'hard_deleted'=>true,'both_sides'=>true,'message_id'=>$id]);
