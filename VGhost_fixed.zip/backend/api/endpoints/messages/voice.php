<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
$receiver=(int)($_POST['receiver_id']??0);
if($receiver<=0 || $receiver===(int)$u['id']) fail('INVALID_RECEIVER',422);
if(empty($_FILES['audio']) || $_FILES['audio']['error']!==UPLOAD_ERR_OK) fail('AUDIO_UPLOAD_FAILED',422);
$f=$_FILES['audio'];
if(!is_uploaded_file($f['tmp_name'])) fail('INVALID_UPLOAD',422);

// Self-heal older production databases that were deployed before voice-message columns existed.
// The statements are fixed constants (no user-controlled SQL) and run only for this voice route.
$schemaPdo = db();
try {
  $hasPath = (bool)$schemaPdo->query("SHOW COLUMNS FROM messages LIKE 'audio_path'")->fetch(PDO::FETCH_ASSOC);
  if (!$hasPath) {
    $schemaPdo->exec("ALTER TABLE messages ADD COLUMN audio_path VARCHAR(500) NULL");
  }
  $hasDuration = (bool)$schemaPdo->query("SHOW COLUMNS FROM messages LIKE 'audio_duration'")->fetch(PDO::FETCH_ASSOC);
  if (!$hasDuration) {
    $schemaPdo->exec("ALTER TABLE messages ADD COLUMN audio_duration INT UNSIGNED NULL");
  }
} catch (Throwable $schemaError) {
  fail('VOICE_SCHEMA_UPDATE_FAILED',500);
}
if($f['size']<=0 || $f['size']>1024*1024*1024) fail('INVALID_AUDIO_SIZE',422);
$duration=(int)($_POST['duration']??0);
if($duration<1 || $duration>600) fail('INVALID_AUDIO_DURATION',422);
if($f['size'] > 1024*1024*1024) fail('INVALID_AUDIO_SIZE',422);
$allowed=['audio/mp4'=>'m4a','audio/x-m4a'=>'m4a','video/mp4'=>'m4a','audio/aac'=>'aac','audio/ogg'=>'ogg','application/ogg'=>'ogg','audio/3gpp'=>'3gp'];
$mime=upload_mime_type((string)$f['tmp_name'], (string)($f['name']??''));
if($mime==='') fail('UNSUPPORTED_MEDIA_TYPE',422);
$clientExt=strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
if(!isset($allowed[$mime])) fail('INVALID_AUDIO_TYPE',422);
if($duration > 0 && $f['size'] < 100) fail('INVALID_AUDIO_FILE',422);
$ext=$allowed[$mime];
if($ext==='m4a' && !in_array($clientExt,['m4a','mp4'],true)) fail('INVALID_AUDIO_EXTENSION',422);
if($ext==='aac' && $clientExt!=='aac') fail('INVALID_AUDIO_EXTENSION',422);
if($ext==='ogg' && !in_array($clientExt,['ogg','oga'],true)) fail('INVALID_AUDIO_EXTENSION',422);
if($ext==='3gp' && !in_array($clientExt,['3gp','3gpp'],true)) fail('INVALID_AUDIO_EXTENSION',422);
$dir=dirname(__DIR__,3).'/storage/voice';
// Voice files are private application data; the storage/.htaccess also blocks direct web access on Apache.
if (is_link($dir)) fail('STORAGE_UNAVAILABLE',500);
if(!is_dir($dir)&&!mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
$name=bin2hex(random_bytes(24)).'.'.$ext; $dest=$dir.'/'.$name;
if(!move_uploaded_file($f['tmp_name'],$dest)) fail('AUDIO_STORE_FAILED',500);
$pdo=db();
try {
  $pdo->beginTransaction();
  $q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1');
  $q->execute([$receiver]); if(!$q->fetch()) throw new RuntimeException('RECEIVER_NOT_FOUND');
  $a=min((int)$u['id'],$receiver); $b=max((int)$u['id'],$receiver);
  $pdo->prepare('INSERT IGNORE INTO conversations(user_one_id,user_two_id,created_at,updated_at) VALUES(?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([$a,$b]);
  $q=$pdo->prepare('SELECT id FROM conversations WHERE user_one_id=? AND user_two_id=? LIMIT 1'); $q->execute([$a,$b]); $cid=(int)$q->fetchColumn();
  $pdo->prepare('INSERT INTO messages(conversation_id,sender_id,receiver_id,message,message_type,audio_path,audio_duration,created_at,expires_at,is_read,is_deleted) VALUES(?,?,?,? ,?,?,?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),0,0)')
    ->execute([$cid,$u['id'],$receiver,'🎤 Voice message','voice','voice/'.$name,$duration,gmdate('Y-m-d H:i:s')]);
  $mid=(int)$pdo->lastInsertId();
  $pdo->prepare('UPDATE conversations SET updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([$cid]);
  $pdo->commit();
  ok(['message'=>['id'=>$mid,'message_type'=>'voice','audio_url'=>'/messages/voice_file?id='.$mid,'duration'=>$duration,'expires_at'=>gmdate('Y-m-d H:i:s',time()+86400)]]);
} catch(Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); @unlink($dest); throw $e; }
