<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Response.php';
require_once __DIR__.'/../../core/Auth.php';
require_once __DIR__.'/../../core/Wallet.php';

$u=current_user();
$pdo=db();
ensure_wallet_schema($pdo);
ensure_wallet($pdo,(int)$u['id']);
$s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=? LIMIT 1');
$s->execute([$u['id']]);
$balance=$s->fetchColumn();
if($balance===false) fail('WALLET_NOT_FOUND',404);
ok(['balance'=>(int)$balance,'coinBalance'=>(int)$balance,'wallet'=>['balance'=>(int)$balance]]);
