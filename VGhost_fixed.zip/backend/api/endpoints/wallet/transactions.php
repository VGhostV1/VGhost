<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php'; $u=current_user(); $s=db()->prepare('SELECT id,type,amount,reference,created_at FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT 100'); $s->execute([$u['id']]); ok(['transactions'=>$s->fetchAll()]);
