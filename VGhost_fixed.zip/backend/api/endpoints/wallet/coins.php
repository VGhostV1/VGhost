<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Wallet.php';
require_method('POST');
$u=current_user();
$b=body();
$amount=(int)($b['amount']??0);
if ($amount >= 0) fail('CLIENT_CREDIT_FORBIDDEN',403);
$pdo=db();
$pdo->beginTransaction();
try {
    $balance=debit_wallet($pdo,(int)$u['id'],abs($amount),'spend','app');
    $pdo->commit();
    ok(['balance'=>$balance]);
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
