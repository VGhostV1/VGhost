<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Fcm.php';
require_method('POST');

// Guest devices are only used for public/broadcast announcements. No account
// identity is stored and a token is moved to user_devices automatically after login.
$pdo=db();
$pdo->exec("CREATE TABLE IF NOT EXISTS guest_devices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    device_id VARCHAR(255) NULL,
    fcm_token TEXT NOT NULL,
    token_hash CHAR(64) NOT NULL,
    language VARCHAR(16) NOT NULL DEFAULT 'en',
    last_seen_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_guest_token_hash (token_hash),
    KEY idx_guest_device (device_id),
    KEY idx_guest_last_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$b=body();
$token=trim((string)($b['token']??''));
if($token==='') fail('INVALID_INPUT',422);
$device=trim((string)($b['deviceId']??''));
$lang=strtolower(trim((string)($b['language']??'en')));
if(str_contains($lang,'-')) $lang=explode('-', $lang, 2)[0];
if(!in_array($lang,['az','en','tr','ru'],true)) $lang='en';
$hash=hash('sha256',$token);
try {
    // If this device/token has just become authenticated, it must stop being treated as guest.
    $pdo->prepare('DELETE FROM guest_devices WHERE token_hash=?')->execute([$hash]);
    if($device!=='') $pdo->prepare('DELETE FROM guest_devices WHERE device_id=?')->execute([$device]);
    $pdo->prepare('INSERT INTO guest_devices(device_id,fcm_token,token_hash,language,last_seen_at,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE device_id=VALUES(device_id),fcm_token=VALUES(fcm_token),language=VALUES(language),last_seen_at=UTC_TIMESTAMP()')
        ->execute([$device!==''?$device:null,$token,$hash,$lang]);
    ok(['saved'=>true,'guest'=>true]);
} catch(Throwable $e) { fail('GUEST_DEVICE_SAVE_FAILED',500); }
