<?php
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
require_once __DIR__.'/../../core/Notifications.php';
$b=body();
$token=trim((string)($b['token']??''));
if($token==='') fail('INVALID_INPUT',422);
$device=trim((string)($b['deviceId']??''));
$pdo=db();
$pdo->beginTransaction();
try {
    // A device that has just authenticated must no longer be treated as a guest.
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS guest_devices (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, device_id VARCHAR(255) NULL, fcm_token TEXT NOT NULL, token_hash CHAR(64) NOT NULL,
            language VARCHAR(16) NOT NULL DEFAULT 'en', last_seen_at DATETIME NOT NULL, created_at DATETIME NOT NULL, PRIMARY KEY(id),
            UNIQUE KEY uq_guest_token_hash(token_hash), KEY idx_guest_device(device_id), KEY idx_guest_last_seen(last_seen_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->prepare("DELETE FROM guest_devices WHERE token_hash=? OR (device_id IS NOT NULL AND device_id=? AND ?<>'')")->execute([hash('sha256',$token),$device,$device]);
    } catch(Throwable $ignore) {}
    // One FCM token/device belongs to one account only. This prevents pushes
    // for another account from reaching the currently logged-in device.
    $pdo->prepare('DELETE FROM user_devices WHERE fcm_token=? AND user_id<>?')->execute([$token,(int)$u['id']]);
    if($device!=='') $pdo->prepare('DELETE FROM user_devices WHERE device_id=? AND user_id<>?')->execute([$device,(int)$u['id']]);

    $s=$pdo->prepare('SELECT id FROM user_devices WHERE user_id=? AND fcm_token=? LIMIT 1');
    $s->execute([(int)$u['id'],$token]);
    $id=$s->fetchColumn();
    $isNewDevice = false;
    if($id){
        $pdo->prepare('UPDATE user_devices SET device_id=?,last_seen_at=UTC_TIMESTAMP() WHERE id=?')->execute([$device?:null,$id]);
    } else {
        $pdo->prepare('INSERT INTO user_devices(user_id,device_id,fcm_token,platform,last_seen_at,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([(int)$u['id'],$device?:null,$token,'android']);
        $isNewDevice = true;
    }
    $pdo->commit();

    // Registration happens before an FCM token exists, so deliver the initial
    // welcome bonus as soon as the first device token is bound to the account.
    if($isNewDevice){
        $w=$pdo->prepare('SELECT n.id,n.title,n.body,n.data_json FROM app_notifications n JOIN users u ON u.id=n.user_id WHERE n.user_id=? AND n.type="welcome_bonus" AND n.is_read=0 AND u.created_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 24 HOUR) ORDER BY n.id DESC LIMIT 1');
        $w->execute([(int)$u['id']]);
        $welcome=$w->fetch(PDO::FETCH_ASSOC);
        if($welcome){
            $data=[]; try { $data=json_decode((string)($welcome['data_json']??''),true)?:[]; } catch(Throwable $ignore){}
            $data['notificationId']=(string)$welcome['id']; $data['type']='welcome_bonus'; $data['target']='profile';
            fcm_send_tokens_result([$token],(string)(fcm_config()['project_id']??''),(string)$welcome['title'],(string)$welcome['body'],$data);
        }
    }
    ok(['saved'=>true]);
}catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); fail('DEVICE_SAVE_FAILED',500); }
