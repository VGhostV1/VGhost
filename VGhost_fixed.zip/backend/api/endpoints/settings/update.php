<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php';
require_method('POST'); $u=current_user(); $in=request_json(); $allowed=['messagePrivacy','friendPrivacy','language']; $updates=[];
foreach($allowed as $k) if(array_key_exists($k,$in)) $updates[$k]=(string)$in[$k];
if(isset($updates['messagePrivacy']) && !in_array($updates['messagePrivacy'],['everyone','friends','nobody'],true)) fail('INVALID_MESSAGE_PRIVACY',422);
if(isset($updates['friendPrivacy']) && !in_array($updates['friendPrivacy'],['everyone','friends_of_friends','nobody'],true)) fail('INVALID_FRIEND_PRIVACY',422);
if(isset($updates['language'])) { $lang=strtolower(explode('-', $updates['language'], 2)[0]); if(!in_array($lang, ['en','az','tr','ru'], true)) fail('INVALID_LANGUAGE',422); $updates['language']=$lang; }
if(isset($in['notifications']) && is_array($in['notifications'])){
 foreach(['all','messages','friendRequests','likes','comments','app','sound','vibration'] as $k) if(array_key_exists($k,$in['notifications'])) $updates['notification_'.$k]=((bool)$in['notifications'][$k])?'1':'0';
}
$pdo=db(); $st=$pdo->prepare('INSERT INTO user_settings(user_id,setting_key,setting_value,updated_at) VALUES(?,?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=UTC_TIMESTAMP()');
foreach($updates as $k=>$v) $st->execute([(int)$u['id'],$k,$v]);
ok(['saved'=>true]);
