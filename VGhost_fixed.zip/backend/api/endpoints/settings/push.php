<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method($_SERVER['REQUEST_METHOD'] ?? 'GET');
$u=current_user();
$pdo=db();
if(($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'){
    $q=$pdo->prepare('SELECT COALESCE(push_enabled,1) FROM users WHERE id=? LIMIT 1'); $q->execute([(int)$u['id']]);
    ok(['pushEnabled'=>(bool)$q->fetchColumn()]);
}
$in=body();
if(!array_key_exists('enabled',$in)) fail('MISSING_enabled',422);
$enabled=(bool)$in['enabled'];
$st=$pdo->prepare('UPDATE users SET push_enabled=? WHERE id=?'); $st->execute([$enabled?1:0,(int)$u['id']]);
ok(['pushEnabled'=>$enabled]);
