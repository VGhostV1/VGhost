<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php';
require_method('GET'); $u=current_user();
$s=db()->prepare('SELECT setting_key,setting_value FROM user_settings WHERE user_id=?'); $s->execute([(int)$u['id']]);
$out=[
 'messagePrivacy'=>'everyone','friendPrivacy'=>'everyone','language'=>'en',
 'notifications'=>['all'=>true,'messages'=>true,'friendRequests'=>true,'likes'=>true,'comments'=>true,'app'=>true,'sound'=>true,'vibration'=>true]
];
foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r){$k=$r['setting_key']; $v=$r['setting_value']; if(str_starts_with($k,'notification_')) $out['notifications'][substr($k,13)]=(bool)(int)$v; elseif(array_key_exists($k,$out)) $out[$k]=$v;}
ok(['settings'=>$out]);
