<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method($_SERVER['REQUEST_METHOD'] ?? 'GET');
$u=current_user();
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $q=db()->prepare('SELECT message_permission,friend_permission FROM users WHERE id=? LIMIT 1');
    $q->execute([(int)$u['id']]); $r=$q->fetch() ?: [];
    ok(['privacy'=>['messagePermission'=>$r['message_permission'] ?? 'everyone','friendPermission'=>$r['friend_permission'] ?? 'everyone']]);
}
$in=request_json();
$message=(string)($in['messagePermission'] ?? '');
$friend=(string)($in['friendPermission'] ?? '');
if(!in_array($message,['everyone','friends','nobody'],true)) fail('INVALID_MESSAGE_PERMISSION',422);
if(!in_array($friend,['everyone','nobody'],true)) fail('INVALID_FRIEND_PERMISSION',422);
$db=db(); $q=$db->prepare('UPDATE users SET message_permission=?,friend_permission=?,updated_at=UTC_TIMESTAMP() WHERE id=?');
$q->execute([$message,$friend,(int)$u['id']]);
ok(['privacy'=>['messagePermission'=>$message,'friendPermission'=>$friend]]);
