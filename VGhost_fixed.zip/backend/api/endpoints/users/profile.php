<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php';
$u=current_user(); $id=isset($_GET['id'])?(int)$_GET['id']:(int)$u['id']; $stmt=db()->prepare('SELECT id,nickname,email,status,created_at,last_seen_at,is_vip,vip_expires_at FROM users WHERE id=? AND is_deleted=0 LIMIT 1'); $stmt->execute([$id]); $p=$stmt->fetch(); if(!$p) fail('USER_NOT_FOUND',404); $p['isVip']=(int)($p['is_vip']??0)===1 && (empty($p['vip_expires_at']) || strtotime((string)$p['vip_expires_at'])>time()); $p['vipExpiresAt']=$p['isVip']?($p['vip_expires_at']??null):null; unset($p['is_vip'],$p['vip_expires_at']); ok(['profile'=>$p]);
