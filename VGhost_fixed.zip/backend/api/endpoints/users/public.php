<?php
declare(strict_types=1); require_once __DIR__.'/../../core/App.php'; require_once __DIR__.'/../../core/Migrations.php'; require_method('GET'); require_once __DIR__.'/../../core/Level.php'; $me=null;
$token=bearer_token();
if($token){ try { $me=current_user(); } catch(Throwable $e){ $me=null; } } $u=find_user_by_nickname((string)($_GET['nickname']??'')); if(!$u) fail('NOT_FOUND',404); $id=(int)$u['id']; $isVip=(int)($u['is_vip']??0)===1 && (empty($u['vip_expires_at']) || strtotime((string)$u['vip_expires_at'])>time()); $p=db()->prepare('SELECT display_name,bio,avatar_url FROM user_profiles WHERE user_id=?'); $p->execute([$id]); $pr=$p->fetch()?:[]; $aq=db()->prepare('SELECT COALESCE(activity_xp,0) FROM users WHERE id=? LIMIT 1'); $aq->execute([$id]); $activityXp=(int)$aq->fetchColumn(); $activityLevel=activity_level($activityXp);
$st=db()->prepare('SELECT (is_online=1 AND last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE)) FROM user_status WHERE user_id=?');$st->execute([$id]);$online=(bool)$st->fetchColumn(); if(!empty($u['is_ghost'])) $online=false;
$friend='none'; $blockedByMe=false; $blockedMe=false;
if($me){ $fq=db()->prepare('SELECT status,requester_id FROM friendships WHERE user_one_id=? AND user_two_id=? LIMIT 1');$fq->execute([min((int)$me['id'],$id),max((int)$me['id'],$id)]);if($fr=$fq->fetch()){if($fr['status']==='accepted')$friend='friends';elseif($fr['status']==='pending')$friend=((int)$fr['requester_id']===(int)$me['id'])?'pending_sent':'pending_received';}
$bq=db()->prepare('SELECT EXISTS(SELECT 1 FROM blocks WHERE blocker_id=? AND blocked_id=?)');$bq->execute([$me['id'],$id]);$blockedByMe=(bool)$bq->fetchColumn();$bq->execute([$id,$me['id']]);$blockedMe=(bool)$bq->fetchColumn(); }
$giftIcons=['love'=>'❤️','rose'=>'🌹','diamond'=>'💎','crown'=>'👑','cake'=>'🎂','gift_box'=>'🎁','money_bag'=>'💰','butterfly'=>'🦋','fire'=>'🔥','rocket'=>'🚀','dragon'=>'🐉','trophy'=>'🏆','thunder'=>'⚡','ghost'=>'👻','galaxy'=>'🌌','ufo'=>'🛸','meteor'=>'☄️','castle'=>'🏰','volcano'=>'🌋','vghost_royal'=>'👻💎'];
$giftKeys=[1=>'love',2=>'rose',3=>'diamond',4=>'crown',5=>'cake',6=>'gift_box',7=>'money_bag',8=>'butterfly',9=>'fire',10=>'rocket',11=>'dragon',12=>'trophy',13=>'thunder',14=>'ghost',15=>'galaxy',16=>'ufo',17=>'meteor',18=>'castle',19=>'volcano',20=>'vghost_royal'];
$gifts=[]; $giftXp=0;
try {
    $cq=db()->prepare('SELECT g.id AS gift_id,g.name,g.coin_cost AS price,COUNT(*) AS count FROM gift_transactions gt JOIN gifts g ON g.id=gt.gift_id WHERE gt.receiver_id=? GROUP BY g.id,g.name,g.coin_cost ORDER BY g.id');
    $cq->execute([$id]);
    foreach($cq->fetchAll() as $gr){
        $gr['gift_id']=(string)$gr['gift_id'];
        $gr['giftId']=(string)$gr['gift_id'];
        $gr['giftKey']=$giftKeys[(int)$gr['gift_id']]??strtolower(trim((string)$gr['name']));
        $gr['icon']=$giftIcons[$gr['name']]??'🎁';
        $gr['price']=(int)$gr['price']; $gr['count']=(int)$gr['count'];
        $giftXp += $gr['price']*$gr['count'];
        $gifts[]=$gr;
    }
} catch(Throwable $e) { /* gift tables may not exist yet; profile remains usable */ }
$giftLevel=max(1,(int)floor($giftXp/100)+1);
ok(['user'=>['uid'=>(string)$id,'nickname'=>$u['nickname'],'status'=>$u['status'],'displayName'=>$pr['display_name']??null,'bio'=>$pr['bio']??null,'avatarUrl'=>$pr['avatar_url']??null,'online'=>$online,'ghostMode'=>(bool)($u['is_ghost']??false),'friendStatus'=>$friend,'blockedByMe'=>$blockedByMe,'blockedMe'=>$blockedMe,'activityXp'=>$activityXp,'activityLevel'=>$activityLevel,'giftXp'=>$giftXp,'giftLevel'=>$giftLevel,'nextGiftLevelXp'=>$giftLevel*100,'gifts'=>$gifts,'gender'=>$u['gender']??null,'avatarId'=>$u['avatar_id']??'male_01','vipFrameId'=>$u['vip_frame_id']??'vip_02','isVip'=>$isVip]]);
