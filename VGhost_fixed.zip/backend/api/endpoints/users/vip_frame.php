<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');

$u = current_user();
ensure_vip_frame_schema();
$pdo = db();
$uid = (int)$u['id'];

$check=$pdo->prepare('SELECT is_vip,vip_expires_at,vip_frame_id FROM users WHERE id=? AND is_deleted=0 LIMIT 1');
$check->execute([$uid]);
$row=$check->fetch(PDO::FETCH_ASSOC) ?: [];
$isVip=(int)($row['is_vip']??0)===1 && (empty($row['vip_expires_at']) || strtotime((string)$row['vip_expires_at'])>time());
if(!$isVip) fail('VIP_REQUIRED',403);

$b=body();
$frame=strtolower(trim((string)($b['vipFrameId'] ?? $b['frameId'] ?? '')));
$allowed=['vip_02'];
if(!in_array($frame,$allowed,true)) fail('INVALID_VIP_FRAME',422);

try {
    $pdo->prepare('UPDATE users SET vip_frame_id=?,updated_at=UTC_TIMESTAMP() WHERE id=? AND is_deleted=0')->execute([$frame,$uid]);
    $verify=$pdo->prepare('SELECT vip_frame_id FROM users WHERE id=? AND is_deleted=0 LIMIT 1');
    $verify->execute([$uid]);
    $saved=(string)$verify->fetchColumn();
    if($saved!==$frame) fail('VIP_FRAME_SAVE_FAILED',500);
    ok(['vipFrameId'=>$saved]);
} catch(Throwable $e) {
    error_log('users/vip-frame update failed: '.$e->getMessage());
    fail('VIP_FRAME_SAVE_FAILED',500);
}
