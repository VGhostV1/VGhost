<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$me=current_user();
// Presence is refreshed by the Android heartbeat. A LEFT JOIN fallback also supports
// accounts whose status row was not created yet.
$sql="SELECT u.id,u.nickname,u.avatar_id AS avatarId,u.vip_frame_id AS vipFrameId,CASE WHEN COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()) THEN 1 ELSE 0 END AS isVip FROM users u LEFT JOIN user_status us ON us.user_id=u.id
 WHERE u.is_deleted=0 AND u.is_banned=0 AND u.id<>? AND u.is_ghost=0
 AND (us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE))
 ORDER BY u.nickname LIMIT 500";
$s=db()->prepare($sql); $s->execute([$me['id']]);
ok(['users'=>array_map(fn($u)=>['uid'=>(string)$u['id'],'nickname'=>$u['nickname'],'online'=>true,'avatarId'=>(string)($u['avatarId']??'male_01'),'vipFrameId'=>(string)($u['vipFrameId']??'vip_02'),'isVip'=>(bool)($u['isVip']??0)],$s->fetchAll())]);
