<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
ensure_avatar_schema();
$id=(int)($_GET['id']??0);
if($id<1){http_response_code(404);exit;}
$pdo=db();
$q=$pdo->prepare('SELECT avatar_url FROM user_profiles WHERE user_id=? LIMIT 1');$q->execute([$id]);
$url=(string)($q->fetchColumn()?:'');
if($url==='' || !str_contains($url,'avatar_media')){http_response_code(404);exit;}
// Store paths in a sidecar file keyed by user id to avoid exposing filesystem paths in DB.
$root=dirname(__DIR__,3).'/storage/profile_avatars';
$index=$root.'/'.(string)$id.'.json';
if(!is_file($index)){http_response_code(404);exit;}
$data=json_decode((string)file_get_contents($index),true);
$file=isset($data['file']) ? realpath($root.'/'.basename((string)$data['file'])) : false;
if(!$file || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file)){http_response_code(404);exit;}
header('Content-Type: image/jpeg'); header('Cache-Control: public, max-age=86400'); header('X-Content-Type-Options: nosniff'); header('Content-Length: '.filesize($file)); readfile($file);
