<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_method('POST');

$u = current_user();
ensure_avatar_schema();
$pdo = db();
$uid = (int)$u['id'];

// Preset avatar selection only. Personal/gallery photos and legacy Ghost IDs are disabled.

$b = body();
$avatar = strtolower(trim((string)($b['avatarId'] ?? $b['avatar_id'] ?? '')));
$allowed = [];
for ($i=1; $i<=6; $i++) {
    $allowed[]='male_'.str_pad((string)$i,2,'0',STR_PAD_LEFT);
    $allowed[]='female_'.str_pad((string)$i,2,'0',STR_PAD_LEFT);
}
if (!in_array($avatar, $allowed, true)) fail('INVALID_AVATAR',422);

$gender = str_starts_with($avatar,'female_') ? 'female' : (str_starts_with($avatar,'male_') ? 'male' : null);
try {
    $pdo->prepare('UPDATE users SET avatar_id=?, gender=?, updated_at=UTC_TIMESTAMP() WHERE id=? AND is_deleted=0')->execute([$avatar,$gender,$uid]);
    $pdo->prepare('INSERT INTO user_profiles(user_id,avatar_url,updated_at) VALUES(?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE avatar_url=NULL,updated_at=UTC_TIMESTAMP()')->execute([$uid,null]);
    $check = $pdo->prepare('SELECT avatar_id FROM users WHERE id=? AND is_deleted=0 LIMIT 1'); $check->execute([$uid]);
    if (strtolower((string)$check->fetchColumn()) !== $avatar) fail('AVATAR_SAVE_FAILED',500);
} catch (Throwable $e) {
    error_log('users/avatar update failed: '.$e->getMessage());
    fail('AVATAR_SAVE_FAILED',500);
}
ok(['avatarId'=>$avatar,'gender'=>$gender,'avatarUrl'=>null]);
