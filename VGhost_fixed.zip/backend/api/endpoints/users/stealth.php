<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user(); $b=body(); $enabled=(bool)($b['enabled']??false); $pdo=db();
$pdo->prepare('UPDATE users SET is_ghost=?, updated_at=UTC_TIMESTAMP(), last_seen_at=UTC_TIMESTAMP() WHERE id=?')->execute([$enabled?1:0,$u['id']]);
if($enabled){$pdo->prepare('INSERT INTO user_status(user_id,is_online,last_seen_at) VALUES(?,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE is_online=0,last_seen_at=UTC_TIMESTAMP()')->execute([$u['id']]);}
else {$pdo->prepare('INSERT INTO user_status(user_id,is_online,last_seen_at) VALUES(?,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE is_online=is_online,last_seen_at=last_seen_at')->execute([$u['id']]);}
ok(['ghostMode'=>$enabled]);
