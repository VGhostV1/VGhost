<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user(); $b=body();
$id=(int)($b['user_id']??0); $reason=trim((string)($b['reason']??''));
if($id<1 || $id===(int)$u['id']) fail('INVALID_USER_ID',422);
if($reason==='') $reason='Inappropriate content';
$reason=mb_substr($reason,0,255);
$pdo=db();
$q=$pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 LIMIT 1'); $q->execute([$id]); if(!$q->fetch()) fail('USER_NOT_FOUND',404);
$q=$pdo->prepare("SELECT id FROM content_reports WHERE reporter_id=? AND target_type='user' AND target_id=? AND status='pending' LIMIT 1");
$q->execute([(int)$u['id'],$id]); if($q->fetch()) ok(['reported'=>true,'duplicate'=>true]);
try {
  $q=$pdo->prepare("INSERT INTO content_reports(reporter_id,target_type,target_id,reason,status,created_at) VALUES(?,'user',?,?, 'pending',UTC_TIMESTAMP())");
  $q->execute([(int)$u['id'],$id,$reason]);
  ok(['reported'=>true,'report_id'=>(int)$pdo->lastInsertId()]);
} catch(Throwable $e) { fail('REPORT_SAVE_FAILED',500); }
