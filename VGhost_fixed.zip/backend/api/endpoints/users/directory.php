<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_method('GET');
ensure_activity_level_schema();
$me = null;
$token = bearer_token();
if($token){ try { $me=current_user(); } catch(Throwable $e){ $me=null; } }
$category = strtolower(trim((string)($_GET['category'] ?? 'all')));
if (!in_array($category, ['all','online','vip','friends'], true)) $category = 'all';
$q = trim(ltrim((string)($_GET['q'] ?? ''), '@'));
$q = substr($q, 0, 64);
$limit = min(80, max(1, (int)($_GET['limit'] ?? 60)));
$where = ['u.is_deleted=0','u.is_banned=0'];
$args = [];
if($me){ $where[]='u.id<>?'; $args[]=(int)$me['id']; }
if ($category === 'friends') {
    if(!$me) fail('UNAUTHORIZED',401);
    $where[] = "EXISTS (SELECT 1 FROM friendships fx WHERE fx.status='accepted' AND ((fx.user_one_id=? AND fx.user_two_id=u.id) OR (fx.user_two_id=? AND fx.user_one_id=u.id)))";
    $args[]=(int)$me['id']; $args[]=(int)$me['id'];
}
if ($category === 'online') $where[] = "u.is_ghost=0 AND us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE)";
if ($category === 'vip') $where[] = "COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP())";
if ($q !== '') { $where[] = "(LOWER(u.nickname) LIKE LOWER(?) OR CAST(u.id AS CHAR)=?)"; $args[]='%'.$q.'%'; $args[]=$q; }
$sql="SELECT u.id,u.nickname,u.avatar_id AS avatarId,u.vip_frame_id AS vipFrameId,up.avatar_url AS avatarUrl,COALESCE(u.activity_xp,0) AS activityXp,
CASE WHEN COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()) THEN 1 ELSE 0 END AS isVip,
CASE WHEN u.is_ghost=1 THEN 0 WHEN us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) THEN 1 ELSE 0 END AS online
FROM users u LEFT JOIN user_status us ON us.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id
WHERE ".implode(' AND ',$where)." ORDER BY online DESC,isVip DESC,activityXp DESC,u.nickname ASC LIMIT ".$limit;
$stmt=db()->prepare($sql); $stmt->execute($args);
$users=array_map(static fn(array $u):array=>[
 'uid'=>(string)$u['id'],'nickname'=>(string)$u['nickname'],'online'=>(bool)$u['online'],
 'avatarId'=>(string)($u['avatarId']??'male_01'),'vipFrameId'=>(string)($u['vipFrameId']??'vip_02'),
 'avatarUrl'=>$u['avatarUrl']??null,'level'=>max(1,(int)floor(((int)($u['activityXp']??0))/100)+1),'isVip'=>(bool)$u['isVip']
],$stmt->fetchAll());
ok([$category==='friends'?'friends':'users'=>$users]);
