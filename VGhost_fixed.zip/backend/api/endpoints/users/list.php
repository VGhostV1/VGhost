<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_method('GET');
ensure_activity_level_schema();
$me=current_user();
$sql="SELECT u.id,u.nickname,u.avatar_id AS avatarId,u.vip_frame_id AS vipFrameId,up.avatar_url AS avatarUrl,COALESCE(u.activity_xp,0) AS activityXp,CASE WHEN COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()) THEN 1 ELSE 0 END AS isVip,CASE WHEN u.is_ghost=1 THEN 0 WHEN us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) THEN 1 ELSE 0 END AS online FROM users u LEFT JOIN user_status us ON us.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id WHERE u.is_deleted=0 AND u.is_banned=0 AND u.id<>? ORDER BY u.nickname ASC LIMIT 500";
$s=db()->prepare($sql); $s->execute([$me['id']]);
ok(['users'=>array_map(fn($u)=>['uid'=>(string)$u['id'],'nickname'=>$u['nickname'],'online'=>(bool)$u['online'],'avatarId'=>(string)($u['avatarId']??'male_01'),'vipFrameId'=>(string)($u['vipFrameId']??'vip_02'),'avatarUrl'=>$u['avatarUrl']??null,'level'=>max(1,(int)floor(((int)($u['activityXp']??0))/100)+1),'isVip'=>(bool)($u['isVip']??0)],$s->fetchAll())]);
