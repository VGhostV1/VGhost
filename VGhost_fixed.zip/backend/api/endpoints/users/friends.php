<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$me=current_user(); $page=max(1,(int)($_GET['page']??1)); $limit=min(50,max(1,(int)($_GET['limit']??20))); $offset=($page-1)*$limit;
$base="FROM friendships f JOIN users u ON u.id=IF(f.user_one_id=?,f.user_two_id,f.user_one_id) WHERE (f.user_one_id=? OR f.user_two_id=?) AND f.status='accepted' AND u.is_deleted=0 AND u.is_banned=0"; $params=[(int)$me['id'],(int)$me['id'],(int)$me['id']];
$c=db()->prepare("SELECT COUNT(*) $base"); $c->execute($params); $total=(int)$c->fetchColumn();
$s=db()->prepare("SELECT u.id,u.nickname,u.avatar_id AS avatarId,u.vip_frame_id AS vipFrameId,CASE WHEN COALESCE(u.is_ghost,0)=1 THEN 0 WHEN u.last_seen_at IS NOT NULL AND u.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) THEN 1 ELSE 0 END AS online,CASE WHEN COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()) THEN 1 ELSE 0 END AS isVip $base ORDER BY online DESC,u.nickname ASC,u.id ASC LIMIT $limit OFFSET $offset"); $s->execute($params);
$users=array_map(fn($u)=>['uid'=>(string)$u['id'],'id'=>(string)$u['id'],'nickname'=>(string)$u['nickname'],'online'=>(bool)$u['online'],'avatarId'=>(string)($u['avatarId']??'male_01'),'avatarUrl'=>null,'vipFrameId'=>(string)($u['vipFrameId']??'vip_02'),'level'=>1,'isVip'=>(bool)$u['isVip']],$s->fetchAll());
ok(['section'=>'friends','page'=>$page,'limit'=>$limit,'total'=>$total,'hasMore'=>($offset+count($users))<$total,'users'=>$users]);
