<?php
declare(strict_types=1);

require_once __DIR__.'/../../core/App.php';
require_method('GET');
ensure_activity_level_schema();

$current = current_user();

$q = trim((string)($_GET['q'] ?? ''));
$q = trim(ltrim($q, '@'));
if ($q === '') {
    ok(['users' => []]);
}
$q = substr($q, 0, 64);

$like = '%' . $q . '%';
$prefix = $q . '%';

$sql = "SELECT
            u.id,
            u.nickname,
            u.avatar_id AS avatarId,
            u.vip_frame_id AS vipFrameId,
            up.avatar_url AS avatarUrl,
            COALESCE(u.activity_xp, 0) AS activityXp,
            CASE
                WHEN COALESCE(u.is_vip, 0) = 1
                 AND (u.vip_expires_at IS NULL OR u.vip_expires_at > UTC_TIMESTAMP())
                THEN 1 ELSE 0
            END AS isVip,
            CASE
                WHEN u.is_ghost = 1 THEN 0
                WHEN us.is_online = 1
                 AND us.last_seen_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 MINUTE)
                THEN 1 ELSE 0
            END AS online
        FROM users u
        LEFT JOIN user_profiles up ON up.user_id = u.id
        LEFT JOIN user_status us ON us.user_id = u.id
        WHERE u.is_deleted = 0
          AND u.is_banned = 0
          AND u.id <> ?
          AND (
              LOWER(u.nickname) LIKE LOWER(?)
              OR CAST(u.id AS CHAR) = ?
          )
        ORDER BY
            CASE
                WHEN CAST(u.id AS CHAR) = ? THEN 0
                WHEN LOWER(u.nickname) = LOWER(?) THEN 1
                WHEN LOWER(u.nickname) LIKE LOWER(?) THEN 2
                ELSE 3
            END ASC,
            online DESC,
            activityXp DESC,
            u.nickname ASC
        LIMIT 50";

$stmt = db()->prepare($sql);
$stmt->execute([
    (int)$current['id'],
    $like,
    $q,
    $q,
    $q,
    $prefix
]);

$users = array_map(
    static fn(array $u): array => [
        'id' => (string)$u['id'],
        'uid' => (string)$u['id'],
        'nickname' => (string)$u['nickname'],
        'online' => (bool)$u['online'],
        'avatarId' => (string)($u['avatarId'] ?? 'male_01'),
        'vipFrameId' => (string)($u['vipFrameId'] ?? 'vip_02'),
        'avatarUrl' => $u['avatarUrl'] ?? null,
        'level' => max(1, (int)floor(((int)($u['activityXp'] ?? 0)) / 100) + 1),
        'isVip' => (bool)$u['isVip']
    ],
    $stmt->fetchAll()
);

ok(['users' => $users]);
