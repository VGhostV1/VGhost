<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$u=current_user();
$b=body();
$online=($b['online'] ?? false) === true || ($b['online'] ?? null) === 1 || ($b['online'] ?? null) === '1';
$pdo=db();
// Keep lightweight activity sessions for the admin daily-activity report.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_sessions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,started_at DATETIME NOT NULL,last_seen_at DATETIME NOT NULL,ended_at DATETIME NULL,INDEX idx_activity_user_time(user_id,started_at),INDEX idx_activity_active(user_id,ended_at),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    if ($online) {
        $q=$pdo->prepare("SELECT id FROM activity_sessions WHERE user_id=? AND ended_at IS NULL AND last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 10 MINUTE) ORDER BY id DESC LIMIT 1");
        $q->execute([(int)$u['id']]);
        $sid=$q->fetchColumn();
        if ($sid) $pdo->prepare('UPDATE activity_sessions SET last_seen_at=UTC_TIMESTAMP() WHERE id=?')->execute([(int)$sid]);
        else $pdo->prepare('INSERT INTO activity_sessions(user_id,started_at,last_seen_at) VALUES(?,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([(int)$u['id']]);
    } else {
        $pdo->prepare('UPDATE activity_sessions SET ended_at=last_seen_at WHERE user_id=? AND ended_at IS NULL')->execute([(int)$u['id']]);
    }
} catch (Throwable $ignored) {}
$pdo->prepare("INSERT INTO user_status(user_id,is_online,last_seen_at) VALUES(?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE is_online=VALUES(is_online),last_seen_at=UTC_TIMESTAMP()")
    ->execute([$u['id'],$online?1:0]);
$pdo->prepare("UPDATE users SET status=?,last_seen_at=UTC_TIMESTAMP(),updated_at=UTC_TIMESTAMP() WHERE id=?")
    ->execute([$online?'active':'offline',$u['id']]);
ok(['online'=>$online,'serverTime'=>gmdate('c')]);
