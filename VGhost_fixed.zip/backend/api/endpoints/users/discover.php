<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Migrations.php';
require_method('GET');
ensure_activity_level_schema();
$me=current_user();
$section=strtolower(trim((string)($_GET['section'] ?? 'vip')));
if(!in_array($section,['vip','users','friends'],true)) fail('INVALID_SECTION',400);
$page=max(1,(int)($_GET['page'] ?? 1));
$limit=min(50,max(1,(int)($_GET['limit'] ?? 20)));
$q=trim(ltrim((string)($_GET['q'] ?? ''),'@'));
$q=substr($q,0,64);
$offset=($page-1)*$limit;
$where=['u.is_deleted=0','u.is_banned=0','u.id<>?'];
$params=[(int)$me['id']];
if($section==='friends'){
  $where[]="EXISTS (SELECT 1 FROM friendships f WHERE f.status='accepted' AND ((f.user_one_id=? AND f.user_two_id=u.id) OR (f.user_two_id=? AND f.user_one_id=u.id)))";
  $params[]=(int)$me['id']; $params[]=(int)$me['id'];
}
if($section==='vip') $where[]="COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP())";
if($section==='users') $where[]="NOT (COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()))";
if($q!==''){
  $where[]='(LOWER(u.nickname) LIKE LOWER(?) OR CAST(u.id AS CHAR)=?)';
  $params[]='%'.$q.'%'; $params[]=$q;
}
$whereSql=implode(' AND ',$where);
$c=db()->prepare("SELECT COUNT(*) FROM users u WHERE $whereSql");
$c->execute($params); $total=(int)$c->fetchColumn();
$sql="SELECT u.id,u.nickname,u.avatar_id AS avatarId,u.vip_frame_id AS vipFrameId,
 COALESCE(up.avatar_url,NULL) AS avatarUrl,COALESCE(u.activity_xp,0) AS activityXp,
 CASE WHEN COALESCE(u.is_vip,0)=1 AND (u.vip_expires_at IS NULL OR u.vip_expires_at>UTC_TIMESTAMP()) THEN 1 ELSE 0 END AS isVip,
 CASE WHEN u.is_ghost=1 THEN 0 WHEN us.is_online=1 AND us.last_seen_at>=DATE_SUB(UTC_TIMESTAMP(),INTERVAL 2 MINUTE) THEN 1 ELSE 0 END AS online
 FROM users u LEFT JOIN user_status us ON us.user_id=u.id LEFT JOIN user_profiles up ON up.user_id=u.id
 WHERE $whereSql
 ORDER BY online DESC,activityXp DESC,u.nickname ASC,u.id ASC LIMIT $limit OFFSET $offset";
$stmt=db()->prepare($sql); $stmt->execute($params);
$users=array_map(fn($u)=>[
 'uid'=>(string)$u['id'],'id'=>(string)$u['id'],'nickname'=>(string)$u['nickname'],
 'online'=>(bool)$u['online'],'avatarId'=>(string)($u['avatarId']??'male_01'),
 'vipFrameId'=>(string)($u['vipFrameId']??'vip_02'),'avatarUrl'=>$u['avatarUrl']??null,
 'level'=>max(1,(int)floor(((int)($u['activityXp']??0))/100)+1),'isVip'=>(bool)$u['isVip']
],$stmt->fetchAll());
ok(['section'=>$section,'page'=>$page,'limit'=>$limit,'total'=>$total,'hasMore'=>($offset+count($users))<$total,'users'=>$users]);
