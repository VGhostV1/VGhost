<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Story.php';

require_method('POST');
$u=current_user();
$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($_POST['upload_id']??$_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??''));
$visibility=strtolower(trim((string)($_POST['visibility']??'all')));
$caption=trim((string)($_POST['caption']??''));
$mimeHint=trim((string)($_POST['mime_type']??$_SERVER['HTTP_X_VGHOST_MIME_TYPE']??''));
$filmId=(int)($_POST['film_id']??$_POST['filmId']??$_SERVER['HTTP_X_VGHOST_FILM_ID']??0);
$isTrailer=$filmId>0;
if($uploadId==='' || strlen($uploadId)>80) fail('INVALID_UPLOAD',422);
if($isTrailer){
    $admin=require_super_admin();
    $fq=db()->prepare('SELECT id FROM films WHERE id=? AND is_active=1 LIMIT 1'); $fq->execute([$filmId]);
    if(!$fq->fetchColumn()) fail('FILM_NOT_FOUND',404);
}
if(!in_array($visibility,['all','friends'],true)) $visibility='all';
if($isTrailer) $visibility='all'; // Trailers are always public.
if(mb_strlen($caption)>500) $caption=mb_substr($caption,0,500);

$root=realpath(dirname(__DIR__,3)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$dir=$root.'/storage/stories/.chunks/'.$uploadId;
$metaFile=$dir.'/meta.json';
$meta=is_file($metaFile)?json_decode((string)@file_get_contents($metaFile),true):null;
if(!is_array($meta) || (int)($meta['user_id']??0)!==(int)$u['id']) fail('UPLOAD_NOT_FOUND',404);
$total=(int)($meta['total_chunks']??0); $expectedSize=(int)($meta['total_size']??0);
if($total<1 || $expectedSize<1 || $expectedSize>100*1024*1024) fail('INVALID_UPLOAD',422);
if($isTrailer && $mimeHint!=='' && !str_starts_with(strtolower($mimeHint),'video/')) fail('TRAILER_VIDEO_REQUIRED',422);

$tmp=$dir.'/assembled.part';
$out=@fopen($tmp,'wb'); if(!$out) fail('STORAGE_UNWRITABLE',500);
$sum=0;
for($i=0;$i<$total;$i++){
    $part=$dir.'/'.sprintf('%06d.part',$i);
    if(!is_file($part)){ fclose($out); @unlink($tmp); fail('UPLOAD_INCOMPLETE',422,['chunkIndex'=>$i]); }
    $in=@fopen($part,'rb'); if(!$in){ fclose($out); @unlink($tmp); fail('MEDIA_READ_FAILED',500); }
    while(!feof($in)){
        $buf=fread($in,1024*1024); if($buf===false){fclose($in);fclose($out);@unlink($tmp);fail('MEDIA_READ_FAILED',500);}
        if($buf==='') break;
        $sum+=strlen($buf); if($sum>100*1024*1024){fclose($in);fclose($out);@unlink($tmp);fail('INVALID_MEDIA_SIZE',422);}
        fwrite($out,$buf);
    }
    fclose($in);
}
fclose($out);
if($sum!==$expectedSize){ @unlink($tmp); fail('INVALID_MEDIA_SIZE',422,['receivedSize'=>$sum,'expectedSize'=>$expectedSize]); }

$mime=upload_mime_type($tmp, (string)($meta['file_name']??''));
if($mime==='' && $mimeHint!=='') $mime=strtolower($mimeHint);
$allowed=[
 'video/mp4'=>'mp4','video/hevc'=>'mp4','video/h265'=>'mp4','video/x-h265'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov','video/3gpp'=>'3gp','video/3gpp2'=>'3g2','video/mpeg'=>'mpeg','video/x-m4v'=>'m4v','video/x-matroska'=>'mkv','video/ogg'=>'ogv','video/hevc'=>'mp4','video/h265'=>'mp4','video/x-h265'=>'mp4',
 'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'
];
if(!isset($allowed[$mime])){ @unlink($tmp); fail('UNSUPPORTED_MEDIA_TYPE',422,['mime'=>$mime]); }
$dirFinal=$root.'/storage/stories';
if(!is_dir($dirFinal) && !mkdir($dirFinal,0750,true)) { @unlink($tmp); fail('STORAGE_UNAVAILABLE',500); }
if(!is_writable($dirFinal)) { @chmod($dirFinal,0750); }
if(!is_writable($dirFinal)){ @unlink($tmp); fail('STORAGE_UNWRITABLE',500); }
$name=bin2hex(random_bytes(24)).'.'.$allowed[$mime]; $dest=$dirFinal.'/'.$name;
if(!rename($tmp,$dest)){ @unlink($tmp); fail('MEDIA_STORE_FAILED',500); }
$pdo=db();
try{
    ensure_story_schema();
    $expires=$isTrailer ? '2099-12-31 23:59:59' : gmdate('Y-m-d H:i:s',time()+7*24*3600);
    $pdo->prepare('INSERT INTO stories(user_id,media_path,media_type,created_at,expires_at,visibility,caption,film_id,is_trailer) VALUES(?,?,?,?,?,?,?,?,?)')->execute([(int)$u['id'],'storage/stories/'.$name,$mime,gmdate('Y-m-d H:i:s'),$expires,$visibility,$caption,$isTrailer?$filmId:null,$isTrailer?1:0]);
    $id=(int)$pdo->lastInsertId();
}catch(Throwable $e){ @unlink($dest); throw $e; }
$files=@scandir($dir)?:[]; foreach($files as $f){ if($f!=='.'&&$f!=='..') @unlink($dir.'/'.$f); } @rmdir($dir);
ok(['story'=>['id'=>$id,'mediaUrl'=>'api/stories/media?id='.$id,'mediaType'=>$mime,'visibility'=>$visibility,'caption'=>$caption,'expiresAt'=>$expires,'filmId'=>$isTrailer?$filmId:0]]);
