<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Story.php';

require_method('POST');
$u=current_user();
$uploadId=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($_SERVER['HTTP_X_VGHOST_UPLOAD_ID']??''));
$index=(int)($_SERVER['HTTP_X_VGHOST_CHUNK_INDEX']??-1);
$total=(int)($_SERVER['HTTP_X_VGHOST_TOTAL_CHUNKS']??0);
$totalSize=(int)($_SERVER['HTTP_X_VGHOST_TOTAL_SIZE']??0);
if($uploadId==='' || strlen($uploadId)>80 || $index<0 || $total<1 || $index>=$total || $totalSize<1 || $totalSize>100*1024*1024) fail('INVALID_UPLOAD',422);

$root=realpath(dirname(__DIR__,3)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$base=$root.'/storage/stories/.chunks';
if(!is_dir($base) && !mkdir($base,0750,true)) fail('STORAGE_UNAVAILABLE',500);
// Remove abandoned partial uploads older than 24 hours.
foreach(@scandir($base) ?: [] as $d){
    if($d==='.'||$d==='..') continue;
    $dir=$base.'/'.$d;
    if(is_dir($dir) && @filemtime($dir)!==false && filemtime($dir)<time()-86400){
        $files=@scandir($dir) ?: [];
        foreach($files as $f){ if($f!=='.'&&$f!=='..') @unlink($dir.'/'.$f); }
        @rmdir($dir);
    }
}
$dir=$base.'/'.$uploadId;
if(!is_dir($dir) && !mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
$metaFile=$dir.'/meta.json';
$meta=null;
if(is_file($metaFile)) $meta=json_decode((string)@file_get_contents($metaFile),true);
if(!is_array($meta)){
    $meta=['user_id'=>(int)$u['id'],'total_chunks'=>$total,'total_size'=>$totalSize,'created_at'=>time()];
    file_put_contents($metaFile,json_encode($meta,JSON_UNESCAPED_SLASHES),LOCK_EX);
} else if((int)($meta['user_id']??0)!==(int)$u['id'] || (int)($meta['total_chunks']??0)!==$total || (int)($meta['total_size']??0)!==$totalSize){
    fail('UPLOAD_MISMATCH',409);
}

$body=file_get_contents('php://input');
if($body===false || $body==='') fail('EMPTY_CHUNK',422);
if(strlen($body)>5*1024*1024) fail('CHUNK_TOO_LARGE',413);
$part=$dir.'/'.sprintf('%06d.part',$index);
if(file_put_contents($part,$body,LOCK_EX)===false) fail('MEDIA_STORE_FAILED',500);
ok(['uploadId'=>$uploadId,'chunkIndex'=>$index,'receivedBytes'=>filesize($part)]);
