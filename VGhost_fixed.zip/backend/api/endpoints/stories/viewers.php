<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Story.php';
require_method('GET'); $u=current_user(); ensure_story_schema(); $id=(int)($_GET['story_id']??0); if($id<1) fail('INVALID_STORY',422); $pdo=db();
$q=$pdo->prepare('SELECT user_id FROM stories WHERE id=? AND expires_at>UTC_TIMESTAMP() LIMIT 1'); $q->execute([$id]); $owner=$q->fetchColumn(); if($owner===false) fail('STORY_NOT_FOUND',404); if((int)$owner!==(int)$u['id']) fail('FORBIDDEN',403);
$s=$pdo->prepare('SELECT v.user_id,v.viewed_at,u.nickname FROM story_views v JOIN users u ON u.id=v.user_id WHERE v.story_id=? AND u.is_deleted=0 AND u.is_banned=0 ORDER BY v.viewed_at DESC LIMIT 500'); $s->execute([$id]);
$rows=[]; foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[]=['userId'=>(int)$r['user_id'],'nickname'=>(string)$r['nickname'],'viewedAt'=>(string)$r['viewed_at']]; ok(['viewers'=>$rows]);
