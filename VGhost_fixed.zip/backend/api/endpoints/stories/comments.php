<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Story.php';
require_method('GET'); $u=current_user(); ensure_story_schema(); $id=(int)($_GET['story_id']??0); if($id<1) fail('INVALID_STORY',422); $pdo=db();
$q=$pdo->prepare('SELECT id FROM stories WHERE id=? AND expires_at>UTC_TIMESTAMP() LIMIT 1'); $q->execute([$id]); $owner=$q->fetchColumn(); if($owner===false) fail('STORY_NOT_FOUND',404);
$bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1'); $bq->execute([$u['id'],$owner,$owner,$u['id']]); if($bq->fetchColumn()) fail('USER_BLOCKED',403);
$s=$pdo->prepare('SELECT c.id,c.user_id,c.comment,c.parent_comment_id,c.created_at,u.nickname FROM story_comments c JOIN users u ON u.id=c.user_id WHERE c.story_id=? AND u.is_deleted=0 AND u.is_banned=0 ORDER BY c.created_at ASC LIMIT 200'); $s->execute([$id]);
$rows=[]; foreach($s->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[]=['id'=>(int)$r['id'],'userId'=>(int)$r['user_id'],'nickname'=>(string)$r['nickname'],'comment'=>(string)$r['comment'],'parentCommentId'=>isset($r['parent_comment_id'])?(int)$r['parent_comment_id']:null,'createdAt'=>(string)$r['created_at']]; ok(['comments'=>$rows]);
