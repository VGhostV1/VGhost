<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Story.php';
require_method('POST'); $u=current_user(); ensure_story_schema();
$filmId=(int)($_POST['film_id']??$_POST['filmId']??$_SERVER['HTTP_X_VGHOST_FILM_ID']??0);
$isTrailer=$filmId>0;
if($isTrailer){ require_super_admin(); $fq=db()->prepare('SELECT id FROM films WHERE id=? AND is_active=1 LIMIT 1'); $fq->execute([$filmId]); if(!$fq->fetchColumn()) fail('FILM_NOT_FOUND',404); }
if(empty($_FILES['media']) || $_FILES['media']['error']!==UPLOAD_ERR_OK) fail('MEDIA_UPLOAD_FAILED',422);
$f=$_FILES['media']; if(!is_uploaded_file($f['tmp_name']) || $f['size']<=0 || $f['size']>100*1024*1024) fail('INVALID_MEDIA_SIZE',422);
$mime=upload_mime_type($f['tmp_name'], (string)($f['name']??''));
$allowed=[
 'video/mp4'=>'mp4','video/hevc'=>'mp4','video/h265'=>'mp4','video/x-h265'=>'mp4',
 'video/webm'=>'webm',
 'video/quicktime'=>'mov',
 'video/3gpp'=>'3gp',
 'video/3gpp2'=>'3g2',
 'video/mpeg'=>'mpeg',
 'video/x-m4v'=>'m4v',
 'video/x-matroska'=>'mkv',
 'video/ogg'=>'ogv',
 'image/jpeg'=>'jpg',
 'image/png'=>'png',
 'image/webp'=>'webp'
];
if(!isset($allowed[$mime])) fail('UNSUPPORTED_MEDIA_TYPE',422);
$visibility=strtolower(trim((string)($_POST['visibility']??'all'))); if(!in_array($visibility,['all','friends'],true)) $visibility='all';
if($isTrailer) $visibility='all'; // Trailers are always public.
$caption=trim((string)($_POST['caption']??'')); if(mb_strlen($caption)>500) $caption=mb_substr($caption,0,500);
$root=realpath(dirname(__DIR__,3)); if($root===false) fail('STORAGE_UNAVAILABLE',500);
$dir=$root.'/storage/stories';
if(!is_dir($dir) && !mkdir($dir,0750,true)) fail('STORAGE_UNAVAILABLE',500);
if(!is_writable($dir)) { @chmod($dir,0750); }
if(!is_writable($dir)) fail('STORAGE_UNWRITABLE',500);
$name=bin2hex(random_bytes(24)).'.'.$allowed[$mime]; $dest=$dir.'/'.$name; if(!move_uploaded_file($f['tmp_name'],$dest)) fail('MEDIA_STORE_FAILED',500);
$pdo=db(); try {
 $expires=$isTrailer ? '2099-12-31 23:59:59' : gmdate('Y-m-d H:i:s',time()+7*24*3600);
 $pdo->prepare('INSERT INTO stories(user_id,media_path,media_type,created_at,expires_at,visibility,caption,film_id,is_trailer) VALUES(?,?,?,?,?,?,?,?,?)')->execute([(int)$u['id'],'storage/stories/'.$name,$mime,gmdate('Y-m-d H:i:s'),$expires,$visibility,$caption,$isTrailer?$filmId:null,$isTrailer?1:0]);
 $id=(int)$pdo->lastInsertId();
} catch(Throwable $e){@unlink($dest); throw $e;}
ok(['story'=>['id'=>$id,'mediaUrl'=>'api/stories/media?id='.$id,'mediaType'=>$mime,'visibility'=>$visibility,'caption'=>$caption,'expiresAt'=>$expires,'filmId'=>$isTrailer?$filmId:0,'isTrailer'=>$isTrailer]]);
