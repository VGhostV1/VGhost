<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Story.php';
require_method('POST'); $u=current_user(); ensure_story_schema(); $b=body(); $id=(int)($b['comment_id']??0); if($id<1) fail('INVALID_COMMENT',422); $pdo=db();
$q=$pdo->prepare('SELECT c.user_id,c.story_id,s.user_id AS owner_id FROM story_comments c JOIN stories s ON s.id=c.story_id WHERE c.id=? LIMIT 1'); $q->execute([$id]); $r=$q->fetch(PDO::FETCH_ASSOC); if(!$r) fail('COMMENT_NOT_FOUND',404);
if((int)$r['user_id']!==(int)$u['id'] && (int)$r['owner_id']!==(int)$u['id']) fail('FORBIDDEN',403);
$pdo->prepare('DELETE FROM story_comments WHERE id=?')->execute([$id]); ok(['deleted'=>true,'commentId'=>$id]);
