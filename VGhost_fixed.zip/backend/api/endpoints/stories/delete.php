<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Story.php';

require_method('POST');
$u=current_user();
ensure_story_schema();
$b=body();
$id=(int)($b['story_id'] ?? 0);
if($id<1) fail('INVALID_STORY',422);

$pdo=db();
$q=$pdo->prepare('SELECT user_id, media_path FROM stories WHERE id=? LIMIT 1');
$q->execute([$id]);
$story=$q->fetch(PDO::FETCH_ASSOC);
if(!$story) fail('STORY_NOT_FOUND',404);
if((int)$story['user_id'] !== (int)$u['id']) fail('FORBIDDEN',403);

$pdo->beginTransaction();
try {
    foreach (['story_views','story_likes','story_comments'] as $tbl) {
        $pdo->prepare("DELETE FROM {$tbl} WHERE story_id=?")->execute([$id]);
    }
    $pdo->prepare('DELETE FROM stories WHERE id=? AND user_id=?')->execute([$id,(int)$u['id']]);
    $pdo->commit();
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}

$root=realpath(dirname(__DIR__,3).'/storage');
if($root) {
    $file=realpath($root.'/'.ltrim((string)$story['media_path'],'/'));
    if($file && str_starts_with($file,$root.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
}

ok(['deleted'=>true,'storyId'=>$id]);
