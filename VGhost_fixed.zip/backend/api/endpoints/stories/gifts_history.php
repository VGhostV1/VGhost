<?php
declare(strict_types=1);

require_once __DIR__.'/../../core/Auth.php';

require_method('GET');
$u = current_user();
$pdo = db();

$limit = max(1, min(100, (int)($_GET['limit'] ?? 50)));
$direction = strtolower(trim((string)($_GET['direction'] ?? 'all')));
if (!in_array($direction, ['all','received','sent'], true)) {
    fail('INVALID_DIRECTION', 422);
}

$where = [];
$args = [(int)$u['id'], (int)$u['id']];
if ($direction === 'received') {
    $where[] = 'sg.receiver_id=?';
    $args = [(int)$u['id']];
} elseif ($direction === 'sent') {
    $where[] = 'sg.sender_id=?';
    $args = [(int)$u['id']];
} else {
    $where[] = '(sg.sender_id=? OR sg.receiver_id=?)';
}

$sql = 'SELECT
    sg.id, sg.story_id, sg.sender_id, sg.receiver_id, sg.gift_id, sg.coin_cost, sg.created_at,
    g.name AS gift_name,
    su.nickname AS sender_nickname,
    ru.nickname AS receiver_nickname,
    s.media_type, s.caption
FROM story_gift_transactions sg
LEFT JOIN gifts g ON g.id=sg.gift_id
LEFT JOIN users su ON su.id=sg.sender_id
LEFT JOIN users ru ON ru.id=sg.receiver_id
LEFT JOIN stories s ON s.id=sg.story_id
WHERE '.implode(' AND ', $where).'
ORDER BY sg.id DESC
LIMIT '.$limit;

$q = $pdo->prepare($sql);
$q->execute($args);
$rows = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];

$giftKeys=[1=>'love',2=>'rose',3=>'diamond',4=>'crown',5=>'cake',6=>'gift_box',7=>'money_bag',8=>'butterfly',9=>'fire',10=>'rocket',11=>'dragon',12=>'trophy',13=>'thunder',14=>'ghost',15=>'galaxy',16=>'ufo',17=>'meteor',18=>'castle',19=>'volcano',20=>'vghost_royal'];
$out = [];
foreach ($rows as $r) {
    $out[] = [
        'id' => (string)$r['id'],
        'storyId' => (string)$r['story_id'],
        'senderId' => (string)$r['sender_id'],
        'senderNickname' => (string)($r['sender_nickname'] ?? ''),
        'receiverId' => (string)$r['receiver_id'],
        'receiverNickname' => (string)($r['receiver_nickname'] ?? ''),
        'giftId' => (string)$r['gift_id'],
        'giftName' => (string)($r['gift_name'] ?? ''),
        'giftKey' => $giftKeys[(int)$r['gift_id']] ?? strtolower(trim((string)($r['gift_name'] ?? ''))),
        'coinCost' => (int)$r['coin_cost'],
        'mediaType' => (string)($r['media_type'] ?? ''),
        'caption' => (string)($r['caption'] ?? ''),
        'createdAt' => (string)$r['created_at'],
        'direction' => ((int)$r['sender_id'] === (int)$u['id']) ? 'sent' : 'received'
    ];
}

ok([
    'history' => $out,
    'direction' => $direction,
    'count' => count($out)
]);
