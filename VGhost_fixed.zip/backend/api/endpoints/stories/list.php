<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Story.php';
require_method('GET'); $trailerMode=((string)($_GET['type']??'')==='trailer');
if(!$trailerMode){ $u=current_user(); } else { $u=null; }
ensure_story_schema(); purge_expired_stories(); $pdo=db();
$uid=(int)($u['id']??0);
$trailerWhere=$trailerMode ? ' AND s.is_trailer=1 AND s.film_id IS NOT NULL' : ' AND s.is_trailer=0';
if($trailerMode){
    $q=$pdo->query("SELECT s.*,u.nickname,u.avatar_id AS avatarId,up.avatar_url AS avatarUrl,f.title AS film_title,f.category AS film_category,f.release_year AS film_year FROM stories s JOIN users u ON u.id=s.user_id LEFT JOIN user_profiles up ON up.user_id=u.id LEFT JOIN films f ON f.id=s.film_id AND f.is_active=1
     WHERE s.expires_at>UTC_TIMESTAMP() AND s.is_trailer=1 AND s.film_id IS NOT NULL AND (s.media_type LIKE 'video/%' OR s.media_type LIKE 'image/%') AND u.is_deleted=0 AND u.is_banned=0 ORDER BY s.created_at DESC LIMIT 200");
} else {
    $q=$pdo->prepare("SELECT s.*,u.nickname,u.avatar_id AS avatarId,up.avatar_url AS avatarUrl,f.title AS film_title,f.category AS film_category,f.release_year AS film_year FROM stories s JOIN users u ON u.id=s.user_id LEFT JOIN user_profiles up ON up.user_id=u.id LEFT JOIN films f ON f.id=s.film_id AND f.is_active=1
     WHERE s.expires_at>UTC_TIMESTAMP() AND s.is_trailer=0 AND (s.media_type LIKE 'video/%' OR s.media_type LIKE 'image/%') AND u.is_deleted=0 AND u.is_banned=0
     AND NOT EXISTS(SELECT 1 FROM blocks b WHERE (b.blocker_id=? AND b.blocked_id=s.user_id) OR (b.blocker_id=s.user_id AND b.blocked_id=?))
     AND (s.user_id=? OR s.visibility='all' OR (s.visibility='friends' AND EXISTS(SELECT 1 FROM friendships f WHERE f.status='accepted' AND f.user_one_id=LEAST(s.user_id,?) AND f.user_two_id=GREATEST(s.user_id,?)))) ORDER BY s.created_at DESC LIMIT 200");
    $q->execute([$uid,$uid,$uid,$uid,$uid]);
}
$rows=[]; foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r) $rows[]=story_row($pdo,$r,$uid); ok(['stories'=>$rows]);
