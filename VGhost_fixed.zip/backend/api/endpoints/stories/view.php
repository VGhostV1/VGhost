<?php
declare(strict_types=1); require_once __DIR__.'/../../core/Story.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('POST'); $u=current_user(); ensure_story_schema(); $b=body(); $id=(int)($b['story_id']??0); if($id<1) fail('INVALID_STORY',422); $pdo=db();
$q=$pdo->prepare('SELECT user_id FROM stories WHERE id=? AND expires_at>UTC_TIMESTAMP() LIMIT 1'); $q->execute([$id]); $owner=$q->fetchColumn(); if($owner===false) fail('STORY_NOT_FOUND',404); if((int)$owner!==(int)$u['id']) { $bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1'); $bq->execute([$u['id'],$owner,$owner,$u['id']]); if($bq->fetchColumn()) fail('USER_BLOCKED',403); }
$ins=$pdo->prepare('INSERT IGNORE INTO story_views(story_id,user_id,viewed_at) VALUES(?,?,UTC_TIMESTAMP())'); $ins->execute([$id,(int)$u['id']]);
if($ins->rowCount()>0 && (int)$owner!==(int)$u['id']) { $nq=$pdo->prepare('SELECT nickname FROM users WHERE id=? LIMIT 1'); $nq->execute([$u['id']]); $name=(string)$nq->fetchColumn(); notify_localized((int)$owner,'story_view',['name'=>$name],['target'=>'story','storyId'=>(string)$id,'targetValue'=>(string)$id,'senderNickname'=>$name]); }
ok(['viewed'=>true,'newView'=>$ins->rowCount()>0]);
