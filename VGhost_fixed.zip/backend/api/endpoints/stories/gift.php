<?php
declare(strict_types=1);

require_once __DIR__.'/../../core/Story.php';
require_once __DIR__.'/../../core/Wallet.php';
require_once __DIR__.'/../../core/Notifications.php';
require_once __DIR__.'/../../core/Level.php';

require_method('POST');
$u = current_user();
$pdo = db();
ensure_story_schema();
ensure_story_gift_schema($pdo);
$body = body();

$storyId = (int)($body['story_id'] ?? $body['storyId'] ?? 0);
$rawGiftId = $body['giftId'] ?? $body['gift_id'] ?? $body['gift'] ?? null;

if ($storyId < 1 || $rawGiftId === null || $rawGiftId === '') {
    fail('INVALID_INPUT', 422);
}

// The receiver is ALWAYS derived from the Story owner on the server.
// The client never gets to choose a receiver_id for a Story gift.
$storyQ = $pdo->prepare(
    'SELECT id,user_id,media_type,expires_at FROM stories WHERE id=? AND expires_at>UTC_TIMESTAMP() LIMIT 1'
);
$storyQ->execute([$storyId]);
$story = $storyQ->fetch(PDO::FETCH_ASSOC);
if (!$story) fail('STORY_NOT_FOUND', 404);

$receiverId = (int)$story['user_id'];
$senderId = (int)$u['id'];
if ($receiverId < 1 || $receiverId === $senderId) {
    fail('INVALID_RECEIVER', 422);
}

$blocked = $pdo->prepare(
    'SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1'
);
$blocked->execute([$senderId,$receiverId,$receiverId,$senderId]);
if ($blocked->fetchColumn()) fail('USER_BLOCKED', 403);

// Resolve the gift and its price on the server. Never trust a client-supplied price.
$gift = null;
if (is_int($rawGiftId) || (is_string($rawGiftId) && ctype_digit(trim($rawGiftId)))) {
    $gid = (int)$rawGiftId;
    if ($gid > 0) {
        $g = $pdo->prepare('SELECT * FROM gifts WHERE id=? AND is_active=1 LIMIT 1');
        $g->execute([$gid]);
        $gift = $g->fetch(PDO::FETCH_ASSOC) ?: null;
    }
} else {
    $giftName = strtolower(trim((string)$rawGiftId));
    $catalogIds = [
        'love'=>1,'rose'=>2,'diamond'=>3,'crown'=>4,'cake'=>5,'gift_box'=>6,
        'money_bag'=>7,'butterfly'=>8,'fire'=>9,'rocket'=>10,'dragon'=>11,
        'trophy'=>12,'thunder'=>13,'ghost'=>14,'galaxy'=>15,'ufo'=>16,
        'meteor'=>17,'castle'=>18,'volcano'=>19,'vghost_royal'=>20
    ];
    if (isset($catalogIds[$giftName])) {
        $g = $pdo->prepare('SELECT * FROM gifts WHERE id=? AND is_active=1 LIMIT 1');
        $g->execute([$catalogIds[$giftName]]);
        $gift = $g->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (!$gift && $giftName !== '') {
        $g = $pdo->prepare('SELECT * FROM gifts WHERE LOWER(name)=LOWER(?) AND is_active=1 LIMIT 1');
        $g->execute([$giftName]);
        $gift = $g->fetch(PDO::FETCH_ASSOC) ?: null;
    }
}
if (!$gift) fail('GIFT_NOT_FOUND', 404);

$giftId = (int)$gift['id'];
$cost = (int)$gift['coin_cost'];
if ($giftId < 1 || $cost <= 0) fail('INVALID_GIFT', 422);

// Keep wallet rows available for both users on older installations.
ensure_wallet_schema($pdo);
ensure_wallet($pdo, $senderId);
ensure_wallet($pdo, $receiverId);

$pdo->beginTransaction();
try {
    // Lock in deterministic user-id order to avoid sender/receiver deadlocks
    // when two users gift each other concurrently.
    $lockIds = [$senderId, $receiverId];
    sort($lockIds, SORT_NUMERIC);
    $balances = [];
    $lock = $pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
    foreach ($lockIds as $uid) {
        $lock->execute([$uid]);
        $value = $lock->fetchColumn();
        if ($value === false) fail('WALLET_NOT_FOUND', 404);
        $balances[$uid] = (int)$value;
    }

    $senderBalance = $balances[$senderId];
    if ($senderBalance < $cost) fail('INSUFFICIENT_COINS', 409);

    $pdo->prepare(
        'UPDATE wallets SET balance=balance-?,updated_at=UTC_TIMESTAMP() WHERE user_id=?'
    )->execute([$cost, $senderId]);
    $pdo->prepare(
        'UPDATE wallets SET balance=balance+?,updated_at=UTC_TIMESTAMP() WHERE user_id=?'
    )->execute([$cost, $receiverId]);

    $reference = 'story_gift:'.$storyId.':'.$giftId;
    $tx = $pdo->prepare(
        'INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())'
    );
    $tx->execute([$senderId, 'story_gift', -$cost, $reference]);
    $tx->execute([$receiverId, 'story_gift',  $cost, $reference]);

    $pdo->prepare(
        'INSERT INTO story_gift_transactions(story_id,sender_id,receiver_id,gift_id,coin_cost,created_at) VALUES(?,?,?,?,?,UTC_TIMESTAMP())'
    )->execute([$storyId,$senderId,$receiverId,$giftId,$cost]);

    $pdo->commit();

    award_activity_xp($pdo, $senderId, min(100, max(1, (int)floor($cost / 10))), 'story_gift_sent');

    $giftKeys = [
        1=>'love',2=>'rose',3=>'diamond',4=>'crown',5=>'cake',6=>'gift_box',
        7=>'money_bag',8=>'butterfly',9=>'fire',10=>'rocket',11=>'dragon',
        12=>'trophy',13=>'thunder',14=>'ghost',15=>'galaxy',16=>'ufo',
        17=>'meteor',18=>'castle',19=>'volcano',20=>'vghost_royal'
    ];
    $giftKey = $giftKeys[$giftId] ?? strtolower(trim((string)$gift['name']));
    $giftName = (string)$gift['name'];
    $senderName = (string)$u['nickname'];
    $mediaType = strtolower((string)($story['media_type'] ?? ''));
    $mediaWord = str_contains($mediaType, 'video') ? 'videonuza' : 'şəklinizə';

    $giftData = [
        'target'=>'story',
        'targetValue'=>(string)$storyId,
        'action'=>'show_gift_slide',
        'storyId'=>(string)$storyId,
        'story_id'=>(string)$storyId,
        'giftId'=>(string)$giftId,
        'gift_id'=>(string)$giftId,
        'giftKey'=>$giftKey,
        'giftName'=>$giftName,
        'coinCost'=>(string)$cost,
        'amount'=>(string)$cost,
        'senderId'=>(string)$senderId,
        'senderUid'=>(string)$senderId,
        'senderNickname'=>$senderName,
        'receiverId'=>(string)$receiverId,
        'mediaType'=>$mediaType
    ];

    $bodyText = $senderName.' '.$mediaWord.' 💎 '.$giftName.' hədiyyəsi göndərdi. +'.$cost.' GC';
    $notificationId = notify_localized(
        $receiverId,
        'story_gift',
        ['name'=>$senderName, 'amount'=>(string)$cost],
        $giftData
    );
    $giftData['notificationId'] = (string)$notificationId;

    $presence = $pdo->prepare('SELECT is_online,last_seen_at FROM user_status WHERE user_id=? LIMIT 1');
    $presence->execute([$receiverId]);
    $status = $presence->fetch(PDO::FETCH_ASSOC) ?: null;
    $recipientOnline = false;
    if ($status && (int)($status['is_online'] ?? 0) === 1 && !empty($status['last_seen_at'])) {
        $fresh = $pdo->prepare(
            'SELECT CASE WHEN ? >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 60 SECOND) THEN 1 ELSE 0 END'
        );
        $fresh->execute([$status['last_seen_at']]);
        $recipientOnline = (bool)$fresh->fetchColumn();
    }

    $push = ['sent'=>$recipientOnline ? 1 : 0,'failed'=>0,'reason'=>$recipientOnline ? '' : 'RECIPIENT_OFFLINE'];

    $receiverBalanceQ = $pdo->prepare('SELECT balance FROM wallets WHERE user_id=? LIMIT 1');
    $receiverBalanceQ->execute([$receiverId]);
    $receiverBalance = (int)$receiverBalanceQ->fetchColumn();

    ok([
        'sent'=>true,
        'storyId'=>(string)$storyId,
        'giftId'=>(string)$giftId,
        'giftKey'=>$giftKey,
        'coinCost'=>$cost,
        'balance'=>$senderBalance-$cost,
        'senderBalance'=>$senderBalance-$cost,
        'receiverBalance'=>$receiverBalance,
        'receiverId'=>(string)$receiverId,
        'recipientOnline'=>$recipientOnline,
        'notificationId'=>(string)$notificationId,
        'realtimeSent'=>(int)($push['sent'] ?? 0) > 0
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
