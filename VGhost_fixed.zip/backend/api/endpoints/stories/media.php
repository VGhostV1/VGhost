<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Story.php';

require_method('GET');
$viewer=null;
$token=bearer_token();
if($token){ try { $viewer=current_user(); } catch(Throwable $e){ $viewer=null; } }
ensure_story_schema();
purge_expired_stories();
$id=(int)($_GET['id']??0);
if($id<1){ http_response_code(404); exit; }

$pdo=db();
$q=$pdo->prepare('SELECT id,user_id,media_path,media_type,visibility,is_trailer,film_id FROM stories WHERE id=? AND expires_at>UTC_TIMESTAMP() LIMIT 1');
$q->execute([$id]);
$r=$q->fetch(PDO::FETCH_ASSOC);
if(!$r || !(str_starts_with((string)$r['media_type'],'video/') || str_starts_with((string)$r['media_type'],'image/'))){ http_response_code(404); exit; }

$owner=(int)$r['user_id'];
$viewerId=(int)($viewer['id']??0);

// Blocked users must never be able to fetch the protected media directly,
// even if they learned the numeric story id from an older response/cache.
if($viewer && $owner!==$viewerId){
    $bq=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1');
    $bq->execute([$viewerId,$owner,$owner,$viewerId]);
    if($bq->fetchColumn()) { http_response_code(403); exit; }
}

// Trailers are film catalogue media and are intentionally accessible to any
// authenticated VGhost user. Normal Stories still obey their visibility rules.
$allowed = ((int)$r['is_trailer']===1);
if(!$allowed && !$viewer) $allowed=false;
if(!$allowed && $owner===$viewerId) $allowed=true;
if(!$allowed && (string)$r['visibility']==='all') $allowed=true;
if(!$allowed && (string)$r['visibility']==='friends') {
    $fq=$pdo->prepare("SELECT 1 FROM friendships WHERE status='accepted' AND user_one_id=LEAST(?,?) AND user_two_id=GREATEST(?,?) LIMIT 1");
    $fq->execute([$viewerId,$owner,$viewerId,$owner]);
    $allowed=(bool)$fq->fetchColumn();
}
if(!$allowed){ http_response_code(403); exit; }

$root=realpath(dirname(__DIR__,3));
if($root===false){ http_response_code(500); exit; }
$file=realpath($root.'/'.ltrim((string)$r['media_path'],'/'));
if(!$file || !str_starts_with($file,$root.DIRECTORY_SEPARATOR) || !is_file($file) || !is_readable($file)){ http_response_code(404); exit; }

$size=filesize($file);
if($size===false || $size<1){ http_response_code(404); exit; }
$mime=(string)$r['media_type'] ?: 'application/octet-stream';
header('Content-Type: '.$mime);
// This endpoint is authorization-aware; public caching could leak Friends-only media.
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
// Keep authenticated media responses scoped to the caller even when an
// intermediary ignores the no-store directive. The Android client downloads
// this endpoint with its Bearer token and then plays the local file.
header('Vary: Authorization');
header('Content-Disposition: inline');
header('Accept-Ranges: bytes');
header('Connection: keep-alive');
header('X-Accel-Buffering: no');
header('X-Content-Type-Options: nosniff');

$range=$_SERVER['HTTP_RANGE']??'';
$start=0;
$end=$size-1;

if($range!=='' && preg_match('/bytes=(\d*)-(\d*)/i',$range,$m)){
    if($m[1]==='' && $m[2]==='') { http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
    if($m[1]==='') {
        $suffix=(int)$m[2];
        if($suffix<=0){ http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
        $start=max(0,$size-$suffix);
    } else {
        $start=(int)$m[1];
        if($start >= $size){ http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
        if($m[2]!=='') $end=min($size-1,(int)$m[2]);
    }
    if($end<$start){ http_response_code(416); header('Content-Range: bytes */'.$size); exit; }
    $length=$end-$start+1;
    http_response_code(206);
    header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
    header('Content-Length: '.$length);
    $fh=fopen($file,'rb');
    if(!$fh){ http_response_code(404); exit; }
    fseek($fh,$start);
    $remaining=$length;
    while($remaining>0 && !feof($fh)){
        $chunk=fread($fh,min(4*1024*1024,$remaining));
        if($chunk===false || $chunk==='') break;
        echo $chunk;
        $remaining-=strlen($chunk);
        if(function_exists('flush')) @flush();
    }
    fclose($fh);
    exit;
}

header('Content-Length: '.$size);
readfile($file);
exit;
