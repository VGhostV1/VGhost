<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Progression.php';
$u = current_user();
ensure_progression_schema();
ok(progression_public((int)$u['id']));
