<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Progression.php';
require_method('POST');
$u = current_user();
$b = body();
$reason = strtolower(trim((string)($b['reason'] ?? '')));
$amount = (int)($b['amount'] ?? 0);
if ($amount < 1) fail('INVALID_XP_AMOUNT',422);
ok(award_progression_xp((int)$u['id'],$amount,$reason));
