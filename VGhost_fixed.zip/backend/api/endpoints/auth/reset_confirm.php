<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';

$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));

function reset_page(string $title, string $message, bool $showForm = false, string $token = '', int $status = 200): void {
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    $safeToken = htmlspecialchars($token, ENT_QUOTES, 'UTF-8');
    $form = $showForm ? '<form method="post" action="" autocomplete="off">
        <input type="hidden" name="token" value="'.$safeToken.'">
        <label>Yeni şifrə</label>
        <input type="password" name="password" minlength="8" maxlength="200" autocomplete="new-password" placeholder="Yeni şifrənizi yazın" required>
        <label>Şifrəni təkrar yaz</label>
        <input type="password" name="confirm" minlength="8" maxlength="200" autocomplete="new-password" placeholder="Şifrənizi təkrar yazın" required>
        <button type="submit">Şifrəni dəyiş</button>
    </form>' : '';
    $icon = $showForm ? '🔐' : ($status < 300 ? '✓' : '⚠');
    $class = $status < 300 ? 'ok' : 'error';
    echo '<!doctype html><html lang="az"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="dark"><title>VGHOST — Şifrə bərpası</title><style>
    *{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:#07080c;color:#f7f7fa}body{display:flex;align-items:center;justify-content:center;padding:22px;background:radial-gradient(circle at 50% 0,#191c2a 0,#0b0d13 42%,#05060a 100%)}.wrap{width:100%;max-width:470px}.brand{text-align:center;font-weight:950;letter-spacing:7px;font-size:31px;margin:0 0 20px;text-shadow:0 0 22px rgba(255,31,56,.24)}.brand b{color:#ff3048}.sub{text-align:center;color:#777b89;font-size:11px;letter-spacing:3px;margin-top:-12px;margin-bottom:18px}.card{position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.11);background:linear-gradient(145deg,rgba(28,30,40,.92),rgba(12,14,21,.95));box-shadow:0 24px 80px rgba(0,0,0,.58),0 0 45px rgba(255,36,56,.06);border-radius:28px;padding:30px}.card:before{content:"";position:absolute;left:12%;right:12%;top:-55px;height:110px;background:rgba(255,36,56,.13);filter:blur(35px);pointer-events:none}.icon{position:relative;width:68px;height:68px;border-radius:21px;margin:0 auto 20px;display:grid;place-items:center;background:rgba(255,36,56,.09);border:1px solid rgba(255,64,83,.38);box-shadow:0 0 30px rgba(255,36,56,.13);font-size:30px}.title{text-align:center;font-size:25px;font-weight:850;margin:0 0 9px}.msg{text-align:center;color:#aeb2bf;line-height:1.55;margin:0 auto 25px;max-width:380px}.ok{color:#a8efbd}.error{color:#ff8b98}form{display:grid;gap:10px}label{font-size:13px;color:#c5c7d0;margin:5px 2px 0}input{width:100%;height:55px;border-radius:15px;border:1px solid #353846;background:rgba(7,9,14,.86);color:#fff;padding:0 16px;font-size:16px;outline:none;transition:.18s}input::placeholder{color:#696d7a}input:focus{border-color:#ff3048;box-shadow:0 0 0 3px rgba(255,48,72,.12),0 0 20px rgba(255,48,72,.06)}button{height:55px;border:0;border-radius:15px;background:linear-gradient(135deg,#ff263f,#d91531);color:#fff;font-weight:850;font-size:16px;margin-top:9px;cursor:pointer;box-shadow:0 9px 28px rgba(255,36,56,.22)}button:active{transform:scale(.985)}.hint{text-align:center;color:#777b87;font-size:11px;margin:20px 0 0;letter-spacing:.2px}.line{height:1px;background:rgba(255,255,255,.07);margin:23px 0 0}.security{text-align:center;color:#666a76;font-size:10px;margin-top:12px;letter-spacing:.3px}</style></head><body><main class="wrap"><div class="brand"><b>V</b>GHOST</div><div class="sub">SECURE ACCOUNT RECOVERY</div><section class="card"><div class="icon">'.$icon.'</div><h1 class="title">'.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').'</h1><p class="msg '.$class.'">'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</p>'.$form.'<div class="line"></div><p class="hint">Şifrəni ən azı 8 simvoldan seçin.</p><p class="security">VGHOST • Təhlükəsiz hesab bərpası</p></section></main></body></html>';
    exit;
}

if ($token === '' || !preg_match('/^[a-f0-9]{64}$/i', $token)) {
    reset_page('Keçid etibarsızdır', 'Şifrə bərpa keçidi düzgün deyil və ya natamamdır.', false, '', 400);
}

$h = hash('sha256', $token);
$q = db()->prepare('SELECT u.id,u.email FROM password_reset_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.used_at IS NULL AND t.expires_at>UTC_TIMESTAMP() AND u.is_deleted=0 LIMIT 1');
$q->execute([$h]);
$u = $q->fetch();
if (!$u) {
    reset_page('Keçidin vaxtı bitib', 'Bu şifrə bərpa keçidi artıq istifadə olunub və ya 30 dəqiqəlik müddəti bitib.', false, '', 400);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $p = (string)($_POST['password'] ?? '');
    $c = (string)($_POST['confirm'] ?? '');
    if (strlen($p) < 8) reset_page('Şifrə çox qısadır', 'Yeni şifrə ən azı 8 simvoldan ibarət olmalıdır.', true, $token, 422);
    if ($p !== $c) reset_page('Şifrələr uyğun deyil', 'İki şifrə eyni olmalıdır.', true, $token, 422);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $pdo->prepare('UPDATE users SET password_hash=?,updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([password_hash($p, PASSWORD_DEFAULT), (int)$u['id']]);
        $pdo->prepare('UPDATE password_reset_tokens SET used_at=UTC_TIMESTAMP() WHERE token_hash=?')->execute([$h]);
        $pdo->prepare('DELETE FROM user_sessions WHERE user_id=?')->execute([(int)$u['id']]);
        $pdo->commit();
        reset_page('Şifrə dəyişdirildi', 'Yeni şifrəniz uğurla yadda saxlanıldı. İndi VGHOST tətbiqinə yeni şifrənizlə daxil ola bilərsiniz.', false, '', 200);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('VGHOST password reset confirm error: '.$e->getMessage());
        reset_page('Xəta baş verdi', 'Şifrə dəyişdirilə bilmədi. Bir neçə dəqiqə sonra yenidən cəhd edin.', true, $token, 500);
    }
}

reset_page('Yeni şifrə seç', 'Yeni şifrənizi iki dəfə daxil edin. Keçid 30 dəqiqə ərzində etibarlıdır.', true, $token, 200);
