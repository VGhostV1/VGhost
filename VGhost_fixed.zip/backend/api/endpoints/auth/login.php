<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php'; require_once __DIR__.'/../../core/Wallet.php'; require_once __DIR__.'/../../core/Notifications.php';
require_method('POST'); $in=request_json(); $login=trim((string)($in['login'] ?? $in['nickname'] ?? '')); if($login==='') fail('INVALID_INPUT',422); $password=input_string($in,'password',128);
$stmt=db()->prepare('SELECT * FROM users WHERE (nickname=? OR email=?) AND is_deleted=0 LIMIT 1'); $stmt->execute([$login,$login]); $u=$stmt->fetch();
if(!$u || !password_verify($password,$u['password_hash'])) fail('INVALID_CREDENTIALS',401);
if((int)($u['is_banned']??0)===1 && !empty($u['ban_expires_at']) && strtotime((string)$u['ban_expires_at']) <= time()) {
    db()->prepare('UPDATE users SET is_banned=0, ban_expires_at=NULL, updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([(int)$u['id']]);
    $u['is_banned']=0; $u['ban_expires_at']=null;
}
if((int)$u['is_banned']===1) fail('USER_BANNED',403,['banExpiresAt'=>$u['ban_expires_at']??null]);
// A super-admin locked by the coin security failsafe must recover through the
// Gmail recovery link before another login session can be issued.
$lockStmt=db()->prepare('SELECT locked FROM admin_coin_security WHERE admin_user_id=? LIMIT 1');
try { $lockStmt->execute([(int)$u['id']]); $coinLocked=$lockStmt->fetchColumn(); } catch(Throwable $e) { $coinLocked=false; }
if($coinLocked !== false && (int)$coinLocked===1) {
    $roleCheck=db()->prepare('SELECT role FROM admins WHERE user_id=? LIMIT 1'); $roleCheck->execute([(int)$u['id']]);
    if((string)$roleCheck->fetchColumn()==='super_admin') fail('ADMIN_SECURITY_LOCKED',423);
}
rate_limit_clear('/auth/login');
$roleStmt=db()->prepare('SELECT role FROM admins WHERE user_id=? LIMIT 1'); $roleStmt->execute([(int)$u['id']]); $role=$roleStmt->fetchColumn(); $avStmt=db()->prepare('SELECT avatar_url FROM user_profiles WHERE user_id=? LIMIT 1'); $avStmt->execute([(int)$u['id']]); $avatarUrl=$avStmt->fetchColumn(); $token=issue_session((int)$u['id']); $q=db()->prepare('SELECT balance FROM wallets WHERE user_id=?'); $q->execute([(int)$u['id']]); $balance=(int)($q->fetchColumn() ?: 0); db()->prepare('UPDATE users SET last_seen_at=UTC_TIMESTAMP(),updated_at=updated_at WHERE id=?')->execute([$u['id']]);
ok(['user'=>['id'=>(int)$u['id'],'nickname'=>$u['nickname'],'email'=>$u['email'],'gender'=>$u['gender']??null,'avatarId'=>$u['avatar_id']??'male_01','vipFrameId'=>$u['vip_frame_id']??'vip_02','avatarUrl'=>$avatarUrl ?: null,'ghostMode'=>(bool)($u['is_ghost']??false),'adminRole'=>$role?:null,'isAdmin'=>$role!==false,'isSuperAdmin'=>$role==='super_admin','isVip'=>((int)($u['is_vip']??0)===1 && (empty($u['vip_expires_at']) || strtotime((string)$u['vip_expires_at'])>time())),'vipExpiresAt'=>(((int)($u['is_vip']??0)===1 && (empty($u['vip_expires_at']) || strtotime((string)$u['vip_expires_at'])>time()))?($u['vip_expires_at']??null):null)],'token'=>$token,'wallet'=>['balance'=>$balance]]);
