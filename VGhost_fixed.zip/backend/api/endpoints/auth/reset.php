<?php
declare(strict_types=1);

// This endpoint is also safe when routed directly by a web server.
require_once __DIR__.'/../../core/Request.php';
require_once __DIR__.'/../../core/Response.php';
require_once __DIR__.'/../../core/SmtpMailer.php';

// Return JSON for unexpected DB/mail errors instead of letting shared-hosting
// PHP emit an HTML 500 page that the Android client reports as a generic server error.
try {
    require_method('POST');
$in=request_json();
// Compatibility for installations upgraded from older VGHOST versions.
db()->exec('CREATE TABLE IF NOT EXISTS password_reset_tokens (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL, used_at DATETIME NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_password_reset_user (user_id), INDEX idx_password_reset_expires (expires_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
// One input can be either nickname or email. The server always resolves the
// account first, then sends the reset link to the email stored on that account.
$raw=trim((string)($in['login'] ?? $in['nickname'] ?? $in['email'] ?? ''));
if($raw==='') fail('INVALID_INPUT',422);
$value=strtolower($raw);
$nickname=ltrim($value,'@');

$q=db()->prepare('SELECT id,nickname,email FROM users WHERE (LOWER(email)=? OR LOWER(nickname)=?) AND is_deleted=0 LIMIT 1');
$q->execute([$value,$nickname]);
$u=$q->fetch();
if(!$u){
    // Keep account enumeration protection while still letting the app know the
    // request was accepted. No email is sent when no matching account exists.
    json_response(['ok'=>true,'message'=>'If this account exists, a reset link has been processed.','email_found'=>false]);
    exit;
}
$email=trim((string)($u['email'] ?? ''));
if($email==='' || !filter_var($email,FILTER_VALIDATE_EMAIL)){
    json_response(['ok'=>true,'message'=>'No recovery email is configured for this account.','email_found'=>false]);
    exit;
}

$token=bin2hex(random_bytes(32));
$hash=hash('sha256',$token);
db()->prepare('DELETE FROM password_reset_tokens WHERE user_id=? OR expires_at<=UTC_TIMESTAMP()')->execute([(int)$u['id']]);
db()->prepare('INSERT INTO password_reset_tokens(user_id,token_hash,expires_at,created_at) VALUES(?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 30 MINUTE),UTC_TIMESTAMP())')->execute([(int)$u['id'],$hash]);

$base=(string)($config['app']['reset_url']??'');
if($base===''){
    $configuredBase=(string)($config['app']['base_url']??'');
    if($configuredBase!=='') {
        $configuredBase=rtrim($configuredBase,'/');
        $base=$configuredBase.(preg_match('#/api$#i',$configuredBase)?'/auth/reset-confirm':'/api/auth/reset-confirm');
    }
}
if($base===''){
    $host=$_SERVER['HTTP_HOST']??'';
    if($host!=='') $base='https://'.$host.'/api/auth/reset-confirm';
}
if($base==='') fail('RESET_URL_NOT_CONFIGURED',500);

$link=$base.(str_contains($base,'?')?'&':'?').'token='.rawurlencode($token);
$safe=htmlspecialchars($link,ENT_QUOTES,'UTF-8');
$subject='Reset your VGHOST password';
$text="Hello,\n\nWe received a request to reset your VGHOST password. Use the link below within 30 minutes:\n\n{$link}\n\nIf you did not request a password reset, you can safely ignore this email.\n\nVGHOST Support";
$html='<!doctype html><html><body style="margin:0;background:#f5f7fb;font-family:Arial,sans-serif;color:#1f2937"><div style="max-width:600px;margin:32px auto;background:#fff;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden"><div style="padding:24px 28px;border-bottom:1px solid #e5e7eb"><strong style="font-size:22px">VGHOST</strong></div><div style="padding:28px"><h1 style="font-size:24px;margin-top:0">Reset your password</h1><p>We received a request to reset your VGHOST password.</p><p style="margin:28px 0"><a href="'.$safe.'" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:13px 20px;border-radius:8px;font-weight:bold">Reset Password</a></p><p>This link expires in <strong>30 minutes</strong>.</p><p>If you did not request this change, you can safely ignore this email. Your password will remain unchanged.</p></div><div style="padding:18px 28px;background:#f9fafb;font-size:12px;color:#6b7280">This is an automated security email from VGHOST.</div></div></body></html>';

$r=smtp_send_detailed((array)($config['smtp']??[]),$email,$subject,$html,$text);
if(!$r['ok']){
    error_log('VGHOST reset SMTP error: '.$r['error']);
    json_response(['ok'=>false,'error'=>'SMTP_SEND_FAILED','smtp_stage'=>$r['stage']],502);
}
json_response(['ok'=>true,'message'=>'Password reset email sent.','email_found'=>true,'resolved_from_nickname'=>!str_contains($raw,'@')]);
} catch (Throwable $e) {
    error_log('VGHOST password reset error: '.$e->getMessage());
    json_response(['ok'=>false,'error'=>'SERVER_ERROR'],500);
}
