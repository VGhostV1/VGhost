<?php
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$raw=bearer_token() ?: fail('UNAUTHORIZED',401);
$hash=hash('sha256',$raw);
// Keep device token ownership safe when users switch accounts on one phone.
$st=db()->prepare('SELECT user_id FROM user_sessions WHERE token_hash=? LIMIT 1');
$st->execute([$hash]);
$uid=$st->fetchColumn();
if($uid!==false){ db()->prepare('DELETE FROM user_sessions WHERE token_hash=?')->execute([$hash]); db()->prepare("INSERT INTO user_status(user_id,is_online,last_seen_at) VALUES(?,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE is_online=0,last_seen_at=UTC_TIMESTAMP()")->execute([(int)$uid]); db()->prepare("UPDATE users SET status='offline',last_seen_at=UTC_TIMESTAMP(),updated_at=UTC_TIMESTAMP() WHERE id=?")->execute([(int)$uid]); }
ok();
