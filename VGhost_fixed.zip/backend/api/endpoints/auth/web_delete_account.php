<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$in=request_json();
$login=input_string($in,'login',255);
$password=input_string($in,'password',128);
$login=trim((string)$login);

$stmt=db()->prepare('SELECT * FROM users WHERE (nickname=? OR email=?) AND is_deleted=0 LIMIT 1');
$stmt->execute([$login,$login]);
$u=$stmt->fetch();
if(!$u || !password_verify($password,$u['password_hash'])) fail('INVALID_CREDENTIALS',401);
$id=(int)$u['id'];
$pdo=db();
$pdo->beginTransaction();
try {
    permanently_delete_user($pdo, $id);
    $pdo->commit();
    ok(['deleted'=>true,'permanent'=>true,'purged'=>true]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
