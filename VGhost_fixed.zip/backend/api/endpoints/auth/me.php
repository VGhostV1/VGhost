<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/Wallet.php';
require_once __DIR__.'/../../core/Notifications.php';
require_method('GET');
$u=current_user(true);
$daily=grant_daily_login_reward_status((int)$u['id']);
$balance=(int)$daily['balance'];
if(!empty($daily['awarded'])) notify_localized((int)$u['id'],'daily_bonus',['amount'=>'500'], ['amount'=>500,'target'=>'profile']);
db()->prepare('UPDATE users SET last_seen_at=UTC_TIMESTAMP() WHERE id=?')->execute([(int)$u['id']]);
$roleStmt=db()->prepare('SELECT role FROM admins WHERE user_id=? LIMIT 1');
$roleStmt->execute([(int)$u['id']]);
$role=$roleStmt->fetchColumn();
$av=db()->prepare('SELECT gender,avatar_id,vip_frame_id,is_vip,vip_expires_at FROM users WHERE id=? LIMIT 1'); $av->execute([(int)$u['id']]); $avatarRow=$av->fetch(PDO::FETCH_ASSOC) ?: []; $vipActive=(int)($avatarRow['is_vip']??0)===1 && (empty($avatarRow['vip_expires_at']) || strtotime((string)$avatarRow['vip_expires_at'])>time());
ok(['user'=>['id'=>(int)$u['id'],'nickname'=>$u['nickname'],'email'=>$u['email'],'status'=>$u['status'],'is_banned'=>(bool)$u['is_banned'],'banExpiresAt'=>$u['ban_expires_at']??null,'ghostMode'=>(bool)($u['is_ghost']??false),'gender'=>$avatarRow['gender']??null,'avatarId'=>$avatarRow['avatar_id']??'male_01','vipFrameId'=>$avatarRow['vip_frame_id']??'vip_02','avatarUrl'=>($avatarRow['avatar_id']??'')==='custom' ? 'api/users/avatar_media?id='.(int)$u['id'] : null,'adminRole'=>$role?:null,'isAdmin'=>$role!==false,'isSuperAdmin'=>$role==='super_admin','isVip'=>$vipActive,'vipExpiresAt'=>$vipActive?($avatarRow['vip_expires_at']??null):null],'wallet'=>['balance'=>$balance],'dailyReward'=>['awarded'=>(bool)$daily['awarded'],'amount'=>(int)$daily['amount']]]);
