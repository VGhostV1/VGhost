<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/App.php';

require_method('POST');

$u = current_user();
$pdo = db();
$id = (int)$u['id'];

$pdo->beginTransaction();

try {
    permanently_delete_user($pdo, $id);
    $pdo->commit();
    ok(['deleted' => true, 'permanent' => true, 'purged' => true]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    throw $e;
}
