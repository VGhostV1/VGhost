<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST'); $u=current_user(); $b=body();
$current=(string)($b['currentPassword']??''); $new=(string)($b['newPassword']??'');
if(strlen($new)<8) fail('PASSWORD_TOO_SHORT',422);
$q=db()->prepare('SELECT password_hash FROM users WHERE id=? AND is_deleted=0 LIMIT 1');$q->execute([$u['id']]);$hash=(string)$q->fetchColumn();
if(!$hash || !password_verify($current,$hash)) fail('INVALID_CURRENT_PASSWORD',401);
if(password_verify($new,$hash)) fail('PASSWORD_SAME',422);
db()->prepare('UPDATE users SET password_hash=?,updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$u['id']]);
db()->prepare('DELETE FROM user_sessions WHERE user_id=?')->execute([$u['id']]);
$token=issue_session((int)$u['id']); ok(['changed'=>true,'token'=>$token]);
