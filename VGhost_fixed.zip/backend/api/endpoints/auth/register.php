<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/Request.php'; require_once __DIR__.'/../../core/Response.php'; require_once __DIR__.'/../../core/Auth.php'; require_once __DIR__.'/../../core/Wallet.php'; require_once __DIR__.'/../../core/Notifications.php';
require_method('POST'); $in=request_json();
$nickname=input_string($in,'nickname',32); $email=input_string($in,'email',190); $password=input_string($in,'password',128); $gender=(string)($in['gender']??'male'); if(!in_array($gender,['male','female'],true)) fail('INVALID_GENDER',422); $avatarId=$gender.'_01';
if (!filter_var($email,FILTER_VALIDATE_EMAIL)) fail('INVALID_EMAIL');
if (strlen($password)<8) fail('PASSWORD_TOO_SHORT');
if (!preg_match('/^[A-Za-z0-9_\.\-]+$/u',$nickname)) fail('INVALID_NICKNAME');
$pdo=db();
$check=$pdo->prepare('SELECT id FROM users WHERE nickname=? OR email=? LIMIT 1'); $check->execute([$nickname,$email]); if($check->fetch()) fail('USER_ALREADY_EXISTS',409);
$pdo->beginTransaction(); try {
 $stmt=$pdo->prepare('INSERT INTO users (nickname,email,password_hash,status,is_banned,is_deleted,created_at,updated_at,last_seen_at,gender,avatar_id) VALUES (?,?,?,"active",0,0,UTC_TIMESTAMP(),UTC_TIMESTAMP(),UTC_TIMESTAMP(),?,?)');
 $stmt->execute([$nickname,$email,password_hash($password,PASSWORD_DEFAULT),$gender,$avatarId]); $id=(int)$pdo->lastInsertId();
 $pdo->prepare('INSERT INTO wallets (user_id,balance,created_at,updated_at) VALUES (?,1000,UTC_TIMESTAMP(),UTC_TIMESTAMP())')->execute([$id]);
 $pdo->prepare("INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())")->execute([$id,'welcome_bonus',1000,'welcome']);
 notify_localized($id,'welcome_bonus',['amount'=>'1000'], ['amount'=>1000,'target'=>'profile']);
 $pdo->commit();
} catch(Throwable $e){$pdo->rollBack(); throw $e;}
$token=issue_session($id); ok(['user'=>['id'=>$id,'nickname'=>$nickname,'email'=>$email,'gender'=>$gender,'avatarId'=>$avatarId,'vipFrameId'=>'vip_02','avatarUrl'=>null,'ghostMode'=>false,'adminRole'=>null,'isAdmin'=>false,'isSuperAdmin'=>false,'isVip'=>false,'vipExpiresAt'=>null],'token'=>$token,'wallet'=>['balance'=>1000],'coinBalance'=>1000]);
