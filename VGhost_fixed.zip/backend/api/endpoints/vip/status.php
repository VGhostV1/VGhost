<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('GET');
$me=current_user();
try { ensure_vip_schema(); } catch(Throwable $e) {}
$row=db()->prepare('SELECT is_vip,vip_expires_at FROM users WHERE id=? LIMIT 1');
$row->execute([(int)$me['id']]);
$r=$row->fetch(PDO::FETCH_ASSOC) ?: [];
$expires=$r['vip_expires_at'] ?? null;
$active=(int)($r['is_vip']??0)===1 && ($expires===null || strtotime((string)$expires)>time());
if(!$active && (int)($r['is_vip']??0)===1 && $expires!==null){
    db()->prepare('UPDATE users SET is_vip=0 WHERE id=? AND vip_expires_at IS NOT NULL AND vip_expires_at<=UTC_TIMESTAMP()')->execute([(int)$me['id']]);
}
ok(['isVip'=>$active,'vipExpiresAt'=>$active?$expires:null]);
