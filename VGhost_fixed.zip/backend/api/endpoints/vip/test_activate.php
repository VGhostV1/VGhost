<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_method('POST');
$me=current_user();
$config=require __DIR__.'/../../config/config.php';
if (!(bool)($config['vip']['test_mode'] ?? false)) fail('VIP_TEST_MODE_DISABLED',403);

$body=body();
$productId=trim((string)($body['productId'] ?? ''));
$products=[
  'vghost_vip_7d'=>7,
  'vghost_vip_30d'=>30,
  'vghost_vip_90d'=>90,
  'vghost_vip_1y'=>365,
];
if(!isset($products[$productId])) fail('INVALID_VIP_PRODUCT',400);
$days=$products[$productId];

try { ensure_vip_schema(); } catch(Throwable $e) {}
$pdo=db();
$pdo->beginTransaction();
try {
    $row=$pdo->prepare('SELECT is_vip,vip_expires_at FROM users WHERE id=? FOR UPDATE');
    $row->execute([(int)$me['id']]);
    $user=$row->fetch(PDO::FETCH_ASSOC);
    if(!$user) { $pdo->rollBack(); fail('USER_NOT_FOUND',404); }

    $current=(string)($user['vip_expires_at'] ?? '');
    $baseTime=($current!=='' && strtotime($current)>time()) ? strtotime($current) : time();
    $expires=gmdate('Y-m-d H:i:s', $baseTime + ($days*86400));
    $pdo->prepare('UPDATE users SET is_vip=1,vip_expires_at=? WHERE id=?')->execute([$expires,(int)$me['id']]);

    // Test purchases are deliberately separate from Google Play purchase history.
    // They are visible in the same table for easy cleanup/auditing.
    $token='TEST-'.bin2hex(random_bytes(20));
    $pdo->prepare('INSERT INTO vip_purchases(user_id,product_id,purchase_token,order_id,duration_days,purchase_time_ms,granted_until,consumed,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,1,\'granted\',UTC_TIMESTAMP(),UTC_TIMESTAMP())')
        ->execute([(int)$me['id'],$productId,$token,null,$days,(int)round(microtime(true)*1000),$expires]);
    $pdo->commit();
    ok(['isVip'=>true,'vipExpiresAt'=>$expires,'testMode'=>true,'productId'=>$productId]);
} catch(Throwable $e) {
    if($pdo->inTransaction()) $pdo->rollBack();
    fail('VIP_TEST_ACTIVATION_FAILED',500);
}
