<?php
declare(strict_types=1);
require_once __DIR__.'/../../core/App.php';
require_once __DIR__.'/../../core/GooglePlay.php';
require_method('POST');
$me=current_user();
$in=body();
$productId=input_string($in,'productId',64,true);
$token=input_string($in,'purchaseToken',512,true);
$products=[
  'vghost_vip_7d'=>7,
  'vghost_vip_30d'=>30,
  'vghost_vip_90d'=>90,
  'vghost_vip_1y'=>365,
];
if(!isset($products[$productId])) fail('UNKNOWN_VIP_PRODUCT',400);
$pdo=db();
ensure_vip_schema();
$existing=$pdo->prepare('SELECT * FROM vip_purchases WHERE purchase_token=? LIMIT 1');
$existing->execute([$token]);
$already=$existing->fetch(PDO::FETCH_ASSOC);
if($already && (int)$already['user_id'] !== (int)$me['id']) fail('PURCHASE_TOKEN_ALREADY_USED',409);
if($already && in_array((string)$already['status'],['granted','pending_consume'],true)){
    ok(['isVip'=>true,'vipExpiresAt'=>$already['granted_until'],'alreadyProcessed'=>true]);
}
$purchase=google_play_get_product_purchase((string)$productId,(string)$token);
$state=(int)($purchase['purchaseState'] ?? -1); // 0 PURCHASED, 1 CANCELED, 2 PENDING
if($state===2) ok(['isVip'=>false,'pending'=>true,'message'=>'PURCHASE_PENDING']);
if($state!==0) fail('PURCHASE_NOT_COMPLETED',400);
$orderId=(string)($purchase['orderId'] ?? '');
$purchaseTimeMs=(int)($purchase['purchaseTimeMillis'] ?? 0);
$duration=(int)$products[$productId];
$pdo->beginTransaction();
try {
    $q=$pdo->prepare('SELECT * FROM vip_purchases WHERE purchase_token=? FOR UPDATE');
    $q->execute([$token]);
    $row=$q->fetch(PDO::FETCH_ASSOC);
    if($row){
        if((int)$row['user_id'] !== (int)$me['id']) throw new RuntimeException('PURCHASE_TOKEN_ALREADY_USED');
        $pdo->commit();
        ok(['isVip'=>true,'vipExpiresAt'=>$row['granted_until'],'alreadyProcessed'=>true]);
    }
    $u=$pdo->prepare('SELECT is_vip,vip_expires_at FROM users WHERE id=? FOR UPDATE');
    $u->execute([(int)$me['id']]);
    $user=$u->fetch(PDO::FETCH_ASSOC);
    if(!$user) throw new RuntimeException('USER_NOT_FOUND');
    $currentExpiry=(string)($user['vip_expires_at']??'');
    $baseTs=($currentExpiry!=='' && strtotime($currentExpiry)>time()) ? strtotime($currentExpiry) : time();
    $grantUntil=gmdate('Y-m-d H:i:s',$baseTs + ($duration*86400));
    $ins=$pdo->prepare('INSERT INTO vip_purchases(user_id,product_id,purchase_token,order_id,duration_days,purchase_time_ms,granted_until,consumed,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,0,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())');
    $ins->execute([(int)$me['id'],$productId,$token,$orderId!==''?$orderId:null,$duration,$purchaseTimeMs?:null,$grantUntil,'pending_consume']);
    $pdo->prepare('UPDATE users SET is_vip=1,vip_expires_at=? WHERE id=?')->execute([$grantUntil,(int)$me['id']]);
    $pdo->commit();
} catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    if($e->getMessage()==='PURCHASE_TOKEN_ALREADY_USED') fail('PURCHASE_TOKEN_ALREADY_USED',409);
    throw $e;
}
$consumed=false;
try { $consumed=google_play_consume_product((string)$productId,(string)$token); } catch(Throwable $e) {
    error_log('VGHOST VIP consume pending: '.$e->getMessage());
}
$pdo->prepare('UPDATE vip_purchases SET consumed=?,status=?,updated_at=UTC_TIMESTAMP() WHERE purchase_token=?')->execute([$consumed?1:0,$consumed?'granted':'pending_consume',$token]);
ok(['isVip'=>true,'vipExpiresAt'=>$grantUntil,'consumed'=>$consumed]);
