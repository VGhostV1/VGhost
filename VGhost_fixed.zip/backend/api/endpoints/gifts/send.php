<?php
require_once __DIR__.'/../../core/App.php'; require_once __DIR__.'/../../core/Level.php'; require_once __DIR__.'/../../core/Notifications.php';
require_method('POST');

$u = current_user();
$b = body();

$rid = (int)($b['recipientUid'] ?? $b['receiverUid'] ?? $b['receiverId'] ?? 0);
$rawGiftId = $b['giftId'] ?? $b['gift_id'] ?? $b['gift'] ?? null;

if (!$rid || $rid === (int)$u['id'] || $rawGiftId === null || $rawGiftId === '') {
    fail('INVALID_INPUT', 422);
}

$pdo = db();

$ru = $pdo->prepare('SELECT id FROM users WHERE id=? AND is_deleted=0 AND is_banned=0 LIMIT 1');
$ru->execute([$rid]);
if (!$ru->fetchColumn()) fail('USER_NOT_FOUND', 404);
$blocked=$pdo->prepare('SELECT 1 FROM blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1');
$blocked->execute([(int)$u['id'],$rid,$rid,(int)$u['id']]);
if ($blocked->fetchColumn()) fail('USER_BLOCKED',403);

/*
 * Backward compatibility:
 * Older app builds send the gift name (for example "love") while newer
 * builds send the numeric database ID (for example 1). Accept both, but
 * always resolve the real gift and price on the server.
 */
$gift = null;
if (is_int($rawGiftId) || (is_string($rawGiftId) && ctype_digit(trim($rawGiftId)))) {
    $gid = (int)$rawGiftId;
    if ($gid > 0) {
        $g = $pdo->prepare('SELECT * FROM gifts WHERE id=? AND is_active=1 LIMIT 1');
        $g->execute([$gid]);
        $gift = $g->fetch();
    }
} else {
    $giftName = strtolower(trim((string)$rawGiftId));
    // Canonical app IDs are stable even if an older database used display names.
    $catalogIds = [
        'love'=>1,'rose'=>2,'diamond'=>3,'crown'=>4,'cake'=>5,'gift_box'=>6,
        'money_bag'=>7,'butterfly'=>8,'fire'=>9,'rocket'=>10,'dragon'=>11,
        'trophy'=>12,'thunder'=>13,'ghost'=>14,'galaxy'=>15,'ufo'=>16,
        'meteor'=>17,'castle'=>18,'volcano'=>19,'vghost_royal'=>20
    ];
    if (isset($catalogIds[$giftName])) {
        $g = $pdo->prepare('SELECT * FROM gifts WHERE id=? AND is_active=1 LIMIT 1');
        $g->execute([$catalogIds[$giftName]]);
        $gift = $g->fetch();
    }
    if (!$gift && $giftName !== '') {
        $g = $pdo->prepare('SELECT * FROM gifts WHERE LOWER(name)=LOWER(?) AND is_active=1 LIMIT 1');
        $g->execute([$giftName]);
        $gift = $g->fetch();
    }
}

if (!$gift) fail('GIFT_NOT_FOUND', 404);
$gid = (int)$gift['id'];

$pdo->beginTransaction();
try {
    $w = $pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
    $w->execute([$u['id']]);
    $balValue = $w->fetchColumn();
    if ($balValue === false) fail('WALLET_NOT_FOUND', 404);
    $bal = (int)$balValue;

    $cost = (int)$gift['coin_cost'];
    if ($bal < $cost) fail('INSUFFICIENT_COINS', 409);

    $pdo->prepare('UPDATE wallets SET balance=balance-?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')
        ->execute([$cost, $u['id']]);
    $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')
        ->execute([$u['id'], 'gift', -$cost, 'gift:'.$gid]);
    $pdo->prepare('INSERT INTO gift_transactions(sender_id,receiver_id,gift_id,coin_cost,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')
        ->execute([$u['id'], $rid, $gid, $cost]);

    $pdo->commit();
    award_activity_xp(db(),(int)$u['id'],min(100,max(1,(int)floor($cost/10))),'gift_sent');

    // Canonical IDs for all 20 gifts. The Android client can resolve either this
    // stable key or the numeric database ID, so old/new database naming stays compatible.
    $giftKeys = [
        1=>'love',2=>'rose',3=>'diamond',4=>'crown',5=>'cake',6=>'gift_box',
        7=>'money_bag',8=>'butterfly',9=>'fire',10=>'rocket',11=>'dragon',
        12=>'trophy',13=>'thunder',14=>'ghost',15=>'galaxy',16=>'ufo',
        17=>'meteor',18=>'castle',19=>'volcano',20=>'vghost_royal'
    ];
    $giftKey = $giftKeys[$gid] ?? strtolower(trim((string)$gift['name']));
    $giftData = [
        'giftId'=>(string)$gid,
        'gift_id'=>(string)$gid,
        'giftKey'=>$giftKey,
        'giftName'=>(string)$gift['name'],
        'amount'=>(string)$cost,
        'coinCost'=>(string)$cost,
        'senderId'=>(string)$u['id'],
        'senderUid'=>(string)$u['id'],
        'senderNickname'=>(string)$u['nickname'],
        'target'=>'profile',
        'action'=>'show_gift_slide'
    ];

    // Always persist the in-app notification. Only a genuinely foreground/online
    // recipient receives the real-time FCM event that opens the global gift slide.
    $notificationId = notify_localized(
        $rid,
        'gift',
        ['name'=>(string)$u['nickname'], 'amount'=>(string)$cost],
        $giftData
    );
    $giftData['notificationId'] = (string)$notificationId;

    $presence = $pdo->prepare(
        'SELECT is_online,last_seen_at FROM user_status WHERE user_id=? LIMIT 1'
    );
    $presence->execute([$rid]);
    $status = $presence->fetch(PDO::FETCH_ASSOC) ?: null;
    $recipientOnline = false;
    if ($status && (int)($status['is_online'] ?? 0) === 1 && !empty($status['last_seen_at'])) {
        $fresh = $pdo->prepare(
            'SELECT CASE WHEN ? >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 60 SECOND) THEN 1 ELSE 0 END'
        );
        $fresh->execute([$status['last_seen_at']]);
        $recipientOnline = (bool)$fresh->fetchColumn();
    }

    $push = ['sent'=>$recipientOnline ? 1 : 0,'failed'=>0,'reason'=>$recipientOnline ? '' : 'RECIPIENT_OFFLINE'];

    ok([
        'sent'=>true,
        'giftId'=>(string)$gid,
        'giftKey'=>$giftKey,
        'balance'=>$bal-$cost,
        'recipientOnline'=>$recipientOnline,
        'notificationId'=>(string)$notificationId,
        'realtimeSent'=>(int)($push['sent'] ?? 0) > 0
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
