<?php
require_once __DIR__.'/../../core/App.php';
$u=current_user(); $pdo=db();
$s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=?');$s->execute([$u['id']]);$bal=(int)$s->fetchColumn();
$g=$pdo->query('SELECT id,name,coin_cost AS coinCost FROM gifts WHERE is_active=1 ORDER BY id')->fetchAll();
$giftKeys=[1=>'love',2=>'rose',3=>'diamond',4=>'crown',5=>'cake',6=>'gift_box',7=>'money_bag',8=>'butterfly',9=>'fire',10=>'rocket',11=>'dragon',12=>'trophy',13=>'thunder',14=>'ghost',15=>'galaxy',16=>'ufo',17=>'meteor',18=>'castle',19=>'volcano',20=>'vghost_royal'];
foreach($g as &$giftRow){ $giftRow['giftId']=(string)$giftRow['id']; $giftRow['giftKey']=$giftKeys[(int)$giftRow['id']]??strtolower(trim((string)$giftRow['name'])); } unset($giftRow);
$giftIcons=['love'=>'❤️','rose'=>'🌹','diamond'=>'💎','crown'=>'👑','cake'=>'🎂','gift_box'=>'🎁','money_bag'=>'💰','butterfly'=>'🦋','fire'=>'🔥','rocket'=>'🚀','dragon'=>'🐉','trophy'=>'🏆','thunder'=>'⚡','ghost'=>'👻','galaxy'=>'🌌','ufo'=>'🛸','meteor'=>'☄️','castle'=>'🏰','volcano'=>'🌋','vghost_royal'=>'👻💎'];
$c=$pdo->prepare('SELECT g.id AS gift_id,g.name,g.coin_cost AS price,COUNT(*) AS count FROM gift_transactions gt JOIN gifts g ON g.id=gt.gift_id WHERE gt.receiver_id=? GROUP BY g.id,g.name,g.coin_cost ORDER BY g.id');$c->execute([$u['id']]);$owned=$c->fetchAll();
foreach($owned as &$giftRow){ $giftRow['gift_id']=(string)$giftRow['gift_id']; $giftRow['giftId']=$giftRow['gift_id']; $giftRow['giftKey']=$giftKeys[(int)$giftRow['gift_id']]??strtolower(trim((string)$giftRow['name'])); $giftRow['icon']=$giftIcons[$giftRow['name']]??'🎁'; } unset($giftRow);
$xp=0;foreach($owned as $x)$xp+=(int)$x['price']*(int)$x['count'];
ok(['coins'=>$bal,'giftXp'=>$xp,'giftLevel'=>max(1,(int)floor($xp/100)+1),'gifts'=>$g,'collection'=>$owned]);
