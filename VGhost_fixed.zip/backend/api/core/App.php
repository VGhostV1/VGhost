<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Response.php';
require_once __DIR__.'/Request.php';
require_once __DIR__.'/Auth.php';
require_once __DIR__.'/MessageCleanup.php';

// Automatic safety net: if the server's cron is not configured, normal API
// traffic still removes expired messages. The indexed expires_at column keeps
// this operation fast, and the named MySQL lock prevents concurrent cleanups.
try {
    cleanup_expired_messages(db());
} catch (Throwable $e) {
    // Message cleanup must never break normal API requests. The dedicated cron
    // job will retry on its next run.
}
// Request.php already provides require_method(). Keep this fallback guarded so
// direct endpoint execution and normal API routing cannot redeclare the function.
if (!function_exists('require_method')) {
    function require_method(string $m): void {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $m) fail('METHOD_NOT_ALLOWED',405);
    }
}
function body(): array { return request_json(); }

/**
 * Detect an uploaded media MIME type without making the optional Fileinfo PHP
 * extension a hard requirement. Some cPanel/PHP builds do not expose finfo,
 * which previously caused every media upload to end in the generic SERVER_ERROR.
 */
function upload_mime_type(string $tmpPath, string $originalName=''): string {
    $mime='';
    try {
        if (class_exists('finfo')) {
            $fi=new finfo(FILEINFO_MIME_TYPE);
            $mime=(string)($fi->file($tmpPath) ?: '');
        }
    } catch (Throwable $e) {}
    if ($mime==='' && function_exists('mime_content_type')) {
        try { $mime=(string)(mime_content_type($tmpPath) ?: ''); } catch (Throwable $e) {}
    }
    $mime=strtolower(trim($mime));
    if ($mime==='' || $mime==='application/octet-stream') {
        $ext=strtolower(pathinfo($originalName,PATHINFO_EXTENSION));
        $byExt=[
            'jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif','bmp'=>'image/bmp','heic'=>'image/heic','heif'=>'image/heif','avif'=>'image/avif',
            'mp4'=>'video/mp4','m4v'=>'video/x-m4v','webm'=>'video/webm','mov'=>'video/quicktime','3gp'=>'video/3gpp','3gpp'=>'video/3gpp','3g2'=>'video/3gpp2','mpeg'=>'video/mpeg','mpg'=>'video/mpeg','mkv'=>'video/x-matroska','ogv'=>'video/ogg','ts'=>'video/mp2t','m2ts'=>'video/mp2t','flv'=>'video/x-flv',
            'mp3'=>'audio/mpeg','m4a'=>'audio/mp4','aac'=>'audio/aac','ogg'=>'audio/ogg','oga'=>'audio/ogg','wav'=>'audio/wav'
        ];
        if (isset($byExt[$ext])) $mime=$byExt[$ext];
    }
    return $mime;
}
function find_user_by_nickname(string $nickname): ?array { $s=db()->prepare('SELECT * FROM users WHERE LOWER(nickname)=LOWER(?) AND is_deleted=0 LIMIT 1'); $s->execute([ltrim(trim($nickname),'@')]); $r=$s->fetch(); return $r?:null; }
function is_admin(int $uid): bool { $s=db()->prepare("SELECT role FROM admins WHERE user_id=? LIMIT 1"); $s->execute([$uid]); return (bool)$s->fetch(); }
function require_admin_user(): array { $u=current_user(); if(!is_admin((int)$u['id'])) fail('FORBIDDEN',403); return $u; }
function require_super_admin(): array { $u=current_user(); $s=db()->prepare('SELECT role FROM admins WHERE user_id=? LIMIT 1'); $s->execute([(int)$u['id']]); if((string)$s->fetchColumn()!=='super_admin') fail('SUPER_ADMIN_REQUIRED',403); return $u; }
function admin_log(int $admin,string $action,?int $target=null,?array $details=null): void { $s=db()->prepare('INSERT INTO admin_logs(admin_user_id,action,target_user_id,details,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())'); $s->execute([$admin,$action,$target,$details?json_encode($details,JSON_UNESCAPED_UNICODE):null]); }



/**
 * Validate the shared super-admin security code for sensitive admin operations.
 * The code is stored only as a password hash and is never hard-coded in the APK.
 * Callers may supply it in X-Admin-Security-Code or confirmCode.
 */
function require_admin_security(array $admin, ?string $provided=null): void {
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_security (id TINYINT UNSIGNED PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, code_hash VARCHAR(255) NOT NULL, locked TINYINT(1) NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL, FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $sec=$pdo->query('SELECT * FROM admin_coin_security WHERE id=1 LIMIT 1')->fetch();
    if(!$sec){
        $cfg = require __DIR__.'/../config/config.php';
        $hash=(string)($cfg['security']['admin_operation_code_hash'] ?? '');
        if($hash==='') fail('ADMIN_SECURITY_NOT_CONFIGURED',500);
        $ins=$pdo->prepare('INSERT INTO admin_coin_security(id,admin_user_id,code_hash,locked,updated_at) VALUES(1,?,?,?,?,UTC_TIMESTAMP())');
        $ins->execute([(int)$admin['id'],$hash,0]);
        $sec=['admin_user_id'=>(int)$admin['id'],'code_hash'=>$hash,'locked'=>0];
    }
    if((int)$sec['admin_user_id'] !== (int)$admin['id']) {
        // A super-admin account may have been recreated/changed. Rebind the shared
        // security record to the currently authenticated super-admin instead of
        // making a valid code silently unusable.
        $pdo->prepare('UPDATE admin_coin_security SET admin_user_id=?,updated_at=UTC_TIMESTAMP() WHERE id=1')->execute([(int)$admin['id']]);
        $sec['admin_user_id']=(int)$admin['id'];
    }
    if((int)$sec['locked']===1) fail('ADMIN_SECURITY_LOCKED',423);
    // Distributed brute-force protection: a valid admin session alone is not enough
    // to guess the second factor indefinitely. Five bad codes trigger a 15-minute lock.
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_security_attempts (admin_user_id BIGINT UNSIGNED PRIMARY KEY,failed_attempts INT UNSIGNED NOT NULL DEFAULT 0,locked_until DATETIME NULL,updated_at DATETIME NOT NULL,FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $as=$pdo->prepare('SELECT failed_attempts,locked_until FROM admin_security_attempts WHERE admin_user_id=? LIMIT 1');
    $as->execute([(int)$admin['id']]); $attempt=$as->fetch(PDO::FETCH_ASSOC) ?: ['failed_attempts'=>0,'locked_until'=>null];
    if(!empty($attempt['locked_until']) && strtotime((string)$attempt['locked_until'])>time()) fail('ADMIN_SECURITY_LOCKED',423);
    if(!empty($attempt['locked_until'])) $pdo->prepare('UPDATE admin_security_attempts SET failed_attempts=0,locked_until=NULL,updated_at=UTC_TIMESTAMP() WHERE admin_user_id=?')->execute([(int)$admin['id']]);
    $provided = trim($provided ?? (string)($_SERVER['HTTP_X_ADMIN_SECURITY_CODE'] ?? ''));
    if($provided==='') {
        $b=body();
        $provided=trim((string)($b['confirmCode']??''));
    }
    if($provided==='' || !password_verify($provided,(string)$sec['code_hash'])) {
        $pdo->prepare("INSERT INTO admin_security_attempts(admin_user_id,failed_attempts,locked_until,updated_at) VALUES(?,1,NULL,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE failed_attempts=failed_attempts+1,locked_until=IF(failed_attempts+1>=5,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 15 MINUTE),locked_until),updated_at=UTC_TIMESTAMP()")->execute([(int)$admin['id']]);
        admin_log((int)$admin['id'],'admin_security_denied',null,['reason'=>'invalid_confirmation_code']);
        fail('INVALID_SECURITY_CODE',403);
    }
    $pdo->prepare('INSERT INTO admin_security_attempts(admin_user_id,failed_attempts,locked_until,updated_at) VALUES(?,0,NULL,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE failed_attempts=0,locked_until=NULL,updated_at=UTC_TIMESTAMP()')->execute([(int)$admin['id']]);
}

/**
 * Permanently remove one user and every account-owned row in the current DB.
 *
 * The schema mostly uses ON DELETE CASCADE, but older installations can have
 * child tables without the cascade. We therefore discover every foreign key
 * that points at users.id and delete those rows explicitly before deleting the
 * parent. A few legacy/audit tables keep user ids without an FK, so those are
 * removed explicitly as well.
 */
function ensure_films_schema(): void {
    static $done=false; if($done) return; $done=true;
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS films (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, title VARCHAR(180) NOT NULL, description TEXT NULL,
      poster_url VARCHAR(1000) NULL, video_url VARCHAR(1000) NOT NULL DEFAULT '',
      poster_path VARCHAR(500) NULL, video_path VARCHAR(500) NULL, category VARCHAR(80) NOT NULL DEFAULT 'Drama',
      release_year SMALLINT UNSIGNED NULL, duration_minutes SMALLINT UNSIGNED NULL, is_vip TINYINT(1) NOT NULL DEFAULT 0,
      is_featured TINYINT(1) NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1, sort_order INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY(id), KEY idx_films_active_featured(is_active,is_featured,sort_order,id), KEY idx_films_category(category,is_active), KEY idx_films_year(release_year)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    foreach ([
        ['poster_path', 'ALTER TABLE films ADD COLUMN poster_path VARCHAR(500) NULL'],
        ['video_path', 'ALTER TABLE films ADD COLUMN video_path VARCHAR(500) NULL'],
        ['view_count', 'ALTER TABLE films ADD COLUMN view_count BIGINT UNSIGNED NOT NULL DEFAULT 0'],
        ['play_count', 'ALTER TABLE films ADD COLUMN play_count BIGINT UNSIGNED NOT NULL DEFAULT 0'],
        ['watch_seconds', 'ALTER TABLE films ADD COLUMN watch_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0'],
        ['like_count', 'ALTER TABLE films ADD COLUMN like_count BIGINT UNSIGNED NOT NULL DEFAULT 0'],
        ['last_view_at', 'ALTER TABLE films ADD COLUMN last_view_at DATETIME NULL'],
    ] as [$col,$sql]) {
        try { $q=$pdo->query("SHOW COLUMNS FROM films LIKE '".$col."'"); if(!$q->fetch()) $pdo->exec($sql); } catch(Throwable $e) {}
    }
}

function permanently_delete_user(PDO $pdo, int $userId): void {
    if ($userId < 1) throw new InvalidArgumentException('Invalid user id');

    // Capture and physically remove all private message media BEFORE deleting
    // the rows that contain their paths. This prevents orphaned audio/images
    // from surviving a Panic, Delete Account, or Admin Delete operation.
    $privateFiles = [];
    try {
        $mq = $pdo->prepare('SELECT m.audio_path, m.attachment_path FROM messages m JOIN conversations c ON c.id=m.conversation_id WHERE c.user_one_id=? OR c.user_two_id=?');
        $mq->execute([$userId, $userId]);
        foreach ($mq->fetchAll(PDO::FETCH_ASSOC) as $row) {
            foreach (['audio_path','attachment_path'] as $key) {
                $rel = trim((string)($row[$key] ?? ''));
                if ($rel !== '') $privateFiles[$rel] = true;
            }
        }
    } catch (Throwable $e) {
        // Older schemas may not yet have attachment columns. Continue with the
        // database purge; existing rows will still be removed by the FK sweep.
    }

    // Story rows use story_id for their child tables and media_path for the
    // actual file. Capture every owned story file before deleting the rows.
    // This closes the old gap where a hard account delete removed the DB row
    // but left the story image/video in storage/stories.
    $storyFiles = [];
    try {
        $sq = $pdo->prepare('SELECT id, media_path FROM stories WHERE user_id=?');
        $sq->execute([$userId]);
        $storyRows = $sq->fetchAll(PDO::FETCH_ASSOC);
        $storyIds = [];
        foreach ($storyRows as $row) {
            $storyIds[] = (int)$row['id'];
            $rel = trim((string)($row['media_path'] ?? ''));
            if ($rel !== '') $storyFiles[$rel] = true;
        }
        if ($storyIds) {
            $ph = implode(',', array_fill(0, count($storyIds), '?'));
            foreach (['story_views','story_likes','story_comments'] as $tbl) {
                $pdo->prepare("DELETE FROM {$tbl} WHERE story_id IN ($ph)")->execute($storyIds);
            }
        }
    } catch (Throwable $e) {
        // Story tables are optional on older installations.
    }

    // Remove any unfinished uploads belonging to this account. Message/story
    // chunk metadata records the authenticated uploader, and message chunks
    // also record the intended receiver, so a deleted account cannot leave
    // private partial media behind.
    $storageBase = dirname(__DIR__,2).'/storage';
    foreach ([
        [$storageBase.'/stories/.chunks', ['user_id']],
        [$storageBase.'/messages/.chunks', ['user_id','receiver_id']],
    ] as [$baseDir, $ownerKeys]) {
        if (!is_dir($baseDir)) continue;
        foreach (@scandir($baseDir) ?: [] as $dirName) {
            if ($dirName === '.' || $dirName === '..') continue;
            $dir = $baseDir.'/'.$dirName;
            $metaFile = $dir.'/meta.json';
            if (!is_dir($dir) || !is_file($metaFile)) continue;
            $meta = json_decode((string)@file_get_contents($metaFile), true);
            $belongs = is_array($meta) && array_reduce($ownerKeys, static function(bool $carry, string $key) use ($meta, $userId): bool {
                return $carry || (int)($meta[$key] ?? 0) === $userId;
            }, false);
            if ($belongs) {
                foreach (@scandir($dir) ?: [] as $f) {
                    if ($f === '.' || $f === '..') continue;
                    $path = $dir.'/'.$f;
                    if (is_file($path) || is_link($path)) @unlink($path);
                }
                @rmdir($dir);
            }
        }
    }

    // Legacy/custom profile avatars use a sidecar JSON file keyed by user id.
    // The current UI uses presets, but old custom avatars must still be erased.
    $avatarRoot = realpath($storageBase.'/profile_avatars');
    if ($avatarRoot) {
        $avatarIndex = $avatarRoot.'/'.$userId.'.json';
        if (is_file($avatarIndex)) {
            $meta = json_decode((string)@file_get_contents($avatarIndex), true);
            $avatarFile = is_array($meta) ? trim((string)($meta['file'] ?? '')) : '';
            if ($avatarFile !== '') {
                $file = realpath($avatarRoot.'/'.basename($avatarFile));
                if ($file && str_starts_with($file, $avatarRoot.DIRECTORY_SEPARATOR) && is_file($file)) {
                    if (!@unlink($file) && is_file($file)) throw new RuntimeException('PROFILE_MEDIA_DELETE_FAILED');
                }
            }
            if (!@unlink($avatarIndex) && is_file($avatarIndex)) throw new RuntimeException('PROFILE_MEDIA_INDEX_DELETE_FAILED');
        }
    }

    // Legacy/non-FK references which would otherwise survive a hard delete.
    $nonFk = [
        ['admin_logs', 'target_user_id'],
        ['backup_import_tokens', 'admin_user_id'],
        ['story_follows', 'followed_user_id'],
    ];
    foreach ($nonFk as [$table, $column]) {
        try {
            $pdo->prepare("DELETE FROM `{$table}` WHERE `{$column}`=?")->execute([$userId]);
        } catch (PDOException $e) {
            // Optional/legacy tables may not exist on older installations.
            if ((int)$e->errorInfo[1] !== 1146) throw $e;
        }
    }

    // Discover all direct FK references to users.id in the installed schema.
    $q = $pdo->prepare(
        'SELECT TABLE_NAME, COLUMN_NAME
           FROM information_schema.KEY_COLUMN_USAGE
          WHERE CONSTRAINT_SCHEMA = DATABASE()
            AND REFERENCED_TABLE_SCHEMA = DATABASE()
            AND REFERENCED_TABLE_NAME = \'users\'
            AND REFERENCED_COLUMN_NAME = \'id\'
            AND TABLE_NAME <> \'users\'
          ORDER BY TABLE_NAME, ORDINAL_POSITION'
    );
    $q->execute();
    $refs = [];
    foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $table = (string)$row['TABLE_NAME'];
        $column = (string)$row['COLUMN_NAME'];
        $refs[$table][] = $column;
    }

    // Also catch legacy tables/columns which stored a user id without a FK.
    $q2 = $pdo->query(
        "SELECT TABLE_NAME, COLUMN_NAME
           FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME<>'users'
            AND (COLUMN_NAME REGEXP '(^|_)user_id$'
              OR COLUMN_NAME REGEXP '^(sender|receiver|viewer|blocker|blocked|requester|profile_user|target_user|admin_user)_id$')
          ORDER BY TABLE_NAME, ORDINAL_POSITION"
    );
    foreach ($q2->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $table = (string)$row['TABLE_NAME'];
        $column = (string)$row['COLUMN_NAME'];
        $refs[$table][] = $column;
    }

    foreach ($refs as $table => $columns) {
        $parts = [];
        foreach (array_values(array_unique($columns)) as $column) {
            $parts[] = '`'.str_replace('`','``',$column).'`=?';
        }
        if (!$parts) continue;
        $safeTable = '`'.str_replace('`','``',$table).'`';
        $pdo->prepare("DELETE FROM {$safeTable} WHERE ".implode(' OR ', $parts))
            ->execute(array_fill(0, count($parts), $userId));
    }

    // Physically remove account-owned private media from backend storage.
    $storageRoot = realpath($storageBase);
    if ($storageRoot) {
        foreach (array_merge(array_keys($privateFiles), array_keys($storyFiles)) as $rel) {
            $file = realpath($storageRoot.'/'.ltrim($rel,'/'));
            if ($file && str_starts_with($file, $storageRoot.DIRECTORY_SEPARATOR) && is_file($file)) {
                if (!@unlink($file) && is_file($file)) {
                    throw new RuntimeException('PRIVATE_MEDIA_DELETE_FAILED');
                }
            }
        }
    }

    // Finally remove the account itself. This also handles any remaining
    // ON DELETE CASCADE relationships added by future migrations.
    $stmt = $pdo->prepare('DELETE FROM users WHERE id=?');
    $stmt->execute([$userId]);
    if ($stmt->rowCount() !== 1) {
        throw new RuntimeException('USER_DELETE_FAILED');
    }
}
function json_row(array $u): array { return ['id'=>(int)($u['id']??0),'uid'=>(string)($u['id']??''),'nickname'=>(string)($u['nickname']??''),'email'=>(string)($u['email']??''),'status'=>(string)($u['status']??'offline'),'isBanned'=>(bool)($u['is_banned']??false),'lastSeenAt'=>$u['last_seen_at']??null]; }
