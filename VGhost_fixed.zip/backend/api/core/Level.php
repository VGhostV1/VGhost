<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Wallet.php';

/**
 * Adds activity XP and grants 100 coins for every newly reached activity level.
 * Level-up rewards are ledgered as wallet transactions; no app notification or
 * push notification is created here. The Android client detects the level
 * change and displays its own 10-second on-screen animation.
 */
function award_activity_xp(PDO $pdo,int $userId,int $amount,string $reason): int {
    if($amount<=0) return 0;
    $ownTx=!$pdo->inTransaction();
    if($ownTx) $pdo->beginTransaction();
    try {
        $q=$pdo->prepare('SELECT COALESCE(activity_xp,0) AS xp FROM users WHERE id=? AND is_deleted=0 LIMIT 1 FOR UPDATE');
        $q->execute([$userId]);
        $old=$q->fetchColumn();
        if($old===false){ if($ownTx) $pdo->commit(); return 0; }
        $oldXp=(int)$old;
        $newXp=min(4294967295,$oldXp+$amount);
        $oldLevel=max(1,(int)floor($oldXp/100)+1);
        $newLevel=max(1,(int)floor($newXp/100)+1);
        $q=$pdo->prepare('UPDATE users SET activity_xp=? WHERE id=? AND is_deleted=0');
        $q->execute([$newXp,$userId]);

        $levelsGained=max(0,$newLevel-$oldLevel);
        if($levelsGained>0){
            ensure_wallet($pdo,$userId);
            $coinReward=$levelsGained*100;
            $s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
            $s->execute([$userId]);
            $balance=$s->fetchColumn();
            if($balance===false) fail('WALLET_NOT_FOUND',404);
            $newBalance=(int)$balance+$coinReward;
            $pdo->prepare('UPDATE wallets SET balance=?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$newBalance,$userId]);
            $t=$pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())');
            for($level=$oldLevel+1;$level<=$newLevel;$level++){
                $t->execute([$userId,'level_up_reward',100,'level:'.$level]);
            }
        }
        if($ownTx) $pdo->commit();
        return $amount;
    } catch(Throwable $e) {
        if($ownTx && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
function activity_level(int $xp): int { return max(1,(int)floor($xp/100)+1); }
