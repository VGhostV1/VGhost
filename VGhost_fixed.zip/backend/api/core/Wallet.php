<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Response.php';



function ensure_wallet_schema(PDO $pdo): void {
    // Keep wallet setup compatible with both the current schema and older
    // installations. CREATE TABLE IF NOT EXISTS does NOT upgrade an existing
    // legacy table, so explicitly add columns that older VGhost databases may
    // be missing. This prevents wallet operations from becoming HTTP 500 errors.
    $pdo->exec("CREATE TABLE IF NOT EXISTS wallets (
        user_id BIGINT UNSIGNED PRIMARY KEY,
        balance BIGINT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $walletCols = [];
    foreach ($pdo->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='wallets'")->fetchAll(PDO::FETCH_COLUMN) as $c) {
        $walletCols[strtolower((string)$c)] = true;
    }
    if (!isset($walletCols['balance'])) {
        $pdo->exec("ALTER TABLE wallets ADD COLUMN balance BIGINT NOT NULL DEFAULT 0");
    }
    if (!isset($walletCols['created_at'])) {
        $pdo->exec("ALTER TABLE wallets ADD COLUMN created_at DATETIME NULL");
        $pdo->exec("UPDATE wallets SET created_at=UTC_TIMESTAMP() WHERE created_at IS NULL");
    }
    if (!isset($walletCols['updated_at'])) {
        $pdo->exec("ALTER TABLE wallets ADD COLUMN updated_at DATETIME NULL");
        $pdo->exec("UPDATE wallets SET updated_at=UTC_TIMESTAMP() WHERE updated_at IS NULL");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS wallet_transactions (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        type VARCHAR(50) NOT NULL,
        amount BIGINT NOT NULL,
        reference VARCHAR(190) NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_wallet_transactions_user_id(user_id,id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $txCols = [];
    foreach ($pdo->query("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='wallet_transactions'")->fetchAll(PDO::FETCH_COLUMN) as $c) {
        $txCols[strtolower((string)$c)] = true;
    }
    if (!isset($txCols['user_id'])) $pdo->exec("ALTER TABLE wallet_transactions ADD COLUMN user_id BIGINT UNSIGNED NOT NULL DEFAULT 0");
    if (!isset($txCols['type'])) $pdo->exec("ALTER TABLE wallet_transactions ADD COLUMN type VARCHAR(50) NOT NULL DEFAULT 'wallet'");
    if (!isset($txCols['amount'])) $pdo->exec("ALTER TABLE wallet_transactions ADD COLUMN amount BIGINT NOT NULL DEFAULT 0");
    if (!isset($txCols['reference'])) $pdo->exec("ALTER TABLE wallet_transactions ADD COLUMN reference VARCHAR(190) NULL");
    if (!isset($txCols['created_at'])) $pdo->exec("ALTER TABLE wallet_transactions ADD COLUMN created_at DATETIME NULL");
    $pdo->exec("UPDATE wallet_transactions SET created_at=UTC_TIMESTAMP() WHERE created_at IS NULL");
}

function ensure_wallet(PDO $pdo, int $userId): void {
    $pdo->prepare('INSERT INTO wallets(user_id,balance,created_at,updated_at) VALUES(?,0,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE user_id=user_id')->execute([$userId]);
}

/** Award the once-per-UTC-day activity bonus atomically. */
function grant_daily_login_reward_status(int $userId): array {
    $pdo = db(); $reward=500; $pdo->beginTransaction();
    try {
        $stmt=$pdo->prepare('INSERT IGNORE INTO daily_coin_rewards(user_id,reward_date,amount,created_at) VALUES(?,UTC_DATE(),?,UTC_TIMESTAMP())'); $stmt->execute([$userId,$reward]); $awarded=$stmt->rowCount()===1;
        if($awarded){ $pdo->prepare('INSERT INTO wallets(user_id,balance,created_at,updated_at) VALUES(?,0,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE user_id=user_id')->execute([$userId]); $pdo->prepare('UPDATE wallets SET balance=balance+?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$reward,$userId]); $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')->execute([$userId,'daily_login',$reward,'daily:'.gmdate('Y-m-d')]); }
        $q=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=?');$q->execute([$userId]);$balance=(int)$q->fetchColumn(); $pdo->commit(); return ['balance'=>$balance,'awarded'=>$awarded,'amount'=>$reward];
    } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
function grant_daily_login_reward(int $userId): int {
    $pdo = db();
    $reward = 500;
    $pdo->beginTransaction();
    try {
        $stmt=$pdo->prepare('INSERT IGNORE INTO daily_coin_rewards(user_id,reward_date,amount,created_at) VALUES(?,UTC_DATE(),?,UTC_TIMESTAMP())');
        $stmt->execute([$userId,$reward]);
        $awarded = $stmt->rowCount() === 1;
        if ($awarded) {
            $pdo->prepare('INSERT INTO wallets(user_id,balance,created_at,updated_at) VALUES(?,0,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE user_id=user_id')->execute([$userId]);
            $pdo->prepare('UPDATE wallets SET balance=balance+?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$reward,$userId]);
            $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')
                ->execute([$userId,'daily_login',$reward,'daily:'.gmdate('Y-m-d')]);
        }
        $s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=?');
        $s->execute([$userId]);
        $balance=(int)$s->fetchColumn();
        $pdo->commit();
        return $balance;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function credit_wallet(PDO $pdo, int $userId, int $amount, string $type, string $reference): int {
    if ($amount <= 0) fail('INVALID_CREDIT',422);
    ensure_wallet($pdo,$userId);
    $s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
    $s->execute([$userId]);
    $balance=$s->fetchColumn();
    if ($balance === false) fail('WALLET_NOT_FOUND',404);
    $new=(int)$balance+$amount;
    $pdo->prepare('UPDATE wallets SET balance=?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$new,$userId]);
    $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')->execute([$userId,$type,$amount,$reference]);
    return $new;
}

function debit_wallet(PDO $pdo, int $userId, int $amount, string $type, string $reference): int {
    if ($amount <= 0) fail('INVALID_DEBIT',422);
    ensure_wallet($pdo,$userId);
    $s=$pdo->prepare('SELECT balance FROM wallets WHERE user_id=? FOR UPDATE');
    $s->execute([$userId]);
    $balance=$s->fetchColumn();
    if ($balance === false) fail('WALLET_NOT_FOUND',404);
    $balance=(int)$balance;
    if ($balance < $amount) fail('INSUFFICIENT_COINS',409);
    $new=$balance-$amount;
    $pdo->prepare('UPDATE wallets SET balance=?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')->execute([$new,$userId]);
    $pdo->prepare('INSERT INTO wallet_transactions(user_id,type,amount,reference,created_at) VALUES(?,?,?,?,UTC_TIMESTAMP())')->execute([$userId,$type,-$amount,$reference]);
    return $new;
}
