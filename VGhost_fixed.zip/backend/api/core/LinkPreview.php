<?php
declare(strict_types=1);

/** Link preview support shared by messages/send and messages/list. */
function ensure_link_preview_schema(PDO $pdo): void {
    $cols = [
        'link_preview_url' => "ALTER TABLE messages ADD COLUMN link_preview_url VARCHAR(2048) NULL",
        'link_preview_title' => "ALTER TABLE messages ADD COLUMN link_preview_title VARCHAR(500) NULL",
        'link_preview_description' => "ALTER TABLE messages ADD COLUMN link_preview_description TEXT NULL",
        'link_preview_image' => "ALTER TABLE messages ADD COLUMN link_preview_image VARCHAR(2048) NULL",
        'link_preview_site' => "ALTER TABLE messages ADD COLUMN link_preview_site VARCHAR(190) NULL",
        'link_preview_type' => "ALTER TABLE messages ADD COLUMN link_preview_type VARCHAR(30) NULL",
        'link_preview_video' => "ALTER TABLE messages ADD COLUMN link_preview_video VARCHAR(2048) NULL"
    ];
    foreach ($cols as $col => $sql) {
        try {
            $q = $pdo->query("SHOW COLUMNS FROM messages LIKE '" . $col . "'");
            if (!$q->fetch(PDO::FETCH_ASSOC)) $pdo->exec($sql);
        } catch (Throwable $e) {
            // A legacy DB can continue without previews; the caller will use the
            // fallback insert/select paths below.
        }
    }
}

function vg_preview_first_url(string $text): ?string {
    if (!preg_match('~https?://[^\s<>"\']+~iu', $text, $m)) return null;
    $url = trim($m[0], " \t\r\n<>\"'.,;!?)]}");
    if ($url === '' || strlen($url) > 2048) return null;
    $parts = parse_url($url);
    if (!$parts || empty($parts['host']) || !in_array(strtolower((string)($parts['scheme'] ?? '')), ['http','https'], true)) return null;
    return $url;
}

function vg_preview_host_allowed(string $host): bool {
    $host = strtolower(trim($host));
    if ($host === '' || $host === 'localhost' || str_ends_with($host, '.local')) return false;
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        return (bool)filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }
    $ips = @gethostbynamel($host) ?: [];
    if (!$ips) return false;
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
    }
    return true;
}

function vg_preview_http(string $url, int $maxBytes = 1200000): ?string {
    if (!function_exists('curl_init')) return null;
    $current = $url;
    for ($hop = 0; $hop < 4; $hop++) {
        $parts = parse_url($current);
        $host = (string)($parts['host'] ?? '');
        if (!$host || !in_array(strtolower((string)($parts['scheme'] ?? '')), ['http','https'], true) || !vg_preview_host_allowed($host)) return null;
        $body = '';
        $location = null;
        $ch = curl_init($current);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 2,
            CURLOPT_TIMEOUT => 2,
            CURLOPT_USERAGENT => 'VGhost-LinkPreview/1.0',
            CURLOPT_HTTPHEADER => ['Accept: text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.5'],
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_ENCODING => '',
            CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$body, $maxBytes): int {
                $remaining = $maxBytes - strlen($body);
                if ($remaining <= 0) return 0;
                $take = substr($chunk, 0, $remaining);
                $body .= $take;
                return strlen($chunk);
            },
            CURLOPT_HEADERFUNCTION => static function ($ch, string $header) use (&$location): int {
                if (stripos($header, 'Location:') === 0) $location = trim(substr($header, 9));
                return strlen($header);
            },
        ]);
        $ok = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $contentType = strtolower((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
        curl_close($ch);
        if ($ok === false) return null;
        if ($code >= 300 && $code < 400 && $location) {
            $next = vg_preview_abs_url($location, $current);
            if (!$next) return null;
            $current = $next;
            continue;
        }
        if ($code < 200 || $code >= 400) return null;
        if ($body === '' || (strpos($contentType, 'html') === false && strpos($contentType, 'xhtml') === false && strpos($contentType, 'json') === false)) return null;
        return $body;
    }
    return null;
}
function vg_preview_abs_url(string $value, string $base): ?string {
    $value = trim(html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($value === '') return null;
    if (preg_match('~^https?://~i', $value)) return strlen($value) <= 2048 ? $value : null;
    if (str_starts_with($value, '//')) {
        $scheme = (string)(parse_url($base, PHP_URL_SCHEME) ?: 'https');
        return $scheme . ':' . substr($value, 2);
    }
    $p = parse_url($base);
    if (!$p || empty($p['host'])) return null;
    $scheme = strtolower((string)($p['scheme'] ?? 'https'));
    $origin = $scheme . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    if (str_starts_with($value, '/')) return $origin . $value;
    $path = (string)($p['path'] ?? '/');
    $dir = rtrim(str_replace('\\', '/', dirname($path)), '/');
    return $origin . ($dir ? '/' . $dir . '/' : '/') . $value;
}

function vg_preview_oembed(string $url, string $provider): ?array {
    $endpoint = $provider === 'youtube'
        ? 'https://www.youtube.com/oembed?url=' . rawurlencode($url) . '&format=json'
        : 'https://www.tiktok.com/oembed?url=' . rawurlencode($url);
    $json = vg_preview_http($endpoint, 200000);
    if (!$json) return null;
    $data = json_decode($json, true);
    if (!is_array($data)) return null;
    return [
        'url' => $url,
        'title' => trim((string)($data['title'] ?? '')),
        'description' => trim((string)($data['author_name'] ?? '')),
        'image' => vg_preview_abs_url((string)($data['thumbnail_url'] ?? ''), $url),
        'site' => $provider === 'youtube' ? 'YouTube' : 'TikTok',
        'type' => 'video'
    ];
}

function extract_meta_value(string $tag, string $key): ?string {
    $pattern = '~(?:property|name)\\s*=\\s*["\\\']' . preg_quote($key, '~') . '["\\\'][^>]*content\\s*=\\s*["\\\']([^"\\\']*)["\\\']~iu';
    if (preg_match($pattern, $tag, $m)) return html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $pattern = '~content\\s*=\\s*["\\\']([^"\\\']*)["\\\'][^>]*(?:property|name)\\s*=\\s*["\\\']' . preg_quote($key, '~') . '["\\\']~iu';
    if (preg_match($pattern, $tag, $m)) return html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return null;
}

function vg_link_preview(string $url): ?array {
    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    if ($host === '') return null;
    $pathLower = strtolower((string)(parse_url($url, PHP_URL_PATH) ?? ''));
    if (preg_match('~\.(?:mp4|webm|m4v|mov)(?:$|[?#])~i', $pathLower)) {
        return ['url'=>$url,'title'=>basename((string)(parse_url($url, PHP_URL_PATH) ?? 'Video')),'description'=>'','image'=>null,'site'=>$host,'type'=>'video','video'=>$url];
    }
    if (preg_match('~(^|\\.)youtube\\.com$~i', $host) || preg_match('~(^|\\.)youtu\\.be$~i', $host)) {
        $p = vg_preview_oembed($url, 'youtube');
        if ($p) return $p;
    }
    if (preg_match('~(^|\\.)tiktok\\.com$~i', $host)) {
        $p = vg_preview_oembed($url, 'tiktok');
        if ($p) return $p;
    }

    $html = vg_preview_http($url);
    if (!$html) return null;
    $title = '';
    if (preg_match('~<title[^>]*>(.*?)</title>~isu', $html, $m)) $title = trim(preg_replace('/\\s+/u', ' ', strip_tags(html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8'))));
    $meta = [];
    if (preg_match_all('~<meta\\b[^>]*>~iu', $html, $tags)) {
        foreach ($tags[0] as $tag) {
            foreach (['og:title','og:description','og:image','og:image:url','og:image:secure_url','og:site_name','og:type','og:video','og:video:url','og:video:secure_url','twitter:title','twitter:description','twitter:image','twitter:image:src','twitter:player:stream'] as $key) {
                if (!isset($meta[$key])) {
                    $v = extract_meta_value($tag, $key);
                    if ($v !== null && $v !== '') $meta[$key] = $v;
                }
            }
        }
    }
    $finalTitle = trim((string)($meta['og:title'] ?? $meta['twitter:title'] ?? $title));
    $description = trim((string)($meta['og:description'] ?? $meta['twitter:description'] ?? ''));
    $imageRaw = (string)($meta['og:image'] ?? $meta['og:image:url'] ?? $meta['og:image:secure_url'] ?? $meta['twitter:image'] ?? $meta['twitter:image:src'] ?? '');
    $image = vg_preview_abs_url($imageRaw, $url);
    if ($image === null && preg_match('~<link\b[^>]*rel\s*=\s*[\"\']image_src[\"\'][^>]*>~iu', $html, $linkTag)) {
        if (preg_match('~href\s*=\s*[\"\']([^\"\']+)~iu', $linkTag[0], $lm)) $image = vg_preview_abs_url($lm[1], $url);
    }
    $videoRaw = (string)($meta['og:video'] ?? $meta['og:video:url'] ?? $meta['og:video:secure_url'] ?? $meta['twitter:player:stream'] ?? '');
    $video = vg_preview_abs_url($videoRaw, $url);
    if ($video === null && preg_match('~<video\b[^>]*>.*?<source\b[^>]*src\s*=\s*[\"\']([^\"\']+)~isu', $html, $vm)) {
        $video = vg_preview_abs_url($vm[1], $url);
    }
    $pathLower = strtolower((string)(parse_url($url, PHP_URL_PATH) ?? ''));
    if ($video === null && preg_match('~\.(?:mp4|webm|m4v|mov)(?:$|[?#])~i', $pathLower)) $video = $url;
    $type = ($video !== null || str_starts_with(strtolower((string)($meta['og:type'] ?? '')), 'video') || !empty($meta['og:video'])) ? 'video' : 'website';
    $site = trim((string)($meta['og:site_name'] ?? $host));
    if ($finalTitle === '' && $description === '' && $image === null) {
        $finalTitle = $site !== '' ? $site : $host;
        $description = $url;
    }
    return [
        'url' => $url,
        'title' => substr($finalTitle, 0, 500),
        'description' => substr($description, 0, 1000),
        'image' => $image,
        'site' => substr($site, 0, 190),
        'type' => $type,
        'video' => $video
    ];
}
