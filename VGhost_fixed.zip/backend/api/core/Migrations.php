<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';


/** Ensure all private runtime storage directories exist before upload/backup endpoints use them. */
function ensure_storage_directories(): void {
    static $done=false; if($done) return; $done=true;
    $root=dirname(__DIR__,2).'/storage';
    $dirs=[
        $root,
        $root.'/voice',
        $root.'/media',
        $root.'/profile_avatars',
        $root.'/stories',
        $root.'/stories/.chunks',
        $root.'/exports',
        $root.'/imports',
    ];
    foreach($dirs as $dir){
        if(!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir)) {
            throw new RuntimeException('STORAGE_UNAVAILABLE');
        }
    }
}

/** Lightweight idempotent schema upgrade for already-installed VGHOST databases. */
function ensure_runtime_schema(): void {
    static $done=false; if($done)return; $done=true;
    $pdo=db();
    // Do not run incompatible CREATE statements on every API request.
    // Only bootstrap missing tables; existing production schemas are left untouched.
    $has = static function(PDO $pdo, string $table): bool {
        $q=$pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');
        $q->execute([$table]); return (int)$q->fetchColumn()>0;
    };
    if (!$has($pdo,'app_notifications')) {
        $pdo->exec('CREATE TABLE app_notifications (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,type VARCHAR(64) NOT NULL,title VARCHAR(190) NOT NULL,body TEXT NOT NULL,data_json TEXT NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,read_at DATETIME NULL,INDEX(user_id,is_read,created_at),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB');
    }
    if (!$has($pdo,'daily_coin_rewards')) {
        $pdo->exec('CREATE TABLE daily_coin_rewards (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,reward_date DATE NOT NULL,amount BIGINT NOT NULL DEFAULT 500,created_at DATETIME NOT NULL,UNIQUE KEY daily_user_date(user_id,reward_date),INDEX(reward_date),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB');
    }
}


/** Ensure message storage supports 4-byte Unicode characters (emoji). */
function ensure_ugc_reports_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS content_reports (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            reporter_id BIGINT UNSIGNED NOT NULL,
            target_type ENUM('message','user','story') NOT NULL,
            target_id BIGINT UNSIGNED NOT NULL,
            reason VARCHAR(255) NOT NULL,
            status ENUM('pending','reviewed','actioned','dismissed') NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL,
            reviewed_at DATETIME NULL,
            reviewed_by BIGINT UNSIGNED NULL,
            INDEX idx_reports_status_created(status,created_at),
            INDEX idx_reports_target(target_type,target_id),
            UNIQUE KEY one_pending_report(reporter_id,target_type,target_id,status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch(Throwable $e) {}
}

function ensure_message_attachment_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $defs=[
            'attachment_path'=>"ALTER TABLE messages ADD COLUMN attachment_path VARCHAR(500) NULL",
            'attachment_type'=>"ALTER TABLE messages ADD COLUMN attachment_type VARCHAR(80) NULL",
            'attachment_name'=>"ALTER TABLE messages ADD COLUMN attachment_name VARCHAR(255) NULL",
            'attachment_size'=>"ALTER TABLE messages ADD COLUMN attachment_size BIGINT UNSIGNED NULL",
        ];
        foreach($defs as $column=>$sql){
            $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='messages' AND column_name=?");
            $q->execute([$column]);
            if((int)$q->fetchColumn()===0){
                try { $pdo->exec($sql); } catch(Throwable $e) { /* endpoint will return a clear schema error if storage is truly incompatible */ }
            }
        }
    } catch(Throwable $e) {}
}

function ensure_utf8mb4_schema(): void {
    static $done=false; if($done)return; $done=true;
    $pdo=db();
    // Existing installations may have tables created with MySQL's old utf8/latin1 defaults.
    // Convert only text-bearing tables; this is idempotent and allows emoji such as ❤️🤣🐈.
    foreach (['messages','app_notifications','user_profiles','gifts','gift_transactions'] as $table) {
        try {
            $q=$pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');
            $q->execute([$table]);
            if ((int)$q->fetchColumn() > 0) {
                $pdo->exec("ALTER TABLE `$table` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            }
        } catch (Throwable $e) {
            // Do not take the API down if a hosting account lacks ALTER permission.
            // New installs are still created as utf8mb4 via schema.sql.
        }
    }
}


function ensure_gift_catalog(): void {
    static $done=false; if($done)return; $done=true;
    $pdo=db();
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS gifts (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            coin_cost BIGINT NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS gift_transactions (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            sender_id BIGINT UNSIGNED NOT NULL,
            receiver_id BIGINT UNSIGNED NOT NULL,
            gift_id BIGINT UNSIGNED NOT NULL,
            coin_cost BIGINT NOT NULL,
            created_at DATETIME NOT NULL,
            INDEX(sender_id), INDEX(receiver_id),
            FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(gift_id) REFERENCES gifts(id) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $catalog=[
            [1,'love',10],[2,'rose',20],[3,'diamond',50],[4,'crown',100],[5,'cake',150],
            [6,'gift_box',200],[7,'money_bag',300],[8,'butterfly',400],[9,'fire',500],[10,'rocket',750],
            [11,'dragon',1000],[12,'trophy',1500],[13,'thunder',2000],[14,'ghost',3000],[15,'galaxy',5000],
            [16,'ufo',7500],[17,'meteor',10000],[18,'castle',15000],[19,'volcano',25000],[20,'vghost_royal',50000]
        ];
        $q=$pdo->prepare('INSERT INTO gifts(id,name,coin_cost,is_active) VALUES(?,?,?,1) ON DUPLICATE KEY UPDATE name=VALUES(name),coin_cost=VALUES(coin_cost),is_active=1');
        foreach($catalog as [$id,$name,$cost]) $q->execute([$id,$name,$cost]);
    } catch(Throwable $e) { /* optional gift migration must never break an otherwise healthy API */ }
}

function ensure_push_settings_schema(): void {
    static $done=false; if($done)return; $done=true;
    $pdo=db();
    try {
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='push_enabled'");
        $q->execute();
        if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN push_enabled TINYINT(1) NOT NULL DEFAULT 1");
    } catch(Throwable $e) { /* keep API online if ALTER is unavailable */ }
}

function ensure_activity_level_schema(): void {
    static $done=false; if($done)return; $done=true;
    $pdo=db();
    try {
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='activity_xp'");
        $q->execute();
        if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN activity_xp INT UNSIGNED NOT NULL DEFAULT 0");
    } catch(Throwable $e) {}
}

function ensure_privacy_settings_schema(): void {
    static $done=false; if($done)return; $done=true;
    $pdo=db();
    try {
        foreach ([
            ['message_permission', "ENUM('everyone','friends','nobody') NOT NULL DEFAULT 'everyone'"],
            ['friend_permission', "ENUM('everyone','nobody') NOT NULL DEFAULT 'everyone'"]
        ] as [$column,$definition]) {
            $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name=?");
            $q->execute([$column]);
            if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN `$column` $definition");
        }
    } catch(Throwable $e) {}
}

/** Ensure message reactions exist without changing existing message/Panic behavior. */
function ensure_message_reactions_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='message_reactions'");
        $q->execute();
        if((int)$q->fetchColumn()===0) {
            // Some older production databases use a slightly different integer
            // definition for messages/users. Create the reaction table first
            // without foreign keys, so reactions still work on those installs.
            // The API only accepts reactions for messages the authenticated user
            // can access, so referential integrity is enforced by react.php.
            try {
                $pdo->exec('CREATE TABLE message_reactions (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,message_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,reaction VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,UNIQUE KEY one_reaction_per_user(message_id,user_id),INDEX(message_id),INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
            } catch (Throwable $e) {
                // If the server rejects the BIGINT definition, retry with the
                // widest compatible signed integer type and no foreign keys.
                try {
                    $pdo->exec('CREATE TABLE IF NOT EXISTS message_reactions (id BIGINT AUTO_INCREMENT PRIMARY KEY,message_id BIGINT NOT NULL,user_id BIGINT NOT NULL,reaction VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,UNIQUE KEY one_reaction_per_user(message_id,user_id),INDEX(message_id),INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
                } catch (Throwable $ignored) {}
            }
        } else {
            try {
                $pdo->exec("ALTER TABLE message_reactions MODIFY reaction VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL");
            } catch (Throwable $e) { /* keep API online if ALTER is unavailable */ }
        }
    } catch(Throwable $e) { /* Never take the existing API down if migration is unavailable. */ }
}


/** Ensure admin coin-transfer security storage exists. */

/** Ensure the VGHOST sticker catalog and message sticker linkage exist. */
function ensure_sticker_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS stickers (
            id BIGINT UNSIGNED PRIMARY KEY,
            sticker_key VARCHAR(64) NOT NULL UNIQUE,
            emoji VARCHAR(32) NOT NULL,
            label VARCHAR(190) NOT NULL,
            image_url VARCHAR(1000) NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            sort_order INT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            INDEX(is_active,sort_order)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='messages' AND column_name='sticker_id'");
        $q->execute();
        if((int)$q->fetchColumn()===0) {
            try { $pdo->exec("ALTER TABLE messages ADD COLUMN sticker_id BIGINT UNSIGNED NULL AFTER message_type, ADD INDEX idx_messages_sticker_id(sticker_id)"); } catch(Throwable $e) {}
        }

        $catalog = [
            [1,'sticker_001','🖼️','Sticker 1','stickers/sticker_001.webp'],
            [2,'sticker_002','🖼️','Sticker 2','stickers/sticker_002.webp'],
            [3,'sticker_003','🖼️','Sticker 3','stickers/sticker_003.webp'],
            [4,'sticker_004','🖼️','Sticker 4','stickers/sticker_004.webp'],
            [5,'sticker_005','🖼️','Sticker 5','stickers/sticker_005.webp'],
            [6,'sticker_006','🖼️','Sticker 6','stickers/sticker_006.webp'],
            [7,'sticker_007','🖼️','Sticker 7','stickers/sticker_007.webp'],
            [8,'sticker_008','🖼️','Sticker 8','stickers/sticker_008.webp'],
            [9,'sticker_009','🖼️','Sticker 9','stickers/sticker_009.webp'],
            [10,'sticker_010','🖼️','Sticker 10','stickers/sticker_010.webp'],
            [11,'sticker_011','🖼️','Sticker 11','stickers/sticker_011.webp'],
            [12,'sticker_012','🖼️','Sticker 12','stickers/sticker_012.webp'],
            [13,'sticker_013','🖼️','Sticker 13','stickers/sticker_013.webp'],
            [14,'sticker_014','🖼️','Sticker 14','stickers/sticker_014.webp'],
            [15,'sticker_015','🖼️','Sticker 15','stickers/sticker_015.webp'],
            [16,'sticker_016','🖼️','Sticker 16','stickers/sticker_016.webp'],
            [17,'sticker_017','🖼️','Sticker 17','stickers/sticker_017.webp'],
            [18,'sticker_018','🖼️','Sticker 18','stickers/sticker_018.webp'],
            [19,'sticker_019','🖼️','Sticker 19','stickers/sticker_019.webp'],
            [20,'sticker_020','🖼️','Sticker 20','stickers/sticker_020.webp'],
            [21,'sticker_021','🖼️','Sticker 21','stickers/sticker_021.webp'],
            [22,'sticker_022','🖼️','Sticker 22','stickers/sticker_022.webp'],
            [23,'sticker_023','🖼️','Sticker 23','stickers/sticker_023.webp'],
            [24,'sticker_024','🖼️','Sticker 24','stickers/sticker_024.webp'],
            [25,'sticker_025','🖼️','Sticker 25','stickers/sticker_025.webp'],
            [26,'sticker_026','🖼️','Sticker 26','stickers/sticker_026.webp'],
            [27,'sticker_027','🖼️','Sticker 27','stickers/sticker_027.webp'],
            [28,'sticker_028','🖼️','Sticker 28','stickers/sticker_028.webp'],
            [29,'sticker_029','🖼️','Sticker 29','stickers/sticker_029.webp'],
            [30,'sticker_030','🖼️','Sticker 30','stickers/sticker_030.webp'],
            [31,'sticker_031','🖼️','Sticker 31','stickers/sticker_031.webp'],
            [32,'sticker_032','🖼️','Sticker 32','stickers/sticker_032.webp'],
            [33,'sticker_033','🖼️','Sticker 33','stickers/sticker_033.webp'],
            [34,'sticker_034','🖼️','Sticker 34','stickers/sticker_034.webp'],
            [35,'sticker_035','🖼️','Sticker 35','stickers/sticker_035.webp'],
            [36,'sticker_036','🖼️','Sticker 36','stickers/sticker_036.webp'],
            [37,'sticker_037','🖼️','Sticker 37','stickers/sticker_037.webp'],
            [38,'sticker_038','🖼️','Sticker 38','stickers/sticker_038.webp'],
            [39,'sticker_039','🖼️','Sticker 39','stickers/sticker_039.webp'],
            [40,'sticker_040','🖼️','Sticker 40','stickers/sticker_040.webp'],
            [41,'sticker_041','🖼️','Sticker 41','stickers/sticker_041.webp'],
            [42,'sticker_042','🖼️','Sticker 42','stickers/sticker_042.webp'],
            [43,'sticker_043','🖼️','Sticker 43','stickers/sticker_043.webp'],
            [44,'sticker_044','🖼️','Sticker 44','stickers/sticker_044.webp'],
            [45,'sticker_045','🖼️','Sticker 45','stickers/sticker_045.webp'],
            [46,'sticker_046','🖼️','Sticker 46','stickers/sticker_046.webp'],
            [47,'sticker_047','🖼️','Sticker 47','stickers/sticker_047.webp'],
            [48,'sticker_048','🖼️','Sticker 48','stickers/sticker_048.webp'],
            [49,'sticker_049','🖼️','Sticker 49','stickers/sticker_049.webp'],
            [50,'sticker_050','🖼️','Sticker 50','stickers/sticker_050.webp'],
            [51,'sticker_051','🖼️','Sticker 51','stickers/sticker_051.webp'],
            [52,'sticker_052','🖼️','Sticker 52','stickers/sticker_052.webp'],
            [53,'sticker_053','🖼️','Sticker 53','stickers/sticker_053.webp'],
            [54,'sticker_054','🖼️','Sticker 54','stickers/sticker_054.webp'],
            [55,'sticker_055','🖼️','Sticker 55','stickers/sticker_055.webp'],
            [56,'sticker_056','🖼️','Sticker 56','stickers/sticker_056.webp'],
            [57,'sticker_057','🖼️','Sticker 57','stickers/sticker_057.webp'],
            [58,'sticker_058','🖼️','Sticker 58','stickers/sticker_058.webp'],
            [59,'sticker_059','🖼️','Sticker 59','stickers/sticker_059.webp'],
            [60,'sticker_060','🖼️','Sticker 60','stickers/sticker_060.webp'],
            [61,'sticker_061','🖼️','Sticker 61','stickers/sticker_061.webp'],
            [62,'sticker_062','🖼️','Sticker 62','stickers/sticker_062.webp'],
            [63,'sticker_063','🖼️','Sticker 63','stickers/sticker_063.webp'],
            [64,'sticker_064','🖼️','Sticker 64','stickers/sticker_064.webp'],
            [65,'sticker_065','🖼️','Sticker 65','stickers/sticker_065.webp'],
            [66,'sticker_066','🖼️','Sticker 66','stickers/sticker_066.webp'],
            [67,'sticker_067','🖼️','Sticker 67','stickers/sticker_067.webp'],
            [68,'sticker_068','🖼️','Sticker 68','stickers/sticker_068.webp'],
            [69,'sticker_069','🖼️','Sticker 69','stickers/sticker_069.webp'],
            [70,'sticker_070','🖼️','Sticker 70','stickers/sticker_070.webp'],
            [71,'sticker_071','🖼️','Sticker 71','stickers/sticker_071.webp'],
            [72,'sticker_072','🖼️','Sticker 72','stickers/sticker_072.webp'],
        ];
        $ins=$pdo->prepare("INSERT INTO stickers(id,sticker_key,emoji,label,image_url,is_active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,1,?,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE sticker_key=VALUES(sticker_key),emoji=VALUES(emoji),label=VALUES(label),image_url=VALUES(image_url),is_active=1,sort_order=VALUES(sort_order),updated_at=UTC_TIMESTAMP()");
        foreach($catalog as $i=>$row) { [$id,$key,$emoji,$label,$imageUrl]=$row; $ins->execute([$id,$key,$emoji,$label,$imageUrl,$i+1]); }
    } catch(Throwable $e) { /* Sticker support must never take the existing API down. */ }

        try { sync_sticker_files($pdo); } catch (Throwable $e) { /* catalog sync is best-effort */ }
}


function ensure_idempotency_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS api_idempotency_keys (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,endpoint VARCHAR(120) NOT NULL,idem_key_hash CHAR(64) NOT NULL,request_hash CHAR(64) NOT NULL,status ENUM('pending','completed') NOT NULL DEFAULT 'pending',response_json LONGTEXT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,expires_at DATETIME NOT NULL,UNIQUE KEY uq_idem(user_id,endpoint,idem_key_hash),INDEX idx_idem_exp(expires_at),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch(Throwable $e) {}
}

function ensure_admin_coin_security_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_security (id TINYINT UNSIGNED PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, code_hash VARCHAR(255) NOT NULL, locked TINYINT(1) NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL, FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_coin_code_reset_tokens (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, admin_user_id BIGINT UNSIGNED NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL, used_at DATETIME NULL, created_at DATETIME NOT NULL, INDEX(admin_user_id), INDEX(expires_at), FOREIGN KEY(admin_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) { /* Existing API remains available if migration permission is temporarily unavailable. */ }
}

/** Sync backend sticker files into the sticker catalog automatically. */
function sync_sticker_files(PDO $pdo): void {
    $dir=dirname(__DIR__,2).'/stickers';
    if(!is_dir($dir)) return;
    $allowed=['webp','png','jpg','jpeg','gif']; $keys=[];
    foreach(scandir($dir) ?: [] as $name){
        if($name==='.'||$name==='..') continue; $path=$dir.'/'.$name; if(!is_file($path)) continue;
        $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION)); if(!in_array($ext,$allowed,true)) continue;
        $base=pathinfo($name,PATHINFO_FILENAME); if($base==='') continue;
        $key=preg_replace('/[^A-Za-z0-9_-]+/','_',strtolower($base)); $key=trim((string)$key,'_'); if($key==='') continue;
        $row=$pdo->prepare('SELECT id FROM stickers WHERE sticker_key=? LIMIT 1'); $row->execute([$key]); $id=$row->fetchColumn();
        if($id===false){ $numeric=null; if(preg_match('/(?:^|_)(\d+)$/',$base,$m)) $numeric=(int)$m[1]; if(!$numeric||$numeric<1) $numeric=(int)$pdo->query('SELECT COALESCE(MAX(id),0)+1 FROM stickers')->fetchColumn(); $chk=$pdo->prepare('SELECT id FROM stickers WHERE id=? LIMIT 1'); $chk->execute([$numeric]); if($chk->fetchColumn()!==false) $numeric=(int)$pdo->query('SELECT COALESCE(MAX(id),0)+1 FROM stickers')->fetchColumn(); $id=$numeric; }
        $label=ucwords(trim((string)preg_replace('/[_-]+/',' ',$base))); $url='/stickers/'.rawurlencode($name);
        $up=$pdo->prepare('INSERT INTO stickers(id,sticker_key,emoji,label,image_url,is_active,sort_order,created_at,updated_at) VALUES(?,?,?,?,?,1,?,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE sticker_key=VALUES(sticker_key),label=VALUES(label),image_url=VALUES(image_url),is_active=1,sort_order=VALUES(sort_order),updated_at=UTC_TIMESTAMP()');
        $up->execute([(int)$id,$key,'🖼️',$label,$url,(int)$id]); $keys[]=$key;
    }
    if($keys){ $ph=implode(',',array_fill(0,count($keys),'?')); $pdo->prepare("UPDATE stickers SET is_active=0,updated_at=UTC_TIMESTAMP() WHERE sticker_key NOT IN ($ph)")->execute($keys); } else $pdo->exec('UPDATE stickers SET is_active=0,updated_at=UTC_TIMESTAMP()');
}


function ensure_vip_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='is_vip'");
        $q->execute();
        if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN is_vip TINYINT(1) NOT NULL DEFAULT 0 AFTER is_ghost");
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='vip_expires_at'");
        $q->execute();
        if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN vip_expires_at DATETIME NULL AFTER is_vip");
        $pdo->exec("CREATE TABLE IF NOT EXISTS vip_purchases (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED NOT NULL,
            product_id VARCHAR(64) NOT NULL,
            purchase_token VARCHAR(512) NOT NULL,
            order_id VARCHAR(128) NULL,
            duration_days INT UNSIGNED NOT NULL,
            purchase_time_ms BIGINT UNSIGNED NULL,
            granted_until DATETIME NULL,
            consumed TINYINT(1) NOT NULL DEFAULT 0,
            status ENUM('granted','pending_consume','rejected','refunded') NOT NULL DEFAULT 'granted',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            UNIQUE KEY uq_vip_purchase_token (purchase_token),
            KEY idx_vip_user_status (user_id,status,granted_until),
            CONSTRAINT fk_vip_purchase_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch(Throwable $e) { error_log('VGHOST VIP schema: '.$e->getMessage()); }
}



/** Ensure admin bans support automatic expiry without changing existing ban behavior. */
function ensure_admin_ban_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='ban_expires_at'");
        $q->execute();
        if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN ban_expires_at DATETIME NULL AFTER is_banned");
        // Expired temporary bans are automatically cleared. Permanent bans keep NULL.
        $pdo->exec("UPDATE users SET is_banned=0, ban_expires_at=NULL WHERE is_banned=1 AND ban_expires_at IS NOT NULL AND ban_expires_at<=UTC_TIMESTAMP()");
    } catch(Throwable $e) { error_log('VGHOST admin ban schema: '.$e->getMessage()); }
}

/** Ensure persistent VIP profile-frame selection exists. */
function ensure_vip_frame_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name='vip_frame_id'");
        $q->execute();
        if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN vip_frame_id VARCHAR(32) NOT NULL DEFAULT 'vip_02' AFTER avatar_id");
        $pdo->exec("UPDATE users SET vip_frame_id='vip_02' WHERE vip_frame_id IS NULL OR vip_frame_id='' OR vip_frame_id NOT IN ('vip_02')");
    } catch(Throwable $e) { error_log('VGHOST VIP frame schema: '.$e->getMessage()); }
}

/** Ensure gender + selectable Ghost avatar columns exist on all existing installs. */
function ensure_avatar_schema(): void {
    static $done=false; if($done)return; $done=true;
    try {
        $pdo=db();
        foreach ([
            ['gender', "ENUM('male','female') NULL"],
            ['avatar_id', "VARCHAR(32) NOT NULL DEFAULT 'ghost'"]
        ] as [$column,$definition]) {
            $q=$pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='users' AND column_name=?");
            $q->execute([$column]);
            if((int)$q->fetchColumn()===0) $pdo->exec("ALTER TABLE users ADD COLUMN `$column` $definition");
        }
        $pdo->exec("UPDATE users SET avatar_id='female' WHERE (avatar_id='ghost' OR avatar_id IS NULL OR avatar_id='') AND gender='female'");
        $pdo->exec("UPDATE users SET avatar_id='male' WHERE (avatar_id='ghost' OR avatar_id IS NULL OR avatar_id='') AND gender='male'");
    } catch(Throwable $e) { /* keep existing API online; schema.sql/update_v30 remains available */ }
}
