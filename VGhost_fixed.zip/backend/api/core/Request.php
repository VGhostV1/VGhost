<?php
declare(strict_types=1);
function request_json(): array {
    $raw = file_get_contents('php://input') ?: '';
    $max = 1048576;
    if (strlen($raw) > $max) fail('PAYLOAD_TOO_LARGE', 413);
    if ($raw === '') return [];
    $data = json_decode($raw, true);
    if (!is_array($data)) fail('INVALID_JSON', 400);
    return $data;
}
function require_method(string $method): void { if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $method) fail('METHOD_NOT_ALLOWED',405); }
function bearer_token(): ?string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $h, $m)) return trim($m[1]);
    return null;
}
function input_string(array $in, string $key, int $max=255, bool $required=true): ?string {
    $v = isset($in[$key]) ? trim((string)$in[$key]) : '';
    if ($required && $v === '') fail('MISSING_'.$key);
    if ($v !== '') { $length = function_exists('mb_strlen') ? mb_strlen($v) : strlen($v); if ($length > $max) fail('INVALID_'.$key); }
    return $v === '' ? null : $v;
}

/** Backward-compatible JSON parser alias. */
function json_body(): array { return request_json(); }
