<?php
declare(strict_types=1);

/** Returns [ok=>bool,error=>string,stage=>string,debug=>array]. Never includes SMTP password. */
function smtp_send_detailed(array $cfg,string $to,string $subject,string $html,string $text=''): array {
    $debug=[]; $stage='validate';
    $result=['ok'=>false,'error'=>'','stage'=>$stage,'debug'=>&$debug];
    if(!filter_var($to,FILTER_VALIDATE_EMAIL)) { $result['error']='INVALID_RECIPIENT_EMAIL'; return $result; }

    $host=(string)($cfg['host']??''); $port=(int)($cfg['port']??587);
    $user=(string)($cfg['username']??''); $pass=(string)($cfg['password']??'');
    $enc=strtolower((string)($cfg['encryption']??'tls'));
    $from=(string)($cfg['from_email']??$user);
    $name=(string)($cfg['from_name']??'VGHOST');
    $smtpEnabled=!empty($cfg['enabled']);

    if(!filter_var($from,FILTER_VALIDATE_EMAIL)) {
        // cPanel/PHP mail commonly supplies the envelope sender itself, but the
        // From header still needs a valid address. Derive it from the request host
        // only when no configured sender exists.
        $hostHeader=(string)($_SERVER['HTTP_HOST']??'');
        $hostHeader=preg_replace('/:\\d+$/','',$hostHeader);
        if($from==='' && $hostHeader && preg_match('/^[A-Za-z0-9.-]+$/',$hostHeader)) {
            $from='noreply@'.$hostHeader;
        }
    }
    if(!filter_var($from,FILTER_VALIDATE_EMAIL)) {
        $result['error']='INVALID_FROM_EMAIL';
        return $result;
    }

    $encodedSubject='=?UTF-8?B?'.base64_encode($subject).'?=';
    $plain=$text?:strip_tags($html);
    $headers="From: =?UTF-8?B?".base64_encode($name)."?= <{$from}>\r\n"
        ."Reply-To: <{$from}>\r\n"
        ."MIME-Version: 1.0\r\n"
        ."Content-Type: text/html; charset=UTF-8\r\n"
        ."Content-Transfer-Encoding: 8bit\r\n";

    // First use the configured SMTP transport when available.
    if($smtpEnabled) {
        if($host==='') { $debug[]='SMTP enabled but host is missing'; }
        elseif(!in_array($enc,['ssl','tls','none',''],true)) { $debug[]='Invalid SMTP encryption: '.$enc; }
        else {
            $stage='connect'; $remote=(($enc==='ssl')?'ssl://':'').$host.':'.$port;
            $debug[]='Connecting to '.$host.':'.$port.' ('.$enc.')';
            $errno=0; $errstr='';
            $fp=@stream_socket_client($remote,$errno,$errstr,20,STREAM_CLIENT_CONNECT);
            if($fp){
                stream_set_timeout($fp,20);
                $read=function()use($fp){$out=''; do{$l=fgets($fp,515);if($l===false)break;$out.=$l;}while(strlen($l)>=4&&$l[3]==='-');return trim($out);};
                $ok=function(string $r,array $codes){foreach($codes as $c)if(preg_match('/^'.$c.'\\b/m',$r))return true;return false;};
                $send=function(string $cmd)use($fp,$read,&$debug){fwrite($fp,$cmd."\r\n");$r=$read();$debug[]='S: '.$r;return $r;};
                try {
                    $stage='greeting'; $r=$read(); $debug[]='S: '.$r; if(!$ok($r,[220])) throw new RuntimeException('SMTP_GREETING_FAILED: '.$r);
                    $stage='ehlo'; $r=$send('EHLO '.preg_replace('/[^A-Za-z0-9.-]/','',gethostname()?:'localhost')); if(!$ok($r,[250])) throw new RuntimeException('EHLO_FAILED: '.$r);
                    if($enc==='tls') { $stage='starttls'; $r=$send('STARTTLS'); if(!$ok($r,[220])) throw new RuntimeException('STARTTLS_FAILED: '.$r); if(!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('TLS_CRYPTO_FAILED'); $stage='ehlo_after_tls'; $r=$send('EHLO localhost'); if(!$ok($r,[250])) throw new RuntimeException('EHLO_AFTER_TLS_FAILED: '.$r); }
                    if($user!=='') { $stage='auth'; $r=$send('AUTH LOGIN'); if(!$ok($r,[334])) throw new RuntimeException('AUTH_LOGIN_FAILED: '.$r); $r=$send(base64_encode($user)); if(!$ok($r,[334])) throw new RuntimeException('AUTH_USERNAME_FAILED: '.$r); $r=$send(base64_encode($pass)); if(!$ok($r,[235])) throw new RuntimeException('AUTH_PASSWORD_FAILED: '.$r); }
                    $stage='mail_from'; $r=$send('MAIL FROM:<'.$from.'>'); if(!$ok($r,[250])) throw new RuntimeException('MAIL_FROM_FAILED: '.$r);
                    $stage='rcpt_to'; $r=$send('RCPT TO:<'.$to.'>'); if(!$ok($r,[250,251])) throw new RuntimeException('RCPT_TO_FAILED: '.$r);
                    $stage='data'; $r=$send('DATA'); if(!$ok($r,[354])) throw new RuntimeException('DATA_FAILED: '.$r);
                    $boundary='b'.bin2hex(random_bytes(12));
                    $msg="From: =?UTF-8?B?".base64_encode($name)."?= <{$from}>\r\nTo: <{$to}>\r\nSubject: {$encodedSubject}\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n\r\n"
                        ."--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$plain}\r\n"
                        ."--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$html}\r\n"
                        ."--{$boundary}--\r\n.";
                    $stage='send_message'; $r=$send($msg); if(!$ok($r,[250])) throw new RuntimeException('MESSAGE_REJECTED: '.$r);
                    @fwrite($fp,"QUIT\r\n"); @fclose($fp);
                    return ['ok'=>true,'error'=>'','stage'=>'complete','debug'=>$debug];
                } catch(Throwable $e) {
                    @fwrite($fp,"QUIT\r\n"); @fclose($fp);
                    $debug[]='SMTP failed at '.$stage.': '.$e->getMessage();
                }
            } else {
                $debug[]='SMTP connect failed: '.$errstr.' ('.$errno.')';
            }
        }
    } else {
        $debug[]='SMTP disabled/not configured; trying PHP mail() fallback';
    }

    // Shared/cPanel hosting often has local PHP mail delivery even when external
    // SMTP credentials are absent or blocked. Use it as a compatibility fallback.
    $mailHeaders=$headers;
    $mailStage='php_mail';
    $mailOk=false;
    try { $mailOk=@mail($to,$encodedSubject,$html,$mailHeaders,'-f'.$from); }
    catch(Throwable $e) { $debug[]='PHP mail exception: '.$e->getMessage(); }
    if($mailOk) return ['ok'=>true,'error'=>'','stage'=>$mailStage,'debug'=>$debug];

    return ['ok'=>false,'error'=>'SMTP_SEND_FAILED','stage'=>$stage,'debug'=>$debug];
}
function smtp_send(array $cfg,string $to,string $subject,string $html,string $text=''): bool { return smtp_send_detailed($cfg,$to,$subject,$html,$text)['ok']; }
