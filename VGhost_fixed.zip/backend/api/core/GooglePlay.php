<?php
declare(strict_types=1);

/** Minimal Google Play Developer API client using a service-account JWT.
 *  No third-party PHP package is required. Credentials stay outside public_html.
 */
function google_play_config(): array {
    $cfg = require __DIR__.'/../config/config.php';
    return $cfg['google_play'] ?? [];
}

function google_play_access_token(): string {
    static $cached = null;
    static $expiresAt = 0;
    if ($cached && $expiresAt > time() + 60) return $cached;

    $cfg = google_play_config();
    $path = (string)($cfg['service_account_json'] ?? '');
    if ($path === '' || !is_file($path)) fail('GOOGLE_PLAY_NOT_CONFIGURED', 503);
    $sa = json_decode((string)file_get_contents($path), true);
    if (!is_array($sa) || empty($sa['client_email']) || empty($sa['private_key'])) fail('GOOGLE_PLAY_NOT_CONFIGURED', 503);

    $now = time();
    $header = ['alg'=>'RS256','typ'=>'JWT'];
    $claims = [
        'iss'=>(string)$sa['client_email'],
        'scope'=>'https://www.googleapis.com/auth/androidpublisher',
        'aud'=>'https://oauth2.googleapis.com/token',
        'iat'=>$now,
        'exp'=>$now+3600,
    ];
    $b64 = static function(array $v): string {
        return rtrim(strtr(base64_encode(json_encode($v, JSON_UNESCAPED_SLASHES)), '+/', '-_'), '=');
    };
    $unsigned = $b64($header).'.'.$b64($claims);
    $signature = '';
    $ok = openssl_sign($unsigned, $signature, (string)$sa['private_key'], OPENSSL_ALGO_SHA256);
    if (!$ok) fail('GOOGLE_PLAY_AUTH_FAILED', 503);
    $jwt = $unsigned.'.'.rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');

    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>http_build_query(['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$jwt]),
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_TIMEOUT=>20,
        CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $body = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($body === false || $http < 200 || $http >= 300) {
        error_log('VGHOST Google Play OAuth failed: '.$http.' '.$err);
        fail('GOOGLE_PLAY_AUTH_FAILED', 503);
    }
    $out = json_decode((string)$body, true);
    $token = (string)($out['access_token'] ?? '');
    if ($token === '') fail('GOOGLE_PLAY_AUTH_FAILED', 503);
    $cached = $token;
    $expiresAt = $now + (int)($out['expires_in'] ?? 3600);
    return $token;
}

function google_play_request(string $method, string $path): array {
    $cfg = google_play_config();
    $package = trim((string)($cfg['package_name'] ?? 'com.vghost.app'));
    if ($package === '') fail('GOOGLE_PLAY_NOT_CONFIGURED', 503);
    $url = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'.rawurlencode($package).'/'.ltrim($path,'/');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST=>$method,
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_TIMEOUT=>25,
        CURLOPT_HTTPHEADER=>['Authorization: Bearer '.google_play_access_token(),'Accept: application/json'],
    ]);
    if ($method === 'POST') curl_setopt($ch, CURLOPT_POSTFIELDS, '');
    $body = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($body === false) {
        error_log('VGHOST Google Play request failed: '.$err);
        fail('GOOGLE_PLAY_UNAVAILABLE', 503);
    }
    $out = json_decode((string)$body, true);
    if ($http < 200 || $http >= 300) {
        error_log('VGHOST Google Play HTTP '.$http.': '.substr((string)$body,0,500));
        fail($http === 404 ? 'PURCHASE_NOT_FOUND' : 'GOOGLE_PLAY_REJECTED', 502);
    }
    return is_array($out) ? $out : [];
}

function google_play_get_product_purchase(string $productId, string $token): array {
    return google_play_request('GET', 'purchases/products/'.rawurlencode($productId).'/tokens/'.rawurlencode($token));
}

function google_play_consume_product(string $productId, string $token): bool {
    google_play_request('POST', 'purchases/products/'.rawurlencode($productId).'/tokens/'.rawurlencode($token).':consume');
    return true;
}
