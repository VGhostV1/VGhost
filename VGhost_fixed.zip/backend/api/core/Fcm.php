<?php
declare(strict_types=1);

/**
 * Firebase Cloud Messaging HTTP v1 adapter.
 *
 * The Firebase service-account credential is NEVER bundled with the Android APK
 * or this deployable ZIP. Configure production using either:
 *
 *   FCM_SERVICE_ACCOUNT_JSON=/absolute/private/path/service-account.json
 *
 * or, preferably when your hosting platform supports secret/env variables:
 *
 *   FCM_SERVICE_ACCOUNT_JSON_CONTENT='{"type":"service_account",...}'
 *
 * The optional api/config/config.php -> ['fcm']['service_account_json'] is kept
 * as a private-file fallback for existing deployments. No credential is shipped
 * in this package.
 */
function fcm_config(): array {
    $cfg = [];
    $file = __DIR__.'/../config/config.php';
    if (is_file($file)) {
        $all = require $file;
        $cfg = is_array($all['fcm'] ?? null) ? $all['fcm'] : [];
    }

    $content = trim((string)(getenv('FCM_SERVICE_ACCOUNT_JSON_CONTENT') ?: ''));
    // cPanel fallback: keep the credential outside public_html.
    $cpanelDefault = '/home/vghostsite/vg-secret/firebase-service-account.json';
    $configuredPath = trim((string)(getenv('FCM_SERVICE_ACCOUNT_JSON') ?: ($cfg['service_account_json'] ?? $cpanelDefault)));
    if ($configuredPath === '') { $configuredPath = $cpanelDefault; }

    $raw = '';
    $source = '';
    if ($content !== '') {
        $raw = $content;
        $source = 'environment_content';
    } elseif ($configuredPath !== '' && is_file($configuredPath) && is_readable($configuredPath)) {
        $raw = (string)file_get_contents($configuredPath);
        $source = 'environment_file';
    }

    if ($raw === '') {
        return [
            'enabled' => (bool)($cfg['enabled'] ?? true),
            'project_id' => '',
            'service_account_json' => $configuredPath,
            'service_account' => null,
            'reason' => 'FCM_NOT_CONFIGURED',
            'source' => '',
        ];
    }

    $sa = json_decode($raw, true);
    if (!is_array($sa) || empty($sa['project_id']) || empty($sa['client_email']) || empty($sa['private_key'])) {
        return [
            'enabled' => false,
            'project_id' => '',
            'service_account_json' => $source === 'environment_file' ? $configuredPath : '',
            'service_account' => null,
            'reason' => 'FCM_INVALID_SERVICE_ACCOUNT',
            'source' => $source,
        ];
    }

    return [
        'enabled' => (bool)($cfg['enabled'] ?? true),
        'project_id' => (string)$sa['project_id'],
        'service_account_json' => $source === 'environment_file' ? $configuredPath : '',
        'service_account' => $sa,
        'reason' => (bool)($cfg['enabled'] ?? true) ? '' : 'FCM_DISABLED',
        'source' => $source,
    ];
}

function fcm_b64url(string $v): string { return rtrim(strtr(base64_encode($v), '+/', '-_'), '='); }

function fcm_access_token(array $serviceAccount): ?string {
    if (!function_exists('openssl_sign') || !function_exists('curl_init')) return null;
    $now = time();
    $header = fcm_b64url(json_encode(['alg'=>'RS256','typ'=>'JWT'], JSON_UNESCAPED_SLASHES));
    $claims = fcm_b64url(json_encode([
        'iss'=>(string)$serviceAccount['client_email'],
        'scope'=>'https://www.googleapis.com/auth/firebase.messaging',
        'aud'=>'https://oauth2.googleapis.com/token',
        'iat'=>$now,
        'exp'=>$now + 3500,
    ], JSON_UNESCAPED_SLASHES));
    $unsigned = $header.'.'.$claims;
    $signature = '';
    if (!openssl_sign($unsigned, $signature, (string)$serviceAccount['private_key'], OPENSSL_ALGO_SHA256)) return null;
    $jwt = $unsigned.'.'.fcm_b64url($signature);
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>http_build_query([
            'grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'=>$jwt,
        ]),
        CURLOPT_RETURNTRANSFER=>true,
        CURLOPT_CONNECTTIMEOUT=>3,
        CURLOPT_TIMEOUT=>6,
        CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $json = is_string($raw) ? json_decode($raw, true) : null;
    return ($code >= 200 && $code < 300 && is_array($json) && !empty($json['access_token'])) ? (string)$json['access_token'] : null;
}

/** @return array{sent:int,failed:int,invalidTokens:array<int,string>,reason:string} */
function fcm_send_tokens_result(array $tokens, string $projectId, string $title, string $body, array $data = []): array {
    $tokens = array_values(array_unique(array_filter(array_map('strval', $tokens), fn($v)=>trim($v)!=='')));
    if (!$tokens) return ['sent'=>0,'failed'=>0,'invalidTokens'=>[],'reason'=>'NO_TOKENS'];
    $cfg = fcm_config();
    if (empty($cfg['enabled']) || $projectId === '' || empty($cfg['service_account'])) {
        return ['sent'=>0,'failed'=>count($tokens),'invalidTokens'=>[],'reason'=>(string)($cfg['reason'] ?? 'FCM_NOT_CONFIGURED')];
    }
    $access = fcm_access_token($cfg['service_account']);
    if ($access === null) return ['sent'=>0,'failed'=>count($tokens),'invalidTokens'=>[],'reason'=>'FCM_AUTH_FAILED'];

    $sent=0; $failed=0; $invalid=[];
    foreach ($tokens as $token) {
        $payloadData = array_merge([
            'title'=>(string)$title,
            'body'=>(string)$body,
            'type'=>(string)($data['type'] ?? ''),
        ], array_map('strval', $data));
        $message = [
            'token'=>$token,
            'data'=>$payloadData,
            'android'=>[
                'priority'=>'high',
                'ttl'=>'86400s',
            ],
        ];
        $ch = curl_init('https://fcm.googleapis.com/v1/projects/'.rawurlencode($projectId).'/messages:send');
        curl_setopt_array($ch, [
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode(['message'=>$message], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CONNECTTIMEOUT=>3,
            CURLOPT_TIMEOUT=>6,
            CURLOPT_HTTPHEADER=>[
                'Content-Type: application/json; charset=utf-8',
                'Authorization: Bearer '.$access,
            ],
        ]);
        $raw=curl_exec($ch); $code=(int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
        if ($code >= 200 && $code < 300) { $sent++; continue; }
        $failed++;
        $text = is_string($raw) ? $raw : '';
        if (stripos($text,'UNREGISTERED')!==false || stripos($text,'NOT_FOUND')!==false) $invalid[]=$token;
    }
    return ['sent'=>$sent,'failed'=>$failed,'invalidTokens'=>$invalid,'reason'=>''];
}

function fcm_send_tokens(array $tokens, string $projectId, string $title, string $body, array $data = []): int {
    return fcm_send_tokens_result($tokens,$projectId,$title,$body,$data)['sent'];
}
