<?php
declare(strict_types=1);
require_once __DIR__.'/App.php';

function ensure_story_schema(): void {
    static $done=false; if($done) return; $done=true;
    $pdo=db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS stories (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        media_path VARCHAR(500) NOT NULL,
        media_type VARCHAR(80) NOT NULL,
        created_at DATETIME NOT NULL,
        expires_at DATETIME NOT NULL,
        visibility VARCHAR(16) NOT NULL DEFAULT 'all',
        caption VARCHAR(500) NOT NULL DEFAULT '',
        film_id BIGINT UNSIGNED NULL,
        is_trailer TINYINT(1) NOT NULL DEFAULT 0,
        INDEX idx_stories_user_expiry(user_id,expires_at),
        INDEX idx_stories_trailer(is_trailer,film_id,created_at),
        INDEX idx_stories_expiry(expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS story_views (
        story_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        viewed_at DATETIME NOT NULL,
        PRIMARY KEY(story_id,user_id), INDEX idx_story_views_user(user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS story_likes (
        story_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY(story_id,user_id), INDEX idx_story_likes_user(user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS story_comments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        story_id BIGINT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        comment VARCHAR(500) NOT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_story_comments_story(story_id,created_at), INDEX idx_story_comments_user(user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS story_follows (
        user_id BIGINT UNSIGNED NOT NULL,
        followed_user_id BIGINT UNSIGNED NOT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY(user_id,followed_user_id), INDEX idx_story_follows_target(followed_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // Safe upgrades for installations created before Story V2.
    try {
        $c=$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='story_comments' AND COLUMN_NAME='parent_comment_id'")->fetchColumn();
        if(!(int)$c) $pdo->exec("ALTER TABLE story_comments ADD COLUMN parent_comment_id BIGINT UNSIGNED NULL AFTER comment");
        try { $pdo->exec("CREATE INDEX idx_story_comments_parent ON story_comments(parent_comment_id)"); } catch(Throwable $e) {}
    } catch(Throwable $e) {}
    try {
        $c=$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='stories' AND COLUMN_NAME='visibility'")->fetchColumn();
        if(!(int)$c) $pdo->exec("ALTER TABLE stories ADD COLUMN visibility VARCHAR(16) NOT NULL DEFAULT 'all' AFTER expires_at");
        $cc=$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='stories' AND COLUMN_NAME='caption'")->fetchColumn();
        if(!(int)$cc) $pdo->exec("ALTER TABLE stories ADD COLUMN caption VARCHAR(500) NOT NULL DEFAULT '' AFTER visibility");
        $fc=$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='stories' AND COLUMN_NAME='film_id'")->fetchColumn();
        if(!(int)$fc) $pdo->exec("ALTER TABLE stories ADD COLUMN film_id BIGINT UNSIGNED NULL AFTER caption");
        $tc=$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='stories' AND COLUMN_NAME='is_trailer'")->fetchColumn();
        if(!(int)$tc) $pdo->exec("ALTER TABLE stories ADD COLUMN is_trailer TINYINT(1) NOT NULL DEFAULT 0 AFTER film_id");
        try { $pdo->exec("CREATE INDEX idx_stories_trailer ON stories(is_trailer,film_id,created_at)"); } catch(Throwable $e) {}
    } catch(Throwable $e) {}
    $pdo->exec("CREATE TABLE IF NOT EXISTS story_reports (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, story_id BIGINT UNSIGNED NOT NULL, reporter_id BIGINT UNSIGNED NOT NULL, reason VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL,
        INDEX idx_story_reports_story(story_id), INDEX idx_story_reports_reporter(reporter_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // Story lifetime is 7 days. Normalize active/legacy rows to the canonical 7-day Story lifetime.
    try { $pdo->exec("UPDATE stories SET expires_at=DATE_ADD(created_at,INTERVAL 7 DAY) WHERE is_trailer=0 AND (expires_at>DATE_ADD(created_at,INTERVAL 7 DAY) OR expires_at<DATE_ADD(created_at,INTERVAL 7 DAY))"); } catch(Throwable $e) {}
    try { $pdo->exec("UPDATE stories SET expires_at='2099-12-31 23:59:59' WHERE is_trailer=1 AND expires_at<'2099-01-01 00:00:00'"); } catch(Throwable $e) {}
    // Trailers are public by design; normalize legacy rows that were saved as friends-only.
    try { $pdo->exec("UPDATE stories SET visibility='all' WHERE is_trailer=1 AND visibility<>'all'"); } catch(Throwable $e) {}
}
function ensure_story_gift_schema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS story_gift_transactions (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        story_id BIGINT UNSIGNED NOT NULL,
        sender_id BIGINT UNSIGNED NOT NULL,
        receiver_id BIGINT UNSIGNED NOT NULL,
        gift_id BIGINT UNSIGNED NOT NULL,
        coin_cost BIGINT NOT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_story_gift_story(story_id),
        INDEX idx_story_gift_sender(sender_id),
        INDEX idx_story_gift_receiver(receiver_id),
        INDEX idx_story_gift_created(created_at),
        FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
        FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (gift_id) REFERENCES gifts(id) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
function purge_expired_stories(): void {
    $pdo=db();
    try {
        $q=$pdo->query('SELECT id,media_path FROM stories WHERE is_trailer=0 AND expires_at<=UTC_TIMESTAMP() LIMIT 500');
        $files=[]; $ids=[]; foreach($q->fetchAll(PDO::FETCH_ASSOC) as $r){ $ids[]=(int)$r['id']; $files[(string)$r['media_path']]=true; }
        if($ids){
            $ph=implode(',',array_fill(0,count($ids),'?'));
            foreach(['story_views','story_likes','story_comments'] as $tbl){ $pdo->prepare("DELETE FROM {$tbl} WHERE story_id IN ($ph)")->execute($ids); }
            $pdo->prepare("DELETE FROM stories WHERE id IN ($ph)")->execute($ids);
        }
        $root=realpath(dirname(__DIR__,2).'/storage');
        if($root) foreach(array_keys($files) as $rel){ $f=realpath($root.'/'.ltrim($rel,'/')); if($f && str_starts_with($f,$root.DIRECTORY_SEPARATOR) && is_file($f)) @unlink($f); }
    } catch(Throwable $e) { /* cleanup is best effort */ }
}
function story_row(PDO $pdo, array $r, int $viewer): array {
    $id=(int)$r['id']; $owner=(int)$r['user_id'];
    $s=$pdo->prepare('SELECT COUNT(*) FROM story_views WHERE story_id=?'); $s->execute([$id]); $views=(int)$s->fetchColumn();
    $s=$pdo->prepare('SELECT COUNT(*) FROM story_likes WHERE story_id=?'); $s->execute([$id]); $likes=(int)$s->fetchColumn();
    $s=$pdo->prepare('SELECT COUNT(*) FROM story_comments WHERE story_id=?'); $s->execute([$id]); $comments=(int)$s->fetchColumn();
    $s=$pdo->prepare('SELECT 1 FROM story_likes WHERE story_id=? AND user_id=? LIMIT 1'); $s->execute([$id,$viewer]); $liked=(bool)$s->fetchColumn();
    $s=$pdo->prepare('SELECT 1 FROM story_views WHERE story_id=? AND user_id=? LIMIT 1'); $s->execute([$id,$viewer]); $seen=(bool)$s->fetchColumn();
    $s=$pdo->prepare('SELECT 1 FROM story_follows WHERE user_id=? AND followed_user_id=? LIMIT 1'); $s->execute([$viewer,$owner]); $followed=(bool)$s->fetchColumn();
    $filmId=(int)($r['film_id']??0);
    $filmTitle=(string)($r['film_title']??'');
    $filmCategory=(string)($r['film_category']??'');
    $filmYear=isset($r['film_year']) && $r['film_year']!==null ? (int)$r['film_year'] : null;
    return ['id'=>$id,'userId'=>$owner,'nickname'=>(string)$r['nickname'],'avatarId'=>(string)($r['avatarId']??'ghost'),'avatarUrl'=>(string)($r['avatarUrl']??''),'mediaUrl'=>'api/stories/media?id='.$id,'mediaType'=>(string)$r['media_type'],'createdAt'=>(string)$r['created_at'],'expiresAt'=>(string)$r['expires_at'],'visibility'=>(string)($r['visibility']??'all'),'caption'=>(string)($r['caption']??''),'views'=>$views,'likes'=>$likes,'comments'=>$comments,'liked'=>$liked,'seen'=>$seen,'followed'=>$followed,'filmId'=>$filmId,'filmTitle'=>$filmTitle,'filmCategory'=>$filmCategory,'filmYear'=>$filmYear];
}
