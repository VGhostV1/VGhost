<?php
declare(strict_types=1);

/**
 * Delete messages whose 24-hour lifetime has expired.
 *
 * This is intentionally safe to call from both the CLI cron job and the API
 * bootstrap. The expires_at column is indexed, so the DELETE remains bounded
 * to expired rows.
 */
function cleanup_expired_messages(PDO $pdo): int {
    // Prevent multiple PHP workers from running the cleanup at the same time.
    $lock = false;
    try {
        $lock = (bool)$pdo->query("SELECT GET_LOCK('vghost_cleanup_messages', 0)")->fetchColumn();
    } catch (Throwable $e) {
        // GET_LOCK is optional; cleanup can still safely run without it.
    }

    try {
        // Repair legacy rows that predate the 24-hour expiry field. Their lifetime
        // is always derived from created_at, never from the cleanup time.
        try {
            $pdo->exec("UPDATE messages SET expires_at=DATE_ADD(created_at, INTERVAL 24 HOUR) WHERE expires_at IS NULL");
        } catch (Throwable $e) {}

        // Remove private voice files first, then delete their expired message rows.
        $voiceFiles = [];
        $mediaFiles = [];
        try {
            $q = $pdo->query("SELECT audio_path FROM messages WHERE expires_at <= UTC_TIMESTAMP() AND message_type='voice' AND audio_path IS NOT NULL");
            $voiceFiles = $q ? $q->fetchAll(PDO::FETCH_COLUMN) : [];
        } catch (Throwable $e) {}
        try {
            $q = $pdo->query("SELECT attachment_path FROM messages WHERE expires_at <= UTC_TIMESTAMP() AND attachment_path IS NOT NULL");
            $mediaFiles = $q ? $q->fetchAll(PDO::FETCH_COLUMN) : [];
        } catch (Throwable $e) {}
        $stmt = $pdo->prepare('DELETE FROM messages WHERE expires_at <= UTC_TIMESTAMP()');
        $stmt->execute();
        $deleted = $stmt->rowCount();
        $root = realpath(dirname(__DIR__,2).'/storage/voice');
        if ($root) foreach ($voiceFiles as $rel) {
            $file = realpath(dirname(__DIR__,2).'/storage/'.ltrim((string)$rel,'/'));
            if ($file && str_starts_with($file,$root.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
        }
        $mediaRoot = realpath(dirname(__DIR__,2).'/storage/media');
        if ($mediaRoot) foreach ($mediaFiles as $rel) {
            $file = realpath(dirname(__DIR__,2).'/storage/'.ltrim((string)$rel,'/'));
            if ($file && str_starts_with($file,$mediaRoot.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
        }
        return $deleted;
    } finally {
        if ($lock) {
            try { $pdo->query("SELECT RELEASE_LOCK('vghost_cleanup_messages')"); } catch (Throwable $e) {}
        }
    }
}
