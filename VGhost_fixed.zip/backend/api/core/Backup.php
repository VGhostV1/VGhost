<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';

function backup_storage_dir(string $name): string {
    $dir=__DIR__.'/../../storage/'.$name;
    if(!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir)) throw new RuntimeException('BACKUP_STORAGE_UNAVAILABLE');
    return $dir;
}
function backup_tables(PDO $pdo): array {
    $tables=[];
    $q=$pdo->query("SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME");
    while($r=$q->fetch(PDO::FETCH_ASSOC)) { $name=(string)$r['TABLE_NAME']; if($name==='backup_import_tokens') continue; $tables[]=$name; }
    return $tables;
}
function backup_create_file(PDO $pdo): array {
    $tables=backup_tables($pdo); $name='vghost-backup-'.gmdate('Ymd-His').'-'.bin2hex(random_bytes(8)).'.sql.gz';
    $file=backup_storage_dir('exports').'/'.$name; $gz=gzopen($file,'wb9'); if(!$gz) throw new RuntimeException('BACKUP_CREATE_FAILED');
    gzwrite($gz,"-- VGHOST FULL DATABASE BACKUP\n-- UTC ".gmdate('c')."\nSET FOREIGN_KEY_CHECKS=0;\nSTART TRANSACTION;\n");
    foreach($tables as $table){
        $safe='`'.str_replace('`','``',$table).'`'; gzwrite($gz,"\n-- TABLE $table\n");
        $cols=$pdo->query("SHOW COLUMNS FROM $safe")->fetchAll(PDO::FETCH_COLUMN);
        $colSql=implode(',',array_map(fn($c)=>'`'.str_replace('`','``',(string)$c).'`',$cols));
        $st=$pdo->query("SELECT * FROM $safe");
        while($row=$st->fetch(PDO::FETCH_ASSOC)){
            $vals=[]; foreach($cols as $c){$v=$row[$c];$vals[]=$v===null?'NULL':$pdo->quote((string)$v);} 
            gzwrite($gz,"INSERT INTO $safe ($colSql) VALUES (".implode(',',$vals).");\n");
        }
    }
    gzwrite($gz,"COMMIT;\nSET FOREIGN_KEY_CHECKS=1;\n"); gzclose($gz);
    return ['file'=>$file,'name'=>$name,'tables'=>count($tables),'size'=>(int)filesize($file)];
}
function backup_cleanup_imports(): void {
    try { db()->prepare('DELETE FROM backup_import_tokens WHERE expires_at<=UTC_TIMESTAMP() OR used_at IS NOT NULL')->execute(); } catch(Throwable $e) {}
    foreach(glob(backup_storage_dir('imports').'/*') ?: [] as $f){ if(is_file($f) && filemtime($f)<time()-900) @unlink($f); }
}
function backup_import_schema(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS backup_import_tokens (token CHAR(64) PRIMARY KEY,file_path VARCHAR(500) NOT NULL,sha256 CHAR(64) NOT NULL,size_bytes BIGINT UNSIGNED NOT NULL,statement_count INT UNSIGNED NOT NULL,admin_user_id BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,expires_at DATETIME NOT NULL,used_at DATETIME NULL,INDEX(expires_at),INDEX(admin_user_id)) ENGINE=InnoDB");
}
/** Validate only SQL produced by VGHOST exporter: comments, transaction controls and INSERT INTO known tables. */
function backup_validate_gzip(string $path, PDO $pdo): array {
    if(!is_file($path) || filesize($path)<=0 || filesize($path)>512*1024*1024) throw new RuntimeException('INVALID_BACKUP');
    $fh=gzopen($path,'rb'); if(!$fh) throw new RuntimeException('INVALID_GZIP');
    $allowed=array_fill_keys(backup_tables($pdo),true); $count=0; $buffer=''; $maxUncompressed=1024*1024*1024; $read=0;
    try {
        while(!gzeof($fh)){
            $line=gzgets($fh); if($line===false) break; $read+=strlen($line); if($read>$maxUncompressed) throw new RuntimeException('BACKUP_TOO_LARGE');
            $trim=trim($line); if($trim==='' || str_starts_with($trim,'--')) continue;
            $buffer.=$trim."\n";
            if(!str_ends_with($trim,';')) continue;
            $sql=trim($buffer); $buffer='';
            if(preg_match('/^(SET FOREIGN_KEY_CHECKS\s*=\s*[01]|START TRANSACTION|COMMIT)\s*;?$/i',$sql)) continue;
            if(!preg_match('/^INSERT\s+INTO\s+`([^`]+)`\s*\(/is',$sql,$m) || !isset($allowed[$m[1]])) throw new RuntimeException('UNSAFE_BACKUP_SQL');
            $count++;
        }
        if(trim($buffer)!=='') throw new RuntimeException('INVALID_BACKUP_SQL');
    } finally { gzclose($fh); }
    return ['statements'=>$count,'tables'=>count($allowed),'size'=>(int)filesize($path)];
}
function backup_import_file(PDO $pdo,string $path): int {
    $fh=gzopen($path,'rb'); if(!$fh) throw new RuntimeException('INVALID_GZIP'); $count=0; $buffer='';
    // A FULL IMPORT is a restore operation. Disable FK checks for this connection,
    // clear application tables, then replay the validated INSERT-only backup.
    $tables=backup_tables($pdo);
    // Do not delete the temporary confirmation table until this request has finished.
    $tables=array_values(array_filter($tables, fn($t)=>$t!=='backup_import_tokens'));
    try {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
        $pdo->beginTransaction();
        foreach($tables as $table){
            $safe='`'.str_replace('`','``',$table).'`';
            $pdo->exec("DELETE FROM $safe");
        }
        while(!gzeof($fh)){
            $line=gzgets($fh); if($line===false) break; $trim=trim($line); if($trim===''||str_starts_with($trim,'--')) continue;
            $buffer.=$trim."\n"; if(!str_ends_with($trim,';')) continue; $sql=trim($buffer); $buffer='';
            if(preg_match('/^(SET FOREIGN_KEY_CHECKS|START TRANSACTION|COMMIT)/i',$sql)) continue;
            $pdo->exec($sql); $count++;
        }
        if(trim($buffer)!=='') throw new RuntimeException('INVALID_BACKUP_SQL');
        $pdo->commit(); return $count;
    } catch(Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
    finally { $pdo->exec('SET FOREIGN_KEY_CHECKS=1'); gzclose($fh); }
}
