<?php
declare(strict_types=1);

function json_response(array $data, int $status=200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $json = json_encode(
        $data,
        JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE
    );
    if ($json === false) {
        http_response_code(500);
        $json = '{"ok":false,"error":"SERVER_RESPONSE_ENCODING_ERROR"}';
    }
    echo $json;
    exit;
}
function ok(array $data=[]): void { json_response(['ok'=>true] + $data); }
function fail(string $error, int $status=400, array $extra=[]): void { json_response(['ok'=>false,'error'=>$error] + $extra, $status); }
