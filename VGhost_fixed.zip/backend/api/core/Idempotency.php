<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Response.php';

/**
 * Prevent replay/duplicate execution of money-moving API requests.
 * Must be called inside the caller's existing DB transaction.
 * Returns a cached response array when the key was already completed.
 */
function ensure_idempotency_schema(PDO $pdo): void {
    // DDL implicitly commits on MySQL. Keep schema creation OUTSIDE money-transfer
    // transactions; otherwise a later commit() can fail with HTTP 500.
    $pdo->exec("CREATE TABLE IF NOT EXISTS api_idempotency_keys (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        endpoint VARCHAR(120) NOT NULL,
        idem_key_hash CHAR(64) NOT NULL,
        request_hash CHAR(64) NOT NULL,
        status ENUM('pending','completed') NOT NULL DEFAULT 'pending',
        response_json LONGTEXT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        expires_at DATETIME NOT NULL,
        UNIQUE KEY uq_idem(user_id,endpoint,idem_key_hash),
        INDEX idx_idem_exp(expires_at),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function idempotency_begin(PDO $pdo, int $userId, string $endpoint, string $key, string $fingerprint): ?array {
    $key = trim($key);
    if ($key === '') return null;
    if (strlen($key) > 128) fail('INVALID_IDEMPOTENCY_KEY', 422);
    if (!preg_match('/^[A-Za-z0-9._~:-]{8,128}$/', $key)) fail('INVALID_IDEMPOTENCY_KEY', 422);
    if (strlen($fingerprint) > 128) fail('INVALID_REQUEST_FINGERPRINT', 422);
    $hash = hash('sha256', $key);
    $requestHash = hash('sha256', $fingerprint);
    $ins = $pdo->prepare("INSERT IGNORE INTO api_idempotency_keys(user_id,endpoint,idem_key_hash,request_hash,status,created_at,updated_at,expires_at) VALUES(?,?,?,?, 'pending',UTC_TIMESTAMP(),UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR))");
    $ins->execute([$userId,$endpoint,$hash,$requestHash]);
    $q = $pdo->prepare('SELECT request_hash,status,response_json FROM api_idempotency_keys WHERE user_id=? AND endpoint=? AND idem_key_hash=? LIMIT 1 FOR UPDATE');
    $q->execute([$userId,$endpoint,$hash]);
    $row = $q->fetch(PDO::FETCH_ASSOC);
    if (!$row) fail('IDEMPOTENCY_UNAVAILABLE',503);
    if (!hash_equals((string)$row['request_hash'], $requestHash)) fail('IDEMPOTENCY_KEY_REUSED',409);
    if ((string)$row['status'] === 'completed' && (string)$row['response_json'] !== '') {
        $decoded = json_decode((string)$row['response_json'], true);
        if (is_array($decoded)) return $decoded;
    }
    return null;
}

function idempotency_complete(PDO $pdo, int $userId, string $endpoint, string $key, array $response): void {
    $key = trim($key);
    if ($key === '') return;
    $hash = hash('sha256', $key);
    $json = json_encode($response, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) fail('SERVER_RESPONSE_ENCODING_ERROR',500);
    $pdo->prepare("UPDATE api_idempotency_keys SET status='completed',response_json=?,updated_at=UTC_TIMESTAMP() WHERE user_id=? AND endpoint=? AND idem_key_hash=?")->execute([$json,$userId,$endpoint,$hash]);
}

function idempotency_cleanup(PDO $pdo): void {
    try { $pdo->exec('DELETE FROM api_idempotency_keys WHERE expires_at<=UTC_TIMESTAMP()'); } catch (Throwable $e) {}
}
