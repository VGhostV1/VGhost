<?php
declare(strict_types=1);

/**
 * Canonical VGhost film genres used by the Android Admin Film form.
 * Keep these values stable because they are persisted in films.category.
 */
function film_genre_options(): array {
    return [
        'Drama',
        'Aksiya',
        'Komediya',
        'Romantik',
        'Qorxu',
        'Fantastika',
        'Macəra',
        'Triller',
        'Detektiv',
        'Animasiya',
        'Ailə',
    ];
}

/**
 * Return the canonical genres first, then any legacy/custom genres already
 * stored in the database so existing films are never hidden from filters.
 */
function film_genres_with_existing(PDO $pdo): array {
    $genres = film_genre_options();
    try {
        $rows = $pdo->query("SELECT DISTINCT category FROM films WHERE category IS NOT NULL AND TRIM(category)<>'' ORDER BY category ASC")
            ->fetchAll(PDO::FETCH_COLUMN);
        $seen = [];
        foreach ($genres as $genre) $seen[mb_strtolower($genre, 'UTF-8')] = true;
        foreach ($rows as $row) {
            $value = trim((string)$row);
            if ($value === '') continue;
            $key = mb_strtolower($value, 'UTF-8');
            if (!isset($seen[$key])) {
                $genres[] = $value;
                $seen[$key] = true;
            }
        }
    } catch (Throwable $e) {
        // The films table may not exist on an old/partially migrated install.
        // The canonical list is still safe to return.
    }
    return $genres;
}
