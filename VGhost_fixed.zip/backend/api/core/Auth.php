<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Response.php';

function issue_session(int $userId): string {
    $raw = bin2hex(random_bytes(32));
    $hash = hash('sha256', $raw);
    $config = require __DIR__.'/../config/config.php';
    $days = max(1, min(90, (int)($config['security']['session_ttl_days'] ?? 30)));
    // Keep only a bounded number of active sessions per account.
    db()->prepare('DELETE FROM user_sessions WHERE user_id=? AND (expires_at<=UTC_TIMESTAMP() OR id NOT IN (SELECT id FROM (SELECT id FROM user_sessions WHERE user_id=? ORDER BY created_at DESC LIMIT 5) x))')->execute([$userId,$userId]);
    // Do not bind the DAY value inside DATE_ADD(... INTERVAL ? DAY).
    // Some MariaDB/PDO builds reject a parameter marker in the INTERVAL
    // expression even though the same SQL works in other environments.
    // Calculate the UTC expiry in PHP instead; this keeps login portable.
    $expiresAt = gmdate('Y-m-d H:i:s', time() + ($days * 86400));
    $stmt = db()->prepare('INSERT INTO user_sessions (user_id, token_hash, expires_at, created_at) VALUES (?, ?, ?, UTC_TIMESTAMP())');
    $stmt->execute([$userId,$hash,$expiresAt]);
    return $raw;
}
function current_user(bool $allowBanned=false): array {
    static $user = null;
    if ($user !== null) return $user;
    $token = bearer_token();
    if (!$token) fail('UNAUTHORIZED',401);
    $hash = hash('sha256',$token);
    $stmt = db()->prepare('SELECT u.* FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>UTC_TIMESTAMP() AND u.is_deleted=0 LIMIT 1');
    $stmt->execute([$hash]);
    $user = $stmt->fetch();
    if (!$user) fail('UNAUTHORIZED',401);
    // Temporary admin bans expire automatically. A permanent ban has NULL expiry.
    if ((int)($user['is_banned'] ?? 0)===1 && !empty($user['ban_expires_at']) && strtotime((string)$user['ban_expires_at']) <= time()) {
        db()->prepare('UPDATE users SET is_banned=0, ban_expires_at=NULL, updated_at=UTC_TIMESTAMP() WHERE id=?')->execute([(int)$user['id']]);
        $user['is_banned']=0; $user['ban_expires_at']=null;
    }
    db()->prepare('UPDATE user_sessions SET last_seen_at=UTC_TIMESTAMP() WHERE token_hash=?')->execute([$hash]);
    if (!$allowBanned && (int)($user['is_banned'] ?? 0)===1) fail('USER_BANNED',403);
    return $user;
}
