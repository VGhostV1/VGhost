<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Response.php';

/*
 * Server-authoritative VGHOST progression.
 * Level starts at 1 with 0 XP. XP required for the next level is:
 *   100 + (currentLevel * 11)
 * This mirrors the Android client while keeping the real value on the server.
 */
function progression_required_xp(int $level): int {
    return max(1, min(10000, 100 + $level * 11));
}

function ensure_progression_schema(): void {
    static $done = false; if ($done) return; $done = true;
    $pdo = db();
    $pdo->exec('CREATE TABLE IF NOT EXISTS user_progression (
        user_id BIGINT UNSIGNED PRIMARY KEY,
        level INT UNSIGNED NOT NULL DEFAULT 1,
        xp INT UNSIGNED NOT NULL DEFAULT 0,
        total_xp BIGINT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL,
        INDEX(level),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');

    $pdo->exec('CREATE TABLE IF NOT EXISTS progression_daily (
        user_id BIGINT UNSIGNED NOT NULL,
        reward_date DATE NOT NULL,
        reason VARCHAR(32) NOT NULL,
        amount INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY(user_id,reward_date,reason),
        INDEX(reward_date),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
}

function progression_rules(): array {
    return [
        'message'   => ['max'=>1,   'daily'=>50],
        'friend'    => ['max'=>10,  'daily'=>100],
    ];
}

function progression_row(int $userId, bool $forUpdate=false): array {
    $pdo = db();
    $sql = 'SELECT user_id,level,xp,total_xp,updated_at FROM user_progression WHERE user_id=? LIMIT 1';
    if ($forUpdate) $sql .= ' FOR UPDATE';
    $st = $pdo->prepare($sql); $st->execute([$userId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row) return $row;
    $pdo->prepare('INSERT INTO user_progression(user_id,level,xp,total_xp,updated_at) VALUES(?,1,0,0,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE user_id=user_id')
        ->execute([$userId]);
    $st = $pdo->prepare($sql); $st->execute([$userId]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: ['user_id'=>$userId,'level'=>1,'xp'=>0,'total_xp'=>0,'updated_at'=>gmdate('Y-m-d H:i:s')];
}

function progression_public(int $userId): array {
    $row = progression_row($userId);
    $level = max(1, (int)$row['level']);
    $xp = max(0, (int)$row['xp']);
    return [
        'level'=>$level,
        'xp'=>$xp,
        'currentXp'=>$xp,
        'xpIntoLevel'=>$xp,
        'nextLevelXp'=>progression_required_xp($level),
        'totalXp'=>(int)$row['total_xp'],
    ];
}

function award_progression_xp(int $userId, int $requested, string $reason): array {
    ensure_progression_schema();
    $rules = progression_rules();
    if (!isset($rules[$reason])) fail('INVALID_XP_REASON',422);
    $requested = max(0, min((int)$rules[$reason]['max'], $requested));
    if ($requested <= 0) return progression_public($userId);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $row = progression_row($userId, true);
        $today = gmdate('Y-m-d');
        $st = $pdo->prepare('SELECT amount FROM progression_daily WHERE user_id=? AND reward_date=? AND reason=? FOR UPDATE');
        $st->execute([$userId,$today,$reason]);
        $used = (int)($st->fetchColumn() ?: 0);
        $allowed = max(0, min($requested, (int)$rules[$reason]['daily'] - $used));

        if ($allowed > 0) {
            $up = $pdo->prepare(
                'INSERT INTO progression_daily(user_id,reward_date,reason,amount) VALUES(?,?,?,?) '
                .'ON DUPLICATE KEY UPDATE amount=amount+VALUES(amount)'
            );
            $up->execute([$userId,$today,$reason,$allowed]);

            $level = max(1, (int)$row['level']);
            $xp = max(0, (int)$row['xp']) + $allowed;
            $total = max(0, (int)$row['total_xp']) + $allowed;
            $oldLevel = $level;
            while ($xp >= progression_required_xp($level)) {
                $xp -= progression_required_xp($level);
                $level++;
                if ($level >= 1000000) { $level = 1000000; $xp = 0; break; }
            }
            $pdo->prepare('UPDATE user_progression SET level=?,xp=?,total_xp=?,updated_at=UTC_TIMESTAMP() WHERE user_id=?')
                ->execute([$level,$xp,$total,$userId]);
        }
        $out = progression_public($userId);
        $out['awardedXp'] = $allowed;
        $out['reason'] = $reason;
        $out['levelUp'] = $allowed > 0 && $out['level'] > $oldLevel;
        $out['oldLevel'] = $oldLevel;
        $pdo->commit();
        return $out;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
