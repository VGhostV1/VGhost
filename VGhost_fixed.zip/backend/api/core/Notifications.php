<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Fcm.php';

const VG_SUPPORTED_LANGUAGES = ['en','az','tr','ru'];

function vg_user_language(int $userId): string {
    try {
        $q = db()->prepare("SELECT setting_value FROM user_settings WHERE user_id=? AND setting_key='language' LIMIT 1");
        $q->execute([$userId]);
        $lang = strtolower(trim((string)($q->fetchColumn() ?: 'en')));
        if (str_contains($lang, '-')) $lang = explode('-', $lang, 2)[0];
        return in_array($lang, VG_SUPPORTED_LANGUAGES, true) ? $lang : 'en';
    } catch (Throwable $e) { return 'az'; }
}

/** Localized automatic notification copy. Dynamic values are inserted without translating user-generated names/text. */
function vg_notification_copy(string $lang, string $type, array $v=[]): array {
    $name = (string)($v['name'] ?? '');
    $amount = (string)($v['amount'] ?? '');
    $reaction = (string)($v['reaction'] ?? '');
    $maps = [
        'az'=>[
            'welcome'=>['Xoş gəlmisən!', '1000 Coin bonusu hesabına əlavə edildi.'],
            'daily_bonus'=>['Gündəlik bonus', 'Bu gün ilk girişin üçün 500 Coin bonusu hesabına əlavə edildi.'],
            'message'=>['Yeni mesaj', $name.' sənə yeni mesaj göndərdi.'],
            'message_reaction'=>['Mesaja reaksiya', $name.' mesajına '.$reaction.' reaksiyası verdi.'],
            'friend_request'=>['Dostluq istəyi', $name.' sənə dostluq istəyi göndərdi.'],
            'friend_accepted'=>['Dostluq qəbul edildi', $name.' dostluq istəyini qəbul etdi.'],
            'profile_visit'=>['Profil qonağın var!', $name.' profilinə baxdı.'],
            'story_like'=>['Story bəyənildi ❤️', $name.' story-nizi bəyəndi.'],
            'story_comment'=>['Story şərhi 💬', $name.' story-nizə şərh yazdı.'],
            'story_reply'=>['Şərhə cavab 💬', $name.' şərhinizə cavab yazdı.'],
            'story_view'=>['Story baxışı 👀', $name.' story-nizə baxdı.'],
            'story_follow'=>['Yeni izləyici 👤', $name.' sizi izləməyə başladı.'],
            'gift'=>['Hədiyyə alındı 🎁', $name.' sizə hədiyyə göndərdi. +'.$amount.' GC'],
            'story_gift'=>['Story hədiyyəsi 🎁', $name.' story-nizə hədiyyə göndərdi. +'.$amount.' GC'],
            'coin_transfer'=>['Coin transferi', $name.' sənə '.$amount.' GC göndərdi.'],
            'coin_bonus'=>['Coin bonussi', 'Admin sənə '.$amount.' Coin göndərdi.'],
            'admin_ban'=>['Hesab bloklandı', 'Admin hesabını blokladı.'],
            'admin_unban'=>['Hesabın bloku açıldı', 'Admin hesabının bloku açıldı.'],
        ],
        'tr'=>[
            'welcome'=>['Hoş geldin!', '1000 Coin bonusu hesabına eklendi.'],
            'daily_bonus'=>['Günlük bonus', 'Bugünkü ilk girişin için hesabına 500 Coin bonusu eklendi.'],
            'message'=>['Yeni mesaj', $name.' sana yeni bir mesaj gönderdi.'],
            'message_reaction'=>['Mesaja tepki', $name.' mesajına '.$reaction.' tepkisi verdi.'],
            'friend_request'=>['Arkadaşlık isteği', $name.' sana arkadaşlık isteği gönderdi.'],
            'friend_accepted'=>['İstek kabul edildi', $name.' arkadaşlık isteğini kabul etti.'],
            'profile_visit'=>['Profil ziyareti', $name.' profilini görüntüledi.'],
            'story_like'=>['Hikaye beğenildi ❤️', $name.' hikayeni beğendi.'],
            'story_comment'=>['Hikaye yorumu 💬', $name.' hikayene yorum yaptı.'],
            'story_reply'=>['Yoruma yanıt 💬', $name.' yorumunuza yanıt verdi.'],
            'story_view'=>['Hikaye görüntülendi 👀', $name.' hikayeni görüntüledi.'],
            'story_follow'=>['Yeni takipçi 👤', $name.' seni takip etmeye başladı.'],
            'gift'=>['Hediye alındı 🎁', $name.' sana hediye gönderdi. +'.$amount.' GC'],
            'story_gift'=>['Hikaye hediyesi 🎁', $name.' hikayene hediye gönderdi. +'.$amount.' GC'],
            'coin_transfer'=>['Coin transferi', $name.' sana '.$amount.' GC gönderdi.'],
            'coin_bonus'=>['Coin', 'Yönetici sana '.$amount.' Coin gönderdi.'],
            'admin_ban'=>['Hesap engellendi', 'Yönetici hesabını engelledi.'],
            'admin_unban'=>['Hesap engeli kaldırıldı', 'Hesap engelin kaldırıldı.'],
        ],
        'en'=>[
            'welcome'=>['Welcome!', 'Your 1000 Coin bonus has been added to your account.'],
            'daily_bonus'=>['Daily bonus', '500 Coin has been added for your first login today.'],
            'message'=>['New message', $name.' sent you a new message.'],
            'message_reaction'=>['Message reaction', $name.' reacted '.$reaction.' to your message.'],
            'friend_request'=>['Friend request', $name.' sent you a friend request.'],
            'friend_accepted'=>['Friend request accepted', $name.' accepted your friend request.'],
            'profile_visit'=>['Profile visit', $name.' viewed your profile.'],
            'story_like'=>['Story liked ❤️', $name.' liked your story.'],
            'story_comment'=>['Story comment 💬', $name.' commented on your story.'],
            'story_reply'=>['Comment reply 💬', $name.' replied to your comment.'],
            'story_view'=>['Story view 👀', $name.' viewed your story.'],
            'story_follow'=>['New follower 👤', $name.' started following you.'],
            'gift'=>['Gift received 🎁', $name.' sent you a gift. +'.$amount.' GC'],
            'story_gift'=>['Story gift 🎁', $name.' sent you a gift on your story. +'.$amount.' GC'],
            'coin_transfer'=>['Coin transfer', $name.' sent you '.$amount.' GC.'],
            'coin_bonus'=>['Coin', 'An admin sent you '.$amount.' Coins.'],
            'admin_ban'=>['Account blocked', 'An admin blocked your account.'],
            'admin_unban'=>['Account unblocked', 'Your account block has been removed.'],
        ],
        'ru'=>[
            'welcome'=>['Добро пожаловать!', 'Бонус 1000 Coin зачислен на ваш аккаунт.'],
            'daily_bonus'=>['Ежедневный бонус', 'За первый вход сегодня вам начислено 500 Coin.'],
            'message'=>['Новое сообщение', $name.' отправил(а) вам новое сообщение.'],
            'message_reaction'=>['Реакция на сообщение', $name.' отреагировал(а) '.$reaction.' на ваше сообщение.'],
            'friend_request'=>['Запрос в друзья', $name.' отправил(а) вам запрос в друзья.'],
            'friend_accepted'=>['Запрос принят', $name.' принял(а) ваш запрос в друзья.'],
            'profile_visit'=>['Посещение профиля', $name.' просмотрел(а) ваш профиль.'],
            'story_like'=>['История понравилась ❤️', $name.' оценил(а) вашу историю.'],
            'story_comment'=>['Комментарий к истории 💬', $name.' прокомментировал(а) вашу историю.'],
            'story_reply'=>['Ответ на комментарий 💬', $name.' ответил(а) на ваш комментарий.'],
            'story_view'=>['Просмотр истории 👀', $name.' просмотрел(а) вашу историю.'],
            'story_follow'=>['Новый подписчик 👤', $name.' начал(а) на вас подписываться.'],
            'gift'=>['Подарок получен 🎁', $name.' отправил(а) вам подарок. +'.$amount.' GC'],
            'story_gift'=>['Подарок для истории 🎁', $name.' отправил(а) подарок на вашу историю. +'.$amount.' GC'],
            'coin_transfer'=>['Перевод монет', $name.' отправил(а) вам '.$amount.' GC.'],
            'coin_bonus'=>['Монеты', 'Администратор отправил вам '.$amount.' монет.'],
            'admin_ban'=>['Аккаунт заблокирован', 'Администратор заблокировал ваш аккаунт.'],
            'admin_unban'=>['Аккаунт разблокирован', 'Блокировка вашего аккаунта снята.'],
        ],
    ];
    $copy = $maps[$lang][$type] ?? $maps['en'][$type] ?? null;
    return $copy ?: [$type, ''];
}

function notify_localized(int $userId,string $type,array $vars=[],array $data=[]): int {
    // Keep dynamic notification values in data_json as well as in the rendered
    // copy. The Android client re-localizes notifications when the app language
    // changes, so it must always have sender/amount available.
    $name = trim((string)($vars['name'] ?? $vars['senderNickname'] ?? $vars['sender'] ?? ''));
    $amount = (string)($vars['amount'] ?? $data['amount'] ?? '');
    if ($amount === '') {
        if ($type === 'daily_bonus') $amount = '500';
        elseif ($type === 'welcome_bonus') $amount = '1000';
    }
    if ($name !== '') {
        if (empty($data['senderNickname'])) $data['senderNickname'] = $name;
        if (empty($data['sender'])) $data['sender'] = $name;
    }
    if ($amount !== '' && !isset($data['amount'])) $data['amount'] = $amount;
    $copy = vg_notification_copy(vg_user_language($userId), $type, array_merge($vars, ['name'=>$name, 'amount'=>$amount]));
    $copy = [
        str_replace(['{sender}','{senderNickname}','${sender}','${senderNickname}'], $name, (string)$copy[0]),
        str_replace(['{sender}','{senderNickname}','${sender}','${senderNickname}'], $name, (string)$copy[1]),
    ];
    $copy[1] = str_replace(['{amount}','${amount}'], $amount, $copy[1]);
    return notify_user($userId,$type,$copy[0],$copy[1],$data);
}

function create_notification(int $userId,string $type,string $title,string $body,array $data=[]): int {
    $pdo=db();
    $typeKey=substr($type,0,64);
    $senderKey=trim((string)($data['senderUid'] ?? $data['senderId'] ?? $data['senderNickname'] ?? $data['sender'] ?? ''));
    // Collapse identical unread notifications from the same sender into one
    // persistent row. This keeps message/coin/bonus/reaction pushes from stacking
    // dozens of identical alerts while still keeping different senders/types apart.
    if($senderKey!=='') {
        $q=$pdo->prepare("SELECT id,data_json FROM app_notifications WHERE user_id=? AND type=? AND is_read=0 AND data_json LIKE ? ORDER BY id DESC LIMIT 1");
        $q->execute([$userId,$typeKey,'%\"senderUid\":\"'.addcslashes($senderKey,'\\\"').'%']);
        $existing=$q->fetch(PDO::FETCH_ASSOC);
        if(!$existing && is_numeric($senderKey)) {
            $q=$pdo->prepare("SELECT id,data_json FROM app_notifications WHERE user_id=? AND type=? AND is_read=0 AND data_json LIKE ? ORDER BY id DESC LIMIT 1");
            $q->execute([$userId,$typeKey,'%\"senderId\":'.(int)$senderKey.'%']);
            $existing=$q->fetch(PDO::FETCH_ASSOC);
        }
        if(!$existing && !is_numeric($senderKey)) {
            $safeName=addcslashes($senderKey,'\\\"');
            $q=$pdo->prepare("SELECT id,data_json FROM app_notifications WHERE user_id=? AND type=? AND is_read=0 AND data_json LIKE ? ORDER BY id DESC LIMIT 1");
            $q->execute([$userId,$typeKey,'%\"senderNickname\":\"'.$safeName.'%']);
            $existing=$q->fetch(PDO::FETCH_ASSOC);
        }
        if($existing) {
            $old=[];
            try { $old=json_decode((string)($existing['data_json']??''),true) ?: []; } catch(Throwable $e) {}
            $count=max(1,(int)($old['count']??1))+1;
            $merged=array_merge($old,$data,['count'=>$count]);
            $st=$pdo->prepare('UPDATE app_notifications SET title=?,body=?,data_json=?,created_at=UTC_TIMESTAMP(),is_read=0,read_at=NULL WHERE id=? AND user_id=?');
            $st->execute([substr($title,0,190),$body,json_encode($merged,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),(int)$existing['id'],$userId]);
            return (int)$existing['id'];
        }
    }
    $dataWithCount=$data; if(!isset($dataWithCount['count'])) $dataWithCount['count']=1;
    $st=$pdo->prepare('INSERT INTO app_notifications(user_id,type,title,body,data_json,is_read,created_at) VALUES(?,?,?,?,?,0,UTC_TIMESTAMP())');
    $st->execute([$userId,$typeKey,substr($title,0,190),$body,json_encode($dataWithCount,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    return (int)$pdo->lastInsertId();
}
function delete_friend_request_notification(int $recipientUserId, int $senderUserId): void {
    if ($recipientUserId <= 0 || $senderUserId <= 0) return;
    $pdo = db();
    // Friend-request notifications carry the sender in senderUid/senderId.
    // Remove only the handled request notification; never touch the acceptance
    // notification that may have been created for the requester.
    $q = $pdo->prepare("SELECT id,data_json FROM app_notifications WHERE user_id=? AND type='friend_request'");
    $q->execute([$recipientUserId]);
    $ids = [];
    while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
        $data = [];
        try { $data = json_decode((string)($row['data_json'] ?? ''), true) ?: []; } catch (Throwable $e) {}
        $sender = (int)($data['senderUid'] ?? $data['senderId'] ?? $data['fromUserId'] ?? 0);
        if ($sender === $senderUserId) $ids[] = (int)$row['id'];
    }
    if (!$ids) return;
    $del = $pdo->prepare('DELETE FROM app_notifications WHERE user_id=? AND id=?');
    foreach ($ids as $id) $del->execute([$recipientUserId, $id]);
}

function notification_count(int $userId,int $notificationId): int {
    try {
        $q=db()->prepare('SELECT data_json FROM app_notifications WHERE id=? AND user_id=? LIMIT 1');
        $q->execute([$notificationId,$userId]);
        $raw=$q->fetchColumn(); $j=is_string($raw)?json_decode($raw,true):null;
        return is_array($j) ? max(1,(int)($j['count']??1)) : 1;
    } catch(Throwable $e) { return 1; }
}

function push_notification_to_user(int $userId,string $type,string $title,string $body,array $data=[]): array {
    $pdo=db();
    $enabledQ=$pdo->prepare('SELECT COALESCE(push_enabled,1) FROM users WHERE id=? LIMIT 1'); $enabledQ->execute([$userId]);
    if((int)$enabledQ->fetchColumn()!==1) return ['sent'=>0,'failed'=>0,'invalidTokens'=>[],'reason'=>'PUSH_DISABLED'];
    $q=$pdo->prepare("SELECT fcm_token FROM user_devices WHERE user_id=? AND fcm_token<>''"); $q->execute([$userId]);
    $tokens=$q->fetchAll(PDO::FETCH_COLUMN) ?: []; $cfg=fcm_config();
    try { return fcm_send_tokens_result($tokens,(string)($cfg['project_id']??''),$title,$body,array_merge(['type'=>$type],$data)); }
    catch(Throwable $e){ return ['sent'=>0,'failed'=>count($tokens),'invalidTokens'=>[],'reason'=>'PUSH_EXCEPTION']; }
}
function notify_user(int $userId,string $type,string $title,string $body,array $data=[]): int {
    $id=create_notification($userId,$type,$title,$body,$data);
    $count=notification_count($userId,$id);
    $pushData=array_merge($data,['notificationId'=>(string)$id,'count'=>(string)$count]);
    $r=push_notification_to_user($userId,$type,$title,$body,$pushData);
    if(!empty($r['invalidTokens'])) { $d=db()->prepare('DELETE FROM user_devices WHERE fcm_token=?'); foreach($r['invalidTokens'] as $t)$d->execute([$t]); }
    return $id;
}
