<?php
declare(strict_types=1);
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/Response.php';

/**
 * DB-only rate limiter. Requires only PHP + PDO MySQL; no Redis/files/external service.
 */
function client_ip(): string {
    return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function rate_limit(string $bucket, int $maxHits, int $windowSeconds, ?string $extra = null): void {
    if ($maxHits < 1 || $windowSeconds < 1) return;
    static $ready = false;
    if (!$ready) {
        db()->exec('CREATE TABLE IF NOT EXISTS rate_limits (rate_key VARCHAR(191) NOT NULL PRIMARY KEY,window_start DATETIME NOT NULL,hits INT UNSIGNED NOT NULL DEFAULT 0,INDEX(window_start)) ENGINE=InnoDB');
        $ready = true;
    }
    $key = $bucket.'|'.client_ip().($extra !== null && $extra !== '' ? '|'.hash('sha256', strtolower(trim($extra))) : '');
    $pdo = db();
    $pdo->prepare(
        'INSERT INTO rate_limits(rate_key,window_start,hits) VALUES(?,UTC_TIMESTAMP(),1) '
        .'ON DUPLICATE KEY UPDATE '
        .'hits=IF(window_start <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL '.$windowSeconds.' SECOND),1,hits+1), '
        .'window_start=IF(window_start <= DATE_SUB(UTC_TIMESTAMP(), INTERVAL '.$windowSeconds.' SECOND),UTC_TIMESTAMP(),window_start)'
    )->execute([$key]);

    $st = $pdo->prepare('SELECT hits, window_start FROM rate_limits WHERE rate_key=? LIMIT 1');
    $st->execute([$key]);
    $row = $st->fetch();
    if ($row && (int)$row['hits'] > $maxHits) {
        $retry = max(1, $windowSeconds - (time() - strtotime((string)$row['window_start'])));
        header('Retry-After: '.$retry);
        fail('RATE_LIMITED',429);
    }
}


/**
 * Clear a rate-limit bucket after a successful action (for example, login).
 * This prevents successful logins from accumulating toward the next lockout.
 */
function rate_limit_clear(string $bucket, ?string $extra = null): void {
    try {
        $key = $bucket.'|'.client_ip().($extra !== null && $extra !== '' ? '|'.hash('sha256', strtolower(trim($extra))) : '');
        db()->prepare('DELETE FROM rate_limits WHERE rate_key=?')->execute([$key]);
    } catch (Throwable $e) {
        // Best-effort only; a cleanup failure must not break a successful request.
    }
}

function rate_limit_cleanup(): void {
    try {
        db()->exec('DELETE FROM rate_limits WHERE window_start < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 2 DAY)');
    } catch (Throwable $e) {
        // Cleanup is best-effort and must never break the request.
    }
}
