package com.vghost.app.ui.theme

import androidx.compose.ui.graphics.Color

// VGhost cinematic brand palette: BLACK + RED + WHITE, with pearl-white sparkle highlights.
val GhostBlack = Color(0xFF050507)
val GhostDarkBackground = Color(0xFF08090C)
val GhostSurface = Color(0xFF0E0F13)
val GhostSurfaceElevated = Color(0xFF15161B)
val GhostSurfaceHighlight = Color(0xFF1E2026)
val GhostBorder = Color(0xFF2B2D33)
val GhostBorderLight = Color(0xFF454850)

val GhostRedPrimary = Color(0xFFFF2438)
val GhostRedHover = Color(0xFFFF4A59)
val GhostRedDark = Color(0xFF7F101D)
val GhostRedGlow = Color(0xFFFF6875)
val GhostRedBannerBg = Color(0xFF19070B)
val GhostRedBannerBorder = Color(0xFF6E1A25)

// Pearl is used only for the glossy/star-like highlights requested for the new visual identity.
val GhostPearl = Color(0xFFF2F1EC)
val GhostPearlSoft = Color(0xFFD9D8D4)

val GhostSurfaceGlass = Color(0xCC0D0E12)
val GhostSurfaceGlassStrong = Color(0xEE121318)
val GhostNeonSoft = GhostPearl
val GhostNeonDim = GhostRedDark
val GhostShadowRed = Color(0x99030006)
val GhostWhiteSoft = Color(0xFFF7F7F5)

val GhostTextWhite = Color(0xFFF7F7F5)
val GhostTextSecondary = Color(0xFFB9BABD)
val GhostTextMuted = Color(0xFF74767B)
val GhostTextRed = Color(0xFFFF6875)

// Kept white so the strict three-color UI remains consistent; semantic status is still
// represented by text/icon shape where applicable.
val GhostStatusOnline = GhostPearl
val GhostStatusOffline = GhostWhiteSoft
val GhostPearlBg = GhostRedBannerBg
val GhostPearlBorder = GhostRedBannerBorder
val GhostPearlText = GhostPearl
