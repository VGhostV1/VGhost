package com.vghost.app.ui.components
import com.vghost.app.i18n.trKey

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.filled.LocalMovies
import androidx.compose.material.icons.outlined.Whatshot
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostPearl
import com.vghost.app.i18n.tr
import com.vghost.app.R


enum class NavTab { FILMS, CHATS, FIND, STORY, PANIC, PROFILE }

@Composable
fun VGhostBottomNavBar(
    currentTab: NavTab,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(28.dp, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xF2181D25),
                        Color(0xF2080B10)
                    )
                ),
                RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
            )
    ) {
        HorizontalDivider(thickness = 1.dp, color = Color(0xFF42505F).copy(.45f))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .height(76.dp)
                .padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeonBottomNavItem(
                selected = currentTab == NavTab.FILMS,
                accent = GhostRedPrimary,
                accent2 = GhostPearl,
                icon = Icons.Filled.LocalMovies,
                contentDescription = tr("Filmlər"),
                testTag = "nav_films",
                onClick = { onTabSelected(NavTab.FILMS) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.STORY,
                accent = GhostPearl,
                accent2 = GhostRedPrimary,
                icon = Icons.Outlined.Whatshot,
                contentDescription = trKey("trailer_nav"),
                testTag = "nav_story",
                onClick = { onTabSelected(NavTab.STORY) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.FIND,
                accent = GhostRedPrimary,
                accent2 = GhostPearl,
                icon = Icons.Outlined.People,
                contentDescription = tr("İnsanlar"),
                testTag = "nav_find",
                onClick = { onTabSelected(NavTab.FIND) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.CHATS,
                accent = GhostPearl,
                accent2 = GhostRedPrimary,
                icon = Icons.Outlined.ChatBubbleOutline,
                contentDescription = trKey("chat"),
                testTag = "nav_chats",
                onClick = { onTabSelected(NavTab.CHATS) }
            )
            NeonBottomNavItem(
                selected = currentTab == NavTab.PROFILE,
                accent = GhostPearl,
                accent2 = GhostRedPrimary,
                icon = Icons.Outlined.Person,
                contentDescription = trKey("profile"),
                testTag = "nav_profile",
                onClick = { onTabSelected(NavTab.PROFILE) }
            )
        }
    }
}

@Composable
private fun NeonBottomNavItem(
    selected: Boolean,
    accent: Color,
    accent2: Color,
    icon: ImageVector,
    contentDescription: String,
    testTag: String,
    onClick: () -> Unit
) {
    val iconSize = if (selected) 30.dp else 27.dp
    Box(
        modifier = Modifier
            .width(64.dp)
            .height(58.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (selected) Brush.linearGradient(
                    listOf(accent.copy(alpha = 0.20f), accent2.copy(alpha = 0.08f))
                ) else Brush.linearGradient(
                    listOf(Color.Transparent, Color.Transparent)
                ),
                RoundedCornerShape(20.dp)
            )
            .border(
                width = if (selected) 1.dp else 0.dp,
                color = if (selected) accent.copy(alpha = 0.42f) else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (selected) accent else Color(0xFF8B96A4),
            modifier = Modifier
                .size(iconSize)
                .shadow(
                    if (selected) 16.dp else 0.dp,
                    CircleShape,
                    ambientColor = accent.copy(.55f),
                    spotColor = accent2.copy(.45f)
                )
        )
        if (selected) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .width(22.dp)
                    .height(2.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(accent, accent2)))
            )
        }
    }
}
