package com.vghost.app.ui.screens

import com.vghost.app.ui.components.premiumBackdrop

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.localizedFilmCategory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

private data class AdminFilmRow(val id:Long,val title:String,val category:String,val year:Int?,val active:Boolean,val featured:Boolean)

@Composable
fun AdminFilmsScreen(onBack:()->Unit) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<AdminFilmRow>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf(0L) }
    var title by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }
    var poster by remember { mutableStateOf("") }; var video by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Drama") }; var year by remember { mutableStateOf("") }; var duration by remember { mutableStateOf("") }
    var categoryMenuOpen by remember { mutableStateOf(false) }
    var categories by remember { mutableStateOf(listOf("Drama", "Action", "Comedy", "Romance", "Horror", "Fantasy", "Adventure", "Thriller", "Detective", "Crime", "Animation", "Family", "Historical", "Documentary", "Musical", "Science Fiction", "Biography", "Mystery")) }
    var vip by remember { mutableStateOf(false) }; var featured by remember { mutableStateOf(false) }; var active by remember { mutableStateOf(true) }
    var codeDialog by remember { mutableStateOf(false) }; var code by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var uploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableFloatStateOf(0f) }
    var uploadSent by remember { mutableLongStateOf(0L) }
    var uploadTotal by remember { mutableLongStateOf(0L) }
    var uploadKind by remember { mutableStateOf("") }
    var selectedPosterName by remember { mutableStateOf("") }
    var selectedVideoName by remember { mutableStateOf("") }
    var selectedPosterUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var selectedVideoUri by remember { mutableStateOf<android.net.Uri?>(null) }

    fun secure(action:()->Unit) { pending=action; code=""; codeDialog=true }
    fun load() { scope.launch { loading=true; try { val a=VGhostApi.adminFilms().optJSONArray("films") ?: JSONArray(); rows=(0 until a.length()).map{ val o=a.getJSONObject(it); AdminFilmRow(o.optLong("id"),o.optString("title"),o.optString("category"),if(o.isNull("release_year"))null else o.optInt("release_year"),o.optInt("is_active") == 1 || o.optBoolean("is_active"),o.optInt("is_featured") == 1 || o.optBoolean("is_featured")) }; status="" } catch(e:Throwable){ status=e.message.orEmpty() } finally { loading=false } } }
    LaunchedEffect(Unit){
        load()
        try {
            val a = VGhostApi.filmCategories().optJSONArray("categories") ?: JSONArray()
            val serverCategories = (0 until a.length()).map { a.getString(it) }.filter { it.isNotBlank() }
            if (serverCategories.isNotEmpty()) {
                categories = (serverCategories + categories).distinct()
            }
        } catch (_: Throwable) { }
    }

    fun mimeFor(kind:String, uri:android.net.Uri):String {
        val actual=context.contentResolver.getType(uri).orEmpty().lowercase()
        if(actual.isNotBlank() && actual!="application/octet-stream") return actual
        val name = runCatching {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if(c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull().orEmpty()
        val ext = name.substringAfterLast('.', "").lowercase()
        return when(ext) {
            "jpg","jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif";
            "bmp" -> "image/bmp"; "heic" -> "image/heic"; "heif" -> "image/heif"; "avif" -> "image/avif";
            "mp4" -> "video/mp4"; "webm" -> "video/webm"; "m4v" -> "video/x-m4v"; "mov" -> "video/quicktime";
            "3gp","3gpp" -> "video/3gpp"; "3g2" -> "video/3gpp2"; "mpeg","mpg" -> "video/mpeg";
            "mkv" -> "video/x-matroska"; "ogv" -> "video/ogg"; "ts","m2ts" -> "video/mp2t"; "flv" -> "video/x-flv";
            else -> if(kind=="poster") "image/jpeg" else "video/mp4"
        }
    }
    fun extensionFor(mime:String, kind:String)=when(mime.lowercase()) {
        "image/png"->"png"; "image/webp"->"webp"; "image/jpeg","image/jpg"->"jpg"; "image/gif"->"gif";
        "image/bmp"->"bmp"; "image/heic"->"heic"; "image/heif"->"heif"; "image/avif"->"avif";
        "video/webm"->"webm"; "video/x-m4v"->"m4v"; "video/quicktime"->"mov"; "video/3gpp"->"3gp";
        "video/3gpp2"->"3g2"; "video/mpeg"->"mpeg"; "video/x-matroska"->"mkv"; "video/ogg"->"ogv";
        "video/mp2t"->"ts"; "video/x-flv"->"flv"; "video/mp4"->"mp4";
        else->if(kind=="poster")"jpg" else "mp4"
    }
    suspend fun uploadFileNow(uri: android.net.Uri, kind: String, security: String): String {
        var temp: File? = null
        try {
            val mime = mimeFor(kind, uri)
            val ext = extensionFor(mime, kind)
            temp = withContext(Dispatchers.IO) {
                val f = File.createTempFile("vghost_film_", ".${ext}", context.cacheDir)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    f.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
                } ?: throw IllegalStateException(tr("Fayl oxuna bilmədi"))
                f
            }
            if (kind == "video" && temp.length() > 5L * 1024L * 1024L * 1024L) {
                throw IllegalStateException(tr("Film videosu maksimum 5 GB ola bilər"))
            }
            uploadKind = if (kind == "poster") "Poster" else "Video"
            uploadSent = 0L
            uploadTotal = temp.length()
            uploadProgress = 0f
            val result = VGhostApi.adminFilmUpload(editingId, kind, temp, temp.name, mime, security) { sent, total ->
                uploadSent = sent
                uploadTotal = total
                uploadProgress = if (total > 0L) (sent.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                status = "${if (kind == "poster") tr("Poster") else tr("Video")} ${tr("yüklənir…")} ${(uploadProgress * 100).toInt()}%"
            }
            return result.optString("url").ifBlank { throw IllegalStateException("MEDIA_UPLOAD_NO_URL") }
        } finally {
            temp?.delete()
            if (kind == "video" || kind == "poster") {
                if (uploadProgress >= 1f) {
                    uploadSent = uploadTotal
                    uploadProgress = 1f
                }
            }
        }
    }
    val posterPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selectedPosterUri = it; selectedPosterName = it.lastPathSegment?.substringAfterLast('/') ?: tr("Poster seçildi") }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selectedVideoUri = it; selectedVideoName = it.lastPathSegment?.substringAfterLast('/') ?: tr("Video seçildi") }
    }
    fun saveFilm(security: String) {
        scope.launch {
            uploading = true
            uploadProgress = 0f
            uploadSent = 0L
            uploadTotal = 0L
            uploadKind = ""
            try {
                val hasBackgroundUpload = selectedPosterUri != null || selectedVideoUri != null
                val result = VGhostApi.adminFilmSave(
                    editingId, title, desc, poster, video, category, year.toIntOrNull(),
                    duration.toIntOrNull(), vip, featured, if (hasBackgroundUpload) false else active, 0, security
                )
                val newId = result.optLong("id", editingId)
                if (newId <= 0L) throw IllegalStateException(tr("Film yaradılmadı"))
                editingId = newId

                if (!hasBackgroundUpload) {
                    status = tr("Film hazırdır ✓")
                    showForm = false
                    load()
                } else {
                    val uploadDir = File(context.filesDir, "film_uploads").apply { mkdirs() }
                    suspend fun copySelected(uri: android.net.Uri, prefix: String, fallbackExt: String): File = withContext(Dispatchers.IO) {
                        val name = uri.lastPathSegment?.substringAfterLast('/')?.replace(Regex("[^A-Za-z0-9._-]"), "_").orEmpty()
                        val ext = name.substringAfterLast('.', fallbackExt).ifBlank { fallbackExt }
                        val out = File(uploadDir, "${newId}_${prefix}_${System.currentTimeMillis()}.$ext")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            out.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
                        } ?: throw IllegalStateException(tr("Fayl oxuna bilmədi"))
                        out
                    }
                    val posterFile = selectedPosterUri?.let { copySelected(it, "poster", "jpg") }
                    val videoFile = selectedVideoUri?.let { copySelected(it, "video", "mp4") }
                    val serviceIntent = android.content.Intent(context, com.vghost.app.service.FilmUploadForegroundService::class.java).apply {
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_FILM_ID, newId)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_SECURITY, security)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_POSTER_PATH, posterFile?.absolutePath.orEmpty())
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_VIDEO_PATH, videoFile?.absolutePath.orEmpty())
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_EXISTING_POSTER, poster)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_EXISTING_VIDEO, video)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_TITLE, title)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_DESC, desc)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_CATEGORY, category)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_YEAR, year.toIntOrNull() ?: 0)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_DURATION, duration.toIntOrNull() ?: 0)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_VIP, vip)
                        putExtra(com.vghost.app.service.FilmUploadForegroundService.EXTRA_FEATURED, featured)
                    }
                    com.vghost.app.service.FilmUploadForegroundService.start(context, serviceIntent)
                    status = tr("Film arxa planda yüklənir…")
                    selectedPosterUri = null
                    selectedVideoUri = null
                    showForm = false
                    load()
                }
            } catch (e: Throwable) {
                status = e.message.orEmpty()
            } finally {
                uploading = false
                uploadKind = ""
            }
        }
    }

    Box(Modifier.fillMaxSize().premiumBackdrop()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { IconButton(onClick=onBack){Icon(Icons.Filled.ArrowBack,trKey("admin_back"),tint=Color.White)}; Text(trKey("admin_films_title"),color=Color.White,fontSize=21.sp); IconButton(onClick={load()}){Icon(Icons.Filled.Refresh,trKey("admin_refresh"),tint=Color.White)} }
            if(status.isNotBlank()) Text(status,color=if(uploading) Color(0xFFF2F1EC) else Color(0xFFD8D8DE),fontSize=11.sp,modifier=Modifier.padding(8.dp))
            Button(onClick={ editingId=0; uploading=false; uploadProgress=0f; uploadSent=0L; uploadTotal=0L; uploadKind=""; title="";desc="";poster="";video="";selectedPosterName="";selectedVideoName="";selectedPosterUri=null;selectedVideoUri=null;category="Drama";categoryMenuOpen=false;year="";duration="";vip=false;featured=false;active=false;showForm=true }, modifier=Modifier.fillMaxWidth()) { Text(trKey("t_c75fe0e98c99")) }
            Spacer(Modifier.height(10.dp))
            if(loading) CircularProgressIndicator(color=Color(0xFFFF1838),modifier=Modifier.padding(20.dp)) else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                items(rows) { row ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF15121A)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    try {
                                        val f = VGhostApi.film(row.id).optJSONObject("film")!!
                                        editingId = row.id
                                        uploading = false
                                        selectedPosterUri = null
                                        selectedVideoUri = null
                                        title = f.optString("title")
                                        desc = f.optString("description")
                                        poster = f.optString("poster_url")
                                        video = f.optString("video_url")
                                        selectedPosterName = if (poster.isNotBlank()) tr("Serverdəki poster") else ""
                                        selectedVideoName = if (video.isNotBlank()) tr("Serverdəki video") else ""
                                        category = f.optString("category")
                                        year = if (f.isNull("release_year")) "" else f.optInt("release_year").toString()
                                        duration = if (f.isNull("duration_minutes")) "" else f.optInt("duration_minutes").toString()
                                        vip = f.optInt("is_vip") == 1
                                        featured = f.optInt("is_featured") == 1
                                        active = f.optInt("is_active", 1) == 1
                                        showForm = true
                                    } catch (e: Throwable) {
                                        status = e.message.orEmpty()
                                    }
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(13.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(row.title, color = Color.White)
                                Text(
                                    "${localizedFilmCategory(row.category)}${row.year?.let { " • $it" } ?: ""}",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                            IconButton(
                                onClick = {
                                    secure {
                                        scope.launch {
                                            try {
                                                VGhostApi.adminFilmDelete(row.id, code)
                                                load()
                                            } catch (e: Throwable) {
                                                status = e.message.orEmpty()
                                            }
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = trKey("admin_delete"),
                                    tint = Color(0xFFFF4356)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    if(showForm) AlertDialog(
        onDismissRequest={ if(!uploading) showForm=false },
        title={ Text(if(editingId>0) tr("Filmi düzəlt") else tr("Yeni film")) },
        text={
            Column(Modifier.fillMaxWidth().heightIn(max=620.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedTextField(title,{title=it},label={Text(tr("Başlıq"))},singleLine=true,modifier=Modifier.fillMaxWidth())
                Box(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = localizedFilmCategory(category),
                        onValueChange = { },
                        label = { Text(tr("Janr")) },
                        readOnly = true,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { categoryMenuOpen = true },
                        trailingIcon = {
                            TextButton(onClick = { categoryMenuOpen = !categoryMenuOpen }) {
                                Text(if (categoryMenuOpen) "▲" else "▼")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = categoryMenuOpen,
                        onDismissRequest = { categoryMenuOpen = false },
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        categories.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(localizedFilmCategory(option)) },
                                onClick = {
                                    category = option
                                    categoryMenuOpen = false
                                }
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedTextField(year,{year=it},label={Text(tr("İl"))},singleLine=true,modifier=Modifier.weight(1f))
                    OutlinedTextField(duration,{duration=it},label={Text(tr("Müddət"))},singleLine=true,modifier=Modifier.weight(1f))
                }
                OutlinedTextField(desc,{desc=it},label={Text(tr("Açıqlama"))},minLines=3,modifier=Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(enabled=!uploading,onClick={posterPicker.launch("image/*")},modifier=Modifier.weight(1f)){
                        Text(if(selectedPosterName.isBlank()) "🖼 Poster" else "✓ Poster",maxLines=1)
                    }
                    OutlinedButton(enabled=!uploading,onClick={videoPicker.launch("video/*")},modifier=Modifier.weight(1f)){
                        Text(if(selectedVideoName.isBlank()) "🎬 Video" else "✓ Video",maxLines=1)
                    }
                }
                if(selectedPosterName.isNotBlank()) Text(selectedPosterName,color=Color(0xFFAAAAB8),fontSize=10.sp)
                if(selectedVideoName.isNotBlank()) Text(selectedVideoName,color=Color(0xFFAAAAB8),fontSize=10.sp)
                if (uploading) {
                    Column(Modifier.fillMaxWidth().padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        val percent = (uploadProgress * 100f).toInt().coerceIn(0, 100)
                        val sentMb = uploadSent / (1024f * 1024f)
                        val totalMb = uploadTotal / (1024f * 1024f)
                        Text(
                            "${tr(uploadKind.ifBlank { "Fayl" })} ${tr("yüklənir")} • $percent%",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(18.dp)
                                .background(Color(0xFF3A3740), RoundedCornerShape(9.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(uploadProgress.coerceIn(0f, 1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFFF1838), RoundedCornerShape(9.dp))
                            )
                            Text(
                                text = "$percent%",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.align(androidx.compose.ui.Alignment.Center)
                            )
                        }
                        Text(
                            if (uploadTotal > 0L) "${String.format(java.util.Locale.US, "%.1f", sentMb)} / ${String.format(java.util.Locale.US, "%.1f", totalMb)} MB" else tr("Fayl hazırlanır…"),
                            color = Color(0xFFBDBAC5),
                            fontSize = 11.sp
                        )
                    }
                }
                Row{
                    Checkbox(vip,{vip=it}); Text("VIP",modifier=Modifier.padding(top=12.dp))
                    Spacer(Modifier.width(12.dp))
                    Checkbox(featured,{featured=it}); Text(tr("Featured"),modifier=Modifier.padding(top=12.dp))
                }
                Text(tr("Poster və video seç, sonra yalnız bir dəfə təsdiq kodunu daxil et."),color=Color(0xFF9E9EAA),fontSize=10.sp)
            }
        },
        confirmButton={
            Button(enabled=!uploading && title.isNotBlank(),onClick={secure{saveFilm(code)}}){
                Text(if(uploading) tr("Yüklənir…") else tr("Yadda saxla"))
            }
        },
        dismissButton={TextButton(enabled=!uploading,onClick={showForm=false}){Text(tr("Ləğv et"))}}
    )
    if(codeDialog) AlertDialog(
        onDismissRequest={codeDialog=false},
        title={Text(tr("Admin kodu"))},
        text={OutlinedTextField(code,{code=it},label={Text(tr("Təsdiq kodu"))},visualTransformation=PasswordVisualTransformation(),singleLine=true)},
        confirmButton={Button(onClick={val action=pending;codeDialog=false;action?.invoke()}){Text(tr("Başla"))}},
        dismissButton={TextButton(onClick={codeDialog=false}){Text(tr("Ləğv et"))}}
    )
}
