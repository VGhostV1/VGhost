package com.vghost.app.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostPearl
import com.vghost.app.ui.theme.GhostRedPrimary

/** Shared cinematic VGhost backdrop: black + red + white with pearlescent star glints. */
fun Modifier.premiumBackdrop(): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF0A0507), GhostBlack, Color(0xFF030304))
        )
    )

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(GhostRedPrimary.copy(alpha = 0.105f), Color.Transparent),
            center = Offset(w * 0.86f, h * 0.20f),
            radius = w * 0.90f
        ),
        center = Offset(w * 0.86f, h * 0.20f),
        radius = w * 0.90f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(GhostRedPrimary.copy(alpha = 0.055f), Color.Transparent),
            center = Offset(w * 0.12f, h * 0.78f),
            radius = w * 0.75f
        ),
        center = Offset(w * 0.12f, h * 0.78f),
        radius = w * 0.75f
    )

    val streaks = listOf(
        Offset(-w * 0.10f, h * 0.18f) to Offset(w * 0.42f, -h * 0.02f),
        Offset(w * 0.68f, -h * 0.02f) to Offset(w * 1.10f, h * 0.18f),
        Offset(-w * 0.08f, h * 0.88f) to Offset(w * 0.32f, h * 1.04f),
        Offset(w * 0.78f, h * 1.03f) to Offset(w * 1.08f, h * 0.84f)
    )
    streaks.forEachIndexed { i, (start, end) ->
        val tint = if (i % 2 == 0) GhostPearl else GhostRedPrimary
        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, tint.copy(alpha = 0.13f), Color.Transparent),
                start = start,
                end = end
            ),
            start = start,
            end = end,
            strokeWidth = 1.5f
        )
    }

    // Pearlescent four-point star glints: restrained and premium, not a colorful galaxy.
    val stars = listOf(
        0.09f to 0.12f, 0.24f to 0.08f, 0.48f to 0.16f, 0.79f to 0.10f,
        0.91f to 0.30f, 0.14f to 0.48f, 0.36f to 0.72f, 0.68f to 0.63f,
        0.86f to 0.79f, 0.53f to 0.90f, 0.07f to 0.88f
    )
    stars.forEachIndexed { i, (x, y) ->
        val r = if (i % 4 == 0) 2.2f else 1.2f
        val c = GhostPearl.copy(alpha = if (i % 4 == 0) 0.72f else 0.30f)
        val center = Offset(w * x, h * y)
        drawLine(c, Offset(center.x - r * 3.2f, center.y), Offset(center.x + r * 3.2f, center.y), strokeWidth = 0.7f)
        drawLine(c, Offset(center.x, center.y - r * 3.2f), Offset(center.x, center.y + r * 3.2f), strokeWidth = 0.7f)
        drawCircle(c, r, center)
    }

    // One thin red cinematic arc for depth.
    drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, GhostRedPrimary.copy(alpha = 0.12f), Color.Transparent)),
        startAngle = 204f,
        sweepAngle = 68f,
        useCenter = false,
        topLeft = Offset(-w * 0.10f, h * 0.56f),
        size = androidx.compose.ui.geometry.Size(w * 1.20f, w * 1.20f),
        style = Stroke(width = 1.6f)
    )
}
