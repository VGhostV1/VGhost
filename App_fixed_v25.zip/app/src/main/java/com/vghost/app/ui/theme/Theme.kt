package com.vghost.app.ui.theme

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = GhostRedPrimary,
    onPrimary = GhostWhiteSoft,
    primaryContainer = GhostRedDark,
    onPrimaryContainer = GhostWhiteSoft,
    secondary = GhostPearl,
    onSecondary = GhostBlack,
    tertiary = GhostRedHover,
    onTertiary = GhostWhiteSoft,
    tertiaryContainer = GhostRedBannerBg,
    onTertiaryContainer = GhostWhiteSoft,
    background = GhostBlack,
    onBackground = GhostTextWhite,
    surface = GhostSurface,
    onSurface = GhostTextWhite,
    surfaceVariant = GhostSurfaceElevated,
    onSurfaceVariant = GhostTextSecondary,
    outline = GhostBorder,
    outlineVariant = GhostBorderLight
)

@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

/** Global VGhost atmosphere: cinematic black/red background with pearl-white sparkles. */
@Composable
fun NeonBackdrop(content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "vghost_pearl_sparkles")
    val drift by transition.animateFloat(
        initialValue = -0.06f,
        targetValue = 0.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(9000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift"
    )
    val sparkle by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sparkle"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF1A080C),
                        Color(0xFF09090C),
                        GhostBlack
                    ),
                    radius = 1350f
                )
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = (drift * 24f).dp)
                .alpha(0.82f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            GhostRedPrimary.copy(alpha = 0.105f),
                            Color.Transparent
                        ),
                        radius = 900f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = (-drift * 18f).dp)
                .alpha(0.9f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            GhostPearl.copy(alpha = 0.035f),
                            Color.Transparent
                        ),
                        radius = 780f
                    )
                )
        )
        // Pearl-white sparkle points. The shared backdrop makes the new visual language
        // consistent even on screens that do not draw their own cards/backgrounds.
        Canvas(Modifier.fillMaxSize().alpha(sparkle)) {
            val stars = listOf(
                0.07f to 0.10f, 0.21f to 0.18f, 0.42f to 0.07f, 0.72f to 0.14f,
                0.91f to 0.24f, 0.13f to 0.48f, 0.34f to 0.71f, 0.64f to 0.59f,
                0.86f to 0.77f, 0.50f to 0.90f
            )
            stars.forEachIndexed { i, (x, y) ->
                val r = if (i % 3 == 0) 2.1f else 1.1f
                val c = GhostPearl.copy(alpha = if (i % 3 == 0) 0.66f else 0.26f)
                val center = Offset(size.width * x, size.height * y)
                drawLine(c, Offset(center.x - r * 3f, center.y), Offset(center.x + r * 3f, center.y), strokeWidth = 0.7f)
                drawLine(c, Offset(center.x, center.y - r * 3f), Offset(center.x, center.y + r * 3f), strokeWidth = 0.7f)
                drawCircle(c, r, center)
            }
        }
        content()
    }
}
