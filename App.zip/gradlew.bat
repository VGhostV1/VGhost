@echo off
setlocal
set APP_HOME=%~dp0
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
set EXPECTED_SHA256=b3a875ddc1f044746e1b1a55f645584505f4a10438c1afea9f15e92a7c42ec13
set WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v9.3.1/gradle/wrapper/gradle-wrapper.jar

if not exist "%WRAPPER_JAR%" (
  where curl >nul 2>nul
  if %ERRORLEVEL% EQU 0 (
    curl -fsSL --retry 3 -o "%WRAPPER_JAR%.tmp" "%WRAPPER_URL%"
  ) else (
    where powershell >nul 2>nul
    if not %ERRORLEVEL% EQU 0 (
      echo ERROR: curl or PowerShell is required to bootstrap Gradle Wrapper.
      exit /b 1
    )
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%.tmp'"
  )
  move /Y "%WRAPPER_JAR%.tmp" "%WRAPPER_JAR%" >nul
)

if not defined JAVA_HOME (
  where java >nul 2>nul
  if not %ERRORLEVEL% EQU 0 (
    echo ERROR: JAVA_HOME is not set and java was not found.
    exit /b 1
  )
  set JAVA_CMD=java
) else (
  set JAVA_CMD=%JAVA_HOME%\bin\java.exe
)

"%JAVA_CMD%" -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
set EXIT_CODE=%ERRORLEVEL%
endlocal & exit /b %EXIT_CODE%
