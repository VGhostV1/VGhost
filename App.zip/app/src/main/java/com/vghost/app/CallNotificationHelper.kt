package com.vghost.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

/** Dedicated incoming-call notification. Calls are time-sensitive and may open
 * the full-screen incoming-call activity while the app is backgrounded. */
object CallNotificationHelper {
    private const val CHANNEL_ID = "vghost_calls"
    private const val CHANNEL_NAME = "VGhost Calls"

    fun showIncoming(
        context: Context,
        callId: Long,
        callerName: String,
        callType: String,
        isTest: Boolean = false
    ) {
        if (callId < 1L) return
        val manager = context.getSystemService(NotificationManager::class.java)
        createChannel(manager)

        val intent = IncomingCallActivity.intent(context, callId, callerName, callType, isTest)
        val pending = PendingIntent.getActivity(
            context,
            callId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (isTest) "🧪 VGHOST Test Zəngi" else "VGHOST"
        val body = if (callType.equals("video", true)) "$callerName — gələn video zəng" else "$callerName — gələn səs zəngi"
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vghost)
            .setContentTitle(title)
            .setContentText(body)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setTimeoutAfter(120_000L)
            .setContentIntent(pending)
            .setFullScreenIntent(pending, true)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$body\nZəngi qəbul etmək və ya rədd etmək üçün toxun."))
            .build()
        manager.notify(notificationId(callId), notification)
    }

    fun cancel(context: Context, callId: Long) {
        if (callId < 1L) return
        context.getSystemService(NotificationManager::class.java).cancel(notificationId(callId))
    }

    private fun notificationId(callId: Long): Int = (callId xor (callId ushr 32)).toInt()

    private fun createChannel(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val ringtone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                description = "VGhost incoming voice and video calls"
                setSound(ringtone, attrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 300, 500)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
        )
    }
}
