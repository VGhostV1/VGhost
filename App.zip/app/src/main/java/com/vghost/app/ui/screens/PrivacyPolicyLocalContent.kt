package com.vghost.app.ui.screens

import android.content.Context
import com.vghost.app.R

data class LocalPrivacySection(val title: String, val body: String)
data class LocalPrivacyDocument(val title: String, val intro: String, val sections: List<LocalPrivacySection>)

object VGhostLocalPrivacyPolicy {
    fun get(context: Context): LocalPrivacyDocument {
        fun s(id: Int) = context.getString(id)
        val sections = listOf(
            R.string.privacy_s1_title to R.string.privacy_s1_body,
            R.string.privacy_s2_title to R.string.privacy_s2_body,
            R.string.privacy_s3_title to R.string.privacy_s3_body,
            R.string.privacy_s4_title to R.string.privacy_s4_body,
            R.string.privacy_s6_title to R.string.privacy_s6_body,
            R.string.privacy_s7_title to R.string.privacy_s7_body,
            R.string.privacy_s8_title to R.string.privacy_s8_body
        ).map { (titleId, bodyId) -> LocalPrivacySection(s(titleId), s(bodyId)) }
        return LocalPrivacyDocument(s(R.string.privacy_title), s(R.string.privacy_intro), sections)
    }
}
