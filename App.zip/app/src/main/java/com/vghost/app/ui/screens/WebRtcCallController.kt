package com.vghost.app.ui.screens

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import com.vghost.app.network.VGhostApi

class WebRtcCallController(
    private val context: Context,
    private val callId: Long,
    private val callType: String,
    private val isCaller: Boolean
) {
    data class UiState(val connectionState: String = "CONNECTING")
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()

    private val eglBase = EglBase.create()
    val eglContext: EglBase.Context get() = eglBase.eglBaseContext
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var videoTrack: VideoTrack? = null
    private var remoteVideoTrack: VideoTrack? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var signalJob: Job? = null
    private var captureJob: Job? = null
    private var lastSignalId = 0L
    private val queuedIce = mutableListOf<IceCandidate>()
    private var remoteDescriptionSet = false
    private var started = false

    fun start(scope: CoroutineScope) {
        if (started) return
        started = true
        try {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            val encoder = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
            val decoder = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
            factory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(encoder)
                .setVideoDecoderFactory(decoder)
                .createPeerConnectionFactory()

            val iceServers = listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
            )
            val config = PeerConnection.RTCConfiguration(iceServers).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            }
            peer = factory!!.createPeerConnection(config, observer())
            createLocalTracks()
            signalJob = scope.launch { signalLoop() }
            _state.value = UiState(if (isCaller) "RINGING" else "CONNECTING")
            if (isCaller) {
                scope.launch { createOffer() }
            } else {
                scope.launch { waitForOffer() }
            }
        } catch (t: Throwable) {
            _state.value = UiState("FAILED")
        }
    }

    private fun createLocalTracks() {
        val f = factory ?: return
        val audioSource = f.createAudioSource(MediaConstraints())
        audioTrack = f.createAudioTrack("VGHOST_AUDIO_$callId", audioSource)
        audioTrack?.setEnabled(true)
        peer?.addTrack(audioTrack)
        if (callType.equals("video", true)) {
            val capturer = createCameraCapturer(context)
            videoCapturer = capturer
            val videoSource = f.createVideoSource(capturer.isScreencast)
            videoTrack = f.createVideoTrack("VGHOST_VIDEO_$callId", videoSource)
            videoTrack?.setEnabled(true)
            peer?.addTrack(videoTrack)
            capturer.initialize(SurfaceTextureHelper.create("VGhostCapture", eglBase.eglBaseContext), context, videoSource.capturerObserver)
            capturer.startCapture(640, 480, 24)
        }
    }

    private fun createCameraCapturer(context: Context): CameraVideoCapturer {
        val enumerator = Camera2Enumerator(context)
        val names = enumerator.deviceNames
        val front = names.firstOrNull { enumerator.isFrontFacing(it) }
        val back = names.firstOrNull { !enumerator.isFrontFacing(it) }
        return when {
            front != null -> enumerator.createCapturer(front, null)
            back != null -> enumerator.createCapturer(back, null)
            else -> throw IllegalStateException("No camera")
        }
    }

    private suspend fun waitForOffer() {
        // Signal loop receives the offer and creates the answer.
    }

    private suspend fun createOffer() {
        val p = peer ?: return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (callType.equals("video", true)) "true" else "false"))
        }
        p.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                p.setLocalDescription(SdpObserverAdapter(), desc)
                sendSignal("offer", JSONObject().put("type", desc.type.canonicalForm()).put("sdp", desc.description))
            }
            override fun onCreateFailure(error: String) { _state.value = UiState("FAILED") }
        }, constraints)
    }

    private suspend fun createAnswer() {
        val p = peer ?: return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (callType.equals("video", true)) "true" else "false"))
        }
        p.createAnswer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                p.setLocalDescription(SdpObserverAdapter(), desc)
                sendSignal("answer", JSONObject().put("type", desc.type.canonicalForm()).put("sdp", desc.description))
            }
            override fun onCreateFailure(error: String) { _state.value = UiState("FAILED") }
        }, constraints)
    }

    private suspend fun signalLoop() {
        while (started) {
            try {
                val response = VGhostApi.call("call/signals?call_id=$callId&after=$lastSignalId")
                val arr = response.optJSONArray("signals") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    lastSignalId = maxOf(lastSignalId, s.optLong("id"))
                    handleSignal(s.optString("signalType"), s.opt("payload"))
                }
                if (response.optString("status") in listOf("ended", "rejected", "missed", "cancelled")) {
                    _state.value = UiState("CLOSED")
                    break
                }
            } catch (_: Throwable) { }
            delay(500)
        }
    }

    private suspend fun handleSignal(type: String, payload: Any?) {
        when (type) {
            "offer" -> {
                if (isCaller) return
                val o = payload as? JSONObject ?: return
                val desc = SessionDescription(SessionDescription.Type.OFFER, o.optString("sdp"))
                peer?.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        queuedIce.forEach { peer?.addIceCandidate(it) }
                        queuedIce.clear()
                        CoroutineScope(kotlinx.coroutines.Dispatchers.Default).launch { createAnswer() }
                    }
                }, desc)
            }
            "answer" -> {
                if (!isCaller) return
                val o = payload as? JSONObject ?: return
                val desc = SessionDescription(SessionDescription.Type.ANSWER, o.optString("sdp"))
                peer?.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        queuedIce.forEach { peer?.addIceCandidate(it) }
                        queuedIce.clear()
                    }
                }, desc)
            }
            "ice" -> {
                val o = payload as? JSONObject ?: return
                val c = IceCandidate(o.optString("sdpMid"), o.optInt("sdpMLineIndex"), o.optString("candidate"))
                if (remoteDescriptionSet) peer?.addIceCandidate(c) else queuedIce += c
            }
            "hangup", "reject" -> _state.value = UiState("CLOSED")
        }
    }

    private fun sendSignal(type: String, payload: JSONObject) {
        kotlinx.coroutines.GlobalScope.launch {
            try {
                VGhostApi.call("call/signal", "POST", JSONObject().put("call_id", callId).put("signal_type", type).put("payload", payload))
            } catch (_: Throwable) { }
        }
    }

    private fun observer() = object : PeerConnection.Observer {
        override fun onSignalingChange(p0: PeerConnection.SignalingState) = Unit
        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
            _state.value = UiState(when (state) {
                PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> "CONNECTED"
                PeerConnection.IceConnectionState.FAILED -> "FAILED"
                PeerConnection.IceConnectionState.CLOSED -> "CLOSED"
                else -> "CONNECTING"
            })
        }
        override fun onIceConnectionReceivingChange(p0: Boolean) = Unit
        override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState) = Unit
        override fun onIceCandidate(c: IceCandidate) {
            kotlinx.coroutines.GlobalScope.launch {
                sendSignal("ice", JSONObject().put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex).put("candidate", c.sdp))
            }
        }
        override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>) = Unit
        override fun onAddStream(p0: MediaStream) = Unit
        override fun onRemoveStream(p0: MediaStream) = Unit
        override fun onDataChannel(p0: DataChannel) = Unit
        override fun onRenegotiationNeeded() = Unit
        override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {
            val track = receiver.track()
            if (track is VideoTrack) { remoteVideoTrack = track; remoteRenderer?.let { track.addSink(it) } }
        }
        override fun onRemoveTrack(receiver: RtpReceiver) {
            if (receiver.track() === remoteVideoTrack) remoteVideoTrack = null
        }
        override fun onTrack(transceiver: RtpTransceiver) {
            val track = transceiver.receiver.track()
            if (track is VideoTrack) { remoteVideoTrack = track; remoteRenderer?.let { track.addSink(it) } }
        }
        override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
            if (newState == PeerConnection.PeerConnectionState.CONNECTED) _state.value = UiState("CONNECTED")
            if (newState == PeerConnection.PeerConnectionState.FAILED) _state.value = UiState("FAILED")
            if (newState == PeerConnection.PeerConnectionState.CLOSED) _state.value = UiState("CLOSED")
        }
        override fun onStandardizedIceConnectionChange(p0: PeerConnection.IceConnectionState) = Unit
        override fun onSelectedCandidatePairChanged(p0: CandidatePairChangeEvent) = Unit
    }

    fun setRemoteRenderer(renderer: SurfaceViewRenderer) {
        remoteRenderer = renderer
        remoteVideoTrack?.let { it.addSink(renderer) }
    }
    fun setLocalRenderer(renderer: SurfaceViewRenderer) {
        localRenderer = renderer
        videoTrack?.let { it.addSink(renderer) }
    }
    fun setMicEnabled(enabled: Boolean) { audioTrack?.setEnabled(enabled) }
    fun setCameraEnabled(enabled: Boolean) { videoTrack?.setEnabled(enabled) }
    fun switchCamera() { videoCapturer?.switchCamera(null) }

    fun stop() {
        if (!started) return
        started = false
        signalJob?.cancel(); captureJob?.cancel()
        try { videoCapturer?.stopCapture() } catch (_: Throwable) {}
        videoCapturer?.dispose(); videoCapturer = null
        videoTrack?.dispose(); remoteVideoTrack?.dispose(); audioTrack?.dispose(); videoTrack = null; remoteVideoTrack = null; audioTrack = null
        peer?.close(); peer?.dispose(); peer = null
        factory?.dispose(); factory = null
        localRenderer?.release(); remoteRenderer?.release()
        localRenderer = null; remoteRenderer = null
        eglBase.release()
    }
}

open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) = Unit
    override fun onSetSuccess() = Unit
    override fun onCreateFailure(error: String) = Unit
    override fun onSetFailure(error: String) = Unit
}
