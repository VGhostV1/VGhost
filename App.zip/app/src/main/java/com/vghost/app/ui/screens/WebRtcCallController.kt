package com.vghost.app.ui.screens

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import com.vghost.app.network.VGhostApi

/**
 * Production WebRTC controller for VGhost App <-> App and Admin Browser <-> App calls.
 * The PHP API is signaling only; media is peer-to-peer. TURN is intentionally not used yet.
 */
class WebRtcCallController(
    private val context: Context,
    private val callId: Long,
    private val callType: String,
    private val isCaller: Boolean
) {
    data class Diagnostic(
        val time: String,
        val title: String,
        val detail: String,
        val ok: Boolean? = null
    )

    data class UiState(
        val connectionState: String = "STARTING",
        val signalingState: String = "IDLE",
        val iceState: String = "NEW",
        val localAudio: Boolean = false,
        val localVideo: Boolean = false,
        val remoteAudio: Boolean = false,
        val remoteVideo: Boolean = false,
        val diagnostics: List<Diagnostic> = emptyList(),
        val error: String? = null
    )

    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()

    private val eglBase = EglBase.create()
    val eglContext: EglBase.Context get() = eglBase.eglBaseContext
    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var audioTrack: AudioTrack? = null
    private var videoTrack: VideoTrack? = null
    private var remoteVideoTrack: VideoTrack? = null
    private var remoteAudioTrack: AudioTrack? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var localRenderer: SurfaceViewRenderer? = null
    private var remoteRenderer: SurfaceViewRenderer? = null
    private var signalJob: Job? = null
    private var lastSignalId = 0L
    private val queuedIce = mutableListOf<IceCandidate>()
    private var remoteDescriptionSet = false
    private var started = false
    private var stopped = false

    private fun update(block: (UiState) -> UiState) {
        _state.value = block(_state.value)
    }

    private fun diag(title: String, detail: String, ok: Boolean? = null) {
        val hhmmss = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
            .format(java.util.Date())
        update {
            it.copy(diagnostics = (it.diagnostics + Diagnostic(hhmmss, title, detail, ok)).takeLast(80))
        }
    }

    private fun setConnection(value: String) {
        update { it.copy(connectionState = value) }
        diag("WebRTC", value)
    }

    fun start(scope: CoroutineScope) {
        if (started || stopped) return
        started = true
        stopped = false
        diag("CALL", "Call #$callId • ${callType.uppercase()} • ${if (isCaller) "CALLER" else "CALLEE"}")
        diag("NETWORK", "TURN OFF • STUN: stun.l.google.com:19302", true)
        try {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            diag("ENGINE", "PeerConnectionFactory initialized", true)

            val encoder = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
            val decoder = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
            factory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(encoder)
                .setVideoDecoderFactory(decoder)
                .createPeerConnectionFactory()
            diag("ENGINE", "Encoder/decoder ready", true)

            val iceServers = listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
            )
            val config = PeerConnection.RTCConfiguration(iceServers).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            }
            peer = factory?.createPeerConnection(config, observer())
            if (peer == null) throw IllegalStateException("PeerConnection yaradılmadı")
            diag("PEER", "PeerConnection created", true)

            createLocalTracks()
            signalJob = scope.launch { signalLoop() }
            setConnection(if (isCaller) "RINGING" else "CONNECTING")

            if (isCaller) {
                scope.launch { createOffer() }
            } else {
                diag("SIGNALING", "Offer gözlənilir…")
            }
        } catch (t: Throwable) {
            val msg = t.message ?: t.javaClass.simpleName
            update { it.copy(connectionState = "FAILED", error = msg) }
            diag("FATAL", msg, false)
        }
    }

    private fun createLocalTracks() {
        val f = factory ?: return
        try {
            val audioSource = f.createAudioSource(MediaConstraints())
            audioTrack = f.createAudioTrack("VGHOST_AUDIO_$callId", audioSource)
            audioTrack?.setEnabled(true)
            peer?.addTrack(audioTrack)
            update { it.copy(localAudio = audioTrack != null) }
            diag("MIC", if (audioTrack != null) "Local audio track hazır" else "Audio track yaradıla bilmədi", audioTrack != null)

            if (callType.equals("video", true)) {
                val capturer = createCameraCapturer(context)
                videoCapturer = capturer
                val videoSource = f.createVideoSource(capturer.isScreencast)
                videoTrack = f.createVideoTrack("VGHOST_VIDEO_$callId", videoSource)
                videoTrack?.setEnabled(true)
                peer?.addTrack(videoTrack)
                capturer.initialize(
                    SurfaceTextureHelper.create("VGhostCapture", eglBase.eglBaseContext),
                    context,
                    videoSource.capturerObserver
                )
                capturer.startCapture(640, 480, 24)
                update { it.copy(localVideo = videoTrack != null) }
                diag("CAMERA", if (videoTrack != null) "Local video track + capture hazır" else "Video track yaradıla bilmədi", videoTrack != null)
            } else {
                diag("CAMERA", "Voice call • kamera lazım deyil", true)
            }
        } catch (t: Throwable) {
            val msg = t.message ?: t.javaClass.simpleName
            update { it.copy(error = msg) }
            diag("MEDIA", msg, false)
            if (callType.equals("video", true)) throw t
        }
    }

    private fun createCameraCapturer(context: Context): CameraVideoCapturer {
        val enumerator = Camera2Enumerator(context)
        val names = enumerator.deviceNames
        val front = names.firstOrNull { enumerator.isFrontFacing(it) }
        val back = names.firstOrNull { !enumerator.isFrontFacing(it) }
        return when {
            front != null -> enumerator.createCapturer(front, null)
            back != null -> enumerator.createCapturer(back, null)
            else -> throw IllegalStateException("Kamera tapılmadı")
        }
    }

    private suspend fun createOffer() {
        val p = peer ?: return
        diag("SIGNALING", "Offer yaradılır…")
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (callType.equals("video", true)) "true" else "false"))
        }
        p.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                p.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        diag("SDP", "Local OFFER set edildi", true)
                        sendSignal("offer", JSONObject().put("type", desc.type.canonicalForm()).put("sdp", desc.description))
                    }
                    override fun onSetFailure(error: String) { diag("SDP", "Offer local set failed: $error", false) }
                }, desc)
            }
            override fun onCreateFailure(error: String) {
                update { it.copy(connectionState = "FAILED", error = error) }
                diag("SDP", "Offer create failed: $error", false)
            }
        }, constraints)
    }

    private suspend fun createAnswer() {
        val p = peer ?: return
        diag("SIGNALING", "Answer yaradılır…")
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", if (callType.equals("video", true)) "true" else "false"))
        }
        p.createAnswer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                p.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        diag("SDP", "Local ANSWER set edildi", true)
                        sendSignal("answer", JSONObject().put("type", desc.type.canonicalForm()).put("sdp", desc.description))
                    }
                    override fun onSetFailure(error: String) { diag("SDP", "Answer local set failed: $error", false) }
                }, desc)
            }
            override fun onCreateFailure(error: String) {
                update { it.copy(connectionState = "FAILED", error = error) }
                diag("SDP", "Answer create failed: $error", false)
            }
        }, constraints)
    }

    private suspend fun signalLoop() {
        diag("SIGNALING", "Backend polling başladı", true)
        while (started && !stopped) {
            try {
                val peerName = if (isCaller) "app" else "app"
                val response = VGhostApi.call("call/signals?call_id=$callId&after=$lastSignalId&peer=$peerName")
                val arr = response.optJSONArray("signals") ?: JSONArray()
                if (arr.length() > 0) diag("SIGNALING", "${arr.length()} yeni signal alındı", true)
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    lastSignalId = maxOf(lastSignalId, s.optLong("id"))
                    handleSignal(s.optString("signalType"), s.opt("payload"))
                }
                val status = response.optString("status")
                if (status in listOf("ended", "rejected", "missed", "cancelled")) {
                    diag("CALL", "Backend status: $status", status == "ended")
                    update { it.copy(connectionState = "CLOSED") }
                    break
                }
            } catch (t: Throwable) {
                diag("SIGNALING", "Poll xətası: ${t.message ?: t.javaClass.simpleName}", false)
            }
            delay(450L)
        }
        diag("SIGNALING", "Backend polling dayandı")
    }

    private fun payloadObject(payload: Any?): JSONObject? {
        return when (payload) {
            is JSONObject -> payload
            is String -> runCatching { JSONObject(payload) }.getOrNull()
            else -> null
        }
    }

    private suspend fun handleSignal(type: String, payload: Any?) {
        when (type) {
            "offer" -> {
                if (isCaller) return
                val o = payloadObject(payload) ?: return
                val sdp = o.optString("sdp")
                if (sdp.isBlank()) { diag("SDP", "Boş offer alındı", false); return }
                diag("SDP", "Remote OFFER alındı", true)
                val desc = SessionDescription(SessionDescription.Type.OFFER, sdp)
                peer?.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        diag("SDP", "Remote OFFER set edildi", true)
                        flushIce()
                        CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch { createAnswer() }
                    }
                    override fun onSetFailure(error: String) { diag("SDP", "Remote offer set failed: $error", false) }
                }, desc)
            }
            "answer" -> {
                if (!isCaller) return
                val o = payloadObject(payload) ?: return
                val sdp = o.optString("sdp")
                if (sdp.isBlank()) { diag("SDP", "Boş answer alındı", false); return }
                diag("SDP", "Remote ANSWER alındı", true)
                val desc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
                peer?.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        diag("SDP", "Remote ANSWER set edildi", true)
                        flushIce()
                    }
                    override fun onSetFailure(error: String) { diag("SDP", "Remote answer set failed: $error", false) }
                }, desc)
            }
            "ice" -> {
                val o = payloadObject(payload) ?: return
                val candidate = o.optString("candidate")
                if (candidate.isBlank()) return
                val c = IceCandidate(o.optString("sdpMid"), o.optInt("sdpMLineIndex"), candidate)
                if (remoteDescriptionSet) {
                    peer?.addIceCandidate(c)
                    diag("ICE", "Remote ICE əlavə edildi", true)
                } else {
                    queuedIce += c
                    diag("ICE", "Remote ICE növbəyə alındı (${queuedIce.size})")
                }
            }
            "hangup", "reject" -> {
                diag("CALL", "Remote ${type.uppercase()} alındı", true)
                update { it.copy(connectionState = "CLOSED") }
            }
        }
    }

    private fun flushIce() {
        if (!remoteDescriptionSet) return
        if (queuedIce.isNotEmpty()) diag("ICE", "${queuedIce.size} queued ICE əlavə edilir…")
        queuedIce.forEach { runCatching { peer?.addIceCandidate(it) } }
        queuedIce.clear()
    }

    private fun sendSignal(type: String, payload: JSONObject) {
        diag("SIGNALING", "$type göndərilir…")
        CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                VGhostApi.call(
                    "call/signal",
                    "POST",
                    JSONObject()
                        .put("call_id", callId)
                        .put("signal_type", type)
                        .put("payload", payload)
                        .put("peer", "app")
                )
                diag("SIGNALING", "$type backend-ə göndərildi", true)
            } catch (t: Throwable) {
                diag("SIGNALING", "$type send failed: ${t.message ?: t.javaClass.simpleName}", false)
            }
        }
    }

    private fun observer() = object : PeerConnection.Observer {
        override fun onSignalingChange(state: PeerConnection.SignalingState) {
            diag("PEER", "Signaling: $state")
        }
        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
            update { it.copy(iceState = state.name) }
            diag("ICE", state.name, state == PeerConnection.IceConnectionState.CONNECTED || state == PeerConnection.IceConnectionState.COMPLETED)
            when (state) {
                PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> setConnection("CONNECTED")
                PeerConnection.IceConnectionState.FAILED -> setConnection("FAILED")
                PeerConnection.IceConnectionState.CLOSED -> update { it.copy(connectionState = "CLOSED") }
                else -> if (_state.value.connectionState != "CONNECTED") setConnection("CONNECTING")
            }
        }
        override fun onIceConnectionReceivingChange(receiving: Boolean) = diag("ICE", "Receiving: $receiving")
        override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) = diag("ICE", "Gathering: $state")
        override fun onIceCandidate(c: IceCandidate) {
            diag("ICE", "Local candidate hazır", true)
            sendSignal("ice", JSONObject().put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex).put("candidate", c.sdp))
        }
        override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) = diag("ICE", "${candidates.size} candidate silindi")
        override fun onAddStream(stream: MediaStream) = Unit
        override fun onRemoveStream(stream: MediaStream) = Unit
        override fun onDataChannel(channel: DataChannel) = diag("DATA", "DataChannel alındı")
        override fun onRenegotiationNeeded() = diag("PEER", "Renegotiation lazım")
        override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {
            val track = receiver.track()
            when (track) {
                is VideoTrack -> {
                    remoteVideoTrack = track
                    track.setEnabled(true)
                    update { it.copy(remoteVideo = true) }
                    remoteRenderer?.let { track.addSink(it) }
                    diag("REMOTE VIDEO", "Remote video track alındı", true)
                }
                is AudioTrack -> {
                    remoteAudioTrack = track
                    track.setEnabled(true)
                    update { it.copy(remoteAudio = true) }
                    diag("REMOTE AUDIO", "Remote audio track alındı", true)
                }
            }
        }
        override fun onRemoveTrack(receiver: RtpReceiver) {
            if (receiver.track() === remoteVideoTrack) remoteVideoTrack = null
            if (receiver.track() === remoteAudioTrack) remoteAudioTrack = null
        }
        override fun onTrack(transceiver: RtpTransceiver) {
            val track = transceiver.receiver.track()
            when (track) {
                is VideoTrack -> {
                    remoteVideoTrack = track
                    track.setEnabled(true)
                    update { it.copy(remoteVideo = true) }
                    remoteRenderer?.let { track.addSink(it) }
                    diag("REMOTE VIDEO", "Remote video transceiver track alındı", true)
                }
                is AudioTrack -> {
                    remoteAudioTrack = track
                    track.setEnabled(true)
                    update { it.copy(remoteAudio = true) }
                    diag("REMOTE AUDIO", "Remote audio transceiver track alındı", true)
                }
            }
        }
        override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
            diag("PEER", "Connection: $newState")
            when (newState) {
                PeerConnection.PeerConnectionState.CONNECTED -> setConnection("CONNECTED")
                PeerConnection.PeerConnectionState.FAILED -> setConnection("FAILED")
                PeerConnection.PeerConnectionState.DISCONNECTED -> setConnection("DISCONNECTED")
                PeerConnection.PeerConnectionState.CLOSED -> update { it.copy(connectionState = "CLOSED") }
                else -> Unit
            }
        }
        override fun onStandardizedIceConnectionChange(state: PeerConnection.IceConnectionState) = Unit
        override fun onSelectedCandidatePairChanged(event: CandidatePairChangeEvent) = diag("ICE", "Candidate pair seçildi", true)
    }

    fun setRemoteRenderer(renderer: SurfaceViewRenderer) {
        remoteRenderer = renderer
        remoteVideoTrack?.let { it.addSink(renderer) }
    }

    fun setLocalRenderer(renderer: SurfaceViewRenderer) {
        localRenderer = renderer
        videoTrack?.let { it.addSink(renderer) }
    }

    fun setMicEnabled(enabled: Boolean) {
        audioTrack?.setEnabled(enabled)
        diag("MIC", if (enabled) "Mikrofon ON" else "Mikrofon OFF", true)
    }

    fun setCameraEnabled(enabled: Boolean) {
        videoTrack?.setEnabled(enabled)
        diag("CAMERA", if (enabled) "Kamera ON" else "Kamera OFF", true)
    }

    fun switchCamera() {
        try {
            videoCapturer?.switchCamera(null)
            diag("CAMERA", "Kamera dəyişdirildi", true)
        } catch (t: Throwable) {
            diag("CAMERA", "Kamera dəyişmədi: ${t.message ?: t.javaClass.simpleName}", false)
        }
    }

    fun stop() {
        if (stopped) return
        stopped = true
        started = false
        signalJob?.cancel()
        signalJob = null
        try { videoCapturer?.stopCapture() } catch (_: Throwable) {}
        try { videoCapturer?.dispose() } catch (_: Throwable) {}
        videoCapturer = null
        try { videoTrack?.dispose() } catch (_: Throwable) {}
        try { remoteVideoTrack?.dispose() } catch (_: Throwable) {}
        try { audioTrack?.dispose() } catch (_: Throwable) {}
        videoTrack = null
        remoteVideoTrack = null
        remoteAudioTrack = null
        audioTrack = null
        try { peer?.close() } catch (_: Throwable) {}
        try { peer?.dispose() } catch (_: Throwable) {}
        peer = null
        try { factory?.dispose() } catch (_: Throwable) {}
        factory = null
        try { localRenderer?.release() } catch (_: Throwable) {}
        try { remoteRenderer?.release() } catch (_: Throwable) {}
        localRenderer = null
        remoteRenderer = null
        try { eglBase.release() } catch (_: Throwable) {}
    }
}

open class SdpObserverAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) = Unit
    override fun onSetSuccess() = Unit
    override fun onCreateFailure(error: String) = Unit
    override fun onSetFailure(error: String) = Unit
}
