package com.vghost.app.ui.screens

import java.util.Locale
import kotlinx.coroutines.isActive
import com.vghost.app.R
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.media.AudioAttributes
import android.media.SoundPool
import android.media.MediaRecorder
import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.content.ContentValues
import android.provider.MediaStore
import androidx.core.content.FileProvider
import android.Manifest
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import com.vghost.app.ui.components.premiumBackdrop
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.ChatMessage
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.data.model.GiftItem
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.network.VGhostApi
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostGoldBg
import com.vghost.app.ui.theme.GhostGoldBorder
import com.vghost.app.ui.theme.GhostGoldText
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostStatusOnline
import com.vghost.app.ui.theme.GhostStatusOffline
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostSurfaceElevated
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.widget.ImageView


private const val STICKER_PREFIX = "__VG_STICKER__:"

private data class VGhostRemoteMedia(
    val id: String,
    val key: String,
    val label: String,
    val imageUrl: String
)

private suspend fun loadRemoteStickers(): List<VGhostRemoteMedia> {
    val response = VGhostApi.stickers()
    val array = response.optJSONArray("stickers") ?: return emptyList()
    return buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
            val key = item.optString("key", "sticker_$id")
            val imagePath = item.optString("image_url").takeIf { it.isNotBlank() } ?: continue
            add(VGhostRemoteMedia(id, key, item.optString("label", key), VGhostApi.publicUrl(imagePath)))
        }
    }
}

private suspend fun loadRemoteGifs(): List<VGhostRemoteMedia> {
    val response = VGhostApi.gifs()
    val array = response.optJSONArray("gifs") ?: return emptyList()
    return buildList {
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
            val key = item.optString("key", id)
            val imagePath = item.optString("image_url").takeIf { it.isNotBlank() } ?: continue
            add(VGhostRemoteMedia(id, key, item.optString("label", key), VGhostApi.publicUrl(imagePath)))
        }
    }
}

@Composable
private fun RemoteStaticWebpThumbnail(
    imageUrl: String,
    modifier: Modifier = Modifier,
    decodeSize: Int = 96,
    animate: Boolean = true
) {
    val context = LocalContext.current
    var localFile by remember(imageUrl) { mutableStateOf<java.io.File?>(null) }

    LaunchedEffect(Unit) {
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            val cutoff = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L
            context.cacheDir.listFiles()?.forEach { f ->
                if (f.name.startsWith("vghost_media_") && f.lastModified() < cutoff) {
                    try { f.delete() } catch (_: Throwable) { }
                }
            }
        }
    }

    LaunchedEffect(imageUrl) {
        localFile = null
        localFile = try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val hash = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(imageUrl.toByteArray(Charsets.UTF_8))
                    .joinToString("") { "%02x".format(it) }
                val file = java.io.File(context.cacheDir, "vghost_thumb_$hash")
                if (!file.isFile || file.length() == 0L) {
                    val connection = java.net.URL(imageUrl).openConnection() as java.net.HttpURLConnection
                    connection.connectTimeout = 15000
                    connection.readTimeout = 30000
                    connection.instanceFollowRedirects = true
                    connection.setRequestProperty("User-Agent", "VGhost-Android/1.2")
                    try {
                        connection.connect()
                        if (connection.responseCode !in 200..299) throw java.io.IOException("HTTP ${connection.responseCode}")
                        connection.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                        com.vghost.app.CacheManager.trimCache(context)
                    } finally {
                        connection.disconnect()
                    }
                }
                file
            }
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            null
        }
    }

    val file = localFile
    if (file == null) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("…", color = GhostTextMuted, fontSize = 18.sp)
        }
        return
    }

    val bitmap = remember(file.absolutePath, decodeSize) {
        try {
            val target = decodeSize.coerceIn(32, 192)
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@remember null

            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (maxDim / sample > target * 2 && sample < 16) sample *= 2

            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                inDither = true
            }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (_: Throwable) {
            null
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = tr("Media"),
            modifier = modifier
        )
    } else {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("…", color = GhostTextMuted, fontSize = 18.sp)
        }
    }
}

@Composable
private fun RemoteAnimatedStickerImage(
    imageUrl: String,
    modifier: Modifier = Modifier,
    decodeSize: Int = 96,
    animate: Boolean = true
) {
    val context = LocalContext.current
    var localFile by remember(imageUrl) { mutableStateOf<java.io.File?>(null) }

    LaunchedEffect(Unit) {
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            val cutoff = System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L
            context.cacheDir.listFiles()?.forEach { f ->
                if (f.name.startsWith("vghost_media_") && f.lastModified() < cutoff) {
                    try { f.delete() } catch (_: Throwable) { }
                }
            }
        }
    }

    LaunchedEffect(imageUrl) {
        localFile = null
        localFile = try {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val hash = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(imageUrl.toByteArray(Charsets.UTF_8))
                    .joinToString("") { "%02x".format(it) }
                val file = java.io.File(context.cacheDir, "vghost_media_$hash")
                if (!file.isFile || file.length() == 0L) {
                    val connection = java.net.URL(imageUrl).openConnection() as java.net.HttpURLConnection
                    connection.connectTimeout = 15000
                    connection.readTimeout = 30000
                    connection.instanceFollowRedirects = true
                    connection.setRequestProperty("User-Agent", "VGhost-Android/1.2")
                    try {
                        connection.connect()
                        if (connection.responseCode !in 200..299) throw java.io.IOException("HTTP ${connection.responseCode}")
                        connection.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                        com.vghost.app.CacheManager.trimCache(context)
                    } finally {
                        connection.disconnect()
                    }
                }
                file
            }
        } catch (_: Throwable) {
            null
        }
    }

    val file = localFile
    if (file == null) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("…", color = GhostTextMuted, fontSize = 18.sp)
        }
    } else if (!animate) {
        // Picker thumbnails stay static (first frame) to prevent AnimatedImageDrawable
        // instances from accumulating while a long LazyColumn is scrolled.
        val bitmap = remember(file.absolutePath, decodeSize) {
            try {
                val opts = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
                val maxDim = maxOf(opts.outWidth, opts.outHeight).coerceAtLeast(1)
                val target = decodeSize.coerceIn(32, 512)
                var sample = 1
                while (maxDim / sample > target * 2 && sample < 16) sample *= 2
                opts.inSampleSize = sample
                opts.inJustDecodeBounds = false
                opts.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
            } catch (_: Throwable) { null }
        }
        if (bitmap != null) Image(bitmap = bitmap.asImageBitmap(), contentDescription = tr("Media"), modifier = modifier, contentScale = ContentScale.Fit)
        else Box(modifier = modifier, contentAlignment = Alignment.Center) { Text("…", color = GhostTextMuted) }
    } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
        AndroidView(
            modifier = modifier,
            factory = { ctx ->
                ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    try {
                        val source = ImageDecoder.createSource(file)
                        val drawable = ImageDecoder.decodeDrawable(source) { decoder, _, _ ->
                            val target = decodeSize.coerceIn(32, 512)
                            decoder.setTargetSize(target, target)
                            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        }
                        setImageDrawable(drawable)
                        if (drawable is AnimatedImageDrawable) {
                            drawable.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                            drawable.start()
                        }
                    } catch (_: Throwable) {
                        // A broken/unsupported WebP must never crash the chat while scrolling.
                        setImageDrawable(null)
                    }
                }
            },
            update = { imageView ->
                val drawable = imageView.drawable
                if (drawable is AnimatedImageDrawable && !drawable.isRunning) drawable.start()
            },
            onRelease = { imageView ->
                (imageView.drawable as? AnimatedImageDrawable)?.stop()
            }
        )
    } else {
        val bitmap = remember(file.absolutePath, decodeSize) {
            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
            val maxDim = maxOf(opts.outWidth, opts.outHeight).coerceAtLeast(1)
            val target = decodeSize.coerceIn(32, 512)
            opts.inSampleSize = Integer.highestOneBit((maxDim / target).coerceAtLeast(1))
            if (opts.inSampleSize < 1) opts.inSampleSize = 1
            opts.inJustDecodeBounds = false
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
        }
        if (bitmap != null) {
            Image(bitmap = bitmap.asImageBitmap(), contentDescription = tr("Media"), modifier = modifier)
        }
    }
}

@Composable
fun ChatScreen(
    recipientNickname: String,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val allMessages by repository.messages.collectAsState()
    // Always use the same canonical nickname key as the repository. This prevents
    // chats from disappearing when navigation/search supplies a nickname with a
    // leading @ or surrounding whitespace.
    val chatKey = remember(recipientNickname) { recipientNickname.trim().removePrefix("@").trim() }
    val rawMessages = allMessages[chatKey] ?: emptyList()
    // Keep the 24-hour message lifetime, but do not render any countdown/progress bar.
    // The backend remains authoritative for expiry/deletion.
    val now = System.currentTimeMillis()
    val messages = rawMessages.filter {
        val expiresAt = it.expiresAt ?: (it.createdAt + 24L * 60L * 60L * 1000L)
        expiresAt > now
    }
    val incomingSender = messages.lastOrNull { !it.isOutgoing && it.senderNickname.isNotBlank() }?.senderNickname
    var recipientAvatarId by remember { mutableStateOf("ghost") }
    val displayChatName = incomingSender ?: recipientNickname
    LaunchedEffect(displayChatName) { recipientAvatarId = repository.findUserByNickname(displayChatName)?.avatarId ?: "ghost" }
    var recipientOnline by remember(chatKey) { mutableStateOf<Boolean?>(null) }
    var recipientTyping by remember(chatKey) { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var showGiftDialog by remember { mutableStateOf(false) }
    var selectedGift by remember { mutableStateOf<GiftItem?>(null) }
    var gifting by remember { mutableStateOf(false) }
    var giftError by remember { mutableStateOf<String?>(null) }
    val myBalance by repository.ghostCoins.collectAsState()
    var isSending by remember { mutableStateOf(false) }
    var sendError by remember { mutableStateOf<String?>(null) }
    var sendStatus by remember { mutableStateOf<String?>(null) }
    var reactionMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var actionMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var replyMessage by remember { mutableStateOf<ChatMessage?>(null) }
    val context = LocalContext.current
    var editingMessageId by remember { mutableStateOf<String?>(null) }
    var isRecordingVoice by remember { mutableStateOf(false) }
    var voiceSeconds by remember { mutableStateOf(0) }
    var voiceError by remember { mutableStateOf<String?>(null) }
    var cancelVoiceDrag by remember { mutableStateOf(false) }
    var voiceDragX by remember { mutableStateOf(0f) }
    var voiceLocked by remember { mutableStateOf(false) }
    var voiceDraftFile by remember { mutableStateOf<java.io.File?>(null) }
    var voiceDraftDuration by remember { mutableStateOf(0) }
    var voiceDraftPlaying by remember { mutableStateOf(false) }
    var voiceDraftPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    val voiceRecorder = remember(context) { VGhostVoiceRecorder(context = context) }
    val recordPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) voiceError = "Mikrofon icazəsi verilmədi."
    }
    var selectedAttachmentUri by remember { mutableStateOf<Uri?>(null) }
    var selectedAttachmentUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var attachmentSentCount by remember { mutableStateOf(0) }
    var attachmentTotalCount by remember { mutableStateOf(0) }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraVideo by remember { mutableStateOf(false) }
    val attachmentPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        selectedAttachmentUris = uris
        if (uris.isNotEmpty()) { attachmentSentCount = 0; attachmentTotalCount = uris.size }
    }
    val audioPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selectedAttachmentUris = uris
        if (uris.isNotEmpty()) { attachmentSentCount = 0; attachmentTotalCount = uris.size }
    }
    val cameraPhotoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { ok ->
        if (ok) selectedAttachmentUri = pendingCameraUri
        else pendingCameraUri?.let { try { context.contentResolver.delete(it, null, null) } catch (_: Throwable) {} }
        pendingCameraUri = null
    }
    val cameraVideoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.CaptureVideo()
    ) { ok ->
        if (ok) selectedAttachmentUri = pendingCameraUri
        else pendingCameraUri?.let { try { context.contentResolver.delete(it, null, null) } catch (_: Throwable) {} }
        pendingCameraUri = null
    }
    val cameraPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            pendingCameraUri?.let { if (pendingCameraVideo) cameraVideoLauncher.launch(it) else cameraPhotoLauncher.launch(it) }
        } else {
            sendError = "Kamera icazəsi verilmədi."
            pendingCameraUri = null
        }
    }
    var reactionError by remember { mutableStateOf<String?>(null) }
    var showAllEmojis by remember { mutableStateOf(false) }
    var showComposerPicker by remember { mutableStateOf(false) }
    var composerTab by remember { mutableStateOf(0) } // 0 = Emoji, 1 = Sticker, 2 = GIF
    var remoteStickers by remember { mutableStateOf<List<VGhostRemoteMedia>>(emptyList()) }
    var remoteGifs by remember { mutableStateOf<List<VGhostRemoteMedia>>(emptyList()) }
    var stickersLoading by remember { mutableStateOf(false) }
    var stickerLoadError by remember { mutableStateOf<String?>(null) }
    var gifsLoading by remember { mutableStateOf(false) }
    var gifLoadError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(selectedAttachmentUri, selectedAttachmentUris) {
        val uris = buildList {
            selectedAttachmentUri?.let { add(it) }
            addAll(selectedAttachmentUris)
        }.distinct()
        if (uris.isEmpty()) return@LaunchedEffect
        attachmentSentCount = 0
        attachmentTotalCount = uris.size
        try {
            uris.forEachIndexed { index, uri ->
                val remainingCount = uris.size - index
                sendStatus = if (uris.size > 1) tr("Göndərilir: ${index + 1}/${uris.size} • ${remainingCount - 1} qaldı") else tr("Fayl göndərilir…")
                sendError = null
                val resolver = context.contentResolver
                val mime = resolver.getType(uri).orEmpty().lowercase(Locale.US)
                val kind = when {
                    mime.startsWith("image/") -> "image"
                    mime.startsWith("video/") -> "video"
                    mime.startsWith("audio/") -> "audio"
                    else -> ""
                }
                if (kind.isBlank()) throw IllegalStateException(tr("Yalnız şəkil, video və musiqi göndərmək olar."))
                val name = run {
                    var result = "attachment"
                    resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) result = c.getString(0).orEmpty().ifBlank { result }
                    }
                    result
                }
                val ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime).orEmpty()
                val safeName = if (name.contains('.')) name else if (ext.isNotBlank()) "$name.$ext" else name
                val temp = java.io.File(context.cacheDir, "vghost_upload_${System.currentTimeMillis()}_${safeName.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                try {
                    resolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                        ?: throw IllegalStateException(tr("Fayl oxunmadı."))
                    val tempSize = withContext(kotlinx.coroutines.Dispatchers.IO) { temp.length() }
                    if (tempSize <= 0L) throw IllegalStateException(tr("Fayl boşdur."))
                    if (tempSize > 50L * 1024L * 1024L) throw IllegalStateException(tr("Fayl maksimum 50 MB ola bilər."))
                    val bytes = withContext(kotlinx.coroutines.Dispatchers.IO) { temp.readBytes() }
                    val error = repository.sendAttachment(chatKey, safeName, mime, bytes)
                    if (error != null) throw IllegalStateException(error)
                } finally {
                    temp.delete()
                }
                attachmentSentCount = index + 1
                val left = uris.size - attachmentSentCount
                sendStatus = if (uris.size > 1 && left > 0) tr("${attachmentSentCount} göndərildi ✓ • ${left} qaldı") else tr("Fayl göndərildi ✓")
            }
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            sendError = t.message ?: tr("Fayl göndərilmədi.")
            sendStatus = null
        } finally {
            selectedAttachmentUri = null
            selectedAttachmentUris = emptyList()
        }
    }
    // Hide the completed attachment status card shortly after the upload finishes.
    // The old implementation left the success card stuck above the composer.
    LaunchedEffect(sendStatus, attachmentTotalCount, attachmentSentCount) {
        if (sendError == null && attachmentTotalCount > 0 &&
            attachmentSentCount >= attachmentTotalCount && sendStatus?.contains("✓") == true
        ) {
            kotlinx.coroutines.delay(1200L)
            sendStatus = null
            attachmentSentCount = 0
            attachmentTotalCount = 0
        }
    }

    LaunchedEffect(showComposerPicker, composerTab) {
        if (showComposerPicker && composerTab == 1 && !stickersLoading) {
            stickersLoading = true
            stickerLoadError = null
            try { remoteStickers = loadRemoteStickers() }
            catch (t: Throwable) { stickerLoadError = t.message ?: tr("Stickerlər yüklənmədi") }
            finally { stickersLoading = false }
        }
        if (showComposerPicker && composerTab == 2 && !gifsLoading) {
            gifsLoading = true
            gifLoadError = null
            try { remoteGifs = loadRemoteGifs() }
            catch (t: Throwable) { gifLoadError = t.message ?: tr("GIF-lər yüklənmədi") }
            finally { gifsLoading = false }
        }
    }
    val composerEmojis = remember { listOf(
        "😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","🙃",
        "😉","😍","🥰","😘","😎","🤩","🥳","😏","😢","😭","😤","😠",
        "😡","🤬","😱","😴","🤔","🤭","🤫","😐","😮","😲","🥺","❤️",
        "🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","💕","💯","🔥",
        "✨","⭐","🎉","🎊","👍","👎","👏","🙏","👌","🤝","💪","🫶",
        "👋","✌️","🤞","🤟","🤘","🤙","🎁","⚽","🎮","🍕","☕","🚀"
    ) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    // Short WhatsApp-style sent-message tick. It is local to the sender and
    // does not require notification permission or network access.
    val soundPool = remember {
        SoundPool.Builder()
            .setMaxStreams(1)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
    }
    val sentTickId = remember(soundPool, context) { soundPool.load(context, com.vghost.app.R.raw.message_sent_tick, 1) }
    val voicePressId = remember(soundPool, context) { soundPool.load(context, com.vghost.app.R.raw.voice_press, 1) }
    val voiceReleaseId = remember(soundPool, context) { soundPool.load(context, com.vghost.app.R.raw.voice_release, 1) }
    DisposableEffect(soundPool) {
        onDispose { soundPool.release() }
    }
    DisposableEffect(voiceRecorder) {
        onDispose { try { voiceRecorder.cancel() } catch (_:Throwable) {} }
    }
    BackHandler { onNavigateBack() }

    LaunchedEffect(chatKey) {
        repository.startChatSync(chatKey)
    }
    // Presence is fetched from the server; never render a hard-coded green dot.
    LaunchedEffect(chatKey) {
        while (kotlinx.coroutines.currentCoroutineContext().isActive) {
            try { recipientOnline = repository.getUserOnlineStatus(chatKey) } catch (_: Throwable) { }
            delay(5_000L)
        }
    }
    // Typing indicator: use a short server-side lease and heartbeat instead of
    // a one-shot request per keystroke. This is reliable on real mobile networks
    // where an individual request can be delayed or cancelled while the user
    // keeps typing. The receiver polls the same authoritative status.
    LaunchedEffect(chatKey) {
        while (kotlinx.coroutines.currentCoroutineContext().isActive) {
            try { recipientTyping = repository.getTyping(chatKey) } catch (_: Throwable) {
                // Keep the previous UI state on a transient network error.
            }
            delay(900L)
        }
    }
    LaunchedEffect(inputText, chatKey) {
        if (inputText.isBlank()) {
            try { repository.setTyping(chatKey, false) } catch (_: Throwable) { }
            return@LaunchedEffect
        }

        // Keep refreshing the typing lease while there is actual text in the
        // composer. Clearing the field immediately clears the server state.
        while (kotlinx.coroutines.currentCoroutineContext().isActive && inputText.isNotBlank()) {
            try { repository.setTyping(chatKey, true) } catch (_: Throwable) { }
            delay(1000L)
        }
    }
    DisposableEffect(chatKey) {
        onDispose {
            // Do not leave a stale "Yazır..." state when leaving the chat.
            repository.apiScopeLaunchTypingClear(chatKey)
        }
    }
    DisposableEffect(chatKey) {
        repository.setActiveChat(chatKey)
        onDispose {
            repository.stopChatSync(chatKey)
            repository.setActiveChat(null)
        }
    }

    // Scroll to bottom when messages update
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            if (messages.size <= 1 || lastVisible >= messages.lastIndex - 1) {
                listState.animateScrollToItem(messages.lastIndex)
            }
        }
    }

    fun startVoiceRecording(): Boolean {
        if (isRecordingVoice) return true
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO); return false
        }
        return try { voiceRecorder.start(); isRecordingVoice=true; voiceLocked=false; voiceSeconds=0; voiceError=null; cancelVoiceDrag=false; voiceDragX=0f; soundPool.play(voicePressId,1f,1f,1,0,1f); true } catch (t:Throwable) { voiceError="Səs yazmaq alınmadı."; false }
    }
    fun cancelVoiceRecording() {
        cancelVoiceDrag = false
        voiceLocked = false
        voiceDragX = 0f
        if (!isRecordingVoice) return
        isRecordingVoice=false
        try { voiceRecorder.cancel() } catch (_:Throwable) {}
        voiceSeconds=0
    }

    fun finishVoiceRecordingToDraft() {
        if (!isRecordingVoice) return
        cancelVoiceDrag = false
        voiceDragX = 0f
        isRecordingVoice = false
        soundPool.play(voiceReleaseId,1f,1f,1,0,1f)
        val result = try { voiceRecorder.stop() } catch (_:Throwable) { null }
        if (result == null) { voiceError = "Səs yazısı alınmadı."; return }
        voiceDraftPlayer?.release()
        voiceDraftPlayer = null
        voiceDraftPlaying = false
        voiceDraftFile = result.first
        voiceDraftDuration = result.second
    }

    fun stopLockedAndSendVoice() {
        if (!isRecordingVoice) return
        cancelVoiceDrag = false
        voiceDragX = 0f
        isRecordingVoice = false
        val result = try { voiceRecorder.stop() } catch (_:Throwable) { null }
        if (result == null) { voiceError = "Səs yazısı alınmadı."; return }
        val (file, duration) = result
        voiceLocked = false
        scope.launch {
            val bytes = try { file.readBytes() } catch (_:Throwable) { ByteArray(0) }
            val error = repository.sendVoice(chatKey, file.name, bytes, duration)
            if (error != null) voiceError = error else soundPool.play(sentTickId,1f,1f,1,0,1f)
            file.delete()
        }
    }

    fun sendVoiceDraft() {
        val file = voiceDraftFile ?: return
        val duration = voiceDraftDuration
        voiceDraftPlayer?.release()
        voiceDraftPlayer = null
        voiceDraftPlaying = false
        voiceDraftFile = null
        voiceDraftDuration = 0
        voiceLocked = false
        scope.launch {
            val bytes = try { file.readBytes() } catch (_:Throwable) { ByteArray(0) }
            val error = repository.sendVoice(chatKey, file.name, bytes, duration)
            if(error != null) voiceError = error else soundPool.play(sentTickId,1f,1f,1,0,1f)
            file.delete()
        }
    }

    fun cancelVoiceDraft() {
        voiceDraftPlayer?.release()
        voiceDraftPlayer = null
        voiceDraftPlaying = false
        try { voiceDraftFile?.delete() } catch (_:Throwable) {}
        voiceDraftFile = null
        voiceDraftDuration = 0
        voiceLocked = false
        cancelVoiceDrag = false
        voiceDragX = 0f
        voiceError = "Səs ləğv edildi."
    }

    fun toggleVoiceDraftPlayback() {
        val file = voiceDraftFile ?: return
        try {
            val player = voiceDraftPlayer
            if (player != null) {
                if (player.isPlaying) { player.pause(); voiceDraftPlaying = false }
                else { player.start(); voiceDraftPlaying = true }
                return
            }
            val newPlayer = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { voiceDraftPlaying = false; voiceDraftPlayer?.release(); voiceDraftPlayer = null }
                prepare()
                start()
            }
            voiceDraftPlayer = newPlayer
            voiceDraftPlaying = true
        } catch (_:Throwable) {
            voiceDraftPlaying = false
            voiceDraftPlayer?.release()
            voiceDraftPlayer = null
            voiceError = "Səsi oxutmaq alınmadı."
        }
    }

    LaunchedEffect(isRecordingVoice) {
        while (isRecordingVoice) { delay(1000L); voiceSeconds++ ; if (voiceSeconds >= 600) finishVoiceRecordingToDraft() }
    }

    val handleSend = {
        val textToSend = inputText.trim()
        if (textToSend.isNotBlank() && !isSending) {
            // Clear immediately: sending must feel instant and the user can keep typing
            // while the network request runs in the background.
            inputText = ""
            isSending = true
            sendError = null
            sendStatus = tr("Sending...")
            scope.launch {
                try {
                    val error = if (editingMessageId != null) {
                        repository.editMessage(chatKey, editingMessageId!!, textToSend)
                    } else {
                        repository.sendMessage(chatKey, textToSend, replyToMessage = replyMessage)
                    }
                    if (error == null) {
                        editingMessageId = null
                        replyMessage = null
                        // The tick is confirmation that the server accepted the message,
                        // not merely that the Send button was tapped.
                        soundPool.play(sentTickId, 1.0f, 1.0f, 1, 0, 1f)
                        sendStatus = tr("Sent ✓")
                    } else {
                        // If Edit fails, leave normal Send mode enabled. Otherwise every
                        // following message would keep trying to edit the old message.
                        if (editingMessageId != null) {
                            editingMessageId = null
                            if (inputText.isBlank()) inputText = textToSend
                        }
                        sendError = error
                        sendStatus = null
                    }
                } finally {
                    // This is only a tap-throttle, not the network request lifetime.
                    // Never make the Send button look frozen while cPanel/API is slow.
                    delay(350L)
                    isSending = false
                }
            }
        }
    }

    // Successful send confirmations are transient. They should never remain as a
    // permanent panel above the composer after the message has already appeared.
    LaunchedEffect(sendStatus) {
        val status = sendStatus
        if (status != null && (status.contains("✓") || status.contains("GÖNDƏRİLDİ") || status.contains("GÖNDƏRİLDİ", true))) {
            delay(900L)
            if (sendStatus == status) sendStatus = null
        }
    }

    // Chat gift dialog: reuses the same GiftCatalog + repository sendGift flow as
    // the working profile gift system. The button lives beside the three-dot menu.
    if (showGiftDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = {
                if (!gifting) {
                    showGiftDialog = false
                    selectedGift = null
                    giftError = null
                }
            },
            title = { Text(tr("🎁 HƏDİYYƏ MAĞAZASI"), color = GhostTextWhite, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(trf("Alıcı: %s", displayChatName), color = GhostTextSecondary)
                    Text(trf("Sənin balansın: %d GC", myBalance), color = GhostGoldText, fontWeight = FontWeight.Black)
                    if (selectedGift == null) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.fillMaxWidth().height(390.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(GiftCatalog.items, key = { it.id }) { gift ->
                                Column(
                                    Modifier.fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(GhostSurface.copy(alpha = .9f))
                                        .border(1.dp, GhostRedPrimary.copy(alpha = .45f), RoundedCornerShape(16.dp))
                                        .clickable(enabled = !gifting) { selectedGift = gift; giftError = null }
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(gift.icon, fontSize = 36.sp)
                                    Text(gift.name, color = GhostTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(trf("%d GC", gift.price), color = GhostGoldText, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    } else {
                        val gift = selectedGift!!
                        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(gift.icon, fontSize = 66.sp)
                                Text(gift.name, color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                Text(trf("%d GC", gift.price), color = GhostGoldText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(trf("Do you want to send this gift to %s?", displayChatName), color = GhostTextSecondary)
                    }
                    giftError?.let { Text(it, color = GhostRedPrimary, fontSize = 13.sp) }
                }
            },
            confirmButton = {
                if (selectedGift != null) {
                    Button(
                        enabled = !gifting,
                        onClick = {
                            val gift = selectedGift
                            if (gift != null) {
                                gifting = true
                                giftError = null
                                scope.launch {
                                    try {
                                        val target = repository.findUserByNickname(displayChatName)
                                        val uid = target?.uid?.trim()?.takeIf { it.isNotBlank() }
                                        val myUid = repository.findUserByNickname(repository.currentUserNickname.value)?.uid?.trim()
                                        if (uid == null) {
                                            giftError = tr("İstifadəçi tapılmadı.")
                                        } else if (uid == myUid) {
                                            giftError = tr("Öz hesabınıza hədiyyə göndərə bilməzsiniz.")
                                        } else {
                                            val error = repository.sendGift(uid, gift.id)
                                            if (error == null) {
                                                showGiftDialog = false
                                                selectedGift = null
                                                giftError = null
                                                sendStatus = tr("🎁 HƏDİYYƏ GÖNDƏRİLDİ")
                                            } else {
                                                giftError = error
                                            }
                                        }
                                    } catch (t: Throwable) {
                                        giftError = t.message ?: tr("Hədiyyə göndərilmədi.")
                                    } finally {
                                        gifting = false
                                    }
                                }
                            }
                        },
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                    ) {
                        if (gifting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Text(tr("🎁 GÖNDƏR"))
                    }
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    enabled = !gifting,
                    onClick = {
                        if (selectedGift != null) selectedGift = null
                        else showGiftDialog = false
                    }
                ) { Text(if (selectedGift != null) "← ${tr("Geri")}" else tr("Bağla")) }
            },
            containerColor = GhostSurfaceElevated
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop()
            .imePadding(),
        containerColor = GhostBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .premiumBackdrop()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("chat_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = tr("Back"),
                        tint = GhostTextWhite
                    )
                }

                GhostAvatar(
                    size = 38.dp,
                    showBorder = true,
                    avatarId = recipientAvatarId
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = displayChatName,
                        color = GhostTextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(1.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val isOnline = recipientOnline == true
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isOnline) GhostStatusOnline else GhostStatusOffline)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (recipientTyping) "Yazır..." else tr(if (isOnline) tr("Online") else tr("Offline")),
                            color = if (recipientTyping) GhostRedPrimary else GhostTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (recipientTyping) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }

                // 🎁 Gift button is intentionally placed immediately beside the three-dot menu.
                IconButton(
                    onClick = {
                        selectedGift = null
                        giftError = null
                        showGiftDialog = true
                    },
                    modifier = Modifier.size(48.dp).testTag("chat_gift_button")
                ) {
                    Text("🎁", fontSize = 25.sp)
                }

                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.testTag("chat_options_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = tr("More Options"),
                            tint = GhostTextWhite
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(GhostSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text(tr("Clear Chat"), color = GhostRedPrimary) },
                            onClick = {
                                showMenu = false
                                // Clear this user's chat locally
                                repository.clearChat(chatKey)
                            }
                        )
                    }
                }
            }

            // Chat Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                item {
                    // Date Label: Today
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(GhostSurface)
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = tr("Today"),
                                color = GhostTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Encryption Notice Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 10.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(GhostGoldBg)
                            .border(1.dp, GhostGoldBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = null,
                                tint = GhostGoldText,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = tr("Messages are protected in transit by HTTPS.\nEnd-to-end encryption is not enabled."),
                                color = GhostGoldText,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Start,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }

                itemsIndexed(messages, key = { _, message -> message.id }) { _, message ->
                    MessageBubble(message = message, onLongPress = { actionMessage = message })
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            actionMessage?.let { targetMessage ->
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { actionMessage = null },
                    title = { Text(tr("Mesaj"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            val targetIsGif = targetMessage.messageType.equals("gif", true) || targetMessage.text.startsWith("__VG_GIF__:") || !targetMessage.gifImageUrl.isNullOrBlank()
                            val targetIsSticker = targetMessage.messageType.equals("sticker", true) || targetMessage.text.startsWith(STICKER_PREFIX) || !targetMessage.stickerImageUrl.isNullOrBlank()
                            val targetIsAttachment = targetMessage.messageType.equals("attachment", true) || !targetMessage.attachmentUrl.isNullOrBlank()
                            val targetIsVoice = targetMessage.messageType.equals("voice", true) || targetMessage.messageType.equals("audio", true)
                            val targetIsSpecial = targetIsGif || targetIsSticker || targetIsAttachment || targetIsVoice
                            androidx.compose.material3.TextButton(onClick = {
                                replyMessage = targetMessage
                                editingMessageId = null
                                actionMessage = null
                            }) { Text("↩ ${tr("Yanıtla")}", color = GhostTextWhite) }
                            if (targetMessage.isOutgoing && !targetIsSpecial) {
                                androidx.compose.material3.TextButton(onClick = {
                                    inputText = targetMessage.text
                                    replyMessage = null
                                    editingMessageId = targetMessage.id
                                    actionMessage = null
                                }) { Text(tr("Edit Message"), color = GhostTextWhite) }
                            }
                            if (!targetIsSpecial) {
                                androidx.compose.material3.TextButton(onClick = {
                                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("message", targetMessage.text))
                                    actionMessage = null
                                }) { Text(tr("Copy Message"), color = GhostTextWhite) }
                            }
                            androidx.compose.material3.TextButton(onClick = {
                                scope.launch {
                                    val err = repository.deleteMessageForBoth(chatKey, targetMessage.id)
                                    if (err != null) sendError = err else sendError = null
                                    actionMessage = null
                                }
                            }) { Text(tr("Delete Message"), color = GhostRedPrimary) }
                            androidx.compose.material3.TextButton(onClick = {
                                actionMessage = null
                                reactionMessage = targetMessage
                            }) { Text(tr("Reaction"), color = GhostTextWhite) }
                        }
                    },
                    confirmButton = {
                        androidx.compose.material3.TextButton(onClick = { actionMessage = null }) { Text(tr("Cancel")) }
                    },
                    containerColor = GhostSurfaceElevated
                )
            }

            reactionMessage?.let { targetMessage ->
                // Main reaction picker: keep the existing quick reactions and add a
                // separate + button for the full emoji picker. Cancel remains available.
                val quickEmojis = listOf(
                    "❤️", "😂", "👍", "😮",
                    "😢", "😡", "😍", "😎",
                    "🔥", "🎉", "👎", "👏",
                    "🙏", "💯", "🤔", "😭"
                )

                val allEmojis = listOf(
                    // Smileys & people
                    "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇",
                    "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚",
                    "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩",
                    "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣",
                    "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬",
                    "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗",
                    "🤔", "🤭", "🤫", "🤥", "😶", "😐", "😑", "😬", "🙄", "😯",
                    "😦", "😧", "😮", "😲", "🥱", "😴", "🤤", "😪", "😵", "🤐",
                    "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕", "🤑", "🤠", "😈",
                    "👿", "👹", "👺", "🤡", "💩", "👻", "💀", "☠️", "👽", "👾",
                    "🤖", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿",
                    "😾", "🙈", "🙉", "🙊", "💋", "💯", "💢", "💥", "💫", "💦",
                    "💨", "🕳️", "💬", "👁️", "👀", "🧠", "❤️", "🧡", "💛", "💚",
                    "💙", "💜", "🖤", "🤍", "🤎", "💔", "❤️‍🔥", "❣️", "💕", "💞",
                    "💓", "💗", "💖", "💘", "💝", "💟", "💌", "💋", "💤",
                    // Hands & gestures
                    "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞",
                    "🤟", "🤘", "🤙", "👈", "👉", "👆", "👇", "☝️", "👍", "👎",
                    "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏",
                    "✍️", "💅", "🤳", "💪", "🫶", "🫰", "🖕", "👀",
                    // Animals & nature
                    "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯",
                    "🦁", "🐮", "🐷", "🐸", "🐵", "🙈", "🙉", "🙊", "🐒", "🐔",
                    "🐧", "🐦", "🐤", "🐣", "🐥", "🦆", "🦅", "🦉", "🦇", "🐺",
                    "🐗", "🐴", "🦄", "🐝", "🪲", "🦋", "🐌", "🐞", "🐜", "🕷️",
                    "🐢", "🐍", "🦎", "🦖", "🦕", "🐙", "🦑", "🦀", "🐠", "🐟",
                    "🐡", "🐬", "🐳", "🐋", "🦈", "🐊", "🐘", "🦏", "🦛", "🐪",
                    "🌸", "🌹", "🌺", "🌻", "🌼", "🌷", "🌱", "🌲", "🌳", "🍀",
                    "☀️", "🌤️", "⛅", "🌈", "⭐", "🌟", "✨", "⚡", "🔥", "❄️",
                    // Food & drink
                    "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍒",
                    "🍑", "🥭", "🍍", "🥝", "🍅", "🥑", "🍞", "🥐", "🥨", "🧀",
                    "🍔", "🍟", "🍕", "🌭", "🌮", "🌯", "🍿", "🍩", "🍪", "🎂",
                    "🍰", "🍫", "🍭", "🍬", "☕", "🧋", "🥤", "🍺", "🍻", "🍷",
                    // Activities, objects & symbols
                    "⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🏆", "🥇", "🎮", "🎯",
                    "🎲", "🎸", "🎵", "🎶", "🎤", "🎧", "🎬", "🎨", "🎉", "🎊",
                    "🎁", "🚗", "✈️", "🚀", "💡", "📱", "💻", "⌚", "📷", "🔔",
                    "❤️‍🩹", "☑️", "✅", "❌", "❗", "❓", "‼️", "⁉️", "⭕", "🚫",
                    "✔️", "➕", "➖", "🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "⚫", "⚪"
                )

                val sendReaction: (String) -> Unit = { emoji ->
                    scope.launch {
                        val error = repository.reactToMessage(chatKey, targetMessage.id, emoji)
                        if (error == null) {
                            reactionMessage = null
                            reactionError = null
                            showAllEmojis = false
                        } else {
                            reactionError = error
                        }
                    }
                }

                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { reactionMessage = null; reactionError = null },
                    title = {
                        Text(
                            text = reactionError ?: tr("Choose reaction"),
                            color = if (reactionError != null) GhostRedPrimary else GhostTextWhite,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            (if (showAllEmojis) allEmojis else quickEmojis).chunked(if (showAllEmojis) 6 else 4).forEach { rowEmojis ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    rowEmojis.forEach { emoji ->
                                        Box(
                                            modifier = Modifier
                                                .size(if (showAllEmojis) 43.dp else 49.dp)
                                                .clip(CircleShape)
                                                .clickable { sendReaction(emoji) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(emoji, fontSize = if (showAllEmojis) 22.sp else 26.sp)
                                        }
                                    }
                                    repeat((if (showAllEmojis) 6 else 4) - rowEmojis.size) { Spacer(Modifier.size(if (showAllEmojis) 43.dp else 49.dp)) }
                                }
                            }
                            if (!showAllEmojis) {
                                androidx.compose.material3.TextButton(onClick = { showAllEmojis = true }) {
                                    Text("+", color = GhostTextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                androidx.compose.material3.TextButton(onClick = { showAllEmojis = false }) {
                                    Text(tr("Geri"), color = GhostTextWhite)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        androidx.compose.material3.TextButton(onClick = {
                            reactionMessage = null
                            reactionError = null
                            showAllEmojis = false
                        }) {
                            Text(tr("Cancel"))
                        }
                    },
                    containerColor = GhostSurfaceElevated
                )
            }

            // Visible send state: the old UI swallowed API errors, making it impossible
            // to tell whether a message actually reached the server.
            if (sendError != null || sendStatus != null) {
                val statusText = sendStatus.orEmpty()
                val attachmentFlow = attachmentTotalCount > 0 && (
                    statusText.contains("Göndərilir") ||
                    statusText.contains("Fayl") ||
                    statusText.contains("göndərildi") ||
                    attachmentSentCount > 0
                )
                val uploadActive = sendError == null && attachmentFlow && !statusText.contains("✓")
                val uploadFinished = sendError == null && attachmentFlow && statusText.contains("✓")
                val sent = attachmentSentCount.coerceIn(0, attachmentTotalCount)
                val hasAttachmentProgress = attachmentFlow
                val left = (attachmentTotalCount - sent).coerceAtLeast(0)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, GhostBorder, RoundedCornerShape(16.dp)),
                    color = GhostSurfaceElevated
                ) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(34.dp),
                                shape = CircleShape,
                                color = if (sendError != null) GhostRedPrimary.copy(alpha = 0.14f) else GhostGoldBg
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (uploadFinished) Icons.Filled.Done else Icons.Filled.AttachFile,
                                        contentDescription = null,
                                        tint = if (sendError != null) GhostRedPrimary else GhostGoldText,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = sendError ?: sendStatus.orEmpty(),
                                    color = if (sendError != null) GhostRedPrimary else GhostTextWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2
                                )
                                if (sendError == null && hasAttachmentProgress) {
                                    Text(
                                        text = if (left > 0) "$sent / $attachmentTotalCount fayl" else "Bütün fayllar göndərildi",
                                        color = GhostTextMuted,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }
                        }
                        if (sendError == null && hasAttachmentProgress) {
                            Spacer(Modifier.height(8.dp))
                            if (attachmentTotalCount == 1 && uploadActive) {
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(5.dp)),
                                    color = GhostGoldText,
                                    trackColor = GhostSurface
                                )
                            } else {
                                LinearProgressIndicator(
                                    progress = { sent.toFloat() / attachmentTotalCount.toFloat() },
                                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(5.dp)),
                                    color = GhostGoldText,
                                    trackColor = GhostSurface
                                )
                            }
                        }
                    }
                }
            }

            // Emoji / Sticker picker. Stickers are catalogued and served by the backend.
            if (showComposerPicker) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .border(1.dp, GhostBorder, RoundedCornerShape(18.dp)),
                    color = GhostSurfaceElevated
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            listOf(tr("Emoji"), tr("Sticker"), "GIF").forEachIndexed { index, title ->
                                androidx.compose.material3.TextButton(
                                    onClick = { composerTab = index },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = title,
                                        color = if (composerTab == index) GhostTextWhite else GhostTextMuted,
                                        fontWeight = if (composerTab == index) FontWeight.Bold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                        if (composerTab == 0) {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 230.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(composerEmojis.chunked(8)) { rowEmojis ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        rowEmojis.forEach { emoji ->
                                            Box(
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .clip(CircleShape)
                                                    .clickable {
                                                        // If the composer already has text, insert the emoji at
                                                        // the end of that text. If it is empty, send the emoji
                                                        // directly as a message.
                                                        if (inputText.isNotBlank()) {
                                                            inputText += emoji
                                                            sendError = null
                                                        } else if (!isSending) {
                                                            scope.launch {
                                                                val error = repository.sendMessage(chatKey, emoji)
                                                                if (error != null) sendError = error
                                                                else {
                                                                    sendError = null
                                                                    soundPool.play(sentTickId, 1.0f, 1.0f, 1, 0, 1f)
                                                                }
                                                            }
                                                        }
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(emoji, fontSize = 22.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (composerTab == 1) {
                            when {
                                stickersLoading -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(140.dp),
                                        contentAlignment = Alignment.Center
                                    ) { Text(tr("Stickerlər yüklənir…"), color = GhostTextMuted, fontSize = 13.sp) }
                                }
                                remoteStickers.isEmpty() -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(140.dp),
                                        contentAlignment = Alignment.Center
                                    ) { Text(stickerLoadError ?: tr("Sticker yoxdur"), color = GhostTextMuted, fontSize = 13.sp) }
                                }
                                else -> {
                                    LazyColumn(
                                        modifier = Modifier.fillMaxWidth().heightIn(max = 245.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        items(remoteStickers.chunked(3), key = { row -> row.firstOrNull()?.id ?: row.hashCode().toString() }) { rowStickers ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                rowStickers.forEach { sticker ->
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(76.dp)
                                                            .clickable(enabled = !isSending) {
                                                                scope.launch {
                                                                    val error = repository.sendMessage(chatKey, STICKER_PREFIX + sticker.id, stickerImageUrl = sticker.imageUrl)
                                                                    if (error != null) sendError = error
                                                                    else {
                                                                        sendError = null
                                                                        soundPool.play(sentTickId, 1.0f, 1.0f, 1, 0, 1f)
                                                                    }
                                                                }
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        RemoteAnimatedStickerImage(sticker.imageUrl, Modifier.size(64.dp), decodeSize = 96, animate = true)
                                                    }
                                                }
                                                repeat(3 - rowStickers.size) { Spacer(modifier = Modifier.weight(1f)) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (composerTab == 2) {
                            when {
                                gifsLoading -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(140.dp),
                                        contentAlignment = Alignment.Center
                                    ) { Text(tr("GIF-lər yüklənir…"), color = GhostTextMuted, fontSize = 13.sp) }
                                }
                                remoteGifs.isEmpty() -> {
                                    Box(
                                        modifier = Modifier.fillMaxWidth().height(140.dp),
                                        contentAlignment = Alignment.Center
                                    ) { Text(gifLoadError ?: tr("GIF yoxdur"), color = GhostTextMuted, fontSize = 13.sp) }
                                }
                                else -> {
                                    LazyColumn(
                                        modifier = Modifier.fillMaxWidth().heightIn(max = 245.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        contentPadding = PaddingValues(vertical = 4.dp)
                                    ) {
                                        items(remoteGifs.chunked(3), key = { row -> row.firstOrNull()?.id ?: row.hashCode().toString() }) { rowGifs ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                rowGifs.forEach { gif ->
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(76.dp)
                                                            .clickable(enabled = !isSending) {
                                                                scope.launch {
                                                                    val error = repository.sendMessage(chatKey, "__VG_GIF__:" + gif.id, gifImageUrl = gif.imageUrl)
                                                                    if (error != null) sendError = error
                                                                    else {
                                                                        sendError = null
                                                                        soundPool.play(sentTickId, 1.0f, 1.0f, 1, 0, 1f)
                                                                    }
                                                                }
                                                            },
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        RemoteAnimatedStickerImage(gif.imageUrl, Modifier.size(64.dp), decodeSize = 96, animate = true)
                                                    }
                                                }
                                                repeat(3 - rowGifs.size) { Spacer(modifier = Modifier.weight(1f)) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            if (isRecordingVoice) { Text(trf("🎙️ Yazılır... %ds", voiceSeconds), color = GhostTextWhite, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) }
            voiceError?.let { Text(it, color = GhostRedPrimary, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) }

            // Reply preview sits directly above the composer.
            replyMessage?.let { target ->
                Surface(color = GhostSurface, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("↩ ${target.senderNickname.ifBlank { displayChatName }}", color = GhostGoldText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            ReplyMediaPreview(
                                messageType = target.messageType,
                                text = target.text,
                                audioUrl = target.audioUrl,
                                audioDuration = target.audioDuration,
                                stickerImageUrl = target.stickerImageUrl,
                                gifImageUrl = target.gifImageUrl,
                                attachmentUrl = target.attachmentUrl,
                                attachmentType = target.attachmentType,
                                attachmentName = target.attachmentName
                            )
                        }
                        IconButton(onClick = { replyMessage = null }) { Icon(Icons.Filled.Close, tr("Bağla"), tint = GhostTextWhite) }
                    }
                }
            }

            // Bottom Input Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .premiumBackdrop()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // + opens only Emoji / Sticker / GIF. File sending stays on the paperclip.
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable {
                            showAttachmentMenu = false
                            showComposerPicker = !showComposerPicker
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Add, contentDescription = tr("Emoji, Sticker, GIF"), tint = GhostTextWhite, modifier = Modifier.size(34.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it; sendError = null },
                    placeholder = {
                        Text(tr("Type a message..."), color = GhostTextMuted, fontSize = 14.sp)
                    },
                    singleLine = true,
                    // Keep typing enabled while a request is in flight. The send button
                    // still prevents duplicate taps, but the user never loses the ability
                    // to type the same message again.
                    enabled = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { handleSend() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = GhostSurface,
                        unfocusedContainerColor = GhostSurface,
                        focusedBorderColor = GhostBorder,
                        unfocusedBorderColor = GhostBorder,
                        focusedTextColor = GhostTextWhite,
                        unfocusedTextColor = GhostTextWhite,
                        cursorColor = GhostRedPrimary
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field")
                )

                // Paperclip is beside the voice/send button and owns the file menu.
                Box {
                    IconButton(
                        onClick = { showAttachmentMenu = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            Icons.Filled.AttachFile,
                            contentDescription = tr("Fayl əlavə et"),
                            tint = GhostTextWhite,
                            modifier = Modifier.size(27.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showAttachmentMenu,
                        onDismissRequest = { showAttachmentMenu = false },
                        modifier = Modifier.background(GhostSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("📷 Şəkil çək", color = GhostTextWhite) },
                            onClick = {
                                showAttachmentMenu = false
                                val uri = createCameraUri(context, false)
                                pendingCameraUri = uri
                                pendingCameraVideo = false
                                if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) cameraPhotoLauncher.launch(uri)
                                else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("🎥 Video çək", color = GhostTextWhite) },
                            onClick = {
                                showAttachmentMenu = false
                                val uri = createCameraUri(context, true)
                                pendingCameraUri = uri
                                pendingCameraVideo = true
                                if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) cameraVideoLauncher.launch(uri)
                                else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("🖼️ Qalereyadan seç", color = GhostTextWhite) },
                            onClick = {
                                showAttachmentMenu = false
                                attachmentPicker.launch("image/*")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("🎬 Videodan seç", color = GhostTextWhite) },
                            onClick = {
                                showAttachmentMenu = false
                                attachmentPicker.launch("video/*")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("🎵 MP3 / Musiqi seç", color = GhostTextWhite) },
                            onClick = {
                                showAttachmentMenu = false
                                audioPicker.launch(arrayOf("audio/mpeg", "audio/mp4", "audio/x-m4a", "audio/aac", "audio/ogg", "audio/wav", "audio/x-wav"))
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.width(2.dp))

                // Voice composer / preview. A released recording is kept locally until the user
                // explicitly chooses Play, Send, or Trash.
                if (inputText.isBlank() && editingMessageId == null && voiceDraftFile != null) {
                    Row(
                        modifier = Modifier.wrapContentWidth().height(52.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { cancelVoiceDraft() }, modifier = Modifier.size(48.dp)) {
                            Text("🗑️", fontSize = 22.sp)
                        }
                        IconButton(onClick = { toggleVoiceDraftPlayback() }, modifier = Modifier.size(48.dp)) {
                            Icon(
                                if (voiceDraftPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (voiceDraftPlaying) tr("Pause voice") else tr("Play voice"),
                                tint = GhostTextWhite, modifier = Modifier.size(23.dp)
                            )
                        }
                        IconButton(onClick = { sendVoiceDraft() }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Filled.Send, "Send voice", tint = GhostTextWhite, modifier = Modifier.size(23.dp))
                        }
                    }
                } else if (inputText.isBlank() && editingMessageId == null) {
                    val voiceGlow = rememberInfiniteTransition(label = "voiceGlow")
                    val glowScale by voiceGlow.animateFloat(
                        initialValue = 1f, targetValue = 1.22f,
                        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                        label = "voiceGlowScale"
                    )
                    val pressScale by animateFloatAsState(if (isRecordingVoice) 1.12f else 1f, tween(120), label = "voicePressScale")
                    val dragAnimX by animateFloatAsState(if (isRecordingVoice) voiceDragX else 0f, tween(80), label = "voiceDragX")
                    val cancelScale by animateFloatAsState(if (cancelVoiceDrag) 0.88f else 1f, tween(120), label = "voiceCancelScale")
                    val latestStartVoiceRecording = rememberUpdatedState(::startVoiceRecording)
                    val latestCancelVoiceRecording = rememberUpdatedState(::cancelVoiceRecording)
                    val density = LocalDensity.current
                    val lockDistance = 82.dp
                    val triggerOffset = 16.dp
                    val lockDistancePx = with(density) { (lockDistance + triggerOffset).toPx() }

                    Row(
                        modifier = Modifier
                            .wrapContentWidth()
                            .height(52.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Trash target: shown only while recording. Reaching it cancels.
                        if (isRecordingVoice) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (voiceLocked) GhostRedPrimary.copy(alpha = 0.92f)
                                        else if (cancelVoiceDrag) GhostRedPrimary.copy(alpha = 0.85f) else GhostSurface
                                    )
                                    .border(1.dp, GhostRedPrimary, CircleShape)
                                    .clickable(enabled = voiceLocked) {
                                        latestCancelVoiceRecording.value()
                                        voiceError = "Səs ləğv edildi."
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🗑️", fontSize = 22.sp)
                            }
                        }

                        // Lock target: sits between Trash and the microphone/send control.
                        if (isRecordingVoice) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(if (voiceLocked) GhostRedPrimary.copy(alpha = 0.92f) else GhostSurface)
                                    .border(1.dp, GhostRedPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Lock, "Lock voice", tint = GhostTextWhite, modifier = Modifier.size(22.dp))
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .pointerInput(voiceLocked) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        val pointerId = down.id
                                        val downX = down.position.x

                                        // Once locked, this control is a Send button; dragging is
                                        // handled only while the initial hold is still active.
                                        if (voiceLocked) return@awaitEachGesture
                                        if (!latestStartVoiceRecording.value()) return@awaitEachGesture

                                        cancelVoiceDrag = false
                                        voiceDragX = 0f
                                        down.consume()

                                        var locked = false
                                        while (true) {
                                            val event = awaitPointerEvent(PointerEventPass.Main)
                                            val change = event.changes.firstOrNull { it.id == pointerId } ?: break
                                            val dx = (downX - change.position.x).coerceAtLeast(0f)

                                            if (!locked && dx >= lockDistancePx) {
                                                voiceDragX = lockDistancePx
                                                locked = true
                                                voiceLocked = true
                                            } else if (!locked) {
                                                voiceDragX = dx
                                            }

                                            change.consume()
                                            if (!change.pressed) break
                                        }

                                        if (!locked) {
                                            // Release finishes the recording into a local preview draft.
                                            finishVoiceRecordingToDraft()
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .graphicsLayer {
                                        scaleX = if (voiceLocked) 1f else pressScale * cancelScale
                                        scaleY = if (voiceLocked) 1f else pressScale * cancelScale
                                        translationX = if (isRecordingVoice && !voiceLocked) (-dragAnimX).coerceIn(-lockDistancePx, 0f) else 0f
                                    }
                                    .clip(CircleShape)
                                    .background(if (cancelVoiceDrag) GhostRedPrimary.copy(alpha = 0.72f) else GhostRedPrimary)
                                    .border(1.dp, GhostRedPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (voiceLocked) {
                                    IconButton(onClick = { stopLockedAndSendVoice() }) {
                                        Icon(Icons.AutoMirrored.Filled.Send, "Send voice", tint = GhostTextWhite, modifier = Modifier.size(21.dp))
                                    }
                                } else {
                                    Icon(
                                        Icons.Filled.Mic,
                                        "Voice message",
                                        tint = GhostTextWhite,
                                        modifier = Modifier.size(23.dp)
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(GhostRedPrimary)
                            .border(1.dp, GhostRedPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(onClick = handleSend, enabled = inputText.isNotBlank() && !isSending) {
                            Icon(Icons.AutoMirrored.Filled.Send, tr("Send"), tint = GhostTextWhite, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }

}

private class VGhostVoiceRecorder(private val context: android.content.Context) {
    private var recorder: MediaRecorder? = null
    private var file: java.io.File? = null
    private var startedAt = 0L

    fun start() {
        if (recorder != null) return
        val out = java.io.File(context.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        val r = MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(96000)
            r.setOutputFile(out.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            file = out
            startedAt = System.currentTimeMillis()
        } catch (t: Throwable) {
            try { r.reset(); r.release() } catch (_: Throwable) {}
            out.delete()
            throw t
        }
    }

    fun stop(): Pair<java.io.File, Int>? {
        val r = recorder ?: return null
        val f = file
        recorder = null
        file = null
        val duration = ((System.currentTimeMillis() - startedAt) / 1000L).toInt().coerceIn(1, 600)
        return try {
            r.stop()
            r.release()
            if (f != null && f.exists() && f.length() > 0L) f to duration else null
        } catch (_: Throwable) {
            try { r.reset(); r.release() } catch (_: Throwable) {}
            try { f?.delete() } catch (_: Throwable) {}
            null
        }
    }

    fun cancel() {
        val r = recorder ?: return
        val f = file
        recorder = null
        file = null
        try { r.stop() } catch (_: Throwable) {}
        try { r.reset(); r.release() } catch (_: Throwable) {}
        try { f?.delete() } catch (_: Throwable) {}
    }
}
private fun createCameraUri(context: android.content.Context, video: Boolean): Uri {
    val dir = java.io.File(context.cacheDir, "camera").apply { mkdirs() }
    val ext = if (video) ".mp4" else ".jpg"
    val file = java.io.File(dir, "VGhost_${System.currentTimeMillis()}$ext")
    return FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
}

@Composable
private fun AttachmentDownloadButton(context: android.content.Context, file: java.io.File, name: String?, mime: String) {
    var requested by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(requested) {
        if (!requested) return@LaunchedEffect
        status = try {
            withContext(kotlinx.coroutines.Dispatchers.IO) { saveAttachmentToDownloads(context, file, name, mime) }
            "Yadda saxlanıldı ✓"
        } catch (_: Throwable) {
            "Yükləmə alınmadı"
        } finally {
            requested = false
        }
    }

    TextButton(onClick = {
        status = "Yüklənir…"
        requested = true
    }) {
        Text(status ?: "⬇️ Yüklə", color = GhostTextWhite, fontSize = 12.sp)
    }
}

private fun saveAttachmentToDownloads(context: android.content.Context, file: java.io.File, name: String?, mime: String) {
    val safe = (name ?: file.name).replace(Regex("[^A-Za-z0-9._-]"), "_")
    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, safe); put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" }); put(MediaStore.Downloads.IS_PENDING, 1) }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("DOWNLOAD_CREATE_FAILED")
        try {
            context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: error("DOWNLOAD_WRITE_FAILED")
            values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); context.contentResolver.update(uri, values, null, null)
        } catch (t: Throwable) { context.contentResolver.delete(uri, null, null); throw t }
    } else {
        val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
        val out = java.io.File(dir, safe); file.inputStream().use { input -> out.outputStream().use { input.copyTo(it) } }
    }
}

@Composable
private fun VoiceMessageBubble(message: ChatMessage, isOutgoing: Boolean) {
    val context = LocalContext.current
    var playing by remember(message.id) { mutableStateOf(false) }
    val player = remember(message.id) { MediaPlayer() }
    val cardShape = RoundedCornerShape(18.dp)
    // Neon-style voice card: dark/translucent base with a clean luminous outline.
    val neonFill = if (isOutgoing) Color(0x241A1028) else Color(0x24101018)
    val neonBorder = if (isOutgoing) Color(0xD66A5CFF) else Color(0xB84DEBFF)

    DisposableEffect(message.id) {
        onDispose {
            try { player.stop() } catch (_: Throwable) {}
            player.release()
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .widthIn(min = 250.dp, max = 310.dp)
            .clip(cardShape)
            .background(neonFill)
            .border(1.2.dp, neonBorder, cardShape)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (isOutgoing) Color(0x332D1B55)
                    else Color(0x33122B35)
                ),
            contentAlignment = Alignment.Center
        ) {
            IconButton(
                onClick = {
                    try {
                        if (playing) {
                            player.pause()
                            playing = false
                        } else {
                            player.reset()
                            val url = VGhostApi.absoluteUrl(message.audioUrl!!)
                            player.setDataSource(
                                context,
                                Uri.parse(url),
                                mapOf("Authorization" to "Bearer ${VGhostApi.token().orEmpty()}")
                            )
                            player.setOnCompletionListener { playing = false }
                            player.setOnErrorListener { _, _, _ -> playing = false; true }
                            player.setOnPreparedListener { mp -> mp.start(); playing = true }
                            player.prepareAsync()
                        }
                    } catch (_: Throwable) {
                        playing = false
                    }
                },
                modifier = Modifier.size(44.dp)
            ) {
                Icon(
                    imageVector = if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (playing) tr("Pause") else tr("Play"),
                    tint = GhostTextWhite,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Spacer(Modifier.width(10.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = tr("Səsli mesaj"),
                color = GhostTextWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Text(
                text = "${message.audioDuration.coerceAtLeast(0)} san",
                color = if (isOutgoing) Color(0xFFFFF3B0) else GhostTextWhite,
                fontSize = 28.sp,
                lineHeight = 31.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

private fun isEmojiOnlyMessage(value: String): Boolean {
    if (value.isBlank()) return false
    var sawEmoji = false
    var i = 0
    while (i < value.length) {
        val cp = value.codePointAt(i)
        i += Character.charCount(cp)
        when {
            Character.isWhitespace(cp) -> Unit
            cp == 0x200D || cp == 0xFE0F || cp == 0x20E3 || (cp in 0x1F3FB..0x1F3FF) -> Unit
            cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2300..0x23FF || cp in 0x2B00..0x2BFF || cp in 0x2190..0x21FF -> sawEmoji = true
            cp in 0x1F1E6..0x1F1FF -> sawEmoji = true
            else -> return false
        }
    }
    return sawEmoji
}

@Composable
private fun Modifier.threeSecondLongPress(onLongPress: () -> Unit): Modifier {
    // Use Compose's built-in long-press detector so the action works reliably
    // for normal text messages, voice messages, emoji and stickers.
    // The existing message action menu is unchanged; only the gesture handling
    // is fixed. A normal long press opens it without requiring an artificial
    // three-second hold.
    val latestOnLongPress = rememberUpdatedState(onLongPress)

    return pointerInput(Unit) {
        detectTapGestures(
            onLongPress = { latestOnLongPress.value() }
        )
    }
}

@Composable
private fun LinkPreviewCard(message: ChatMessage, isOutgoing: Boolean) {
    val uriHandler = LocalUriHandler.current
    val url = message.linkPreviewUrl ?: return
    val title = message.linkPreviewTitle?.takeIf { it.isNotBlank() }
    val description = message.linkPreviewDescription?.takeIf { it.isNotBlank() }
    val image = message.linkPreviewImage?.takeIf { it.isNotBlank() }?.let { VGhostApi.absoluteUrl(it) }
    val site = message.linkPreviewSite?.takeIf { it.isNotBlank() }
        ?: runCatching { java.net.URI(url).host?.removePrefix("www.") }.getOrNull()
        ?: ""

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isOutgoing) Color(0x33000000) else Color(0x22000000))
            .border(0.6.dp, if (isOutgoing) Color(0x66FFE082) else Color(0x445F6368), RoundedCornerShape(12.dp))
            .clickable { try { uriHandler.openUri(url) } catch (_: Throwable) { } }
    ) {
        if (image != null || url.isNotBlank()) {
            RemotePreviewImage(image, url, Modifier.fillMaxWidth().height(150.dp), 640)
        }
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            if (site.isNotBlank()) Text(site, color = GhostTextMuted, fontSize = 10.sp, maxLines = 1)
            if (title != null) Text(title, color = GhostTextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2)
            if (description != null) Text(description, color = GhostTextSecondary, fontSize = 12.sp, lineHeight = 17.sp, maxLines = 3, modifier = Modifier.padding(top = 3.dp))
            Text(url, color = Color(0xFF8CC8FF), fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 5.dp))
        }
    }
}

private fun extractPreviewImageFromHtml(html: String, pageUrl: String): String? {
    val keys = listOf("og:image", "og:image:url", "og:image:secure_url", "twitter:image", "twitter:image:src")
    val tags = Regex("<meta\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html).map { it.value }
    fun value(tag: String, key: String): String? {
        val p1 = Regex("(?:property|name)\\s*=\\s*[\\\"']" + Regex.escape(key) + "[\\\"'][^>]*content\\s*=\\s*[\\\"']([^\\\"']+)", RegexOption.IGNORE_CASE)
        val p2 = Regex("content\\s*=\\s*[\\\"']([^\\\"']+)[\\\"'][^>]*(?:property|name)\\s*=\\s*[\\\"']" + Regex.escape(key) + "[\\\"']", RegexOption.IGNORE_CASE)
        return p1.find(tag)?.groupValues?.getOrNull(1) ?: p2.find(tag)?.groupValues?.getOrNull(1)
    }
    for (tag in tags) for (key in keys) {
        val v = value(tag, key)?.trim()?.takeIf { it.isNotBlank() } ?: continue
        return try {
            val decoded = android.text.Html.fromHtml(v, android.text.Html.FROM_HTML_MODE_LEGACY).toString()
            val base = java.net.URI(pageUrl)
            when {
                decoded.startsWith("http://") || decoded.startsWith("https://") -> decoded
                decoded.startsWith("//") -> "${base.scheme}:${decoded}"
                decoded.startsWith("/") -> "${base.scheme}://${base.authority}$decoded"
                else -> java.net.URI(base.scheme, base.authority, base.path.substringBeforeLast('/', "/") + "/" + decoded, null).toString()
            }
        } catch (_: Throwable) { null }
    }
    return null
}

private suspend fun downloadPreviewBytes(url: String, maxBytes: Int = 1200000): ByteArray {
    return withContext(kotlinx.coroutines.Dispatchers.IO) {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 15000; c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 VGhost/1.0")
        try {
            c.connect()
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            c.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(8192)
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    if (out.size() + n > maxBytes) break
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
        } finally { c.disconnect() }
    }
}

@Composable
private fun RemotePreviewImage(imageUrl: String?, pageUrl: String?, modifier: Modifier = Modifier, decodeSize: Int = 640) {
    val context = LocalContext.current
    var localFile by remember(imageUrl, pageUrl) { mutableStateOf<java.io.File?>(null) }
    LaunchedEffect(imageUrl, pageUrl) {
        localFile = try {
            withContext(kotlinx.coroutines.Dispatchers.IO) {
                val seed = (imageUrl ?: "") + "|" + (pageUrl ?: "")
                val hash = java.security.MessageDigest.getInstance("SHA-256").digest(seed.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
                val file = java.io.File(context.cacheDir, "vghost_preview_$hash")
                if (!file.isFile || file.length() == 0L) {
                    var bytes: ByteArray? = null
                    if (!imageUrl.isNullOrBlank()) bytes = try { downloadPreviewBytes(imageUrl, 3_000_000) } catch (_: Throwable) { null }
                    if ((bytes == null || bytes.isEmpty()) && !pageUrl.isNullOrBlank()) {
                        val html = try { downloadPreviewBytes(pageUrl, 1_500_000).toString(Charsets.UTF_8) } catch (_: Throwable) { null }
                        val fallback = html?.let { extractPreviewImageFromHtml(it, pageUrl) }
                        if (!fallback.isNullOrBlank()) bytes = try { downloadPreviewBytes(fallback, 3_000_000) } catch (_: Throwable) { null }
                    }
                    if (bytes == null || bytes.isEmpty()) throw java.io.IOException("preview image unavailable")
                    file.outputStream().use { it.write(bytes) }
                    com.vghost.app.CacheManager.trimCache(context)
                }
                file
            }
        } catch (_: Throwable) { null }
    }
    val file = localFile
    if (file == null) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) { Text("…", color = GhostTextMuted, fontSize = 18.sp) }
        return
    }
    val bitmap = remember(file.absolutePath, decodeSize) {
        try {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@remember null
            val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (maxDim / sample > decodeSize * 2 && sample < 16) sample *= 2
            val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = android.graphics.Bitmap.Config.RGB_565 }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (_: Throwable) { null }
    }
    if (bitmap != null) Image(bitmap = bitmap.asImageBitmap(), contentDescription = tr("Link preview"), modifier = modifier, contentScale = ContentScale.Crop)
}

@Composable
private fun FullscreenAttachmentDialog(file: java.io.File, type: String, name: String?, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        BackHandler(onBack = onDismiss)
        if (type.startsWith("image/")) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                val bitmap = remember(file.absolutePath) {
                    try {
                        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
                        val maxDim = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
                        var sample = 1
                        while (maxDim / sample > 2048 && sample < 16) sample *= 2
                        val opts = android.graphics.BitmapFactory.Options().apply {
                            inSampleSize = sample
                            inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                        }
                        android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
                    } catch (_: Throwable) { null }
                }
                if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = name ?: tr("Şəkil"), modifier = Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit)
                IconButton(onClick = onDismiss, modifier = Modifier.padding(12.dp).statusBarsPadding().align(Alignment.TopStart).size(52.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr("Geri"), tint = Color.White, modifier = Modifier.size(34.dp))
                }
            }
        } else if (type.startsWith("video/")) {
            val videoView = remember { mutableStateOf<android.widget.VideoView?>(null) }
            var duration by remember { mutableStateOf(0) }
            var position by remember { mutableStateOf(0) }
            var playing by remember { mutableStateOf(false) }
            LaunchedEffect(videoView.value) {
                while (kotlinx.coroutines.currentCoroutineContext().isActive) {
                    val v = videoView.value ?: break
                    position = try { v.currentPosition } catch (_: Throwable) { 0 }
                    duration = try { v.duration.coerceAtLeast(0) } catch (_: Throwable) { 0 }
                    playing = try { v.isPlaying } catch (_: Throwable) { false }
                    kotlinx.coroutines.delay(300)
                }
            }
            DisposableEffect(file.absolutePath) {
                onDispose {
                    try { videoView.value?.stopPlayback() } catch (_: Throwable) { }
                    videoView.value = null
                }
            }
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        android.widget.VideoView(ctx).apply {
                            videoView.value = this
                            setVideoPath(file.absolutePath)
                            setOnPreparedListener { mp ->
                                duration = mp.duration.coerceAtLeast(0)
                                mp.isLooping = false
                                start()
                                playing = true
                            }
                            setOnCompletionListener { playing = false }
                        }
                    }
                )
                IconButton(onClick = onDismiss, modifier = Modifier.padding(12.dp).statusBarsPadding().align(Alignment.TopStart).size(52.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = tr("Geri"), tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Surface(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp),
                    color = Color(0xCC000000), shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        androidx.compose.material3.Slider(
                            value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                            onValueChange = { value -> position = value.toInt(); videoView.value?.seekTo(value.toInt()) },
                            valueRange = 0f..duration.coerceAtLeast(1).toFloat(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            IconButton(onClick = { videoView.value?.let { it.seekTo((it.currentPosition - 10000).coerceAtLeast(0)) } }) { Text("↶10", color = Color.White, fontSize = 13.sp) }
                            IconButton(onClick = {
                                videoView.value?.let { if (it.isPlaying) { it.pause(); playing = false } else { it.start(); playing = true } }
                            }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = tr("Play/Pause"), tint = Color.White, modifier = Modifier.size(32.dp)) }
                            IconButton(onClick = { videoView.value?.let { it.seekTo((it.currentPosition + 10000).coerceAtMost(duration)) } }) { Text("10↷", color = Color.White, fontSize = 13.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AttachmentMessageBubble(message: ChatMessage, isOutgoing: Boolean) {
    val context = LocalContext.current
    val url = remember(message.id, message.attachmentUrl) { message.attachmentUrl?.let { VGhostApi.absoluteUrl(it) } }
    val type = message.attachmentType.orEmpty().lowercase(Locale.US)
    val localFileState = remember(message.id, url) { mutableStateOf<java.io.File?>(null) }
    var loading by remember(message.id, url) { mutableStateOf(true) }
    var error by remember(message.id, url) { mutableStateOf<String?>(null) }
    var fullscreen by remember(message.id) { mutableStateOf(false) }
    LaunchedEffect(url) {
        val remote = url ?: return@LaunchedEffect
        loading = true; error = null
        localFileState.value = try {
            withContext(kotlinx.coroutines.Dispatchers.IO) {
                val hash = java.security.MessageDigest.getInstance("SHA-256").digest(remote.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
                val ext = message.attachmentName?.substringAfterLast('.', "bin")?.replace(Regex("[^A-Za-z0-9]"), "")?.ifBlank { "bin" } ?: "bin"
                val file = java.io.File(context.cacheDir, "vghost_attachment_$hash.$ext")
                if (!file.isFile || file.length() == 0L) {
                    val c = java.net.URL(remote).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 15000; c.readTimeout = 120000; c.instanceFollowRedirects = true
                    c.setRequestProperty("Authorization", "Bearer ${VGhostApi.token().orEmpty()}")
                    try { c.connect(); if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}"); c.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }; com.vghost.app.CacheManager.trimCache(context) }
                    finally { c.disconnect() }
                }
                file
            }
        } catch (t: Throwable) { error = t.message ?: tr("Fayl yüklənmədi."); null }
        loading = false
    }
    val file = localFileState.value
    val card = RoundedCornerShape(18.dp)
    if (loading || file == null) {
        Surface(
            modifier = Modifier
                .widthIn(min = 250.dp, max = 300.dp)
                .height(104.dp)
                .clip(card)
                .border(1.dp, GhostBorder, card),
            color = GhostSurfaceElevated
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.size(50.dp),
                    shape = RoundedCornerShape(15.dp),
                    color = if (error == null) GhostGoldBg else GhostRedPrimary.copy(alpha = 0.14f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (error == null) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(27.dp),
                                strokeWidth = 3.dp,
                                color = GhostGoldText
                            )
                            Icon(
                                imageVector = Icons.Filled.AttachFile,
                                contentDescription = null,
                                tint = GhostGoldText,
                                modifier = Modifier.size(16.dp)
                            )
                        } else {
                            Text("!", color = GhostRedPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = if (error == null) "Fayl hazırlanır…" else "Fayl yüklənmədi",
                        color = GhostTextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    Text(
                        text = message.attachmentName?.takeIf { it.isNotBlank() } ?:
                            if (error == null) "Yüklənir…" else "Yenidən cəhd edin",
                        color = if (error == null) GhostTextMuted else GhostRedPrimary,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                    if (error == null) {
                        Spacer(Modifier.height(7.dp))
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = GhostGoldText,
                            trackColor = GhostSurface
                        )
                    }
                }
            }
        }
        return
    }
    when {
        type.startsWith("image/") -> {
            val bitmap = remember(file.absolutePath) {
                try {
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)
                    val maxDim = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
                    var sample = 1
                    while (maxDim / sample > 1600 && sample < 16) sample *= 2
                    val opts = android.graphics.BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                    }
                    android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
                } catch (_: Throwable) { null }
            }
            Column(horizontalAlignment = Alignment.Start) {
                if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = message.attachmentName ?: tr("Şəkil"), modifier = Modifier.width(280.dp).height(210.dp).clip(card).background(Color.Black).clickable { fullscreen = true }, contentScale = ContentScale.Fit)
                else Text("🖼️ ${message.attachmentName.orEmpty()}", color = GhostTextWhite, modifier = Modifier.padding(12.dp))
                AttachmentDownloadButton(context, file, message.attachmentName, type)
            }
        }
        type.startsWith("video/") -> {
            val thumb = remember(file.absolutePath) {
                try { MediaMetadataRetriever().use { r -> r.setDataSource(file.absolutePath); r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } } catch (_: Throwable) { null }
            }
            Column(horizontalAlignment = Alignment.Start) {
                Box(Modifier.width(280.dp).height(190.dp).clip(card).background(Color.Black).clickable { fullscreen = true }, contentAlignment = Alignment.Center) {
                    if (thumb != null) Image(thumb.asImageBitmap(), contentDescription = message.attachmentName ?: tr("Video"), modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Box(Modifier.fillMaxSize().background(Color(0xFF111111)))
                    Surface(shape = CircleShape, color = Color(0xAA000000)) { Icon(Icons.Filled.PlayArrow, contentDescription = tr("Play"), tint = Color.White, modifier = Modifier.padding(12.dp).size(34.dp)) }
                }
                AttachmentDownloadButton(context, file, message.attachmentName, type)
            }
        }
        type.startsWith("audio/") -> {
            var playing by remember(message.id) { mutableStateOf(false) }
            val player = remember(message.id) { MediaPlayer() }
            DisposableEffect(message.id) { onDispose { try { player.stop() } catch (_: Throwable) {}; player.release() } }
            Column(Modifier.widthIn(min = 240.dp, max = 300.dp).clip(card).background(GhostSurfaceElevated).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { try { if (playing) { player.pause(); playing = false } else { player.reset(); player.setDataSource(file.absolutePath); player.setOnCompletionListener { playing = false }; player.setOnPreparedListener { it.start(); playing = true }; player.prepareAsync() } } catch (_: Throwable) { playing = false } }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = tr("Musiqini oxut"), tint = GhostTextWhite) }
                    Column(Modifier.weight(1f)) { Text(message.attachmentName ?: "Musiqi", color = GhostTextWhite, maxLines = 1); Text("MP3 / Audio", color = GhostTextMuted, fontSize = 11.sp) }
                }
                AttachmentDownloadButton(context, file, message.attachmentName, type)
            }
        }
        else -> Text("📎 ${message.attachmentName.orEmpty()}", color = GhostTextWhite, modifier = Modifier.padding(12.dp))
    }
    if (fullscreen && (type.startsWith("image/") || type.startsWith("video/"))) FullscreenAttachmentDialog(file, type, message.attachmentName) { fullscreen = false }
}

@Composable
private fun ReplyMediaPreview(
    messageType: String,
    text: String,
    audioUrl: String?,
    audioDuration: Int = 0,
    stickerImageUrl: String?,
    gifImageUrl: String?,
    attachmentUrl: String?,
    attachmentType: String?,
    attachmentName: String? = null
) {
    // A reply is a preview of the ORIGINAL message, not a second text-only copy.
    // Prefer explicit media fields, but also recover folder-based sticker/GIF
    // messages from their markers so the preview survives a refresh/legacy API.
    val type = messageType.lowercase()
    val legacyVoice = text.equals("🎤 Voice message", true) || text.equals("Voice message", true)
    val stickerMarker = text.removePrefix(STICKER_PREFIX).takeIf { text.startsWith(STICKER_PREFIX) }
    val gifMarker = text.removePrefix("__VG_GIF__:").takeIf { text.startsWith("__VG_GIF__:") }
    when {
        type == "sticker" || !stickerImageUrl.isNullOrBlank() || stickerMarker != null -> {
            val raw = stickerImageUrl ?: stickerMarker
            val url = raw?.let { VGhostApi.publicUrl(it) }
            if (!url.isNullOrBlank()) RemoteAnimatedStickerImage(url, Modifier.size(52.dp), decodeSize = 160, animate = true)
            else Text("🧩 Sticker", color = GhostTextWhite.copy(alpha = .78f), fontSize = 11.sp, maxLines = 2)
        }
        type == "gif" || !gifImageUrl.isNullOrBlank() || gifMarker != null -> {
            val raw = gifImageUrl ?: gifMarker
            val url = raw?.let { VGhostApi.publicUrl(it) }
            if (!url.isNullOrBlank()) RemoteAnimatedStickerImage(url, Modifier.size(58.dp), decodeSize = 160, animate = true)
            else Text("GIF", color = GhostTextWhite.copy(alpha = .78f), fontSize = 11.sp)
        }
        type == "attachment" || !attachmentUrl.isNullOrBlank() || !attachmentName.isNullOrBlank() -> {
            val url = attachmentUrl?.let { VGhostApi.publicUrl(it) }
            val mediaType = attachmentType.orEmpty().lowercase()
            if (!url.isNullOrBlank() && mediaType.startsWith("image/")) {
                RemotePreviewImage(url, null, Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)), 180)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (mediaType.startsWith("video/")) Icons.Filled.PlayArrow else Icons.Filled.AttachFile,
                        null, tint = GhostTextWhite.copy(alpha = .82f), modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        when {
                            mediaType.startsWith("video/") -> "🎬 Video"
                            !attachmentName.isNullOrBlank() -> "📎 $attachmentName"
                            else -> "📎 Fayl"
                        },
                        color = GhostTextWhite.copy(alpha = .78f), fontSize = 11.sp, maxLines = 2
                    )
                }
            }
        }
        type == "voice" || type == "audio" || !audioUrl.isNullOrBlank() || legacyVoice -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.VolumeUp, null, tint = GhostTextWhite.copy(alpha = .82f), modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "🎙️ Səsli mesaj${if (audioDuration > 0) " • ${audioDuration} san" else ""}",
                    color = GhostTextWhite.copy(alpha = .78f), fontSize = 11.sp
                )
            }
        }
        type == "emoji" || isEmojiOnlyMessage(text) -> {
            Text(text.ifBlank { "😊" }, color = GhostTextWhite, fontSize = 23.sp, maxLines = 2)
        }
        else -> {
            Text(text.ifBlank { messageType.ifBlank { "Mesaj" } }, color = GhostTextWhite.copy(alpha = .78f), fontSize = 11.sp, maxLines = 2)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, onLongPress: () -> Unit = {}) {
    val isOutgoing = message.isOutgoing
    val stickerId = message.text.removePrefix(STICKER_PREFIX).takeIf { message.text.startsWith(STICKER_PREFIX) }
    val stickerImageUrl = message.stickerImageUrl?.let { VGhostApi.publicUrl(it) }
    val gifImageUrl = message.gifImageUrl?.let { VGhostApi.publicUrl(it) }
    val gifId = message.text.removePrefix("__VG_GIF__:").takeIf { message.text.startsWith("__VG_GIF__:") }
    val isGif = message.messageType.equals("gif", true) || gifId != null || gifImageUrl != null
    val isSticker = !isGif && (message.messageType.equals("sticker", true) || stickerId != null || stickerImageUrl != null)
    val isEmoji = message.messageType.equals("emoji", true) || (!isSticker && !isGif && isEmojiOnlyMessage(message.text))
    val isVoice = message.messageType.equals("voice", true) || message.messageType.equals("audio", true)
    val isAttachment = message.messageType.equals("attachment", true) || !message.attachmentUrl.isNullOrBlank()
    val showBackendCard = !isSticker && !isEmoji && !isVoice && !isAttachment

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = if (showBackendCard) {
                Modifier
                    .widthIn(max = 280.dp)
                    .threeSecondLongPress(onLongPress)
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp, topEnd = 16.dp,
                            bottomStart = if (isOutgoing) 16.dp else 4.dp,
                            bottomEnd = if (isOutgoing) 4.dp else 16.dp
                        )
                    )
                    .background(
                        if (isOutgoing) Color(0x66FFD54F) else Color(0x66000000)
                    )
                    .border(
                        width = 0.7.dp,
                        color = if (isOutgoing) Color(0x80FFE082) else Color(0x66999999),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            } else if (isVoice) {
                // Voice messages must still support the normal long-press actions
                // (Delete / Reaction), but Copy Message is hidden in the action dialog
                // because audio is not text. A normal tap is intentionally a no-op so
                // playback remains handled by the Play button inside the voice card.
                Modifier
                    .widthIn(max = 280.dp)
                    .threeSecondLongPress(onLongPress)
                    .padding(horizontal = 2.dp, vertical = 2.dp)
            } else {
                Modifier
                    .widthIn(max = 280.dp)
                    .threeSecondLongPress(onLongPress)
                    .padding(horizontal = 2.dp, vertical = 2.dp)
            }
        ) {
            Column {
                if (message.replyToMessageId != null) {
                    Surface(
                        color = Color.White.copy(alpha = .08f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    ) {
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                            Text("↩ ${message.replyToSenderNickname.orEmpty()}", color = GhostGoldText, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            ReplyMediaPreview(
                                messageType = message.replyToMessageType.orEmpty(),
                                text = message.replyToText.orEmpty(),
                                audioUrl = message.replyToAudioUrl,
                                audioDuration = message.replyToAudioDuration,
                                stickerImageUrl = message.replyToStickerImageUrl,
                                gifImageUrl = message.replyToGifImageUrl,
                                attachmentUrl = message.replyToAttachmentUrl,
                                attachmentType = message.replyToAttachmentType,
                                attachmentName = message.replyToAttachmentName
                            )
                        }
                    }
                }
                if (showBackendCard && !isOutgoing && message.senderNickname.isNotBlank()) {
                    Text(
                        text = message.senderNickname,
                        color = GhostTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                }
                if (isVoice && !message.audioUrl.isNullOrBlank()) {
                    VoiceMessageBubble(message, isOutgoing)
                } else if (isAttachment && !message.attachmentUrl.isNullOrBlank()) {
                    AttachmentMessageBubble(message, isOutgoing)
                } else if (isGif) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        if (gifImageUrl != null) RemoteAnimatedStickerImage(gifImageUrl, Modifier.size(180.dp))
                        else Text("GIF", color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (isSticker) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        val remoteUrl = stickerImageUrl
                        if (remoteUrl != null) RemoteAnimatedStickerImage(remoteUrl, Modifier.size(120.dp), decodeSize = 256)
                        else Text("🖼️", fontSize = 56.sp)
                    }
                } else {
                    Text(
                        text = message.text,
                        color = GhostTextWhite,
                        fontSize = if (isEmoji) 40.sp else 14.sp,
                        lineHeight = if (isEmoji) 44.sp else 20.sp
                    )
                    if (!isEmoji && message.linkPreviewUrl != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinkPreviewCard(message, isOutgoing)
                    }
                }
                if (message.reactions.isNotEmpty()) {
                    Row(modifier = Modifier.padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        message.reactions.forEach { (emoji, count) ->
                            Text("$emoji $count", color = GhostTextWhite, fontSize = 22.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = message.time,
                        color = if (isOutgoing) Color(0xFFE8DFA8) else Color(0xFFBDBDBD),
                        fontSize = 10.sp
                    )

                    if (isOutgoing) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = if (message.isRead) Icons.Filled.DoneAll else Icons.Filled.Done,
                            contentDescription = if (message.isRead) tr("Read") else tr("Delivered"),
                            tint = if (message.isRead) Color(0xFF66CCFF) else Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }
    }
}
