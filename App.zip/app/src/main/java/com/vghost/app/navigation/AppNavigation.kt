package com.vghost.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import org.json.JSONObject
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.ui.components.GiftReceivedOverlay
import com.vghost.app.ui.components.LevelUpOverlay
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.AppLocale
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.screens.ChatScreen
import com.vghost.app.ui.screens.AdminScreen
import com.vghost.app.ui.screens.FindByNicknameScreen
import com.vghost.app.ui.screens.HomeScreen
import com.vghost.app.ui.screens.GameHomeScreen
import com.vghost.app.ui.screens.GhostMinesScreen
import com.vghost.app.ui.screens.VGhostJetScreen
import com.vghost.app.ui.screens.VGhostPenaltyScreen
import com.vghost.app.ui.screens.VGhostRockfallScreen
import com.vghost.app.ui.screens.VGhostTicTacToeScreen
import com.vghost.app.ui.screens.LoginScreen
import com.vghost.app.ui.screens.PanicScreen
import com.vghost.app.ui.screens.StoryScreen
import com.vghost.app.ui.screens.PinLockScreen
import com.vghost.app.ui.screens.ProfileScreen
import com.vghost.app.ui.screens.OtherProfileScreen
import com.vghost.app.ui.screens.RegisterScreen
import com.vghost.app.ui.screens.SettingsScreen
import com.vghost.app.ui.screens.LanguageScreen
import com.vghost.app.ui.screens.PrivacyScreen
import com.vghost.app.ui.screens.LegalDocument
import com.vghost.app.ui.screens.LegalDocumentScreen
import com.vghost.app.ui.screens.WebRtcIncomingCallScreen
import com.vghost.app.ui.screens.WebRtcCallScreen
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

private data class GlobalIncomingCall(val id: Long, val callerName: String, val callType: String, val isTest: Boolean)
private data class GlobalActiveCall(val id: Long, val remoteName: String, val callType: String, val isCaller: Boolean)

object AppRoutes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val GAME = "game"
    const val MINES = "mines"
    const val JET = "jet"
    const val PENALTY = "penalty"
    const val ROCKFALL = "rockfall"
    const val TICTACTOE = "tictactoe"
    const val FIND = "find"
    const val PANIC = "panic"
    const val STORY = "story"
    const val STORY_WITH_ID = "story?storyId={storyId}"
    const val CHAT = "chat/{nickname}"
    const val PIN_LOCK = "pin_lock"
    const val ADMIN = "admin"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val LANGUAGE = "language"
    const val PRIVACY = "privacy"
    const val PRIVACY_POLICY = "privacy_policy"
    const val TERMS = "terms"
    const val OTHER_PROFILE = "other_profile/{nickname}?uid={uid}&online={online}"

    fun chatRoute(nickname: String): String {
        val encoded = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "chat/$encoded"
    }

    fun otherProfileRoute(nickname: String): String {
        val encoded = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "other_profile/$encoded?online=false"
    }

    fun otherProfileRouteWithUid(uid: String, nickname: String, online: Boolean): String {
        val encodedUid = URLEncoder.encode(uid, StandardCharsets.UTF_8.toString())
        val encodedNickname = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "other_profile/$encodedNickname?uid=$encodedUid&online=$online"
    }
}

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    initialChatNickname: String? = null,
    initialNotificationTarget: String? = null,
    initialNotificationTargetValue: String? = null,
    navController: NavHostController = rememberNavController()
) {
    val giftEvent by VGhostRepository.instance.giftReceivedEvent.collectAsState()
    val levelUpEvent by VGhostRepository.instance.levelUpEvent.collectAsState()
    val appLanguage by AppLocale.language.collectAsState()
    val context = LocalContext.current
    val sessionState by VGhostRepository.instance.sessionState.collectAsState()
    var globalIncoming by remember { mutableStateOf<GlobalIncomingCall?>(null) }
    var globalActive by remember { mutableStateOf<GlobalActiveCall?>(null) }

    LaunchedEffect(sessionState) {
        val loggedIn = sessionState is com.vghost.app.data.state.SessionState.LoggedInNormalUser
        if (!loggedIn) {
            globalIncoming = null
            return@LaunchedEffect
        }
        while (kotlinx.coroutines.currentCoroutineContext().isActive) {
            if (globalActive == null && globalIncoming == null) {
                try {
                    val arr = com.vghost.app.network.VGhostApi.call("call/poll").optJSONArray("calls")
                    if (arr != null && arr.length() > 0) {
                        val c = arr.getJSONObject(0)
                        globalIncoming = GlobalIncomingCall(
                            id = c.optLong("id"),
                            callerName = c.optString("callerNickname", "VGHOST"),
                            callType = c.optString("callType", "voice"),
                            isTest = c.optInt("isTest", 0) == 1
                        )
                    }
                } catch (_: Throwable) {}
            }
            delay(1000L)
        }
    }

    Box(modifier.fillMaxSize()) {
        // Changing language rebuilds the whole destination subtree, so every
        // screen immediately reads the new translations, not only Panic.
        key(appLanguage) {
    NavHost(
        navController = navController,
        // Keep an authenticated local session on process recreation. If the
        // repository has an account/session, MainActivity handles the PIN gate
        // first; after unlock navigation must open Home, not Login.
        startDestination = when {
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && !initialChatNickname.isNullOrBlank() -> AppRoutes.chatRoute(initialChatNickname)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("chat", true) && !initialNotificationTargetValue.isNullOrBlank() -> AppRoutes.chatRoute(initialNotificationTargetValue)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("profile", true) && !initialNotificationTargetValue.isNullOrBlank() -> AppRoutes.otherProfileRoute(initialNotificationTargetValue)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("profile", true) -> AppRoutes.PROFILE
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("home", true) -> AppRoutes.HOME
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("find", true) -> AppRoutes.FIND
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("admin", true) -> AppRoutes.ADMIN
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser -> AppRoutes.GAME
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInGhost -> AppRoutes.GAME
            else -> AppRoutes.LOGIN
        },
        modifier = modifier,
        // Smooth app-wide transitions compatible with the Compose version used by this project.
        enterTransition = {
            fadeIn(animationSpec = tween(220)) +
                slideInHorizontally(animationSpec = tween(280)) { it / 8 }
        },
        exitTransition = {
            fadeOut(animationSpec = tween(160)) +
                slideOutHorizontally(animationSpec = tween(220)) { -it / 12 }
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(200)) +
                slideInHorizontally(animationSpec = tween(260)) { -it / 8 }
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(140)) +
                slideOutHorizontally(animationSpec = tween(200)) { it / 12 }
        }
    ) {
        // 1. Login Screen
        composable(AppRoutes.LOGIN) {
            LoginScreen(
                onLoginSuccess = { nickname ->
                    navController.navigate(AppRoutes.GAME) {
                        popUpTo(AppRoutes.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(AppRoutes.REGISTER) {
                        launchSingleTop = true
                    }
                },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onEnterGhostMode = {
                    VGhostRepository.instance.enterGhostMode()
                    navController.navigate(AppRoutes.GAME) {
                        popUpTo(AppRoutes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        // Language picker is available before login and from Profile.
        composable(AppRoutes.LANGUAGE) {
            LanguageScreen(onBack = { navController.popBackStack() })
        }

        // 2. Register Screen
        composable(AppRoutes.REGISTER) {
            RegisterScreen(
                onRegisterSuccess = { nickname ->
                    navController.navigate(AppRoutes.GAME) {
                        popUpTo(AppRoutes.REGISTER) { inclusive = true }
                        popUpTo(AppRoutes.LOGIN) { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    // The Register screen's top-left arrow must ALWAYS return
                    // directly to Login. Do not use popBackStack here because
                    // the previous destination can vary after process restore
                    // or nested navigation. Remove Register from the stack and
                    // land on Login deterministically.
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.REGISTER) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onOpenPrivacyPolicy = { navController.navigate(AppRoutes.PRIVACY_POLICY) },
                onOpenTerms = { navController.navigate(AppRoutes.TERMS) },
                onEnterGhostMode = {
                    VGhostRepository.instance.enterGhostMode()
                    navController.navigate(AppRoutes.GAME) {
                        popUpTo(AppRoutes.REGISTER) { inclusive = true }
                        popUpTo(AppRoutes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        // 3. Home / Chats Screen
        composable(AppRoutes.HOME) {
            HomeScreen(
                onChatClicked = { nickname ->
                    navController.navigate(AppRoutes.chatRoute(nickname))
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.CHATS -> {} // Already on Home
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                onNotificationTarget = { notification ->
                    when (notification.target.lowercase()) {
                        "chat" -> if (notification.targetValue.isNotBlank()) navController.navigate(AppRoutes.chatRoute(notification.targetValue)) { launchSingleTop = true }
                        "profile" -> if (notification.targetValue.isNotBlank()) navController.navigate(AppRoutes.otherProfileRoute(notification.targetValue)) { launchSingleTop = true } else navController.navigate(AppRoutes.PROFILE) { launchSingleTop = true }
                        "story" -> {
                            val sid = notification.targetValue.toLongOrNull() ?: 0L
                            navController.navigate(if (sid > 0L) "story?storyId=$sid" else AppRoutes.STORY) { launchSingleTop = true }
                        }
                        "game" -> navController.navigate(AppRoutes.GAME) { launchSingleTop = true }
                        "find" -> navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                        "admin" -> navController.navigate(AppRoutes.ADMIN) { launchSingleTop = true }
                        "link" -> {
                            val value = notification.targetValue.trim()
                            try {
                                val uri = Uri.parse(value)
                                if ((uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) && uri.host != null) {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                } else {
                                    navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                                }
                            } catch (_: Throwable) {
                                navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                            }
                        }
                        else -> navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                    }
                }
            )
        }

        // 4. Game Home -> Ghost Mines (only active game for now)
        composable(AppRoutes.GAME) {
            GameHomeScreen(
                onOpenMines = { navController.navigate(AppRoutes.MINES) },
                onOpenJet = { navController.navigate(AppRoutes.JET) },
                onOpenPenalty = { navController.navigate(AppRoutes.PENALTY) },
                onOpenRockfall = { navController.navigate(AppRoutes.ROCKFALL) },
                onOpenTicTacToe = { navController.navigate(AppRoutes.TICTACTOE) },
                onAdminSecret = { navController.navigate(AppRoutes.ADMIN) },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> {}
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        composable(AppRoutes.JET) {
            VGhostJetScreen(
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.GAME) { launchSingleTop = true } },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) { popUpTo(AppRoutes.GAME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        composable(AppRoutes.PENALTY) {
            VGhostPenaltyScreen(
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.GAME) { launchSingleTop = true } },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) { popUpTo(AppRoutes.GAME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        composable(AppRoutes.ROCKFALL) {
            VGhostRockfallScreen(
                onBack = { navController.popBackStack() }
            )
        }

        composable(AppRoutes.TICTACTOE) {
            VGhostTicTacToeScreen(
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.GAME) { launchSingleTop = true } }
            )
        }

        composable(AppRoutes.MINES) {
            GhostMinesScreen(
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.GAME) { launchSingleTop = true } },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) { popUpTo(AppRoutes.GAME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        // 4. Super Admin Control Room (inside the Android app)
        composable(AppRoutes.ADMIN) {
            AdminScreen(
                onBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                    }
                },
                onAdminRejected = {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.ADMIN) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 5. Find by Nickname Screen
        composable(AppRoutes.FIND) {
            FindByNicknameScreen(
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.FIND) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                },
                onUserSelected = { user ->
                    navController.navigate(AppRoutes.otherProfileRouteWithUid(user.uid, user.nickname, user.online))
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.FIND -> {} // Already on Find
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // 5. Other User Profile
        composable(
            route = AppRoutes.OTHER_PROFILE,
            arguments = listOf(
                navArgument("nickname") { type = NavType.StringType },
                navArgument("uid") { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument("online") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val nickname = URLDecoder.decode(backStackEntry.arguments?.getString("nickname").orEmpty(), StandardCharsets.UTF_8.toString())
            val initialUid = backStackEntry.arguments?.getString("uid")?.let { URLDecoder.decode(it, StandardCharsets.UTF_8.toString()) }
            val initialOnline = backStackEntry.arguments?.getBoolean("online") ?: false
            OtherProfileScreen(
                nickname = nickname,
                initialUid = initialUid,
                initialOnline = initialOnline,
                onNavigateBack = {
                    if (!navController.popBackStack()) navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                },
                onOpenChat = { target -> navController.navigate(AppRoutes.chatRoute(target)) },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        // 6. Profile Screen
        composable(AppRoutes.PROFILE) {
            ProfileScreen(
                onOpenSettings = { navController.navigate(AppRoutes.SETTINGS) },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> {} // Already on My Profile; repeated taps must not re-enter/reload it.
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                },
                onOpenPanic = { navController.navigate(AppRoutes.PANIC) { launchSingleTop = true } },
                onLogout = {
                    // Explicit user logout: clear the local App PIN as well as the session.
                    // Network outages never call this path, so offline sessions remain intact.
                    VGhostRepository.instance.logoutAndClearLocalPin()
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.PROFILE) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 6. Chat Screen (Text Only)

        composable(AppRoutes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onOpenPrivacy = { navController.navigate(AppRoutes.PRIVACY) },
                onOpenPrivacyPolicy = { navController.navigate(AppRoutes.PRIVACY_POLICY) },
                onOpenTerms = { navController.navigate(AppRoutes.TERMS) },
                onAccountDeleted = {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.SETTINGS) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(AppRoutes.PRIVACY) {
            PrivacyScreen(onBack = { navController.popBackStack() })
        }

        composable(AppRoutes.PRIVACY_POLICY) {
            LegalDocumentScreen(LegalDocument.PRIVACY_POLICY, onBack = { navController.popBackStack() })
        }

        composable(AppRoutes.TERMS) {
            LegalDocumentScreen(LegalDocument.TERMS, onBack = { navController.popBackStack() })
        }

        composable(
            route = AppRoutes.CHAT,
            arguments = listOf(navArgument("nickname") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedNickname = backStackEntry.arguments?.getString("nickname") ?: "Shadow_7"
            val decodedNickname = URLDecoder.decode(encodedNickname, StandardCharsets.UTF_8.toString())
            ChatScreen(
                recipientNickname = decodedNickname,
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // 6. Story / Status screen
        composable(AppRoutes.STORY_WITH_ID, arguments = listOf(navArgument("storyId") { type = NavType.LongType; defaultValue = 0L })) { backStackEntry ->
            val initialStoryId = backStackEntry.arguments?.getLong("storyId") ?: 0L
            val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
            val storyVisible = currentRoute?.startsWith("story") == true
            StoryScreen(
                initialStoryId = initialStoryId,
                isVisible = storyVisible,
                onOpenRegister = { navController.navigate(AppRoutes.REGISTER) { launchSingleTop = true } },
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.HOME) { launchSingleTop = true } },
                onOpenProfile = { uid, nickname ->
                    navController.navigate(AppRoutes.otherProfileRouteWithUid(uid.toString(), nickname, false)) { launchSingleTop = true }
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> {}
                    }
                }
            )
        }

        // 7. Panic Screen — opened from My Profile
        composable(AppRoutes.PANIC) {
            PanicScreen(
                onPanicActivated = {
                    // Panic deletes chats/messages only. Keep the same authenticated
                    // account, App PIN and session; no navigation to Login is needed.
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.GAME -> navController.navigate(AppRoutes.GAME) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // 7. App Lock / PIN Entry Screen
        composable(AppRoutes.PIN_LOCK) {
            PinLockScreen(
                onUnlockSuccess = {
                    navController.navigate(AppRoutes.HOME) {
                        popUpTo(AppRoutes.PIN_LOCK) { inclusive = true }
                    }
                },
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.PIN_LOCK) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }
    }
        } // key(appLanguage)
    giftEvent?.let { event -> GiftCatalog.find(event.giftId)?.let { gift -> GiftReceivedOverlay(gift.icon, gift.name, event.sender, event.token) { VGhostRepository.instance.clearGiftReceived(event.token) } } }
    levelUpEvent?.let { event -> LevelUpOverlay(event.level, event.coins, event.token) { VGhostRepository.instance.clearLevelUpEvent(event.token) } }

        globalIncoming?.let { call ->
            WebRtcIncomingCallScreen(
                callerName = call.callerName,
                callType = call.callType,
                isTest = call.isTest,
                onReject = {
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                        try {
                            com.vghost.app.network.VGhostApi.call("call/signal", "POST", JSONObject().put("call_id", call.id).put("signal_type", "reject").put("payload", JSONObject()))
                        } catch (_: Throwable) {}
                    }
                    globalIncoming = null
                },
                onAccept = {
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                        try {
                            com.vghost.app.network.VGhostApi.call("call/accept", "POST", JSONObject().put("call_id", call.id))
                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                globalActive = GlobalActiveCall(call.id, call.callerName, call.callType, false)
                                globalIncoming = null
                            }
                        } catch (_: Throwable) {
                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { globalIncoming = null }
                        }
                    }
                }
            )
        }
        globalActive?.let { call ->
            WebRtcCallScreen(
                callId = call.id,
                callType = call.callType,
                remoteName = call.remoteName,
                isCaller = call.isCaller,
                onClosed = { globalActive = null }
            )
        }
    }
}
