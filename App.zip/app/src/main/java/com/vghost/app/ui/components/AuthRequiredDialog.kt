package com.vghost.app.ui.components

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trKey
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AuthRequiredDialog(
    onRegister: () -> Unit,
    onLogin: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF100911),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFBDB4C5),
        confirmButton = {
            Button(
                onClick = onRegister,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744))
            ) {
                Text(tr("Qeydiyyatdan keç"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Column(Modifier.fillMaxWidth()) {
                TextButton(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Text(trKey("login"), color = Color(0xFFB86CFF), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text(tr("← Geri"), color = Color(0xFFA9A1AE), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        },
        title = { Text(tr("🔐 Hesab tələb olunur"), fontSize = 24.sp, fontWeight = FontWeight.Black) },
        text = {
            Text(
                tr("Bu funksiyadan istifadə etmək üçün qeydiyyatdan keçin və ya hesabınıza daxil olun."),
                fontSize = 16.sp,
                lineHeight = 23.sp
            )
        }
    )
}
