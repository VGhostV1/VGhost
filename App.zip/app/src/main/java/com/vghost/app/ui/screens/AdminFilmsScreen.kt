package com.vghost.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.vghost.app.workers.FilmUploadWorker
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

private data class AdminFilmRow(val id:Long,val title:String,val category:String,val year:Int?,val active:Boolean,val featured:Boolean)

@Composable
fun AdminFilmsScreen(onBack:()->Unit) {
    val context=LocalContext.current
    val scope=rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<AdminFilmRow>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var editingId by remember { mutableStateOf(0L) }
    var title by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }
    var poster by remember { mutableStateOf("") }; var video by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Drama") }; var year by remember { mutableStateOf("") }; var duration by remember { mutableStateOf("") }
    var categoryMenuOpen by remember { mutableStateOf(false) }
    var categories by remember { mutableStateOf(listOf("Drama", "Aksiya", "Komediya", "Romantik", "Qorxu", "Fantastika", "Macəra", "Triller", "Detektiv", "Kriminal", "Döyüş", "Animasiya", "Ailə", "Tarixi", "Sənədli", "Musiqili", "Elmi-fantastika", "Bioqrafiya", "Misteriya")) }
    var vip by remember { mutableStateOf(false) }; var featured by remember { mutableStateOf(false) }; var active by remember { mutableStateOf(true) }
    var codeDialog by remember { mutableStateOf(false) }; var code by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    var uploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableFloatStateOf(0f) }
    var uploadSent by remember { mutableLongStateOf(0L) }
    var uploadTotal by remember { mutableLongStateOf(0L) }
    var uploadKind by remember { mutableStateOf("") }
    var selectedPosterName by remember { mutableStateOf("") }
    var selectedVideoName by remember { mutableStateOf("") }
    var selectedPosterUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var selectedVideoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var uploadWorkId by remember { mutableStateOf<java.util.UUID?>(null) }
    val workManager = remember { WorkManager.getInstance(context) }

    fun secure(action:()->Unit) { pending=action; code=""; codeDialog=true }
    fun load() { scope.launch { loading=true; try { val a=VGhostApi.adminFilms().optJSONArray("films") ?: JSONArray(); rows=(0 until a.length()).map{ val o=a.getJSONObject(it); AdminFilmRow(o.optLong("id"),o.optString("title"),o.optString("category"),if(o.isNull("release_year"))null else o.optInt("release_year"),o.optInt("is_active") == 1 || o.optBoolean("is_active"),o.optInt("is_featured") == 1 || o.optBoolean("is_featured")) }; status="" } catch(e:Throwable){ status=e.message.orEmpty() } finally { loading=false } } }
    LaunchedEffect(Unit){
        load()
        try {
            val a = VGhostApi.filmCategories().optJSONArray("categories") ?: JSONArray()
            val serverCategories = (0 until a.length()).map { a.getString(it) }.filter { it.isNotBlank() }
            if (serverCategories.isNotEmpty()) {
                categories = (serverCategories + categories).distinct()
            }
        } catch (_: Throwable) { }
    }

    LaunchedEffect(showForm, editingId, uploading) {
        if (showForm && editingId > 0L) {
            while (kotlinx.coroutines.currentCoroutineContext().isActive) {
                refreshUploadWork(editingId)
                kotlinx.coroutines.delay(800L)
            }
        }
    }

    fun persistentCopy(uri: android.net.Uri, kind: String): File {
        val dir = File(context.filesDir, "film_uploads").apply { mkdirs() }
        val name = "${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}_${if (kind == "poster") "poster" else "video"}"
        val outFile = File(dir, name)
        context.contentResolver.openInputStream(uri)?.use { input ->
            outFile.outputStream().use { output -> input.copyTo(output, 128 * 1024) }
        } ?: throw IllegalStateException("Fayl oxuna bilmədi")
        return outFile
    }

    suspend fun cancelUploadWithCode(codeValue: String) {
        val info = withContext(Dispatchers.IO) { workManager.getWorkInfosForUniqueWork(FilmUploadWorker.workName(editingId)).get().firstOrNull() }
        val uploadId = info?.progress?.getString(FilmUploadWorker.KEY_UPLOAD_ID).orEmpty()
        if (uploadId.isNotBlank()) VGhostApi.adminFilmUploadCancel(uploadId, codeValue)
        withContext(Dispatchers.IO) { workManager.cancelUniqueWork(FilmUploadWorker.workName(editingId)) }
        runCatching {
            info?.inputData?.getString(FilmUploadWorker.KEY_POSTER_PATH)?.let { File(it).delete() }
            info?.inputData?.getString(FilmUploadWorker.KEY_VIDEO_PATH)?.let { File(it).delete() }
        }
        uploading = false
        uploadWorkId = null
        uploadProgress = 0f
        uploadSent = 0L
        uploadTotal = 0L
        uploadKind = ""
        status = "Yükləmə ləğv edildi"
    }

    suspend fun refreshUploadWork(id: Long) {
        if (id <= 0L) return
        val infos = withContext(Dispatchers.IO) { workManager.getWorkInfosForUniqueWork(FilmUploadWorker.workName(id)).get() }
        val info = infos.firstOrNull() ?: return
        uploadWorkId = info.id
        when (info.state) {
            WorkInfo.State.RUNNING, WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> {
                uploading = true
                val sent = info.progress.getLong(FilmUploadWorker.KEY_SENT, 0L)
                val total = info.progress.getLong(FilmUploadWorker.KEY_TOTAL, 0L)
                uploadSent = sent; uploadTotal = total
                uploadProgress = if (total > 0L) sent.toFloat() / total.toFloat() else 0f
                uploadKind = info.progress.getString(FilmUploadWorker.KEY_KIND).orEmpty().let { if (it == "video") "Video" else if (it == "poster") "Poster" else "" }
                status = if (uploadProgress > 0f) "Yüklənir… ${(uploadProgress * 100).toInt()}%" else "Yükləmə növbədədir…"
            }
            WorkInfo.State.SUCCEEDED -> {
                uploading = false
                uploadProgress = 1f
                uploadSent = uploadTotal
                uploadKind = ""
                status = "Film hazırdır ✓"
            }
            WorkInfo.State.FAILED -> {
                uploading = false
                status = info.outputData.getString(FilmUploadWorker.KEY_ERROR).orEmpty().ifBlank { "UPLOAD_FAILED" }
            }
            WorkInfo.State.CANCELLED -> {
                uploading = false
                status = "Yükləmə ləğv edildi"
            }
        }
    }

    fun mimeFor(kind:String, uri:android.net.Uri):String {
        val actual=context.contentResolver.getType(uri).orEmpty().lowercase()
        if(actual.isNotBlank() && actual!="application/octet-stream") return actual
        val name = runCatching {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if(c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull().orEmpty()
        val ext = name.substringAfterLast('.', "").lowercase()
        return when(ext) {
            "jpg","jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif";
            "bmp" -> "image/bmp"; "heic" -> "image/heic"; "heif" -> "image/heif"; "avif" -> "image/avif";
            "mp4" -> "video/mp4"; "webm" -> "video/webm"; "m4v" -> "video/x-m4v"; "mov" -> "video/quicktime";
            "3gp","3gpp" -> "video/3gpp"; "3g2" -> "video/3gpp2"; "mpeg","mpg" -> "video/mpeg";
            "mkv" -> "video/x-matroska"; "ogv" -> "video/ogg"; "ts","m2ts" -> "video/mp2t"; "flv" -> "video/x-flv";
            else -> if(kind=="poster") "image/jpeg" else "video/mp4"
        }
    }
    fun extensionFor(mime:String, kind:String)=when(mime.lowercase()) {
        "image/png"->"png"; "image/webp"->"webp"; "image/jpeg","image/jpg"->"jpg"; "image/gif"->"gif";
        "image/bmp"->"bmp"; "image/heic"->"heic"; "image/heif"->"heif"; "image/avif"->"avif";
        "video/webm"->"webm"; "video/x-m4v"->"m4v"; "video/quicktime"->"mov"; "video/3gpp"->"3gp";
        "video/3gpp2"->"3g2"; "video/mpeg"->"mpeg"; "video/x-matroska"->"mkv"; "video/ogg"->"ogv";
        "video/mp2t"->"ts"; "video/x-flv"->"flv"; "video/mp4"->"mp4";
        else->if(kind=="poster")"jpg" else "mp4"
    }
    suspend fun uploadFileNow(uri: android.net.Uri, kind: String, security: String): String {
        var temp: File? = null
        try {
            val mime = mimeFor(kind, uri)
            val ext = extensionFor(mime, kind)
            temp = withContext(Dispatchers.IO) {
                val f = File.createTempFile("vghost_film_", ".${ext}", context.cacheDir)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    f.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
                } ?: throw IllegalStateException("Fayl oxuna bilmədi")
                f
            }
            if (kind == "video" && temp.length() > 5L * 1024L * 1024L * 1024L) {
                throw IllegalStateException("Film videosu maksimum 5 GB ola bilər")
            }
            uploadKind = if (kind == "poster") "Poster" else "Video"
            uploadSent = 0L
            uploadTotal = temp.length()
            uploadProgress = 0f
            val result = VGhostApi.adminFilmUpload(editingId, kind, temp, temp.name, mime, security, onProgress = { sent, total ->
                uploadSent = sent
                uploadTotal = total
                uploadProgress = if (total > 0L) (sent.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                status = "${if (kind == "poster") "Poster" else "Video"} yüklənir… ${(uploadProgress * 100).toInt()}%"
            })
            return result.optString("url").ifBlank { throw IllegalStateException("MEDIA_UPLOAD_NO_URL") }
        } finally {
            temp?.delete()
            if (kind == "video" || kind == "poster") {
                if (uploadProgress >= 1f) {
                    uploadSent = uploadTotal
                    uploadProgress = 1f
                }
            }
        }
    }
    val posterPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selectedPosterUri = it; selectedPosterName = it.lastPathSegment?.substringAfterLast('/') ?: "Poster seçildi" }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { selectedVideoUri = it; selectedVideoName = it.lastPathSegment?.substringAfterLast('/') ?: "Video seçildi" }
    }
    fun saveFilm(security: String) {
        scope.launch {
            uploading = true
            uploadProgress = 0f
            uploadSent = 0L
            uploadTotal = 0L
            uploadKind = ""
            try {
                val result = VGhostApi.adminFilmSave(editingId, title, desc, poster, video, category, year.toIntOrNull(), duration.toIntOrNull(), vip, featured, active, 0, security)
                val newId = result.optLong("id", editingId)
                if (newId <= 0L) throw IllegalStateException("Film yaradılmadı")
                editingId = newId

                val posterFile = selectedPosterUri?.let { persistentCopy(it, "poster") }
                val videoFile = selectedVideoUri?.let { persistentCopy(it, "video") }
                val total = (posterFile?.length() ?: 0L) + (videoFile?.length() ?: 0L)
                if (total == 0L) {
                    VGhostApi.adminFilmSave(editingId, title, desc, poster, video, category, year.toIntOrNull(), duration.toIntOrNull(), vip, featured, true, 0, security)
                    uploading = false
                    active = true
                    status = "Film hazırdır ✓"
                    showForm = false
                    load()
                    return@launch
                }

                val input = workDataOf(
                    FilmUploadWorker.KEY_FILM_ID to editingId,
                    FilmUploadWorker.KEY_TITLE to title,
                    FilmUploadWorker.KEY_DESCRIPTION to desc,
                    FilmUploadWorker.KEY_POSTER_URL to poster,
                    FilmUploadWorker.KEY_VIDEO_URL to video,
                    FilmUploadWorker.KEY_CATEGORY to category,
                    FilmUploadWorker.KEY_YEAR to year,
                    FilmUploadWorker.KEY_DURATION to duration,
                    FilmUploadWorker.KEY_VIP to vip,
                    FilmUploadWorker.KEY_FEATURED to featured,
                    FilmUploadWorker.KEY_ACTIVE to active,
                    FilmUploadWorker.KEY_POSTER_PATH to (posterFile?.absolutePath ?: ""),
                    FilmUploadWorker.KEY_VIDEO_PATH to (videoFile?.absolutePath ?: ""),
                    FilmUploadWorker.KEY_POSTER_NAME to (selectedPosterName.ifBlank { posterFile?.name ?: "" }),
                    FilmUploadWorker.KEY_VIDEO_NAME to (selectedVideoName.ifBlank { videoFile?.name ?: "" }),
                    FilmUploadWorker.KEY_POSTER_MIME to (selectedPosterUri?.let { mimeFor("poster", it) } ?: ""),
                    FilmUploadWorker.KEY_VIDEO_MIME to (selectedVideoUri?.let { mimeFor("video", it) } ?: ""),
                    FilmUploadWorker.KEY_SECURITY to VGhostApi.protectForBackground(security)
                )
                val request = OneTimeWorkRequestBuilder<FilmUploadWorker>()
                    .setInputData(input)
                    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build()
                workManager.enqueueUniqueWork(FilmUploadWorker.workName(editingId), androidx.work.ExistingWorkPolicy.REPLACE, request)
                uploadWorkId = request.id
                selectedPosterUri = null
                selectedVideoUri = null
                status = "Yükləmə arxa planda davam edir…"
                // Keep the form visible and lock all controls while WorkManager uploads.
            } catch (e: Throwable) {
                uploading = false
                status = e.message.orEmpty()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF09090D))) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { IconButton(onClick=onBack){Icon(Icons.Filled.ArrowBack,"Back",tint=Color.White)}; Text("FILM ADMIN",color=Color.White,fontSize=21.sp); IconButton(onClick={load()}){Icon(Icons.Filled.Refresh,"Refresh",tint=Color.White)} }
            if(status.isNotBlank()) Text(status,color=if(uploading) Color(0xFFFFD54A) else Color(0xFFD8D8DE),fontSize=11.sp,modifier=Modifier.padding(8.dp))
            Button(onClick={ editingId=0; uploading=false; uploadProgress=0f; uploadSent=0L; uploadTotal=0L; uploadKind=""; title="";desc="";poster="";video="";selectedPosterName="";selectedVideoName="";selectedPosterUri=null;selectedVideoUri=null;category="Drama";categoryMenuOpen=false;year="";duration="";vip=false;featured=false;active=false;showForm=true }, modifier=Modifier.fillMaxWidth()) { Text("+ FILM ƏLAVƏ ET") }
            Spacer(Modifier.height(10.dp))
            if(loading) CircularProgressIndicator(color=Color(0xFFFF1838),modifier=Modifier.padding(20.dp)) else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                items(rows) { row ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF15121A)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    try {
                                        val f = VGhostApi.film(row.id).optJSONObject("film")!!
                                        editingId = row.id
                                        uploading = false
                                        selectedPosterUri = null
                                        selectedVideoUri = null
                                        title = f.optString("title")
                                        desc = f.optString("description")
                                        poster = f.optString("poster_url")
                                        video = f.optString("video_url")
                                        selectedPosterName = if (poster.isNotBlank()) "Serverdəki poster" else ""
                                        selectedVideoName = if (video.isNotBlank()) "Serverdəki video" else ""
                                        category = f.optString("category")
                                        year = if (f.isNull("release_year")) "" else f.optInt("release_year").toString()
                                        duration = if (f.isNull("duration_minutes")) "" else f.optInt("duration_minutes").toString()
                                        vip = f.optInt("is_vip") == 1
                                        featured = f.optInt("is_featured") == 1
                                        active = f.optInt("is_active", 1) == 1
                                        showForm = true
                                    } catch (e: Throwable) {
                                        status = e.message.orEmpty()
                                    }
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(13.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(row.title, color = Color.White)
                                Text(
                                    "${row.category}${row.year?.let { " • $it" } ?: ""}",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                            IconButton(
                                onClick = {
                                    secure {
                                        scope.launch {
                                            try {
                                                VGhostApi.adminFilmDelete(row.id, code)
                                                load()
                                            } catch (e: Throwable) {
                                                status = e.message.orEmpty()
                                            }
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Delete",
                                    tint = Color(0xFFFF4356)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    if(showForm) AlertDialog(
        onDismissRequest={ if(!uploading) showForm=false },
        title={ Text(if(editingId>0) "Filmi düzəlt" else "Yeni film") },
        text={
            Column(Modifier.fillMaxWidth().heightIn(max=620.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedTextField(title,{title=it},label={Text("Başlıq")},enabled=!uploading,singleLine=true,modifier=Modifier.fillMaxWidth())
                Box(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { },
                        label = { Text("Janr") },
                        readOnly = true,
                        enabled = !uploading,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { categoryMenuOpen = true },
                        trailingIcon = {
                            TextButton(enabled=!uploading, onClick = { categoryMenuOpen = !categoryMenuOpen }) {
                                Text(if (categoryMenuOpen) "▲" else "▼")
                            }
                        }
                    )
                    DropdownMenu(
                        expanded = categoryMenuOpen && !uploading,
                        onDismissRequest = { categoryMenuOpen = false },
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        categories.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    category = option
                                    categoryMenuOpen = false
                                }
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedTextField(year,{year=it},label={Text("İl")},enabled=!uploading,singleLine=true,modifier=Modifier.weight(1f))
                    OutlinedTextField(duration,{duration=it},label={Text("Müddət")},enabled=!uploading,singleLine=true,modifier=Modifier.weight(1f))
                }
                OutlinedTextField(desc,{desc=it},label={Text("Açıqlama")},enabled=!uploading,minLines=3,modifier=Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(enabled=!uploading,onClick={posterPicker.launch("image/*")},modifier=Modifier.weight(1f)){
                        Text(if(selectedPosterName.isBlank()) "🖼 Poster" else "✓ Poster",maxLines=1)
                    }
                    OutlinedButton(enabled=!uploading,onClick={videoPicker.launch("video/*")},modifier=Modifier.weight(1f)){
                        Text(if(selectedVideoName.isBlank()) "🎬 Video" else "✓ Video",maxLines=1)
                    }
                }
                if(selectedPosterName.isNotBlank()) Text(selectedPosterName,color=Color(0xFFAAAAB8),fontSize=10.sp)
                if(selectedVideoName.isNotBlank()) Text(selectedVideoName,color=Color(0xFFAAAAB8),fontSize=10.sp)
                if (uploading) {
                    Column(Modifier.fillMaxWidth().padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        val percent = (uploadProgress * 100f).toInt().coerceIn(0, 100)
                        val sentMb = uploadSent / (1024f * 1024f)
                        val totalMb = uploadTotal / (1024f * 1024f)
                        Text(
                            "${uploadKind.ifBlank { "Fayl" }} yüklənir • $percent%",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(18.dp)
                                .background(Color(0xFF3A3740), RoundedCornerShape(9.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(uploadProgress.coerceIn(0f, 1f))
                                    .fillMaxHeight()
                                    .background(Color(0xFFFF1838), RoundedCornerShape(9.dp))
                            )
                            Text(
                                text = "$percent%",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.align(androidx.compose.ui.Alignment.Center)
                            )
                        }
                        Text(
                            if (uploadTotal > 0L) "${String.format(java.util.Locale.US, "%.1f", sentMb)} / ${String.format(java.util.Locale.US, "%.1f", totalMb)} MB" else "Fayl hazırlanır…",
                            color = Color(0xFFBDBAC5),
                            fontSize = 11.sp
                        )
                    }
                }
                Row{
                    Checkbox(checked=vip,onCheckedChange={if(!uploading) vip=it},enabled=!uploading); Text("VIP",modifier=Modifier.padding(top=12.dp))
                    Spacer(Modifier.width(12.dp))
                    Checkbox(checked=featured,onCheckedChange={if(!uploading) featured=it},enabled=!uploading); Text("Featured",modifier=Modifier.padding(top=12.dp))
                }
                Text("Poster və video seç, sonra yalnız bir dəfə təsdiq kodunu daxil et.",color=Color(0xFF9E9EAA),fontSize=10.sp)
            }
        },
        confirmButton={
            Button(enabled=!uploading && title.isNotBlank(),onClick={secure{saveFilm(code)}}){
                Text(if(uploading) "Yüklənir…" else "Yadda saxla")
            }
        },
        dismissButton={TextButton(onClick={ if (uploading) secure { scope.launch { cancelUploadWithCode(code) } } else showForm=false }){Text("Ləğv et")}}
    )
    if(codeDialog) AlertDialog(
        onDismissRequest={codeDialog=false},
        title={Text("Admin kodu")},
        text={OutlinedTextField(code,{code=it},label={Text("Təsdiq kodu")},visualTransformation=PasswordVisualTransformation(),singleLine=true)},
        confirmButton={Button(onClick={val action=pending;codeDialog=false;action?.invoke()}){Text("Başla")}},
        dismissButton={TextButton(onClick={codeDialog=false}){Text("Ləğv et")}}
    )
}
