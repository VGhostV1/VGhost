package com.vghost.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Fast poster/thumbnail cache: memory first, then disk, then network. */
object FilmMediaCache {
    private val memory = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    private fun key(url: String): String = MessageDigest.getInstance("MD5")
        .digest(url.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    private fun file(context: Context, url: String): File =
        File(context.cacheDir, "film_poster_${key(url)}.img")

    fun getMemory(url: String): Bitmap? = synchronized(memory) { memory.get(url) }

    suspend fun load(context: Context, url: String, authToken: String?): Bitmap? {
        if (url.isBlank()) return null
        getMemory(url)?.let { return it }
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val f = file(context, url)
            var bitmap = decode(f)
            if (bitmap == null) {
                runCatching {
                    val c = (URL(url).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3500
                        readTimeout = 7000
                        instanceFollowRedirects = true
                        requestMethod = "GET"
                        setRequestProperty("Accept", "image/avif,image/webp,image/jpeg,image/png,*/*;q=0.8")
                        setRequestProperty("User-Agent", "VGhost-Android/1.2")
                        setRequestProperty("X-VGhost-Client", "android")
                        if (!authToken.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $authToken")
                    }
                    try {
                        if (c.responseCode !in 200..299) return@runCatching
                        f.outputStream().use { out -> c.inputStream.use { input -> input.copyTo(out, 32 * 1024) } }
                        bitmap = decode(f)
                    } finally { c.disconnect() }
                }
            }
            bitmap?.let {
                synchronized(memory) { memory.put(url, it) }
                f.setLastModified(System.currentTimeMillis())
            }
            bitmap
        }
    }

    private fun decode(file: File): Bitmap? {
        if (!file.exists() || file.length() < 64L) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val maxDim = 640
        var sample = 1
        while (bounds.outWidth / sample > maxDim || bounds.outHeight / sample > maxDim) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 })
    }
}
