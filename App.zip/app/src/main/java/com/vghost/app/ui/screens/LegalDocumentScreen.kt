package com.vghost.app.ui.screens
import com.vghost.app.i18n.trKey

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.*

enum class LegalDocument { PRIVACY_POLICY, TERMS }

@Composable
fun LegalDocumentScreen(document: LegalDocument, onBack: () -> Unit) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val localPrivacy = if (document == LegalDocument.PRIVACY_POLICY) VGhostLocalPrivacyPolicy.get(context) else null
    val title = localPrivacy?.title ?: trKey("terms_conditions")
    val sections = localPrivacy?.let { listOf(it.intro.let { intro -> trKey("privacy_policy") to intro }) + it.sections.map { section -> section.title to section.body } } ?: termsSections()

    Scaffold(modifier = Modifier.fillMaxSize().premiumBackdrop(), containerColor = Color.Transparent) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(GhostSurface.copy(alpha = .78f))
                        .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.ArrowBack, trKey("back"), tint = GhostTextWhite) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = GhostTextWhite, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Text(trKey("legal_last_updated"), color = GhostTextMuted, fontSize = 10.sp)
                }
            }

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 20.dp)
            ) {
                sections.forEach { (heading, body) ->
                    Text(heading, color = GhostTextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(body, color = GhostTextSecondary, fontSize = 13.sp, lineHeight = 19.sp)
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

private fun termsSections() = listOf(
    trKey("acceptance") to trKey("completing_registration_confirm_have_read_accepted_these_terms_conditions"),
    trKey("account") to trKey("account_terms_body"),
    trKey("ghost_coins_2") to trKey("virtual_currency_terms_body"),
    trKey("prohibited_use") to trKey("user_content_terms_body"),
    trKey("privacy_policy") to trKey("privacy_terms_body"),
    trKey("service_availability") to trKey("service_terms_body"),
    trKey("account_suspension_deletion") to trKey("suspension_terms_body"),
    trKey("changes_rules") to trKey("changes_terms_body"),
    trKey("legal_disclaimer") to trKey("legal_terms_body")
)
