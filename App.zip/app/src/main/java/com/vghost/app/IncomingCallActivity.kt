package com.vghost.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.OnBackPressedCallback
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Color
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.screens.WebRtcIncomingCallScreen

/** Standalone incoming-call surface. It intentionally bypasses MainActivity/PIN
 * navigation so a call can be answered even when the app is not open. */
class IncomingCallActivity : ComponentActivity() {
    private var callId: Long = 0L
    private var callerName: String = "VGHOST"
    private var callType: String = "voice"
    private var isTest: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD)

        callId = intent.getLongExtra(EXTRA_CALL_ID, 0L)
        callerName = intent.getStringExtra(EXTRA_CALLER_NAME).orEmpty().ifBlank { "VGHOST" }
        callType = intent.getStringExtra(EXTRA_CALL_TYPE).orEmpty().ifBlank { "voice" }
        isTest = intent.getBooleanExtra(EXTRA_IS_TEST, false)
        if (callId < 1L || callType !in setOf("voice", "video")) {
            finish()
            return
        }
        // FCM can cold-start this activity without MainActivity ever running.
        // Initialize the API/session layer before Accept/Reject/status polling.
        VGhostRepository.instance.initialize(applicationContext)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* explicit Accept / Reject only */ }
        })

        lifecycleScope.launch {
            while (!isFinishing && !isDestroyed) {
                delay(900L)
                try {
                    val r = VGhostApi.call("call/signals?call_id=$callId&after=0&peer=app")
                    val status = r.optString("status")
                    if (status in listOf("accepted", "ended", "rejected", "missed", "cancelled")) {
                        CallNotificationHelper.cancel(this@IncomingCallActivity, callId)
                        finish()
                        break
                    }
                } catch (_: Throwable) { }
            }
        }

        setContent {
            Surface(color = Color(0xFF07080D)) {
                WebRtcIncomingCallScreen(
                    callId = callId,
                    callerName = callerName,
                    callType = callType,
                    isTest = isTest,
                    onReject = { rejectCall() },
                    onAccept = { acceptCall() }
                )
            }
        }
    }

    private suspend fun rejectCall(): Boolean {
        var rejected = false
        repeat(3) {
            if (rejected) return@repeat
            try {
                VGhostApi.call("call/reject", "POST", org.json.JSONObject().put("call_id", callId))
                rejected = true
            } catch (_: Throwable) {
                delay(250L)
            }
        }
        // Always close the local ringing surface. A successful backend reject
        // makes the call terminal; if the network is temporarily unavailable,
        // the server-side 2-minute expiry is the final safety net.
        CallNotificationHelper.cancel(this, callId)
        finish()
        return true
    }

    private suspend fun acceptCall(): Boolean {
        return try {
            VGhostApi.call("call/accept", "POST", org.json.JSONObject().put("call_id", callId))
            CallNotificationHelper.cancel(this, callId)
            startActivity(WebRtcCallActivity.intent(this, callId, callType, callerName, false))
            finish()
            true
        } catch (_: Throwable) {
            false
        }
    }

    companion object {
        private const val EXTRA_CALL_ID = "vghost_call_id"
        private const val EXTRA_CALLER_NAME = "vghost_caller_name"
        private const val EXTRA_CALL_TYPE = "vghost_call_type"
        private const val EXTRA_IS_TEST = "vghost_is_test"

        fun intent(context: Context, callId: Long, callerName: String, callType: String, isTest: Boolean): Intent =
            Intent(context, IncomingCallActivity::class.java).apply {
                putExtra(EXTRA_CALL_ID, callId)
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_CALL_TYPE, callType)
                putExtra(EXTRA_IS_TEST, isTest)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
    }
}
