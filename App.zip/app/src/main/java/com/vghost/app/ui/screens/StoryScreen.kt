package com.vghost.app.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.media.MediaMetadataRetriever
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.vghost.app.i18n.tr
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostGoldText
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostTextWhite
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

private data class StoryItem(
    val id: Long, val userId: Long, val nickname: String, val avatarUrl: String, val avatarId: String, val mediaUrl: String,
    val mediaType: String, val createdAt: String, val expiresAt: String, val visibility: String,
    val caption: String, val views: Int, val likes: Int, val comments: Int,
    val liked: Boolean, val seen: Boolean, val followed: Boolean
)
private data class StoryComment(val id: Long, val userId: Long, val nickname: String, val comment: String, val createdAt: String, val parentCommentId: Long? = null)

@Composable
fun StoryScreen(
    onBack: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    onOpenProfile: (uid: Long, nickname: String) -> Unit,
    initialStoryId: Long = 0L,
    onOpenRegister: () -> Unit = {},
    isVisible: Boolean = true
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val guestMode by VGhostRepository.instance.guestMode.collectAsState()
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var currentUserId by remember { mutableLongStateOf(0L) }
    var currentNickname by remember { mutableStateOf("") }
    var commentStory by remember { mutableStateOf<StoryItem?>(null) }
    var commentText by remember { mutableStateOf("") }
    var replyComment by remember { mutableStateOf<StoryComment?>(null) }
    var comments by remember { mutableStateOf<List<StoryComment>>(emptyList()) }
    var commentsLoading by remember { mutableStateOf(false) }
    var commentError by remember { mutableStateOf<String?>(null) }
    var deleteStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewersStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewers by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    var viewerLoading by remember { mutableStateOf(false) }
    var reportStory by remember { mutableStateOf<StoryItem?>(null) }
    var reportReason by remember { mutableStateOf("") }
    var menuStory by remember { mutableStateOf<StoryItem?>(null) }
    var blockStory by remember { mutableStateOf<StoryItem?>(null) }
    var giftStory by remember { mutableStateOf<StoryItem?>(null) }
    var giftSending by remember { mutableStateOf(false) }
    var createDialog by remember { mutableStateOf(false) }
    var createCaption by remember { mutableStateOf("") }
    var createVisibility by remember { mutableStateOf("all") }
    var selectedMediaUri by remember { mutableStateOf<Uri?>(null) }
    var selectedMediaMime by remember { mutableStateOf("") }
    var mediaUploading by remember { mutableStateOf(false) }
    var mediaUploadProgress by remember { mutableFloatStateOf(0f) }
    var mediaUploadSent by remember { mutableLongStateOf(0L) }
    var mediaUploadTotal by remember { mutableLongStateOf(0L) }
    var initialPositionApplied by remember { mutableStateOf(false) }
    var showGuestRegisterNotice by remember { mutableStateOf(false) }
    // If an authenticated session expires while the user is on Reels, continue as a
    // public/guest viewer instead of leaving a permanent UNAUTHORIZED screen.
    var sessionGuestFallback by remember { mutableStateOf(false) }
    val effectiveGuest = guestMode || sessionGuestFallback

    fun parseStories(json: org.json.JSONObject): List<StoryItem> {
        val arr = json.optJSONArray("stories") ?: org.json.JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            StoryItem(o.optLong("id"), o.optLong("userId"), o.optString("nickname"), VGhostApi.publicUrl(o.optString("avatarUrl")), o.optString("avatarId","ghost"), VGhostApi.publicUrl(o.optString("mediaUrl")),
                o.optString("mediaType"), o.optString("createdAt"), o.optString("expiresAt"), o.optString("visibility", "all"), o.optString("caption"),
                o.optInt("views"), o.optInt("likes"), o.optInt("comments"), o.optBoolean("liked"), o.optBoolean("seen"), o.optBoolean("followed"))
        }
    }
    fun reload(silent: Boolean = false) {
        scope.launch {
            if (!silent) loading = true
            error = null
            try {
                if (guestMode || sessionGuestFallback) {
                    currentUserId = 0L
                    currentNickname = ""
                    stories = parseStories(VGhostApi.publicStories())
                } else {
                    try {
                        val me = VGhostApi.me(); sessionGuestFallback = false; currentUserId = me.optJSONObject("user")?.optLong("id") ?: 0L
                        currentNickname = me.optJSONObject("user")?.optString("nickname", "")?.trim() ?: ""
                        stories = parseStories(VGhostApi.stories())
                    } catch (auth: Throwable) {
                        // A stale/expired token must not make public Reels disappear.
                        if ((auth.message ?: "").contains("401") || (auth.message ?: "").contains("UNAUTHORIZED", true)) {
                            sessionGuestFallback = true
                            currentUserId = 0L
                            currentNickname = ""
                            stories = parseStories(VGhostApi.publicStories())
                        } else throw auth
                    }
                }
            } catch (e: Throwable) {
                // A background refresh must never cover an already playable Story with
                // a red error banner. Keep the previous feed and retry on the next tick.
                if (!silent) error = e.message ?: tr("Story yüklənmədi")
            } finally { if (!silent) loading = false }
        }
    }
    fun loadComments(story: StoryItem) {
        commentStory = story; commentText = ""; replyComment = null; commentError = null; commentsLoading = true
        scope.launch { try { val a=VGhostApi.storyComments(story.id).optJSONArray("comments") ?: org.json.JSONArray(); comments=(0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { StoryComment(it.optLong("id"),it.optLong("userId"),it.optString("nickname"),it.optString("comment"),it.optString("createdAt"),it.optLong("parentCommentId").takeIf { v -> v > 0 }) } } } catch(e:Throwable){comments=emptyList();commentError=e.message?:tr("Şərhlər yüklənmədi")} finally{commentsLoading=false} }
    }
    fun submitComment() {
        val story=commentStory ?: return; val text=commentText.trim(); if(text.isBlank()) return
        val parentId = replyComment?.id
        scope.launch { try { VGhostApi.commentStory(story.id,text,parentId); commentText=""; replyComment=null; loadComments(story); reload() } catch(e:Throwable){commentError=e.message?:tr("Şərh göndərilmədi")} }
    }
    fun requestGuestRegistration() { showGuestRegisterNotice = true }

    fun openProfile(story: StoryItem) {
        if (effectiveGuest) { requestGuestRegistration(); return }
        val mine=story.userId==currentUserId || (currentNickname.isNotBlank() && story.nickname.equals(currentNickname,true))
        if(mine) onTabSelected(NavTab.PROFILE) else onOpenProfile(story.userId,story.nickname)
    }
    fun loadViewers(story: StoryItem) {
        viewersStory=story; viewerLoading=true; viewers=emptyList()
        scope.launch { try { val a=VGhostApi.storyViewers(story.id).optJSONArray("viewers") ?: org.json.JSONArray(); viewers=(0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { it.optString("nickname") to it.optString("viewedAt") } } } catch(e:Throwable){error=e.message?:tr("Baxışlar yüklənmədi")} finally{viewerLoading=false} }
    }
    LaunchedEffect(guestMode, isVisible) {
        // Navigation keeps the Story destination alive in the back stack.
        // Reload immediately when it becomes visible again so the first frame/player
        // is rebuilt from a fresh Story state instead of showing a black paused surface.
        if (isVisible) reload()
        while (isVisible) {
            kotlinx.coroutines.delay(5_000L)
            if (isVisible) reload(silent = true)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val mime = context.contentResolver.getType(uri).orEmpty()
        if (!(mime.startsWith("video/") || mime.startsWith("image/"))) {
            error = tr("Video və ya şəkil seçin")
            return@rememberLauncherForActivityResult
        }
        selectedMediaUri = uri
        selectedMediaMime = mime
        error = null
    }

    fun uploadSelectedMedia() {
        val uri = selectedMediaUri ?: return
        if (mediaUploading) return
        scope.launch {
            mediaUploading = true
            mediaUploadProgress = 0f
            mediaUploadSent = 0L
            mediaUploadTotal = 0L
            try {
                val bytes = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                }
                if (bytes.isEmpty()) throw IllegalStateException(tr("Fayl boşdur"))
                if (bytes.size > 30 * 1024 * 1024) throw IllegalStateException(tr("Fayl çox böyükdür (maks. 30 MB)"))
                val mime = selectedMediaMime.ifBlank { context.contentResolver.getType(uri).orEmpty() }
                if (!(mime.startsWith("video/") || mime.startsWith("image/"))) throw IllegalStateException(tr("Video və ya şəkil seçin"))
                val ext = when (mime) {
                    "video/webm" -> "webm"
                    "image/png" -> "png"
                    "image/webp" -> "webp"
                    "image/jpeg" -> "jpg"
                    else -> if (mime.startsWith("image/")) "jpg" else "mp4"
                }
                mediaUploadTotal = bytes.size.toLong()
                VGhostApi.createStory(
                    "story_${System.currentTimeMillis()}.$ext",
                    bytes, mime, createVisibility, createCaption
                ) { sent, total ->
                    mediaUploadSent = sent
                    mediaUploadTotal = total
                    mediaUploadProgress = if (total > 0L) (sent.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                }
                createDialog = false
                createCaption = ""
                selectedMediaUri = null
                selectedMediaMime = ""
                reload()
            } catch (e: Throwable) {
                error = e.message ?: tr("Story yüklənmədi")
            } finally {
                mediaUploading = false
                if (mediaUploadProgress >= 1f) {
                    mediaUploadSent = mediaUploadTotal
                }
            }
        }
    }
    val visibleStories = stories

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF090305), GhostBlack, GhostBlack))
        )
    ) {
        Row(
            Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.statusBars)
                .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(tr("Status"), color = GhostTextWhite, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    visibleStories.distinctBy { it.userId }.take(3).forEach { profileStory ->
                        StoryTopAvatar(
                            story = profileStory,
                            onClick = { openProfile(profileStory) }
                        )
                    }
                }
                Box(Modifier.width(38.dp).height(3.dp).background(GhostRedPrimary).padding(top = 3.dp))
            }
            if (!effectiveGuest) {
                Box(
                    Modifier.size(43.dp).clip(CircleShape).border(2.dp, GhostRedPrimary, CircleShape)
                        .clickable { createDialog = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.AddAPhoto, tr("Status əlavə et"), tint = GhostTextWhite, modifier = Modifier.size(25.dp))
                }
            }
        }

        error?.let { Text(it, color = GhostRedPrimary, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp)) }

        when {
            loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = GhostRedPrimary)
            }
            visibleStories.isEmpty() -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.AddAPhoto, null, tint = GhostRedPrimary, modifier = Modifier.size(72.dp))
                    Text(tr("Status paylaş"), color = GhostTextWhite, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(tr("Bu bölmədə hələ paylaşım yoxdur."), color = Color(0xFFA7B0C9), fontSize = 14.sp)
                    if (!effectiveGuest) Spacer(Modifier.height(22.dp))
                    if (!effectiveGuest) Button(
                        onClick = { createDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary),
                        shape = RoundedCornerShape(30.dp),
                        modifier = Modifier.fillMaxWidth(.72f).height(56.dp)
                    ) {
                        Icon(Icons.Outlined.AddAPhoto, null)
                        Spacer(Modifier.width(10.dp))
                        Text(tr("Status əlavə et"), fontSize = 16.sp)
                    }
                }
            }
            else -> {
                val pagerState = rememberPagerState(pageCount = { visibleStories.size })
                LaunchedEffect(visibleStories) {
                    if (!initialPositionApplied) {
                        val target = if (initialStoryId > 0L) visibleStories.indexOfFirst { it.id == initialStoryId } else 0
                        if (target >= 0 && target < visibleStories.size) pagerState.scrollToPage(target)
                        initialPositionApplied = true
                    }
                }
                LaunchedEffect(pagerState.currentPage, visibleStories) {
                    visibleStories.getOrNull(pagerState.currentPage)?.let { current ->
                        if (effectiveGuest) {
                            val result = runCatching { VGhostApi.guestStoryView(current.id) }.getOrNull()
                            val newView = result?.optBoolean("newView", true) ?: false
                            stories = stories.map { if (it.id == current.id) it.copy(seen = true, views = if (newView) it.views + 1 else it.views) else it }
                        } else if (current.userId != currentUserId && !current.seen) {
                            val result = runCatching { VGhostApi.viewStory(current.id) }.getOrNull()
                            val newView = result?.optBoolean("newView", false) ?: false
                            stories = stories.map { if (it.id == current.id) it.copy(seen = true, views = if (newView) it.views + 1 else it.views) else it }
                        }
                    }
                }
                VerticalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) { page ->
                    val current = visibleStories.getOrNull(page) ?: return@VerticalPager
                    Box(Modifier.fillMaxSize().background(Color.Black)) {
                        key("story-media-${current.id}-${isVisible}") {
                            StoryMedia(current, autoPlayVideo = isVisible && page == pagerState.currentPage, fullscreen = true)
                        }

                        // Reels actions stay anchored to the bottom and stack upward,
                        // matching the creator name area instead of floating in the middle.
                        Column(
                            Modifier.align(Alignment.BottomEnd)
                                .padding(end = 10.dp, bottom = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            StoryReelsAction(
                                icon = if (current.liked) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                                count = current.likes,
                                tint = if (current.liked) GhostRedPrimary else GhostRedPrimary.copy(alpha = .95f),
                                label = tr("Like"),
                                onClick = {
                                    if (effectiveGuest) requestGuestRegistration() else scope.launch {
                                        runCatching { VGhostApi.likeStory(current.id) }
                                        reload(silent = true)
                                    }
                                }
                            )
                            Spacer(Modifier.height(16.dp))
                            StoryReelsAction(
                                icon = Icons.Outlined.ChatBubbleOutline,
                                count = current.comments,
                                tint = Color(0xFFE66CFF),
                                label = tr("Comment"),
                                onClick = { if (effectiveGuest) requestGuestRegistration() else loadComments(current) }
                            )
                            Spacer(Modifier.height(16.dp))
                            StoryReelsAction(
                                icon = Icons.Outlined.Visibility,
                                count = current.views,
                                tint = Color(0xFF7BE7FF),
                                label = tr("Baxış"),
                                onClick = { if (!effectiveGuest && current.userId == currentUserId) loadViewers(current) }
                            )
                            Spacer(Modifier.height(16.dp))
                            // Tək ••• menyu düyməsi: əlavə/ikinci nöqtə yaratmır.
                            Box(
                                modifier = Modifier
                                    .size(58.dp)
                                    .clip(CircleShape)
                                    .background(GhostRedPrimary.copy(alpha = .10f))
                                    .border(2.dp, GhostRedPrimary.copy(alpha = .72f), CircleShape)
                                    .clickable { if (effectiveGuest) requestGuestRegistration() else menuStory = current },
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    Modifier.size(54.dp).clip(CircleShape)
                                        .background(Color.Black.copy(alpha = .52f))
                                        .border(1.dp, GhostRedPrimary.copy(alpha = .50f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.MoreVert,
                                        contentDescription = tr("Seçimlər"),
                                        tint = Color.White,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                            }
                        }

                        Column(
                            Modifier.align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(start = 18.dp, end = 92.dp, bottom = 6.dp, top = 0.dp)
                        ) {
                            Text(
                                "@${current.nickname}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                modifier = Modifier.clickable { openProfile(current) }
                            )
                            if (current.caption.isNotBlank()) {
                                Spacer(Modifier.height(5.dp))
                                Text(current.caption, color = Color.White.copy(alpha = .95f), fontSize = 14.sp, maxLines = 4)
                            }
                        }
                    }
                }
            }
        }

        VGhostBottomNavBar(
            currentTab = NavTab.STORY,
            onTabSelected = onTabSelected,
            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
        )
    }

    if (showGuestRegisterNotice) {
        AlertDialog(
            onDismissRequest = { showGuestRegisterNotice = false },
            title = { Text(tr("Qeydiyyat"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    tr("Bu funksiyadan istifadə etmək üçün qeydiyyatdan keçin."),
                    color = GhostTextWhite.copy(alpha = .82f)
                )
            },
            confirmButton = {
                TextButton(onClick = { showGuestRegisterNotice = false }) {
                    Text(tr("Geri"), color = GhostTextWhite, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF13080D),
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (createDialog) {
        Dialog(onDismissRequest = { createDialog = false }) {
            Surface(color = Color(0xFF13080D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(.94f)) {
                Column(Modifier.padding(18.dp)) {
                    Text(tr("Status yarat"), color = GhostTextWhite, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Text(tr("Kim görə bilər?"), color = GhostTextWhite.copy(alpha = .7f))
                    Row {
                        FilterButton(tr("Hamı"), createVisibility == "all") { createVisibility = "all" }
                        Spacer(Modifier.width(8.dp))
                        FilterButton(tr("Dostlar"), createVisibility == "friends") { createVisibility = "friends" }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = createCaption, onValueChange = { createCaption = it.take(500) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tr("Caption yaz...")) }, maxLines = 3)
                    Spacer(Modifier.height(12.dp))
                    selectedMediaUri?.let { uri ->
                        StoryCreatePreview(uri, selectedMediaMime)
                        Spacer(Modifier.height(10.dp))
                    }
                    Button(
                        onClick = { picker.launch(arrayOf("video/*", "image/*")) },
                        modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                    ) {
                        Icon(Icons.Outlined.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text(if (selectedMediaUri == null) tr("Video və ya şəkil seç") else tr("Başqa media seç"))
                    }
                    if (selectedMediaUri != null) {
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = { uploadSelectedMedia() },
                            enabled = !mediaUploading,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                        ) {
                            if (mediaUploading) {
                                CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text(tr("Paylaşılır…"))
                            } else {
                                Icon(Icons.Outlined.Send, null); Spacer(Modifier.width(8.dp)); Text(tr("İndi paylaş"))
                            }
                        }
                        if (mediaUploading) {
                            Spacer(Modifier.height(6.dp))
                            Column(Modifier.fillMaxWidth()) {
                                Box(
                                    Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(GhostRedPrimary.copy(alpha = .12f))
                                        .border(1.dp, GhostRedPrimary.copy(alpha = .45f), RoundedCornerShape(50))
                                ) {
                                    Box(
                                        Modifier.fillMaxWidth(mediaUploadProgress.coerceIn(0f, 1f)).fillMaxHeight()
                                            .clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(GhostRedPrimary.copy(alpha = .55f), GhostRedPrimary)))
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                val percent = (mediaUploadProgress * 100f).toInt().coerceIn(0, 100)
                                val totalMb = mediaUploadTotal / (1024f * 1024f)
                                val sentMb = mediaUploadSent / (1024f * 1024f)
                                Text(
                                    if (mediaUploadTotal > 0L) "${percent}% • ${String.format(Locale.US, "%.1f", sentMb)} / ${String.format(Locale.US, "%.1f", totalMb)} MB" else "0% • ${tr("Yüklənir...")}",
                                    color = GhostTextWhite.copy(alpha = .72f), fontSize = 11.sp, modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = { createDialog = false; selectedMediaUri = null; selectedMediaMime = "" }, modifier = Modifier.align(Alignment.End)) { Text(tr("Cancel")) }
                }
            }
        }
    }

    deleteStory?.let { story ->
        AlertDialog(
            onDismissRequest = { deleteStory = null },
            title = { Text(tr("Story-ni sil"), color = GhostTextWhite) },
            text = { Text(tr("Bu Story-ni silmək istəyirsən?"), color = GhostTextWhite.copy(alpha = .82f)) },
            confirmButton = { TextButton(onClick = { scope.launch { try { VGhostApi.deleteStory(story.id); deleteStory = null; reload() } catch (e: Throwable) { deleteStory = null; error = e.message ?: tr("Story silinmədi") } } }) { Text(tr("Sil"), color = GhostRedPrimary) } },
            dismissButton = { TextButton(onClick = { deleteStory = null }) { Text(tr("Cancel"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    viewersStory?.let { story ->
        Dialog(onDismissRequest = { viewersStory = null }) {
            Surface(color = Color(0xFF13080D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(.94f)) {
                Column(Modifier.padding(18.dp)) {
                    Text(tr("Baxışlar"), color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    when {
                        viewerLoading -> CircularProgressIndicator(color = GhostRedPrimary)
                        viewers.isEmpty() -> Text(tr("Hələ baxış yoxdur."), color = GhostTextWhite.copy(alpha = .65f))
                        else -> LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(viewers) { pair ->
                                Text("@${pair.first}", color = GhostTextWhite, fontWeight = FontWeight.Bold)
                                Text(pair.second, color = GhostTextWhite.copy(alpha = .45f), fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                    TextButton(onClick = { viewersStory = null }, modifier = Modifier.align(Alignment.End)) { Text(tr("Close")) }
                }
            }
        }
    }

    menuStory?.let { story ->
        AlertDialog(
            onDismissRequest = { menuStory = null },
            title = { Text(tr("Seçimlər"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (story.userId == currentUserId) {
                        TextButton(
                            onClick = { menuStory = null; deleteStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(tr("Sil"), color = GhostRedPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                    } else {
                        TextButton(
                            onClick = { menuStory = null; scope.launch { runCatching { VGhostApi.followStoryUser(story.userId) }; reload(silent = true) } },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (story.followed) tr("Story izləməsini dayandır") else tr("Story-ləri izlə"), color = GhostTextWhite, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton(
                            onClick = { menuStory = null; giftStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(tr("Hədiyyə göndər"), color = GhostGoldText, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton(
                            onClick = { menuStory = null; reportReason = ""; reportStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(tr("Şikayət et"), color = GhostTextWhite, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton(
                            onClick = { menuStory = null; blockStory = story },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(tr("Blokla"), color = GhostRedPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuStory = null }) { Text(tr("Bağla"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    giftStory?.let { story ->
        AlertDialog(
            onDismissRequest = { if (!giftSending) giftStory = null },
            title = { Text(tr("Story-yə hədiyyə"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    GiftCatalog.items.take(8).forEach { gift ->
                        TextButton(
                            enabled = !giftSending,
                            onClick = {
                                giftSending = true
                                scope.launch {
                                    try {
                                        val err = VGhostRepository.instance.giftStory(story.id, gift.id)
                                        if (err != null) { error = err } else { giftStory = null; reload(silent = true) }
                                    } catch (e: Throwable) { error = e.message ?: tr("Hədiyyə göndərilmədi") }
                                    finally { giftSending = false }
                                }
                            }, modifier = Modifier.fillMaxWidth()
                        ) { Text("${gift.icon}  ${gift.name} — ${gift.price} Coin", color = GhostTextWhite) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(enabled = !giftSending, onClick = { giftStory = null }) { Text(tr("Bağla"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    blockStory?.let { story ->
        AlertDialog(
            onDismissRequest = { blockStory = null },
            title = { Text(tr("Blokla"), color = GhostTextWhite) },
            text = { Text("@${story.nickname} istifadəçisini bloklamaq istəyirsən?", color = GhostTextWhite.copy(alpha = .82f)) },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        try {
                            VGhostApi.addBlock(story.userId)
                            blockStory = null
                            reload()
                        } catch (e: Throwable) {
                            blockStory = null
                            error = e.message ?: tr("Bloklama alınmadı")
                        }
                    }
                }) { Text(tr("Blokla"), color = GhostRedPrimary) }
            },
            dismissButton = { TextButton(onClick = { blockStory = null }) { Text(tr("Cancel"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    reportStory?.let { story ->
        AlertDialog(
            onDismissRequest = { reportStory = null },
            title = { Text(tr("Şikayət et"), color = GhostTextWhite) },
            text = {
                OutlinedTextField(
                    value = reportReason,
                    onValueChange = { reportReason = it.take(255) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(tr("Səbəb...")) }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        try {
                            VGhostApi.reportStory(story.id, reportReason.ifBlank { "Inappropriate content" })
                            reportStory = null
                        } catch (e: Throwable) {
                            error = e.message ?: tr("Şikayət göndərilmədi")
                            reportStory = null
                        }
                    }
                }) { Text(tr("Göndər"), color = GhostRedPrimary) }
            },
            dismissButton = { TextButton(onClick = { reportStory = null }) { Text(tr("Cancel"), color = GhostTextWhite) } },
            containerColor = Color(0xFF13080D)
        )
    }

    commentStory?.let { story ->
        Dialog(onDismissRequest = { commentStory = null; replyComment = null }) {
            Surface(color = Color(0xFF13080D), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(.94f)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SeenAvatar(story); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(tr("Şərhlər"), color = GhostTextWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text("@${story.nickname}", color = GhostTextWhite.copy(alpha = .55f), fontSize = 12.sp) }
                        IconButton(onClick = { commentStory = null }) { Icon(Icons.Outlined.Close, tr("Bağla"), tint = GhostTextWhite) }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (commentsLoading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = GhostRedPrimary)
                    commentError?.let { Text(it, color = GhostRedPrimary, fontSize = 12.sp) }
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(comments, key = { it.id }) { c ->
                            Column(Modifier.fillMaxWidth().padding(start = if (c.parentCommentId != null) 18.dp else 0.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .05f)).padding(10.dp)) {
                                if (c.parentCommentId != null) {
                                    val parent = comments.firstOrNull { it.id == c.parentCommentId }
                                    Text(if (parent != null) "↩ @${parent.nickname}" else "↩ Yanıt", color = GhostGoldText.copy(alpha = .9f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(2.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("@${c.nickname}", color = GhostTextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp); Spacer(Modifier.weight(1f))
                                    TextButton(onClick = { replyComment = c; commentText = "" }) { Text(tr("Yanıtla"), color = GhostTextWhite, fontSize = 11.sp) }
                                    if (c.userId == currentUserId || story.userId == currentUserId) TextButton(onClick = { scope.launch { runCatching { VGhostApi.deleteStoryComment(c.id) }; loadComments(story); reload() } }) { Text(tr("Sil"), color = GhostRedPrimary, fontSize = 11.sp) }
                                }
                                Text(c.comment, color = GhostTextWhite.copy(alpha = .86f), fontSize = 14.sp)
                            }
                        }
                    }
                    replyComment?.let { target ->
                        Surface(color = GhostSurface, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("↩ @${target.nickname}", color = GhostGoldText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(target.comment, color = GhostTextWhite.copy(alpha = .7f), fontSize = 12.sp, maxLines = 1)
                                }
                                IconButton(onClick = { replyComment = null }) { Icon(Icons.Outlined.Close, tr("Bağla"), tint = GhostTextWhite) }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = commentText, onValueChange = { commentText = it.take(500) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tr("Şərh yaz...")) }, maxLines = 4, keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { submitComment() }), trailingIcon = { IconButton(enabled = commentText.trim().isNotEmpty(), onClick = { submitComment() }) { Icon(Icons.Outlined.Send, tr("Şərhi paylaş"), tint = if (commentText.trim().isNotEmpty()) GhostRedPrimary else GhostTextWhite.copy(alpha = .3f)) } })
                }
            }
        }
    }
}

@Composable
private fun StoryCreatePreview(uri: Uri, mime: String) {
    val context = LocalContext.current
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        if (mime.startsWith("image/")) {
            var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
            LaunchedEffect(uri) { bitmap = withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } } }
            bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        } else {
            val player = remember(uri) {
                androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
                    setMediaItem(androidx.media3.common.MediaItem.fromUri(uri))
                    repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                    playWhenReady = true
                    prepare()
                }
            }
            DisposableEffect(player) {
                onDispose {
                    runCatching { player.stop() }
                    runCatching { player.release() }
                }
            }
            AndroidView(
                factory = { ctx ->
                    androidx.media3.ui.PlayerView(ctx).apply {
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        this.player = player
                    }
                },
                update = { it.player = player },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable private fun StoryFilterChip(title:String,selected:Boolean,modifier:Modifier=Modifier,onClick:()->Unit){Box(modifier.clip(RoundedCornerShape(30.dp)).background(if(selected)GhostRedPrimary else Color.Transparent).clickable(onClick=onClick).padding(vertical=11.dp),contentAlignment=Alignment.Center){Text(title,color=if(selected)Color.White else Color(0xFFA7B0C9),fontSize=15.sp,fontWeight=if(selected)FontWeight.Bold else FontWeight.Medium)}}
@Composable private fun FilterButton(title:String,selected:Boolean,onClick:()->Unit){TextButton(onClick=onClick){Text(title,color=if(selected)GhostRedPrimary else GhostTextWhite)}}
@Composable
private fun StoryReelsAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Int?,
    tint: Color,
    label: String,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Neon/glow-like double ring around every action.
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = .10f))
                .border(2.dp, tint.copy(alpha = .48f), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(54.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = .52f))
                    .border(1.dp, tint.copy(alpha = .72f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, label, tint = tint, modifier = Modifier.size(34.dp))
            }
        }
        count?.let { value ->
            Spacer(Modifier.height(3.dp))
            // Small dark round card keeps the number readable on bright videos.
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = .72f))
                    .border(1.dp, tint.copy(alpha = .50f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) {
                Text(
                    formatStoryCount(value),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun formatStoryCount(value: Int): String = when {
    value >= 1_000_000 -> String.format(Locale.US, "%.1fM", value / 1_000_000f).replace(".0M", "M")
    value >= 1_000 -> String.format(Locale.US, "%.1fK", value / 1_000f).replace(".0K", "K")
    else -> value.toString()
}

@Composable
private fun StoryTopAvatar(story: StoryItem, onClick: () -> Unit) {
    // Avatarın altında nickname ayrıca göstərilir. Sabit en + ellipsis uzun
    // adların bir-birinə qarışmasının qarşısını alır və header səliqəli qalır.
    Column(
        modifier = Modifier.width(76.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(GhostRedPrimary.copy(alpha = .10f))
                .border(2.dp, GhostRedPrimary.copy(alpha = .78f), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            GhostAvatar(
                size = 50.dp,
                showBorder = false,
                avatarId = story.avatarId
            )
        }
        Spacer(Modifier.height(3.dp))
        Text(
            text = "@${story.nickname}",
            color = GhostTextWhite.copy(alpha = .92f),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable private fun SeenAvatar(story:StoryItem){Box(Modifier.size(46.dp).clip(CircleShape).background(GhostRedPrimary.copy(alpha=.12f)).border(2.dp,if(story.seen)Color.White.copy(alpha=.28f) else GhostRedPrimary,CircleShape),contentAlignment=Alignment.Center){GhostAvatar(size=38.dp,showBorder=false,avatarId=story.avatarId)}}
@Composable
private fun StoryMedia(story: StoryItem, autoPlayVideo: Boolean = false, fullscreen: Boolean = false) {
    when {
        story.mediaType.startsWith("video/") -> StoryVideoCard(story.mediaUrl, autoPlay = autoPlayVideo, fullscreen = fullscreen)
        story.mediaType.startsWith("image/") -> StoryImageCard(story.mediaUrl)
    }
}

@Composable
private fun StoryImageCard(url: String) {
    val context = LocalContext.current
    var bitmap by remember(url) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(url) {
        bitmap = withContext(Dispatchers.IO) { runCatching {
            val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection)
            c.connectTimeout = 12000; c.readTimeout = 20000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "VGhost/1.0")
            c.connect()
            if (c.responseCode !in 200..299) throw IllegalStateException("Şəkil yüklənmədi")
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        }.getOrNull() }
    }
    bitmap?.let { Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        ?: Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = GhostRedPrimary) }
}

@Composable
private fun StoryVideoCard(url: String, autoPlay: Boolean = false, fullscreen: Boolean = false) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var localPath by remember(url) { mutableStateOf<String?>(null) }
    var firstFrame by remember(url) { mutableStateOf<Bitmap?>(null) }
    var aspectRatio by remember(url) { mutableFloatStateOf(16f / 9f) }
    var loading by remember(url) { mutableStateOf(true) }
    var reloadToken by remember(url) { mutableIntStateOf(0) }

    // Always play a fully downloaded local file. This avoids remote-stream and
    // SurfaceView restore issues after navigating away from Story and coming back.
    LaunchedEffect(url, reloadToken) {
        loading = true
        withContext(Dispatchers.IO) {
            runCatching {
                val key = Integer.toHexString(url.hashCode())
                val file = com.vghost.app.StoryMediaCache.fileFor(context, key)
                com.vghost.app.StoryMediaCache.trim(context, keep = file)
                if (!file.exists() || file.length() < 1024L) {
                    val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection)
                    try {
                        conn.connectTimeout = 12000
                        conn.readTimeout = 30000
                        conn.instanceFollowRedirects = true
                        conn.requestMethod = "GET"
                        conn.setRequestProperty("User-Agent", "VGhost/1.0")
                        conn.connect()
                        if (conn.responseCode !in 200..299) throw IllegalStateException("Video yüklənmədi")
                        conn.inputStream.use { input ->
                            file.outputStream().use { output -> input.copyTo(output, 64 * 1024) }
                        }
                    } finally { conn.disconnect() }
                    if (file.length() < 1024L) throw IllegalStateException("Video faylı boşdur")
                }
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(file.absolutePath)
                    val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloatOrNull() ?: 16f
                    val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloatOrNull() ?: 9f
                    val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    val ratio = if (rotation == 90 || rotation == 270) height / width else width / height
                    val frame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    withContext(Dispatchers.Main) {
                        localPath = file.absolutePath
                        firstFrame = frame
                        aspectRatio = ratio.coerceIn(0.45f, 2.5f)
                        loading = false
                    }
                } finally { retriever.release() }
            }.onFailure {
                withContext(Dispatchers.Main) {
                    loading = false
                    if (reloadToken == 0) {
                        val key = Integer.toHexString(url.hashCode())
                        runCatching { com.vghost.app.StoryMediaCache.fileFor(context, key).delete() }
                        reloadToken = 1
                    }
                }
            }
        }
    }

    val exoPlayer = remember(localPath) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            playWhenReady = false
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            runCatching { exoPlayer.clearVideoTextureView(null) }
            runCatching { exoPlayer.stop() }
            runCatching { exoPlayer.release() }
        }
    }

    LaunchedEffect(localPath) {
        val path = localPath ?: return@LaunchedEffect
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        exoPlayer.setMediaItem(androidx.media3.common.MediaItem.fromUri(Uri.fromFile(java.io.File(path))))
        exoPlayer.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
        exoPlayer.prepare()
        exoPlayer.playWhenReady = autoPlay
        if (autoPlay && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            exoPlayer.play()
        }
    }

    DisposableEffect(lifecycleOwner, exoPlayer, autoPlay) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> if (autoPlay) {
                    exoPlayer.playWhenReady = true
                    exoPlayer.play()
                }
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    exoPlayer.pause()
                    exoPlayer.playWhenReady = false
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(autoPlay, localPath) {
        if (localPath == null) return@LaunchedEffect
        if (autoPlay && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            exoPlayer.playWhenReady = true
            exoPlayer.play()
        } else {
            exoPlayer.playWhenReady = false
            exoPlayer.pause()
        }
    }

    val cardHeight = (context.resources.displayMetrics.widthPixels / context.resources.displayMetrics.density - 24f) / aspectRatio
    Box(
        Modifier
            .fillMaxWidth()
            .then(if (fullscreen) Modifier.fillMaxSize() else Modifier.height(cardHeight.coerceIn(220f, 520f).dp))
            .clip(if (fullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(17.dp))
            .background(Color.Black)
            .clickable(enabled = localPath != null) {
                if (exoPlayer.isPlaying) {
                    exoPlayer.pause()
                    exoPlayer.playWhenReady = false
                } else if (autoPlay) {
                    exoPlayer.playWhenReady = true
                    exoPlayer.play()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (localPath != null) {
            // TextureView is deliberately used instead of Media3 PlayerView's
            // default SurfaceView. SurfaceView can restore as a black surface in
            // Compose after navigation while ExoPlayer itself is still playing.
            AndroidView(
                factory = { ctx ->
                    android.view.TextureView(ctx).apply {
                        isOpaque = false
                        exoPlayer.setVideoTextureView(this)
                    }
                },
                update = { view ->
                    exoPlayer.setVideoTextureView(view)
                },
                onRelease = { view ->
                    runCatching { exoPlayer.clearVideoTextureView(view) }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            firstFrame?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = tr("Video ön izləmə"),
                    modifier = Modifier.fillMaxSize(),
                    contentScale = if (fullscreen) ContentScale.Crop else ContentScale.Fit
                )
            }
            if (loading) CircularProgressIndicator(color = GhostRedPrimary, modifier = Modifier.size(28.dp))
        }
        if (!autoPlay && localPath != null) {
            Box(Modifier.align(Alignment.Center).size(58.dp).clip(CircleShape).background(Color.Black.copy(alpha = .42f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.PlayArrow, tr("Videonu oynat"), tint = Color.White, modifier = Modifier.size(34.dp))
            }
        }
    }
}

@Composable private fun ActionButton(icon:androidx.compose.ui.graphics.vector.ImageVector,text:String,onClick:()->Unit){TextButton(onClick=onClick){Icon(icon,null);Spacer(Modifier.width(5.dp));Text(text)}}
@Composable
private fun StoryExpiryBar(story: StoryItem, modifier: Modifier = Modifier) {
    var now by remember(story.id) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(story.id) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val created = parseUtcMillis(story.createdAt)
    val expires = parseUtcMillis(story.expiresAt)
    val total = (expires - created).coerceAtLeast(1L)
    val remaining = (expires - now).coerceAtLeast(0L)
    val progress = (remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    androidx.compose.material3.LinearProgressIndicator(
        progress = { progress },
        modifier = modifier.height(4.dp).clip(RoundedCornerShape(6.dp)),
        color = GhostGoldText,
        trackColor = GhostSurface
    )
}

private fun parseUtcMillis(value: String): Long {
    return runCatching {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        fmt.parse(value)?.time ?: System.currentTimeMillis()
    }.getOrDefault(System.currentTimeMillis())
}
private fun timeLeft(expires:String):String{try{val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);fmt.timeZone=TimeZone.getTimeZone("UTC");val ms=fmt.parse(expires)?.time?:return "7 gün";val d=ms-System.currentTimeMillis();if(d<=0)return "Expired";val days=d/86400000;val h=(d%86400000)/3600000;return if(days>0)"$days gün $h saat qaldı" else "$h saat qaldı"}catch(_:Throwable){return "7 gün"}}
