package com.vghost.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.ViewGroup
import android.media.AudioManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.webrtc.SurfaceViewRenderer

private val CallBg = Color(0xFF07080D)
private val CallPanel = Color(0xFF11131A)
private val CallPanel2 = Color(0xFF171A22)
private val CallRed = Color(0xFFEF233C)
private val CallGreen = Color(0xFF35D987)
private val CallMuted = Color(0xFF9AA1AE)

@Composable
fun WebRtcIncomingCallScreen(
    callId: Long,
    callerName: String,
    callType: String,
    isTest: Boolean,
    onAccept: suspend () -> Boolean,
    onReject: suspend () -> Boolean
) {
    val isVideo = callType.equals("video", true)
    val typeTitle = if (isVideo) "Gələn video zəng" else "Gələn səs zəngi"
    var actionBusy by remember { mutableStateOf(false) }
    val actionScope = rememberCoroutineScope()

    Dialog(
        onDismissRequest = { /* Incoming calls must use an explicit Reject action. */ },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        )
    ) {
        Box(Modifier.fillMaxSize().background(CallBg)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 22.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (isTest) "🧪 VGHOST TEST ZƏNGİ" else "VGHOST",
                    color = CallRed,
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(Modifier.height(22.dp))
                Box(
                    Modifier
                        .size(132.dp)
                        .clip(CircleShape)
                        .background(CallPanel2)
                        .border(2.dp, CallRed.copy(alpha = .7f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("👤", style = MaterialTheme.typography.displayMedium) }
                Spacer(Modifier.height(18.dp))
                Text(callerName, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(6.dp))
                Text(typeTitle, color = CallMuted, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(20.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = CallPanel,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(15.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("ZƏNG AXINI", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                            Text("INCOMING", color = CallRed, fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(Modifier.height(8.dp))
                        DiagnosticLine("✓", "Backend", "Incoming call aşkarlandı", true)
                        DiagnosticLine("✓", "Call ID", "Zəng #$callId hazırdır", true)
                        DiagnosticLine("→", "WebRTC", "Qəbul etdikdən sonra başlayacaq", null)
                        DiagnosticLine("✓", "Call type", if (isVideo) "VIDEO" else "VOICE", true)
                        DiagnosticLine("•", "Network", "TURN OFF • Google STUN", null)
                    }
                }

                Spacer(Modifier.weight(1f))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            if (!actionBusy) {
                                actionBusy = true
                                actionScope.launch { if (!onReject()) actionBusy = false }
                            }
                        },
                        enabled = !actionBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF351017)),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.weight(1f).height(62.dp)
                    ) {
                        Text("❌ Rədd et", color = CallRed, fontWeight = FontWeight.Black)
                    }
                    Button(
                        onClick = {
                            if (!actionBusy) {
                                actionBusy = true
                                actionScope.launch { if (!onAccept()) actionBusy = false }
                            }
                        },
                        enabled = !actionBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = CallGreen),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.weight(1f).height(62.dp)
                    ) {
                        Text("✅ Qəbul et", color = Color.Black, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    "🔒 Signaling • Media P2P • $typeTitle",
                    color = CallMuted,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun DiagnosticLine(icon: String, title: String, detail: String, ok: Boolean?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, color = when (ok) { true -> CallGreen; false -> CallRed; else -> CallMuted }, fontWeight = FontWeight.Black, modifier = Modifier.width(28.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            Text(detail, color = CallMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

/** Full-screen production call UI with live WebRTC diagnostics. */
@Composable
fun WebRtcCallScreen(
    callId: Long,
    callType: String,
    remoteName: String,
    isCaller: Boolean,
    onClosed: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val audioManager = remember(context) { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val videoEnabled = callType.equals("video", true)
    var micEnabled by remember { mutableStateOf(true) }
    var speakerEnabled by remember { mutableStateOf(videoEnabled) }
    var cameraEnabled by remember { mutableStateOf(videoEnabled) }
    var permissionReady by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
                (!videoEnabled || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
        )
    }
    var ended by remember { mutableStateOf(false) }
    var showDiagnostics by remember { mutableStateOf(true) }
    var startedAt by remember { mutableStateOf<Long?>(null) }
    val controller = remember(callId) { WebRtcCallController(context, callId, callType, isCaller) }
    val state by controller.state.collectAsState()
    var localRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    var remoteRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        permissionReady = result[Manifest.permission.RECORD_AUDIO] == true && (!videoEnabled || result[Manifest.permission.CAMERA] == true)
    }

    fun closeCall() {
        if (ended) return
        ended = true
        scope.launch {
            try { VGhostApi.call("call/end", "POST", JSONObject().put("call_id", callId)) } catch (_: Throwable) {}
        }
        controller.stop()
        onClosed()
    }

    // Start WebRTC only after permissions are ready. Do NOT key a cleanup effect
    // to permissionReady: the permission callback causes recomposition, and the
    // old implementation could stop/release the controller while the call UI
    // was still being created. Cleanup belongs to the lifetime of this call.
    LaunchedEffect(callId, permissionReady) {
        if (permissionReady) {
            try {
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                audioManager.isSpeakerphoneOn = speakerEnabled
            } catch (_: Throwable) {}
            controller.start(this)
        }
    }

    DisposableEffect(callId) {
        onDispose {
            controller.stop()
            try { audioManager.isSpeakerphoneOn = false; audioManager.mode = AudioManager.MODE_NORMAL } catch (_: Throwable) {}
        }
    }

    LaunchedEffect(permissionReady) {
        if (!permissionReady) {
            val permissions = buildList {
                add(Manifest.permission.RECORD_AUDIO)
                if (videoEnabled) add(Manifest.permission.CAMERA)
            }.toTypedArray()
            permissionLauncher.launch(permissions)
        }
    }

    LaunchedEffect(state.connectionState) {
        if (state.connectionState == "CONNECTED" && startedAt == null) {
            startedAt = System.currentTimeMillis()
        }
        if (state.connectionState in setOf("CLOSED", "REJECTED", "ENDED")) {
            delay(650L)
            if (!ended) {
                ended = true
                controller.stop()
                onClosed()
            }
        }
    }

    var durationNow by remember { mutableLongStateOf(0L) }
    LaunchedEffect(startedAt) {
        while (startedAt != null && !ended) {
            durationNow = System.currentTimeMillis() - (startedAt ?: System.currentTimeMillis())
            delay(1000L)
        }
    }

    BackHandler { closeCall() }

    Box(Modifier.fillMaxSize().background(CallBg)) {
            if (videoEnabled && permissionReady) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).also { view ->
                            view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            view.init(controller.eglContext, null)
                            view.setEnableHardwareScaler(true)
                            view.setMirror(false)
                            remoteRenderer = view
                            controller.setRemoteRenderer(view)
                        }
                    },
                    update = { controller.setRemoteRenderer(it) }
                )
                if (cameraEnabled) {
                    AndroidView(
                        modifier = Modifier.align(Alignment.TopEnd).padding(top = 86.dp, end = 16.dp).size(118.dp, 166.dp)
                            .clip(RoundedCornerShape(20.dp)).border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(20.dp)),
                        factory = { ctx ->
                            SurfaceViewRenderer(ctx).also { view ->
                                view.layoutParams = ViewGroup.LayoutParams(118.dp.value.toInt(), 166.dp.value.toInt())
                                view.init(controller.eglContext, null)
                                view.setEnableHardwareScaler(true)
                                view.setMirror(true)
                                localRenderer = view
                                controller.setLocalRenderer(view)
                            }
                        },
                        update = { controller.setLocalRenderer(it) }
                    )
                }
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(150.dp).clip(CircleShape).background(CallPanel2).border(2.dp, CallRed.copy(.55f), CircleShape), contentAlignment = Alignment.Center) {
                            Text("👤", style = MaterialTheme.typography.displayLarge)
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(remoteName, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        Text("Real WebRTC səs bağlantısı", color = CallMuted)
                    }
                }
            }

            Surface(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 40.dp).fillMaxWidth(.92f),
                color = Color(0xCC0B0D13), shape = RoundedCornerShape(22.dp), tonalElevation = 0.dp
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(if (state.connectionState == "CONNECTED") CallGreen else CallRed))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(remoteName, color = Color.White, fontWeight = FontWeight.Black)
                            Text(if (videoEnabled) "VIDEO • ${if (isCaller) "Outgoing" else "Incoming"}" else "VOICE • ${if (isCaller) "Outgoing" else "Incoming"}", color = CallMuted, style = MaterialTheme.typography.labelSmall)
                        }
                        StatusPill(state.connectionState)
                    }
                    if (startedAt != null) {
                        Text(formatDuration(durationNow), color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 7.dp))
                    }
                }
            }

            if (showDiagnostics) {
                Surface(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 118.dp).fillMaxWidth(.94f).heightIn(max = 310.dp),
                    color = Color(0xF20C0E14), shape = RoundedCornerShape(22.dp), tonalElevation = 0.dp
                ) {
                    Column(Modifier.padding(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🔬 CANLI DİAQNOSTİKA", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showDiagnostics = false }) { Text("Gizlət", color = CallMuted) }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            MiniMetric("MIC", state.localAudio)
                            MiniMetric("CAM", !videoEnabled || state.localVideo)
                            MiniMetric("R-AUDIO", state.remoteAudio)
                            MiniMetric("R-VIDEO", !videoEnabled || state.remoteVideo)
                            MiniMetric("ICE", state.iceState == "CONNECTED" || state.iceState == "COMPLETED")
                        }
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false)) {
                            items(state.diagnostics.reversed()) { d ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                                    Text(d.time, color = Color(0xFF6F7683), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(58.dp))
                                    Text(if (d.ok == true) "✓" else if (d.ok == false) "✕" else "•", color = if (d.ok == false) CallRed else if (d.ok == true) CallGreen else CallMuted, fontWeight = FontWeight.Black, modifier = Modifier.width(18.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(d.title, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                        Text(d.detail, color = CallMuted, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                TextButton(onClick = { showDiagnostics = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 112.dp, end = 16.dp)) {
                    Text("🔬 Diaqnostika", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 34.dp).fillMaxWidth(.92f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CallControl(
                    label = if (speakerEnabled) "Dinamik" else "Qulaqlıq",
                    icon = Icons.Filled.VolumeUp,
                    onClick = {
                        speakerEnabled = !speakerEnabled
                        try { audioManager.isSpeakerphoneOn = speakerEnabled } catch (_: Throwable) {}
                    }
                )
                Spacer(Modifier.width(10.dp))
                CallControl(
                    label = if (micEnabled) "Mikrofon" else "Mic OFF",
                    icon = if (micEnabled) Icons.Filled.Mic else Icons.Filled.MicOff,
                    onClick = { micEnabled = !micEnabled; controller.setMicEnabled(micEnabled) }
                )
                if (videoEnabled) {
                    Spacer(Modifier.width(10.dp))
                    CallControl(
                        label = if (cameraEnabled) "Kamera" else "Cam OFF",
                        icon = if (cameraEnabled) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                        onClick = { cameraEnabled = !cameraEnabled; controller.setCameraEnabled(cameraEnabled) }
                    )
                    Spacer(Modifier.width(10.dp))
                    CallControl("Dəyiş", Icons.Filled.Cameraswitch) { controller.switchCamera() }
                }
                Spacer(Modifier.width(10.dp))
                IconButton(onClick = { closeCall() }, modifier = Modifier.size(66.dp).background(CallRed, CircleShape)) {
                    Icon(Icons.Filled.CallEnd, "Zəngi bitir", tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
    }
}

@Composable
private fun StatusPill(state: String) {
    val good = state == "CONNECTED"
    Surface(shape = RoundedCornerShape(99.dp), color = if (good) Color(0x2235D987) else Color(0x22EF233C)) {
        Text(state, color = if (good) CallGreen else Color(0xFFFF8290), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
private fun MiniMetric(label: String, ok: Boolean) {
    Surface(shape = RoundedCornerShape(9.dp), color = if (ok) Color(0x1935D987) else Color(0x19EF233C)) {
        Text("${if (ok) "✓" else "✕"} $label", color = if (ok) CallGreen else CallRed, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp))
    }
}

@Composable
private fun CallControl(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, modifier = Modifier.size(54.dp).background(CallPanel2, CircleShape)) {
            Icon(icon, label, tint = Color.White)
        }
        Text(label, color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelSmall)
    }
}

private fun formatDuration(ms: Long): String {
    val total = (ms / 1000L).toInt().coerceAtLeast(0)
    return "%02d:%02d".format(total / 60, total % 60)
}
