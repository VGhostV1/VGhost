package com.vghost.app.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.webrtc.SurfaceViewRenderer

/** WebRTC P2P voice/video call surface used by VGhost chat. */
@Composable
fun WebRtcCallScreen(
    callId: Long,
    callType: String,
    remoteName: String,
    isCaller: Boolean,
    onClosed: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val videoEnabled = callType.equals("video", true)
    var micEnabled by remember { mutableStateOf(true) }
    var cameraEnabled by remember { mutableStateOf(videoEnabled) }
    var permissionReady by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
                (!videoEnabled || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
        )
    }
    var ended by remember { mutableStateOf(false) }
    val controller = remember(callId) { WebRtcCallController(context, callId, callType, isCaller) }
    val state by controller.state.collectAsState()
    var remoteRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }
    var localRenderer by remember { mutableStateOf<SurfaceViewRenderer?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        permissionReady = result[Manifest.permission.RECORD_AUDIO] == true && (!videoEnabled || result[Manifest.permission.CAMERA] == true)
    }

    fun closeCall() {
        if (ended) return
        ended = true
        scope.launch {
            try { VGhostApi.call("call/end", "POST", JSONObject().put("call_id", callId)) } catch (_: Throwable) {}
        }
        controller.stop()
        onClosed()
    }

    DisposableEffect(callId, permissionReady) {
        if (permissionReady) controller.start(scope)
        onDispose { controller.stop() }
    }

    LaunchedEffect(permissionReady) {
        if (!permissionReady) {
            val permissions = buildList {
                add(Manifest.permission.RECORD_AUDIO)
                if (videoEnabled) add(Manifest.permission.CAMERA)
            }.toTypedArray()
            permissionLauncher.launch(permissions)
        }
    }

    LaunchedEffect(state.connectionState) {
        if (state.connectionState == "CLOSED") {
            delay(250)
            if (!ended) {
                ended = true
                controller.stop()
                onClosed()
            }
        }
    }

    Dialog(
        onDismissRequest = { closeCall() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (videoEnabled && permissionReady) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).also { view ->
                            view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            view.init(controller.eglContext, null)
                            view.setEnableHardwareScaler(true)
                            view.setMirror(false)
                            remoteRenderer = view
                            controller.setRemoteRenderer(view)
                        }
                    },
                    update = { controller.setRemoteRenderer(it) }
                )
                if (cameraEnabled) {
                    AndroidView(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 48.dp, end = 16.dp)
                            .size(width = 120.dp, height = 180.dp),
                        factory = { ctx ->
                            SurfaceViewRenderer(ctx).also { view ->
                                view.layoutParams = ViewGroup.LayoutParams(120.dp.value.toInt(), 180.dp.value.toInt())
                                view.init(controller.eglContext, null)
                                view.setEnableHardwareScaler(true)
                                view.setMirror(true)
                                localRenderer = view
                                controller.setLocalRenderer(view)
                            }
                        },
                        update = { controller.setLocalRenderer(it) }
                    )
                }
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(remoteName, color = Color.White)
                }
            }

            Column(Modifier.align(Alignment.TopCenter).padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(remoteName, color = Color.White)
                Text(
                    when {
                        !permissionReady -> "İcazə gözlənilir..."
                        state.connectionState == "CONNECTED" -> "Qoşuldu"
                        state.connectionState == "CONNECTING" -> "Qoşulur..."
                        state.connectionState == "RINGING" -> "Zəng edilir..."
                        state.connectionState == "FAILED" -> "WebRTC bağlantısı alınmadı"
                        else -> state.connectionState
                    },
                    color = Color.White.copy(alpha = .75f)
                )
            }

            Row(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { micEnabled = !micEnabled; controller.setMicEnabled(micEnabled) },
                    modifier = Modifier.size(58.dp).background(Color(0xAA333333), CircleShape)
                ) { Icon(if (micEnabled) Icons.Filled.Mic else Icons.Filled.MicOff, null, tint = Color.White) }

                if (videoEnabled) {
                    IconButton(
                        onClick = { cameraEnabled = !cameraEnabled; controller.setCameraEnabled(cameraEnabled) },
                        modifier = Modifier.size(58.dp).background(Color(0xAA333333), CircleShape)
                    ) { Icon(if (cameraEnabled) Icons.Filled.Videocam else Icons.Filled.VideocamOff, null, tint = Color.White) }
                    IconButton(
                        onClick = { controller.switchCamera() },
                        modifier = Modifier.size(58.dp).background(Color(0xAA333333), CircleShape)
                    ) { Icon(Icons.Filled.Cameraswitch, null, tint = Color.White) }
                }

                IconButton(
                    onClick = { closeCall() },
                    modifier = Modifier.size(64.dp).background(Color(0xFFE53935), CircleShape)
                ) { Icon(Icons.Filled.CallEnd, null, tint = Color.White) }
            }
        }
    }
}
