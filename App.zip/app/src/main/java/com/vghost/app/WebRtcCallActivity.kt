package com.vghost.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Color
import com.vghost.app.ui.screens.WebRtcCallScreen

/** Dedicated lifecycle for a live WebRTC call. Keeping the call out of the
 * navigation graph prevents the MainActivity/PIN/Dialog lifecycle from tearing
 * down the peer connection when Accept is pressed. */
class WebRtcCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        val callId = intent.getLongExtra(EXTRA_CALL_ID, 0L)
        val callType = intent.getStringExtra(EXTRA_CALL_TYPE).orEmpty().ifBlank { "voice" }
        val remoteName = intent.getStringExtra(EXTRA_REMOTE_NAME).orEmpty().ifBlank { "VGHOST" }
        val isCaller = intent.getBooleanExtra(EXTRA_IS_CALLER, false)
        if (callId < 1L || callType !in setOf("voice", "video")) {
            finish()
            return
        }
        setContent {
            Surface(color = Color(0xFF07080D)) {
                WebRtcCallScreen(
                    callId = callId,
                    callType = callType,
                    remoteName = remoteName,
                    isCaller = isCaller,
                    onClosed = { finish() }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_CALL_ID = "vghost_call_id"
        private const val EXTRA_CALL_TYPE = "vghost_call_type"
        private const val EXTRA_REMOTE_NAME = "vghost_remote_name"
        private const val EXTRA_IS_CALLER = "vghost_is_caller"

        fun intent(context: Context, callId: Long, callType: String, remoteName: String, isCaller: Boolean): Intent =
            Intent(context, WebRtcCallActivity::class.java).apply {
                putExtra(EXTRA_CALL_ID, callId)
                putExtra(EXTRA_CALL_TYPE, callType)
                putExtra(EXTRA_REMOTE_NAME, remoteName)
                putExtra(EXTRA_IS_CALLER, isCaller)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
    }
}
