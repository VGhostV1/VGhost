package com.vghost.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Color
import com.vghost.app.network.VGhostApi
import com.vghost.app.ui.screens.OutgoingCallScreen
import com.vghost.app.ui.screens.WebRtcCallScreen
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Dedicated lifecycle for a call.  The important rule here is:
 *
 *   caller: show RINGING UI first -> do NOT start WebRTC/camera/mic yet
 *   callee: after Accept -> start WebRTC
 *   caller: after callee Accept -> start WebRTC
 *
 * This prevents the old behaviour where the caller screen could disappear while
 * the media engine/permissions were being initialized before the other side had
 * even answered.
 */
class WebRtcCallActivity : ComponentActivity() {
    private var callId: Long = 0L
    private var callType: String = "voice"
    private var remoteName: String = "VGHOST"
    private var isCaller: Boolean = false
    private var active = false
    private var statusJob: Job? = null
    private var statusError: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (android.os.Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        callId = intent.getLongExtra(EXTRA_CALL_ID, 0L)
        callType = intent.getStringExtra(EXTRA_CALL_TYPE).orEmpty().ifBlank { "voice" }
        remoteName = intent.getStringExtra(EXTRA_REMOTE_NAME).orEmpty().ifBlank { "VGHOST" }
        isCaller = intent.getBooleanExtra(EXTRA_IS_CALLER, false)
        if (callId < 1L || callType !in setOf("voice", "video")) {
            finish()
            return
        }

        if (isCaller) {
            showOutgoing()
            startCallerStatusLoop()
        } else {
            showActiveCall()
        }
    }

    private fun showOutgoing() {
        setContent {
            Surface(color = Color(0xFF07080D)) {
                OutgoingCallScreen(
                    callId = callId,
                    remoteName = remoteName,
                    callType = callType,
                    onCancel = { cancelOutgoingCall() }
                )
            }
        }
    }

    private fun startCallerStatusLoop() {
        statusJob?.cancel()
        statusJob = lifecycleScope.launch {
            while (!isFinishing && !isDestroyed && !active) {
                try {
                    val r = VGhostApi.call("call/signals?call_id=$callId&after=0&peer=app")
                    when (r.optString("status")) {
                        "accepted" -> {
                            active = true
                            showActiveCall()
                            break
                        }
                        "rejected", "missed", "cancelled", "ended" -> {
                            CallNotificationHelper.cancel(this@WebRtcCallActivity, callId)
                            active = true
                            showActiveCall()
                            break
                        }
                    }
                } catch (_: Throwable) {
                    // Keep the outgoing call screen alive during transient network errors.
                }
                delay(650L)
            }
        }
    }

    private fun showActiveCall() {
        if (isFinishing || isDestroyed) return
        active = true
        statusJob?.cancel()
        setContent {
            Surface(color = Color(0xFF07080D)) {
                WebRtcCallScreen(
                    callId = callId,
                    callType = callType,
                    remoteName = remoteName,
                    isCaller = isCaller,
                    onClosed = { finish() }
                )
            }
        }
    }

    private fun cancelOutgoingCall() {
        if (isFinishing) return
        statusJob?.cancel()
        lifecycleScope.launch {
            try {
                VGhostApi.call("call/end", "POST", JSONObject().put("call_id", callId))
            } catch (_: Throwable) { }
            CallNotificationHelper.cancel(this@WebRtcCallActivity, callId)
            finish()
        }
    }

    override fun onDestroy() {
        statusJob?.cancel()
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_CALL_ID = "vghost_call_id"
        private const val EXTRA_CALL_TYPE = "vghost_call_type"
        private const val EXTRA_REMOTE_NAME = "vghost_remote_name"
        private const val EXTRA_IS_CALLER = "vghost_is_caller"

        fun intent(context: Context, callId: Long, callType: String, remoteName: String, isCaller: Boolean): Intent =
            Intent(context, WebRtcCallActivity::class.java).apply {
                putExtra(EXTRA_CALL_ID, callId)
                putExtra(EXTRA_CALL_TYPE, callType)
                putExtra(EXTRA_REMOTE_NAME, remoteName)
                putExtra(EXTRA_IS_CALLER, isCaller)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
    }
}
