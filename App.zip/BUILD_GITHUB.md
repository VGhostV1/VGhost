# VGhost Android GitHub Actions Build

This project is prepared for GitHub Actions release builds.

- Android Gradle Plugin: 9.1.2
- Gradle Wrapper distribution: 9.3.1
- Kotlin Compose Gradle plugin: 2.4.20
- JDK: 17
- Compile/Target SDK: 37
- Workflow: `.github/workflows/android-release.yml`

The wrapper script bootstraps the official Gradle 9.3.1 wrapper JAR on first run and verifies its SHA-256 before executing it. The Gradle distribution is also pinned and checksum-verified in `gradle-wrapper.properties`.

GitHub Actions produces:

`app/build/outputs/apk/release/app-release.apk`

and uploads it as the `VGhost-release-apk` artifact.
