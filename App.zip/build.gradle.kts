plugins {
    id("com.android.application") version "9.1.2" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.20" apply false
    id("com.google.gms.google-services") version "4.4.3" apply false
}
