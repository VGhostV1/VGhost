package com.vghost.app.ui.screens
import com.vghost.app.ui.components.VGhostCoinAmount
import com.vghost.app.ui.components.VGhostCoinIcon
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.PersonRemove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.i18n.AppLocale
import com.vghost.app.R
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.data.model.GiftItem
import com.vghost.app.data.model.PublicUserProfile
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.FlyingGhost
import com.vghost.app.ui.components.ProfileAvatarFrame
import com.vghost.app.ui.components.NeonVipName
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostGoldText
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.ui.components.GiftAnimationEngine
import com.vghost.app.ui.theme.GhostStatusOnline
import com.vghost.app.ui.theme.GhostStatusOffline
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OtherProfileScreen(
    nickname: String,
    initialUid: String? = null,
    initialOnline: Boolean = false,
    initialVip: Boolean = false,
    onNavigateBack: () -> Unit,
    onOpenChat: (String) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    // The search result already contains the real UID. Show a safe local profile
    // immediately so the screen never becomes an empty com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found_2") page
    // just because the optional public-profile Function is unavailable/not deployed.
    var profile by remember(nickname, initialUid, initialOnline, initialVip) {
        mutableStateOf(
            initialUid?.takeIf { it.isNotBlank() }?.let {
                PublicUserProfile(
                    uid = it,
                    nickname = nickname,
                    balance = 0,
                    online = initialOnline,
                    ghostMode = false,
                    isVip = initialVip
                )
            }
        )
    }
    var loading by remember(nickname, initialUid, initialOnline, initialVip) { mutableStateOf(initialUid.isNullOrBlank()) }
    var error by remember(nickname) { mutableStateOf<String?>(null) }
    var showGiftDialog by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var showRemoveFriendDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }
    var actionLoading by remember { mutableStateOf(false) }
    var friendAddLoading by remember { mutableStateOf(false) }
    var friendRequestDenied by remember { mutableStateOf(false) }
    var selectedGift by remember { mutableStateOf<GiftItem?>(null) }
    var coinAmountText by remember { mutableStateOf("") }
    var sendCoinsMode by remember { mutableStateOf(false) }
    var gifting by remember { mutableStateOf(false) }
    var giftAnimation by remember { mutableStateOf<GiftItem?>(null) }
    val scope = rememberCoroutineScope()
    val myBalance by repository.ghostCoins.collectAsState()

    suspend fun reloadProfile() {
        loading = true
        error = null
        val remote = repository.getPublicUserProfile(nickname)
        if (remote != null) {
            // VIP must be visible even when an older / partially deployed public-profile
            // endpoint does not return isVip. Use the navigation value first, then the
            // users/search endpoint (which already carries the authoritative VIP flag).
            val vipFromSearch = if (!remote.isVip && !initialVip) {
                repository.findUserByNickname(nickname)?.isVip == true
            } else {
                false
            }
            profile = remote.copy(isVip = remote.isVip || initialVip || vipFromSearch)
        } else if (profile == null) {
            error = trKey("user_not_found")
        }
        loading = false
    }

    LaunchedEffect(nickname) {
        reloadProfile()
    }

    // Keep a sent friend request in sync with the recipient's decision.
    // pending_sent = yellow (waiting), friends = green (accepted), none = blue (declined/cancelled).
    LaunchedEffect(profile?.uid, profile?.friendStatus) {
        while (profile?.friendStatus == "pending_sent") {
            kotlinx.coroutines.delay(60_000)
            reloadProfile()
        }
    }

    val isStealth by repository.isGhostMode.collectAsState()
    LaunchedEffect(profile?.uid, isStealth) {
        val uid = profile?.uid ?: return@LaunchedEffect
        if (!isStealth) repository.recordProfileView(uid)
    }
    BackHandler { onNavigateBack() }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize().background(GhostBlack),
            containerColor = Color.Transparent,
            bottomBar = { VGhostBottomNavBar(currentTab = NavTab.FIND, onTabSelected = onTabSelected) }
        ) { innerPadding ->
            Column(Modifier.fillMaxSize().padding(innerPadding).windowInsetsPadding(WindowInsets.statusBars)) {
                Row(
                    modifier = Modifier.fillMaxWidth().height(58.dp).background(Color.Black).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, trKey("back"), tint = GhostTextWhite)
                    }
                    Text(trKey("profile"), color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                if (loading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = GhostRedPrimary)
                    }
                } else if (profile == null) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(error ?: trKey("user_not_found"), color = GhostTextMuted, fontSize = 15.sp)
                    }
                } else {
                    val p = profile!!
                    val contactBlocked = p.blockedByMe || p.blockedMe
                    LaunchedEffect(p.friendStatus) {
                        if (p.friendStatus != "none") friendRequestDenied = false
                    }
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp).verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Keep the avatar/frame behind the username, matching My Profile.
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(326.dp)
                                .background(GhostBlack),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            ProfileAvatarFrame(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .offset(y = (-20).dp),
                                size = 290.dp,
                                avatarId = p.avatarId,
                                avatarUrl = p.avatarUrl,
                                isVip = p.isVip,
                                vipHero = true,
                                vipFrameId = p.vipFrameId
                            )
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 278.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (p.ghostMode) GhostStatusOffline
                                            else if (p.online) GhostStatusOnline
                                            else GhostStatusOffline
                                        )
                                )
                                Spacer(Modifier.width(7.dp))
                                if (p.isVip) {
                                    Text("👑", fontSize = 24.sp)
                                    Spacer(Modifier.width(5.dp))
                                }
                                if (p.isVip) {
                                    NeonVipName(p.nickname, fontSize = 40.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                } else {
                                    Text(
                                        p.nickname,
                                        color = GhostTextWhite,
                                        fontSize = 40.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // Other-user actions use the same clean icon-only dock as My Profile.
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 8.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                when (p.friendStatus) {
                                    "friends" -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonRemove,
                                        tint = Color(0xFF22C55E),
                                        contentDescription = trKey("remove_friend_2"),
                                        enabled = !actionLoading
                                    ) {
                                        showRemoveFriendDialog = true
                                    }
                                    "pending_sent" -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonAdd,
                                        tint = Color(0xFFFFC107),
                                        contentDescription = trKey("i_stek_bekliyor"),
                                        enabled = !actionLoading
                                    ) {
                                        showRemoveFriendDialog = true
                                    }
                                    "pending_received" -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonAdd,
                                        tint = Color(0xFF2F7CFF),
                                        contentDescription = trKey("accept_friend_request"),
                                        enabled = !actionLoading
                                    ) {
                                        actionLoading = true
                                        scope.launch {
                                            actionMessage = repository.acceptFriend(p.uid)
                                            actionLoading = false
                                            if (actionMessage == null) reloadProfile()
                                        }
                                    }
                                    else -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonAdd,
                                        tint = when {
                                            friendRequestDenied -> Color(0xFFE53935)
                                            friendAddLoading -> Color(0xFFFFC107)
                                            else -> Color(0xFF2F7CFF)
                                        },
                                        contentDescription = if (friendRequestDenied) trKey("dostluq_sor_ular_ba_l_d_r") else trKey("add_friend"),
                                        enabled = !contactBlocked && !actionLoading && !friendAddLoading,
                                        loading = friendAddLoading
                                    ) {
                                        friendAddLoading = true
                                        actionMessage = null
                                        scope.launch {
                                            val result = repository.addFriend(p.uid)
                                            actionMessage = result
                                            friendAddLoading = false
                                            if (result == null) {
                                                friendRequestDenied = false
                                                reloadProfile()
                                            } else {
                                                // A privacy restriction (or any rejected friend request)
                                                // is shown as a red + instead of silently staying blue.
                                                friendRequestDenied = true
                                            }
                                        }
                                    }
                                }
                                OtherProfileActionLogo(
                                    icon = Icons.Outlined.ChatBubbleOutline,
                                    tint = Color(0xFF2F7CFF),
                                    contentDescription = trKey("write_message"),
                                    enabled = !contactBlocked && !actionLoading
                                ) { onOpenChat(p.nickname) }
                                OtherProfileActionLogo(
                                    icon = Icons.Outlined.CardGiftcard,
                                    tint = GhostGoldText,
                                    contentDescription = trKey("send_gift"),
                                    enabled = !contactBlocked && !actionLoading
                                ) { actionMessage = null; showGiftDialog = true }
                                OtherProfileActionLogo(
                                    icon = if (p.blockedByMe) Icons.Outlined.PersonRemove else Icons.Outlined.Block,
                                    tint = if (p.blockedByMe) Color(0xFF18D64B) else GhostRedPrimary,
                                    contentDescription = if (p.blockedByMe) trKey("unblock") else trKey("block_user"),
                                    enabled = !actionLoading
                                ) {
                                    if (p.blockedByMe) {
                                        actionLoading = true
                                        scope.launch {
                                            actionMessage = repository.unblockUser(p.uid)
                                            actionLoading = false
                                            if (actionMessage == null) reloadProfile()
                                        }
                                    } else showBlockDialog = true
                                }
                            }
                    }

                    // Premium activity level — shown under the four profile actions.
                    OtherProfileLevelCard(
                        level = p.activityLevel,
                        xp = p.activityXp
                    )

                    // Bu profilin aldığı hədiyyələr. Hədiyyələr serverdə receiver_id ilə saxlanılır.
                    if (p.gifts.isNotEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(trKey("gift_received_gifts"), color = GhostGoldText, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            Text(trfKey("gifts_bullet_level", p.gifts.sumOf { it.count }, p.giftLevel), color = GhostTextMuted, fontSize = 11.sp)
                            p.gifts.forEach { gift ->
                                GiftCollectionRow(
                                    gift.icon,
                                    GiftCatalog.find(gift.giftId)?.name ?: gift.name,
                                    gift.count,
                                    gift.price,
                                    onClick = { giftAnimation = GiftCatalog.find(gift.giftId) ?: GiftItem(gift.giftId, gift.name, gift.icon, gift.price) }
                                )
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(trKey("gift_received_gifts"), color = GhostGoldText, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            Text(trKey("no_gifts_received_yet_2"), color = GhostTextMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                        }
                    }

                    if (p.blockedMe) {
                        Text(trKey("user_has_blocked"), color = GhostRedPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    actionMessage?.let { msg ->
                        Text(msg, color = if (msg.startsWith(com.vghost.app.i18n.VGhostLanguage.trKey("success"))) Color(0xFF18D64B) else GhostRedPrimary, fontSize = 9.sp)
                    }
                }
            }
        }
    }


    giftAnimation?.let { gift ->
        GiftAnimationEngine(gift = gift) { giftAnimation = null }
    }
}

if (showRemoveFriendDialog && profile != null) {
    AlertDialog(
        onDismissRequest = { if (!actionLoading) showRemoveFriendDialog = false },
        title = { Text(trKey("remove_friend"), fontWeight = FontWeight.Bold) },
        text = { Text(trfKey("sure_want_remove_friend", profile!!.nickname)) },
        confirmButton = {
            Button(
                enabled = !actionLoading,
                onClick = {
                    actionLoading = true
                    scope.launch {
                        actionMessage = repository.removeFriend(profile!!.uid)
                        actionLoading = false
                        if (actionMessage == null) {
                            showRemoveFriendDialog = false
                            reloadProfile()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
            ) {
                if (actionLoading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(trKey("remove"))
            }
        },
        dismissButton = {
            TextButton(enabled = !actionLoading, onClick = { showRemoveFriendDialog = false }) {
                Text(trKey("back"))
            }
        }
    )
}

if (showBlockDialog && profile != null) {
    AlertDialog(
        onDismissRequest = { if (!actionLoading) showBlockDialog = false },
        title = { Text(trKey("block_user_2"), fontWeight = FontWeight.Bold) },
        text = { Text(trfKey("cannot_message_gift_add_friend", profile!!.nickname)) },
        confirmButton = {
            Button(enabled = !actionLoading, onClick = {
                actionLoading = true
                scope.launch {
                    actionMessage = repository.blockUser(profile!!.uid)
                    actionLoading = false
                    showBlockDialog = false
                    if (actionMessage == null) reloadProfile()
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)) { Text(trKey("block")) }
        },
        dismissButton = { TextButton(enabled = !actionLoading, onClick = { showBlockDialog = false }) { Text(trKey("cancel_4")) } }
    )
}

if (showGiftDialog && profile != null) {
    AlertDialog(
        onDismissRequest = { if (!gifting) { showGiftDialog = false; selectedGift = null } },
        title = { Text(trKey("gift_gift_store"), fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(trfKey("recipient", profile!!.nickname), color = GhostTextSecondary)
                VGhostCoinAmount(trfKey("balance_gc", myBalance), iconSize = 26.dp, color = GhostGoldText, fontWeight = FontWeight.Black)
                if (selectedGift == null && !sendCoinsMode) {
                    Button(onClick = { sendCoinsMode = true }) { Text(trKey("coin_gift_coins")) }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxWidth().height(410.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(GiftCatalog.items, key = { it.id }) { gift -> GiftChoiceCard(gift) { selectedGift = gift } }
                    }
                } else if (sendCoinsMode) {
                    OutlinedTextField(value = coinAmountText, onValueChange = { coinAmountText = it.filter(Char::isDigit) }, label = { Text(trKey("gc_send")) })
                    Text(trfKey("send_coins", profile!!.nickname), color = GhostTextSecondary)
                } else {
                    val gift = selectedGift!!
                    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(gift.icon, fontSize = 66.sp)
                            Text(gift.name, color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            VGhostCoinAmount(trfKey("gc_3", gift.price), iconSize = 25.dp, color = GhostGoldText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(trfKey("do_want_send_gift", profile!!.nickname), color = GhostTextSecondary)
                }
                actionMessage?.let { Text(it, color = GhostRedPrimary, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            if (selectedGift != null || sendCoinsMode) {
                Button(enabled = !gifting, onClick = {
                    val gift = selectedGift
                    gifting = true
                    scope.launch {
                        val result = if (sendCoinsMode) repository.sendCoins(profile!!.uid, coinAmountText.toIntOrNull() ?: 0) else repository.sendGift(profile!!.uid, gift!!.id)
                        gifting = false
                        if (result == null) {
                            actionMessage = if (sendCoinsMode) com.vghost.app.i18n.VGhostLanguage.trKey("coins_sent_successfully") else com.vghost.app.i18n.VGhostLanguage.trKey("sent_successfully_2").format(gift!!.name)
                            profile = repository.getPublicUserProfile(profile!!.nickname)
                            showGiftDialog = false
                            selectedGift = null
                            if (!sendCoinsMode) { giftAnimation = gift; delay(1500); giftAnimation = null }
                            sendCoinsMode = false
                            coinAmountText = ""
                        } else actionMessage = result
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)) {
                    if (gifting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Text(trKey("gift_send"))
                }
            }
        },
        dismissButton = {
            TextButton(enabled = !gifting, onClick = {
                if (sendCoinsMode) { sendCoinsMode = false; coinAmountText = "" } else if (selectedGift != null) selectedGift = null else showGiftDialog = false
            }) { Text(if (selectedGift != null || sendCoinsMode) com.vghost.app.i18n.VGhostLanguage.trKey("arrow_left_back") else trKey("close")) }
        }
    )
}
}


@Composable
private fun GiftCollectionRow(icon: String, name: String, count: Int, price: Int, onClick: () -> Unit = {}) {
Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(GhostSurface.copy(alpha = .72f)).border(1.dp, GhostBorder, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
    Text(icon, fontSize = 30.sp)
    Spacer(Modifier.width(12.dp))
    Column(Modifier.weight(1f)) {
        Text(name, color = GhostTextWhite, fontWeight = FontWeight.Bold)
        VGhostCoinAmount(trfKey("gc_value", price), iconSize = 20.dp, color = GhostTextMuted, fontSize = 11.sp)
    }
    Text(trfKey("text_19", count), color = GhostGoldText, fontSize = 17.sp, fontWeight = FontWeight.Black)
}
}

@Composable
private fun GiftChoiceCard(gift: GiftItem, onClick: () -> Unit) {
Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(GhostSurface.copy(alpha = .9f)).border(1.dp, GhostRedPrimary.copy(alpha = .45f), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
    Text(gift.icon, fontSize = 36.sp)
    Text(gift.name, color = GhostTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    VGhostCoinAmount(trfKey("gc_3", gift.price), iconSize = 20.dp, color = GhostGoldText, fontSize = 11.sp, fontWeight = FontWeight.Black)
}
}

@Composable
private fun OtherProfileLevelCard(
    level: Int,
    xp: Int
) {
    val safeLevel = level.coerceAtLeast(1)
    val safeXp = xp.coerceAtLeast(0)
    val nextXp = safeLevel * 100
    val currentLevelXp = (safeLevel - 1) * 100
    val progress = ((safeXp - currentLevelXp).toFloat() / 100f).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Color(0xFF0D0D13).copy(alpha = .96f))
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF292932),
                        Color(0xFF8B5CF6).copy(alpha = .65f),
                        Color(0xFF292932)
                    )
                ),
                RoundedCornerShape(17.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Color(0xFF11111A))
                    .border(1.dp, Color(0xFF6D45B8).copy(alpha = .75f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(trKey("level_2"), color = GhostTextMuted, fontSize = 6.sp, fontWeight = FontWeight.Black)
                    Text(trfKey("text_25", safeLevel), color = GhostTextWhite, fontSize = 17.sp, lineHeight = 17.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(Modifier.width(10.dp))

            Column(Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(trfKey("text_12", safeXp), color = GhostGoldText, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text(trfKey("xp_2", nextXp), color = GhostTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(5.dp))
                Canvas(Modifier.fillMaxWidth().height(9.dp)) {
                    val radius = size.height / 2f
                    drawRoundRect(
                        color = Color(0xFF050507),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xFFFF3D5A), Color(0xFFB02CFF), Color(0xFF8F7CFF))
                        ),
                        size = androidx.compose.ui.geometry.Size(size.width * progress, size.height),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                    drawRoundRect(
                        color = Color.White.copy(alpha = .12f),
                        style = Stroke(width = 1.dp.toPx()),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                }
            }

            Spacer(Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(trKey("next"), color = GhostTextSecondary, fontSize = 7.sp, fontWeight = FontWeight.Black)
                Text(trfKey("text", safeLevel), color = Color(0xFFA855F7), fontSize = 17.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun OtherProfileActionLogo(
icon: androidx.compose.ui.graphics.vector.ImageVector,
tint: Color,
contentDescription: String,
enabled: Boolean = true,
loading: Boolean = false,
onClick: () -> Unit
) {
val ring = RoundedCornerShape(18.dp)
Box(
    modifier = Modifier
        .size(58.dp)
        .clip(ring)
        .background(GhostBlack.copy(alpha = .35f))
        .border(1.5.dp, tint.copy(alpha = if (enabled) .8f else .25f), ring)
        .clickable(enabled = enabled, onClick = onClick),
    contentAlignment = Alignment.Center
) {
    if (loading) {
        CircularProgressIndicator(
            modifier = Modifier.size(28.dp),
            color = tint,
            strokeWidth = 3.dp
        )
    } else {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = if (enabled) tint else GhostTextMuted,
            modifier = Modifier.size(30.dp)
        )
    }
}
}
