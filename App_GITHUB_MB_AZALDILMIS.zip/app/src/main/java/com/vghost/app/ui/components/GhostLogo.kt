package com.vghost.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.Canvas
import androidx.compose.material3.Text
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import com.vghost.app.R
import com.vghost.app.ui.theme.GhostRedPrimary

/**
 * VGhost brand logo. The same supplied artwork is used throughout the app
 * so splash/login/register/chat/profile branding stays consistent.
 */
/**
 * VIP nickname with a bright neon gradient and soft glow. Used wherever a VIP
 * user's name is shown so VIP status is visual rather than plain yellow text.
 */
@Composable
fun NeonVipName(
    nickname: String,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 40.sp,
    maxLines: Int = 1,
    textAlign: androidx.compose.ui.text.style.TextAlign? = null
) {
    Text(
        text = nickname,
        modifier = modifier,
        style = TextStyle(
            brush = Brush.linearGradient(
                listOf(
                    Color(0xFF63F7FF),
                    Color(0xFFFFFFFF),
                    Color(0xFFFF4DDE),
                    Color(0xFF8B5CFF),
                    Color(0xFF63F7FF)
                )
            ),
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            shadow = Shadow(
                color = Color(0xFF55EFFF).copy(alpha = 0.85f),
                blurRadius = (fontSize.value * 0.32f),
                offset = androidx.compose.ui.geometry.Offset.Zero
            )
        ),
        maxLines = maxLines,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        textAlign = textAlign
    )
}

@Composable
fun GhostLogo(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    showHaloRing: Boolean = false,
    animateGlow: Boolean = true
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        if (showHaloRing) {
            Box(
                modifier = Modifier
                    .size(size * 0.94f)
                    .border(1.5.dp, GhostRedPrimary.copy(alpha = 0.70f), CircleShape)
            )
        }

        Image(
            painter = painterResource(id = R.drawable.vg_premium_4_logo),
            contentDescription = com.vghost.app.i18n.VGhostLanguage.trKey("v_ghost_2"),
            modifier = Modifier.size(size),
            contentScale = ContentScale.Fit,
            alpha = if (animateGlow) 1f else 0.98f
        )
    }
}

/**
 * Shared circular profile-avatar renderer. All profile avatars use the same
 * thin VGhost ring and the image is always clipped inside the circle.
 */
@Composable
fun GhostAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    showBorder: Boolean = true,
    avatarId: String = "male_01",
    avatarUrl: String? = null,
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        if (showBorder) {
            Canvas(Modifier.matchParentSize()) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            GhostRedPrimary,
                            Color(0xFFFF5B7D),
                            Color(0xFF7A1FFF),
                            GhostRedPrimary
                        )
                    ),
                    radius = size.toPx() / 2f,
                    style = Stroke(width = 2.5.dp.toPx())
                )
            }
        }
        Image(
            painter = painterResource(id = avatarPainterId(avatarId)),
            contentDescription = com.vghost.app.i18n.VGhostLanguage.trKey("v_ghost_profile_picture"),
            modifier = Modifier
                .size(if (showBorder) size - 5.dp else size)
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    }
}

fun avatarPainterId(avatarId: String): Int = when (avatarId.lowercase().trim()) {
    "female", "female_white", "woman", "female_01" -> R.drawable.avatar_female_01
    "female_02" -> R.drawable.avatar_female_02
    "female_03" -> R.drawable.avatar_female_03
    "female_04" -> R.drawable.avatar_female_04
    "female_05" -> R.drawable.avatar_female_05
    "female_06" -> R.drawable.avatar_female_06
    "male_02" -> R.drawable.avatar_male_02
    "male_03" -> R.drawable.avatar_male_03
    "male_04" -> R.drawable.avatar_male_04
    "male_05" -> R.drawable.avatar_male_05
    "male_06" -> R.drawable.avatar_male_06
    "male", "male_red", "man", "ghost", "" -> R.drawable.avatar_male_01
    "male_01" -> R.drawable.avatar_male_01
    else -> R.drawable.avatar_male_01
}

/** Compatibility wrapper retained for existing screens; no Ghost animation remains. */
@Composable
fun FlyingGhost(
    modifier: Modifier = Modifier,
    size: Dp = 152.dp,
    avatarId: String = "male_01",
    avatarUrl: String? = null,
) {
    GhostAvatar(
        modifier = modifier,
        size = size,
        showBorder = false,
        avatarId = avatarId,
        avatarUrl = avatarUrl
    )
}

fun vipFramePreviewPainterId(frameId: String): Int = when (frameId.lowercase().trim()) {
    "vip_01" -> R.drawable.vip_01_thumb
    "vip_02" -> R.drawable.vip_02_thumb
    "vip_03" -> R.drawable.vip_03_thumb
    "vip_04" -> R.drawable.vip_04_thumb
    "vip_05" -> R.drawable.vip_05_thumb
    "vip_06" -> R.drawable.vip_06_thumb
    "vip_07" -> R.drawable.vip_07_thumb
    "vip_08" -> R.drawable.vip_08_thumb
    "vip_09" -> R.drawable.vip_09_thumb
    else -> R.drawable.vip_01_thumb
}

fun vipFramePainterId(frameId: String): Int = when (frameId.lowercase().trim()) {
    "vip_01" -> R.drawable.vip_01
    "vip_02" -> R.drawable.vip_02
    "vip_03" -> R.drawable.vip_03
    "vip_04" -> R.drawable.vip_04
    "vip_05" -> R.drawable.vip_05
    "vip_06" -> R.drawable.vip_06
    "vip_07" -> R.drawable.vip_07
    "vip_08" -> R.drawable.vip_08
    "vip_09" -> R.drawable.vip_09
    else -> R.drawable.vip_01
}

/**
 * Large profile avatar. VIP users can layer a server-selected VIP frame over
 * the avatar; non-VIP users always get the normal VGhost ring.
 */
@Composable
fun ProfileAvatarFrame(
    modifier: Modifier = Modifier,
    size: Dp = 247.dp,
    avatarId: String = "male_01",
    avatarUrl: String? = null,
    isVip: Boolean = false,
    vipHero: Boolean = false,
    vipFrameId: String = "vip_01",
) {
    if (isVip && vipHero) {
        Box(
            modifier = modifier.size(size),
            contentAlignment = Alignment.Center
        ) {
            // Match the avatar to the circular opening in the supplied VIP
            // artwork. The frame itself stays at its original size; only the
            // avatar is fitted inside the opening.
            val avatarSize = size * 0.42f

            // Frame is deliberately drawn first so the avatar sits in front of
            // the frame's inner opening, exactly in the center.
            Image(
                painter = painterResource(id = vipFramePainterId(vipFrameId)),
                contentDescription = "VIP Frame",
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Fit
            )

            // Thick rounded neon outline around the avatar. It is drawn over
            // the frame so the avatar never appears behind the VIP artwork.
            Canvas(Modifier.size(avatarSize + 18.dp)) {
                val r = this.size.minDimension / 2f - 6.dp.toPx()
                drawCircle(
                    brush = Brush.sweepGradient(
                        listOf(
                            Color(0xFFFF2BD6),
                            Color(0xFF6A5CFF),
                            Color(0xFF00E5FF),
                            Color(0xFFFF2BD6)
                        )
                    ),
                    radius = r,
                    style = Stroke(width = 12.dp.toPx())
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.78f),
                    radius = r,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            Image(
                painter = painterResource(id = avatarPainterId(avatarId)),
                contentDescription = com.vghost.app.i18n.VGhostLanguage.trKey("v_ghost_profile_picture"),
                modifier = Modifier
                    .size(avatarSize)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }
        return
    }

    val inner = size - 8.dp
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.matchParentSize()) {
            val r = this.size.minDimension / 2f - 7.dp.toPx()
            // Normal users get a simple, visible circular ring. VIP users use
            // the dedicated frame branch above.
            drawCircle(
                color = Color.White.copy(alpha = .92f),
                radius = r,
                style = Stroke(width = 5.dp.toPx())
            )
        }
        Image(
            painter = painterResource(id = avatarPainterId(avatarId)),
            contentDescription = com.vghost.app.i18n.VGhostLanguage.trKey("v_ghost_profile_picture"),
            modifier = Modifier
                .size(inner)
                .clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    }
}
