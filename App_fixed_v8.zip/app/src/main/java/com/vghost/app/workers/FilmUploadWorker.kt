package com.vghost.app.workers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.vghost.app.R
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.CancellationException
import java.io.File

class FilmUploadWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    companion object {
        const val KEY_FILM_ID = "filmId"
        const val KEY_TITLE = "title"
        const val KEY_DESCRIPTION = "description"
        const val KEY_POSTER_URL = "posterUrl"
        const val KEY_VIDEO_URL = "videoUrl"
        const val KEY_CATEGORY = "category"
        const val KEY_YEAR = "year"
        const val KEY_DURATION = "duration"
        const val KEY_VIP = "vip"
        const val KEY_FEATURED = "featured"
        const val KEY_ACTIVE = "active"
        const val KEY_POSTER_PATH = "posterPath"
        const val KEY_VIDEO_PATH = "videoPath"
        const val KEY_POSTER_NAME = "posterName"
        const val KEY_VIDEO_NAME = "videoName"
        const val KEY_POSTER_MIME = "posterMime"
        const val KEY_VIDEO_MIME = "videoMime"
        const val KEY_SECURITY = "security"
        const val KEY_UPLOAD_ID = "uploadId"
        const val KEY_SENT = "sent"
        const val KEY_TOTAL = "total"
        const val KEY_KIND = "kind"
        const val KEY_PERCENT = "percent"
        const val KEY_ERROR = "error"
        private const val CHANNEL = "vghost_film_uploads"
        private const val NOTIFICATION_ID = 4817

        fun workName(id: Long) = "vghost-film-upload-$id"
    }

    private fun notification(title: String, text: String, progress: Int, indeterminate: Boolean = false): ForegroundInfo {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Film uploads", NotificationManager.IMPORTANCE_LOW))
        }
        val builder = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_vghost)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (indeterminate) builder.setProgress(100, 0, true) else builder.setProgress(100, progress.coerceIn(0,100), false)
        return ForegroundInfo(NOTIFICATION_ID, builder.build())
    }

    override suspend fun doWork(): Result {
        VGhostApi.init(applicationContext)
        val filmId = inputData.getLong(KEY_FILM_ID, 0L)
        val security = VGhostApi.unprotectForBackground(inputData.getString(KEY_SECURITY).orEmpty())
            ?: return Result.failure(workDataOf(KEY_ERROR to "ADMIN_SECURITY_SESSION_INVALID"))
        if (filmId <= 0L || security.isBlank()) return Result.failure(workDataOf(KEY_ERROR to "UPLOAD_INVALID"))

        val posterPath = inputData.getString(KEY_POSTER_PATH).orEmpty()
        val videoPath = inputData.getString(KEY_VIDEO_PATH).orEmpty()
        val totalBytes = listOf(posterPath, videoPath).filter { it.isNotBlank() }.sumOf { File(it).length().coerceAtLeast(0L) }
        var completedBytes = 0L
        var currentUploadId = ""
        setForeground(notification("V GHOST • Film yüklənir", "Hazırlanır…", 0, true))
        setProgress(workDataOf(KEY_SENT to 0L, KEY_TOTAL to totalBytes, KEY_PERCENT to 0, KEY_KIND to ""))

        try {
            var posterUrl = inputData.getString(KEY_POSTER_URL).orEmpty()
            var videoUrl = inputData.getString(KEY_VIDEO_URL).orEmpty()

            suspend fun upload(path: String, kind: String, name: String, mime: String): String {
                if (path.isBlank()) return if (kind == "poster") posterUrl else videoUrl
                val file = File(path)
                if (!file.isFile || file.length() <= 0L) throw IllegalStateException("UPLOAD_FILE_MISSING")
                val base = completedBytes
                val result = VGhostApi.adminFilmUpload(
                    filmId, kind, file, name.ifBlank { file.name }, mime.ifBlank { "application/octet-stream" }, security,
                    onProgress = { sent, total ->
                        val overall = (base + sent).coerceAtMost(totalBytes)
                        val percent = if (totalBytes > 0L) ((overall * 100L) / totalBytes).toInt() else 0
                        setProgress(workDataOf(KEY_SENT to overall, KEY_TOTAL to totalBytes, KEY_PERCENT to percent, KEY_KIND to kind, KEY_UPLOAD_ID to currentUploadId))
                    },
                    onUploadId = { uploadId ->
                        currentUploadId = uploadId
                        setProgress(workDataOf(KEY_SENT to base, KEY_TOTAL to totalBytes, KEY_PERCENT to if (totalBytes > 0) ((base * 100L) / totalBytes).toInt() else 0, KEY_KIND to kind, KEY_UPLOAD_ID to uploadId))
                    }
                )
                completedBytes += file.length()
                val url = result.optString("url")
                if (url.isBlank()) throw IllegalStateException("MEDIA_UPLOAD_NO_URL")
                file.delete()
                return url
            }

            posterUrl = upload(posterPath, "poster", inputData.getString(KEY_POSTER_NAME).orEmpty(), inputData.getString(KEY_POSTER_MIME).orEmpty())
            videoUrl = upload(videoPath, "video", inputData.getString(KEY_VIDEO_NAME).orEmpty(), inputData.getString(KEY_VIDEO_MIME).orEmpty())

            VGhostApi.adminFilmSave(
                filmId,
                inputData.getString(KEY_TITLE).orEmpty(),
                inputData.getString(KEY_DESCRIPTION).orEmpty(),
                posterUrl,
                videoUrl,
                inputData.getString(KEY_CATEGORY).orEmpty().ifBlank { "Drama" },
                inputData.getString(KEY_YEAR).orEmpty().toIntOrNull(),
                inputData.getString(KEY_DURATION).orEmpty().toIntOrNull(),
                inputData.getBoolean(KEY_VIP, false),
                inputData.getBoolean(KEY_FEATURED, false),
                true,
                0,
                security
            )
            setProgress(workDataOf(KEY_SENT to totalBytes, KEY_TOTAL to totalBytes, KEY_PERCENT to 100, KEY_KIND to "done", KEY_UPLOAD_ID to ""))
            setForeground(notification("V GHOST • Film hazırdır", "Yükləmə tamamlandı ✓", 100))
            return Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            val path1 = inputData.getString(KEY_POSTER_PATH).orEmpty()
            val path2 = inputData.getString(KEY_VIDEO_PATH).orEmpty()
            runCatching { if (path1.isNotBlank()) File(path1).delete() }
            runCatching { if (path2.isNotBlank()) File(path2).delete() }
            return if (runAttemptCount < 3 && (e.message?.contains("SERVER", true) == true || e is java.io.IOException)) {
                Result.retry()
            } else {
                Result.failure(workDataOf(KEY_ERROR to (e.message ?: "UPLOAD_FAILED")))
            }
        }
    }
}
