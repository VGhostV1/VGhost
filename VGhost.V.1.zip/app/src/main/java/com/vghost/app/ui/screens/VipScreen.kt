package com.vghost.app.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.BuildConfig
import com.vghost.app.i18n.trKey
import com.vghost.app.network.VGhostApi
import com.vghost.app.network.VipBillingManager
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import kotlinx.coroutines.launch

private data class VipPlanUi(val productId: String, val titleKey: String, val fallbackPrice: String, val accent: Color)

@Composable
fun VipScreen(
    onNavigateBack: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }
    val context = LocalContext.current
    val activity = context as? Activity
    var message by remember { mutableStateOf<String?>(null) }
    var vipActive by remember { mutableStateOf(false) }
    var vipUntil by remember { mutableStateOf<String?>(null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val repository = VGhostRepository.instance

    val billing = remember {
        VipBillingManager(
            context = context,
            onVerifiedPurchase = { productId, purchaseToken ->
                try {
                    val result = VGhostApi.call(
                        "vip/google/verify",
                        "POST",
                        org.json.JSONObject()
                            .put("productId", productId)
                            .put("purchaseToken", purchaseToken)
                    )
                    vipActive = result.optBoolean("isVip", true)
                    vipUntil = result.optString("vipExpiresAt").takeIf { it.isNotBlank() && it != "null" }
                    repository.refreshVipStatus()
                    message = trKey("vip_purchase_success")
                    true
                } catch (_: Throwable) {
                    false
                }
            },
            onError = { error -> message = error }
        )
    }
    val products by billing.products.collectAsState()

    LaunchedEffect(Unit) {
        if (!BuildConfig.VIP_TEST_MODE) billing.start()
        try {
            val status = VGhostApi.call("vip/status")
            vipActive = status.optBoolean("isVip", false)
            vipUntil = status.optString("vipExpiresAt").takeIf { it.isNotBlank() && it != "null" }
            repository.refreshVipStatus()
        } catch (_: Throwable) { }
    }
    DisposableEffect(Unit) { onDispose { billing.close() } }

    val plans = listOf(
        VipPlanUi(VipBillingManager.VIP_7D, "vip_7_days", "$0.99", Color(0xFFB94CFF)),
        VipPlanUi(VipBillingManager.VIP_30D, "vip_30_days", "$2.99", Color(0xFF2D8CFF)),
        VipPlanUi(VipBillingManager.VIP_90D, "vip_90_days", "$6.99", Color(0xFFFFC83D)),
        VipPlanUi(VipBillingManager.VIP_1Y, "vip_1_year", "$19.99", Color(0xFFFF3D72))
    )

    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = { VGhostBottomNavBar(currentTab = NavTab.FIND, onTabSelected = onTabSelected) }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, trKey("back_3"), tint = GhostTextWhite)
                }
                Text(trKey("vip_screen_title"), color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
            ) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(26.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF15052A), Color(0xFF020713), Color(0xFF241000))))
                            .border(1.dp, Color(0xFFFFC83D).copy(alpha = .9f), RoundedCornerShape(26.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.WorkspacePremium, null, tint = Color(0xFFFFC83D), modifier = Modifier.size(72.dp))
                            Text(trKey("vip_screen_title"), color = Color(0xFFFFD75A), fontSize = 34.sp, fontWeight = FontWeight.Black)
                            Text(trKey("vip_screen_subtitle"), color = GhostTextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (BuildConfig.VIP_TEST_MODE) {
                    item {
                        Text(
                            trKey("vip_test_mode"),
                            color = Color(0xFFFFC83D),
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFFFFC83D).copy(alpha = .10f))
                                .border(1.dp, Color(0xFFFFC83D).copy(alpha = .55f), RoundedCornerShape(14.dp))
                                .padding(12.dp)
                        )
                    }
                }
                if (vipActive) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFF123D24).copy(alpha = .72f))
                                .border(1.dp, Color(0xFF18D64B).copy(alpha = .7f), RoundedCornerShape(18.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF18D64B), modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(trKey("vip_active"), color = Color(0xFF58F57B), fontWeight = FontWeight.Black)
                                if (vipUntil != null) Text("${trKey("vip_until")}: $vipUntil", color = GhostTextWhite, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item { VipFeatureCard(trKey("vip_feature_badge"), trKey("vip_feature_badge_desc")) }
                item { VipFeatureCard(trKey("vip_feature_frame"), trKey("vip_feature_frame_desc")) }
                item { VipFeatureCard(trKey("vip_feature_color"), trKey("vip_feature_color_desc")) }
                item { VipFeatureCard(trKey("vip_feature_priority"), trKey("vip_feature_priority_desc")) }
                item { Text(trKey("vip_packages"), color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black) }

                items(plans.size) { index ->
                    val plan = plans[index]
                    val details = products[plan.productId]
                    val price = details?.oneTimePurchaseOfferDetailsList?.firstOrNull()?.formattedPrice ?: plan.fallbackPrice
                    VipPlan(
                        title = trKey(plan.titleKey),
                        price = if (BuildConfig.VIP_TEST_MODE) trKey("vip_test_price") else price,
                        accent = plan.accent,
                        available = if (BuildConfig.VIP_TEST_MODE) true else details != null && activity != null,
                        onBuy = {
                            if (BuildConfig.VIP_TEST_MODE) {
                                scope.launch {
                                    try {
                                        val result = VGhostApi.call(
                                            "vip/test/activate",
                                            "POST",
                                            org.json.JSONObject().put("productId", plan.productId)
                                        )
                                        vipActive = result.optBoolean("isVip", true)
                                        vipUntil = result.optString("vipExpiresAt").takeIf { it.isNotBlank() && it != "null" }
                                        repository.refreshVipStatus()
                                        message = trKey("vip_test_activated")
                                    } catch (e: Throwable) {
                                        message = e.message ?: trKey("vip_payment_unavailable")
                                    }
                                }
                            } else if (activity != null) billing.launchPurchase(activity, plan.productId)
                        },
                        testMode = BuildConfig.VIP_TEST_MODE
                    )
                }

                if (message != null) {
                    item {
                        Text(message ?: "", color = GhostTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(GhostSurface.copy(alpha = .8f))
                            .border(1.dp, Color(0xFF2D8CFF).copy(alpha = .7f), RoundedCornerShape(18.dp)).padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Lock, null, tint = Color(0xFF2D8CFF), modifier = Modifier.size(30.dp))
                        Spacer(Modifier.size(10.dp))
                        Column {
                            Text(if (BuildConfig.VIP_TEST_MODE) trKey("vip_test_mode_title") else trKey("vip_secure_payment"), color = GhostTextWhite, fontWeight = FontWeight.Bold)
                            Text(if (BuildConfig.VIP_TEST_MODE) trKey("vip_test_mode_desc") else trKey("vip_secure_payment_desc"), color = GhostTextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VipFeatureCard(title: String, description: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(GhostSurface.copy(alpha = .78f))
            .border(1.dp, Color(0xFF9B4DFF).copy(alpha = .55f), RoundedCornerShape(18.dp)).padding(15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.WorkspacePremium, null, tint = Color(0xFFFFC83D), modifier = Modifier.size(34.dp))
        Spacer(Modifier.size(12.dp))
        Column {
            Text(title, color = GhostTextWhite, fontWeight = FontWeight.Black)
            Text(description, color = GhostTextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun VipPlan(title: String, price: String, accent: Color, available: Boolean, onBuy: () -> Unit, testMode: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(GhostSurface.copy(alpha = .84f))
            .border(1.dp, accent.copy(alpha = .85f), RoundedCornerShape(20.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.WorkspacePremium, null, tint = accent, modifier = Modifier.size(42.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = GhostTextWhite, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text(price, color = accent, fontWeight = FontWeight.Black, fontSize = 22.sp)
        }
        Button(
            onClick = onBuy,
            enabled = available,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
        ) { Text(if (testMode) trKey("vip_test_buy") else trKey("vip_buy"), fontWeight = FontWeight.Black) }
    }
}
