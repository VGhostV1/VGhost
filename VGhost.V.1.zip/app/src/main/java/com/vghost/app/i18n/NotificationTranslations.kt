package com.vghost.app.i18n

import android.content.Context
import java.util.Locale

/** Notification localization backed exclusively by Android string resources. */
internal object NotificationTranslations {
    private val languages=setOf("az","tr","en","ru")
    fun localize(type:String,fallbackTitle:String,fallbackBody:String,data:Map<String,String> = emptyMap()):Pair<String,String> = localizeInternal(VGhostLanguage.context(),type,fallbackTitle,fallbackBody,data)
    fun localize(context:Context,type:String,fallbackTitle:String,fallbackBody:String,data:Map<String,String> = emptyMap()):Pair<String,String> = localizeInternal(context,type,fallbackTitle,fallbackBody,data)
    private fun localizeInternal(context:Context?,type:String,fallbackTitle:String,fallbackBody:String,data:Map<String,String>):Pair<String,String>{
        if(context==null) return fallbackTitle to fallbackBody
        val locale=(AppLocale.current(context)).lowercase(Locale.ROOT).let{if(it in languages)it else "en"}
        // Admin broadcasts contain custom title/body text entered by the administrator.
        // Do not replace that content with the generic localized broadcast template.
        // The generic template is useful for other notification types, but would hide
        // the actual announcement text from the user.
        if (type.equals("broadcast", true)) return fallbackTitle to fallbackBody
        // Resolve resources through the context configured for the selected app language.
        // Do not cache translated strings themselves: the same notification object may
        // be rendered again immediately after the user changes language.
        val localizedContext = AppLocale.wrap(context)
        val prefix="nt_${type.lowercase(Locale.ROOT)}_"
        var title=TranslationResources.textKey(localizedContext,prefix+"title") ?: fallbackTitle
        var body=TranslationResources.textKey(localizedContext,prefix+"body") ?: fallbackBody
        val n=data.toMutableMap()
        if(n["sender"].isNullOrBlank()) n["sender"]=n["senderNickname"].orEmpty()
        if(n["senderNickname"].isNullOrBlank()) n["senderNickname"]=n["sender"].orEmpty()
        // Known fixed-value notifications can still be localized correctly when
        // an old database row has no amount metadata.
        if(n["amount"].isNullOrBlank()) {
            n["amount"]=when(type.lowercase(Locale.ROOT)) {
                "daily_bonus" -> "500"
                "welcome_bonus" -> "1000"
                else -> ""
            }
        }
        n.forEach{(k,v)->
            body=body.replace("{$k}",v)
            body=body.replace("${'$'}{$k}",v)
        }
        // Never expose an unresolved implementation token to the user.
        body=body.replace(Regex("\\{(?:sender|senderNickname|amount)\\}"),"")
            .replace(Regex("\\$\\{(?:sender|senderNickname|amount)\\}"),"")
            .replace(Regex("\\s{2,}")," ")
            .trim()
        return title to body
    }
}
