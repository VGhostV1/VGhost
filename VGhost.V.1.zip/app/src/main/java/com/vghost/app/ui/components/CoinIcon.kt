package com.vghost.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.vghost.app.R

/** Shared, deliberately prominent coin visual used wherever a coin amount is shown. */
@Composable
fun VGhostCoinIcon(
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    contentDescription: String? = "Coin"
) {
    Image(
        painter = painterResource(R.drawable.vghost_coin_icon),
        contentDescription = contentDescription,
        modifier = modifier.size(size)
    )
}

@Composable
fun VGhostCoinAmount(
    text: String,
    modifier: Modifier = Modifier,
    iconSize: Dp = 24.dp,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = 14.sp,
    fontWeight: FontWeight? = null
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        VGhostCoinIcon(size = iconSize)
        Spacer(Modifier.width(5.dp))
        Text(text = text, color = color, fontSize = fontSize, fontWeight = fontWeight)
    }
}
