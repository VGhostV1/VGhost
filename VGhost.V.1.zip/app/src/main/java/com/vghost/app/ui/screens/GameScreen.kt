package com.vghost.app.ui.screens
import com.vghost.app.ui.components.VGhostCoinAmount
import com.vghost.app.ui.components.VGhostCoinIcon
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.vghost.app.R
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.roundToInt
import java.util.Locale
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

private val MineRed = Color(0xFFFF1838)
private val MineRedSoft = Color(0xFFFF334F)
private val MineTile = Color(0xFF121216)
private val StarGold = Color(0xFFFFD76A)

@Composable
fun GameHomeScreen(
    onOpenMines: () -> Unit,
    onOpenJet: () -> Unit,
    onOpenPenalty: () -> Unit,
    onOpenRockfall: () -> Unit,
    onOpenTicTacToe: () -> Unit,
    onAdminSecret: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val coins by repository.ghostCoins.collectAsState()
    LaunchedEffect(Unit) {
        while (true) {
            if (repository.hasAccount()) repository.refreshMyWallet()
            delay(15_000L)
        }
    }
    var logoTaps by remember { mutableStateOf(0) }
    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize().premiumBackdrop(),
            containerColor = Color.Transparent,
            bottomBar = { VGhostBottomNavBar(NavTab.GAME, onTabSelected) }
        ) { innerPadding ->
            Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape)
                        .background(Brush.radialGradient(listOf(MineRed.copy(.34f), Color.Transparent)))
                        .border(1.dp, MineRed.copy(.72f), CircleShape)
                        .clickable {
                            logoTaps++
                            if (logoTaps >= 7) {
                                logoTaps = 0
                                onAdminSecret()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.SportsEsports, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(trKey("vghost"), color = GhostTextWhite, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp)
                    Text(trKey("game"), color = GhostTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                }
                CoinPill(coins)
            }
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(trKey("vghost_games"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
                    Text(trKey("choose_game_start_playing"), color = GhostTextMuted, fontSize = 11.sp)
                }
                // Two-column layout: the next two games can be added as a second row
                // without changing the width of the existing cards.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    GameCatalogCard(onClick = onOpenMines, modifier = Modifier.weight(1f))
                    JetCatalogCard(onClick = onOpenJet, modifier = Modifier.weight(1f))
                }
                // Second row stays in the same 2-column grid so future games can be added
                // without stretching Ghost Penalty across the whole screen.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PenaltyCatalogCard(onClick = onOpenPenalty, modifier = Modifier.weight(1f))
                    RockfallCatalogCard(onClick = onOpenRockfall, modifier = Modifier.weight(1f))
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TicTacToeCatalogCard(onClick = onOpenTicTacToe, modifier = Modifier.weight(1f))
                    Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }

        // Cached authenticated sessions open the Game screen immediately.
        // Session restoration continues in the repository in the background,
        // so a slow auth/me request never blocks the game UI with a startup overlay.
    }
}

@Composable
private fun GameCatalogCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
             .height(170.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1A070A), Color(0xFF0D0B0D))))
            .border(1.dp, MineRed.copy(.78f), RoundedCornerShape(18.dp))
            .shadow(18.dp, RoundedCornerShape(18.dp), ambientColor = MineRed.copy(.20f), spotColor = MineRed.copy(.16f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.game_mines_poster),
            contentDescription = trKey("v_ghost_mines"),
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
    }
}

@Composable
private fun JetCatalogCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
             .height(170.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF071522), Color(0xFF090C12))))
            .border(1.dp, Color(0xFF35BFFF).copy(.74f), RoundedCornerShape(18.dp))
            .shadow(18.dp, RoundedCornerShape(18.dp), ambientColor = Color(0xFF35BFFF).copy(.18f), spotColor = Color(0xFF35BFFF).copy(.14f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.game_jet_poster),
            contentDescription = trKey("v_ghost_jet"),
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
    }
}


@Composable
private fun PenaltyCatalogCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(150.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF261014), Color(0xFF140B0E))))
            .border(1.dp, MineRed.copy(.88f), RoundedCornerShape(18.dp))
            .shadow(14.dp, RoundedCornerShape(18.dp), ambientColor = MineRed.copy(.18f), spotColor = MineRed.copy(.14f))
            .clickable(onClick = onClick)
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(58.dp).clip(CircleShape)
                    .background(Color(0xFF0B0C11))
                    .border(1.dp, Color.White.copy(.16f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(trKey("football"), fontSize = 38.sp) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(trKey("ghost"), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                Text(trKey("penalty"), color = MineRedSoft, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(4.dp))
                Text(trKey("choose_one_9_targets"), color = GhostTextMuted, fontSize = 9.sp, textAlign = TextAlign.Center, modifier = Modifier.offset(y = (-3).dp))
            }
        }
    }
}

@Composable
private fun RockfallCatalogCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val pulse by rememberInfiniteTransition(label = "rockfall-card").animateFloat(
        initialValue = 0.88f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "glow"
    )
    Box(
        modifier
            .height(150.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF24103A), Color(0xFF090A11))))
            .border(1.dp, Color(0xFF9B4DFF).copy(.88f), RoundedCornerShape(18.dp))
            .shadow(18.dp, RoundedCornerShape(18.dp), ambientColor = Color(0xFF9B4DFF).copy(.22f), spotColor = Color(0xFFFF2D55).copy(.16f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(trKey("diamond"), fontSize = 32.sp, modifier = Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse })
            Spacer(Modifier.height(3.dp))
            Text(trKey("vghost"), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text(trKey("rockfall"), color = Color(0xFFFFB32D), fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
            Spacer(Modifier.height(4.dp))
            Text(trKey("match_bullet_combo_bullet_win"), color = GhostTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
        }
    }
}


@Composable
private fun TicTacToeCatalogCard(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(150.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF160A20), Color(0xFF080A12))))
            .border(1.dp, Color(0xFFFF2452).copy(.9f), RoundedCornerShape(18.dp))
            .shadow(18.dp, RoundedCornerShape(18.dp), ambientColor = Color(0xFFFF2452).copy(.22f), spotColor = Color(0xFF168BFF).copy(.18f))
            .clickable(onClick = onClick)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(trKey("x"), color = Color(0xFF28A8FF), fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text(trKey("o"), color = Color(0xFFFF3158), fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text(trKey("x"), color = Color(0xFF28A8FF), fontSize = 30.sp, fontWeight = FontWeight.Black)
            }
            Text(trKey("tic_tac_toe"), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
            Spacer(Modifier.height(3.dp))
            Text(trKey("x_v_o_bullet_3_n_bi_rl_di_r"), color = GhostTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
        }
    }
}
@Composable
private fun CoinPill(coins: Int) {
    Row(
        Modifier.clip(RoundedCornerShape(15.dp)).background(GhostSurface)
            .border(1.dp, GhostBorder, RoundedCornerShape(15.dp))
            .padding(horizontal = 11.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VGhostCoinAmount(coins.toString(), iconSize = 26.dp, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
    }
}

private data class MineCell(val mine: Boolean)

@Composable
fun VGhostJetScreen(
    onBack: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val coins by repository.ghostCoins.collectAsState()
    val gameError by repository.lastGameError.collectAsState()
    val audio = rememberGameAudio(LocalContext.current, "jet")
    var bet by remember { mutableStateOf(10) }
    var multiplier by remember { mutableStateOf(1.00) }
    var crashAt by remember { mutableStateOf(0.0) }
    var running by remember { mutableStateOf(false) }
    var crashed by remember { mutableStateOf(false) }
    var cashedOut by remember { mutableStateOf(false) }
    var win by remember { mutableStateOf(0) }
    var roundId by remember { mutableStateOf<String?>(null) }
    val gameScope = rememberCoroutineScope()

    val flightPulse = rememberInfiniteTransition(label = "jet_flight")
    val pulse by flightPulse.animateFloat(
        initialValue = 0.72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "jet_glow"
    )
    val enginePulse by flightPulse.animateFloat(
        initialValue = 0.65f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420), RepeatMode.Reverse),
        label = "engine_glow"
    )

    val jetLift by animateFloatAsState(
        targetValue = when {
            crashed -> 0.12f
            running -> ((multiplier - 1.0) / 10.0).toFloat().coerceIn(0f, 0.82f)
            else -> 0.18f
        },
        animationSpec = tween(500),
        label = "jet_lift"
    )

    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        while (running) {
            kotlinx.coroutines.delay(80)
            multiplier = (multiplier + 0.025).coerceAtMost(50.0)
            if (multiplier >= crashAt) {
                multiplier = crashAt
                running = false
                crashed = true
                audio.play("jet_crash")
                cashedOut = false
                roundId?.let { id ->
                    gameScope.launch { repository.cashOutJet(id) }
                }
                roundId = null
            }
        }
    }

    fun startRound() {
        if (running) return
        gameScope.launch {
            val r = repository.startGame("jet", bet) ?: return@launch
            roundId = r.optString("roundId").takeIf { it.isNotBlank() }
            audio.play("jet_start")
            multiplier = 1.00
            crashAt = r.optDouble("crashAt", 1.35)
            running = true
            crashed = false
            cashedOut = false
            win = 0
        }
    }

    fun payoutAt(currentMultiplier: Double): Int = (bet * currentMultiplier).roundToInt().coerceAtLeast(bet)

    fun cashOut() {
        val id = roundId ?: return
        if (!running || multiplier < 1.01) return
        gameScope.launch {
            val r = repository.cashOutJet(id) ?: return@launch
            audio.play("jet_cashout")
            win = r.optInt("payout", payoutAt(multiplier))
            multiplier = r.optDouble("multiplier", multiplier)
            crashAt = r.optDouble("crashAt", crashAt)
            running = false
            cashedOut = true
            crashed = false
            roundId = null
        }
    }

    val displayedWin = if (cashedOut) win else if (running) payoutAt(multiplier) else 0
    val statusText = when {
        crashed -> trKey("flight_crashed")
        cashedOut -> trKey("flight_secured")
        running -> trKey("collect_before_crash_2")
        else -> tr(trKey("ready_takeoff"))
    }
    val statusColor = when {
        crashed -> MineRedSoft
        cashedOut -> StarGold
        else -> Color(0xFF7DDBFF)
    }

    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = { VGhostBottomNavBar(NavTab.GAME, onTabSelected) }
    ) { innerPadding ->
        Column(
            Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(Modifier.fillMaxWidth().height(42.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape)
                        .background(Color(0xFF35BFFF).copy(.12f))
                        .border(1.dp, Color(0xFF35BFFF).copy(.70f), CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.ArrowBack, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(trKey("vghost_jet"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text(trKey("live_flight_bullet_virtual_gc"), color = Color(0xFF58CFFF), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                }
                CoinPill(coins)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                CompactStat(trKey("current"), if (running) "${String.format(Locale.US, "%.2f", multiplier)}x" else "1.00x", Modifier.weight(1f), statusColor)
                CompactStat(trKey("reward"), if (displayedWin > 0) "💰 +$displayedWin" else "—", Modifier.weight(1f), if (displayedWin > 0) Color(0xFF6DFFAA) else Color.White)
                CompactStat(trKey("crash"), if (crashAt > 0 && (crashed || cashedOut)) "${String.format(Locale.US, "%.2f", crashAt)}x" else "?", Modifier.weight(1f), MineRedSoft)
            }

            Box(
                Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF031A2A), Color(0xFF06111C), Color(0xFF02050A))
                        )
                    )
                    .border(1.dp, Color(0xFF35BFFF).copy(.62f), RoundedCornerShape(22.dp))
                    .shadow(20.dp, RoundedCornerShape(22.dp), ambientColor = Color(0xFF35BFFF).copy(.22f), spotColor = Color(0xFF35BFFF).copy(.18f)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize().padding(12.dp)) {
                    val w = size.width
                    val h = size.height
                    val horizon = h * .72f
                    for (i in 1..6) {
                        val y = horizon + i * 34f
                        drawLine(color = Color(0xFF35BFFF).copy(.055f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f)
                    }
                    for (i in 1..8) {
                        val x = i * w / 9f
                        drawLine(color = Color(0xFF35BFFF).copy(.04f), start = Offset(x, horizon), end = Offset(x - w * .16f, 0f), strokeWidth = 1f)
                    }
                    val progress = ((multiplier - 1.0) / 9.0).toFloat().coerceIn(.03f, .94f)
                    val startX = w * .08f
                    val startY = h * .76f
                    val endX = w * (.12f + progress * .76f)
                    val endY = h * (.73f - progress * .52f)
                    drawLine(color = Color(0xFF35BFFF).copy(.16f), start = Offset(startX, startY), end = Offset(endX, endY), strokeWidth = 9f, cap = StrokeCap.Round)
                    drawLine(color = Color(0xFF8BE5FF).copy(.42f), start = Offset(startX, startY), end = Offset(endX, endY), strokeWidth = 2f, cap = StrokeCap.Round)
                    drawCircle(Color(0xFF7DDBFF).copy(.14f), 22f, androidx.compose.ui.geometry.Offset(endX, endY))
                    drawCircle(Color(0xFF7DDBFF).copy(.18f * pulse), 9f, androidx.compose.ui.geometry.Offset(endX, endY))
                }

                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier.clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(.42f))
                            .border(1.dp, statusColor.copy(.42f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(statusText, color = statusColor, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        when {
                            crashed -> trKey("crashed")
                            cashedOut -> "${String.format(Locale.US, "%.2f", multiplier)}x"
                            else -> "${String.format(Locale.US, "%.2f", multiplier)}x"
                        },
                        color = statusColor,
                        fontSize = 54.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-1.5).sp
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(trKey("ghost_jet"), color = Color.White.copy(.86f), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 2.2.sp)
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.size(84.dp).offset(y = (-jetLift * 20).dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier.size(70.dp).clip(CircleShape)
                                .background(Color(0xFF35BFFF).copy(.10f * pulse))
                                .border(1.dp, Color(0xFF35BFFF).copy(.34f), CircleShape)
                        )
                        Text(if (crashed) "💥" else "✈️", fontSize = 43.sp)
                        if (running) {
                            Text(trKey("text_4"), color = Color(0xFF35BFFF).copy(enginePulse), fontSize = 28.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 2.dp))
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        when {
                            crashed -> trf(trKey("jet_crashed_2fx"), crashAt)
                            cashedOut -> trf(trKey("gc_added_balance"), win)
                            running -> trKey("stay_sharp_bullet_every_second_raises_multiplier")
                            else -> trKey("push_multiplier_bullet_collect_reward_time")
                        },
                        color = GhostTextSecondary,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CompactSelector(trKey("play_cost"), com.vghost.app.i18n.VGhostLanguage.trfKey("gc_2", bet), com.vghost.app.i18n.VGhostLanguage.trKey("g"), Modifier.weight(1f)) {
                    if (!running) {
                        val bets = listOf(10, 20, 30, 40, 50)
                        bet = bets[(bets.indexOf(bet) + 1) % bets.size]
                    }
                }
                CompactNextWin(displayedWin, multiplier, Modifier.weight(1.25f))
            }

            if (!gameError.isNullOrBlank() && !running) { Text(gameError!!, color = MineRedSoft, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }

            ActionButton(
                title = if (running) trKey("collect") else if (crashed || cashedOut) trKey("play_again") else trKey("start_flight"),
                value = if (running) "${String.format(Locale.US, "%.2f", multiplier)}x  •  $displayedWin GC" else com.vghost.app.i18n.VGhostLanguage.trfKey("gc_2", bet),
                modifier = Modifier.fillMaxWidth(),
                enabled = true
            ) {
                if (running) cashOut() else startRound()
            }
        }
    }
}

@Composable
fun GhostMinesScreen(
    onBack: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val coins by repository.ghostCoins.collectAsState()
    val gameError by repository.lastGameError.collectAsState()
    val audio = rememberGameAudio(LocalContext.current, "mines")
    var mineCount by remember { mutableStateOf(4) }
    var bet by remember { mutableStateOf(10) }
    var cells by remember { mutableStateOf<List<MineCell>>(emptyList()) }
    var revealed by remember { mutableStateOf(setOf<Int>()) }
    var collected by remember { mutableStateOf(0) }
    var gameOver by remember { mutableStateOf(false) }
    var started by remember { mutableStateOf(false) }
    var won by remember { mutableStateOf(false) }
    var showWinOverlay by remember { mutableStateOf(false) }
    var roundId by remember { mutableStateOf<String?>(null) }
    val gameScope = rememberCoroutineScope()

    // Keep the first five milestones from the original design, then keep
    // increasing the multiplier for every additional safe reveal until the
    // board is finished. This removes the old 5-star cap.
    fun multiplierFor(safeStars: Int): Double {
        // More mines = more risk, so the same safe reveal pays more.
        // 4 mines keeps the original multipliers; 6 mines gets a 1.50x risk bonus.
        val base = when {
            safeStars <= 0 -> 1.00
            safeStars == 1 -> 1.20
            safeStars == 2 -> 1.50
            safeStars == 3 -> 2.00
            safeStars == 4 -> 3.00
            else -> 5.00 + ((safeStars - 5) * 1.00)
        }
        val mineRiskBonus = when (mineCount) {
            3 -> 1.00
            4 -> 1.15
            5 -> 1.30
            else -> 1.50
        }
        return base * mineRiskBonus
    }

    val multiplier = multiplierFor(revealed.size)
    val nextMultiplier = multiplierFor(revealed.size + 1)
    val nextWin = if (started) (bet * nextMultiplier).roundToInt() else 0
    val currentWin = if (started && revealed.isNotEmpty()) (bet * multiplier).roundToInt() else if (won) collected else 0

    if (showWinOverlay) {
        Dialog(
            onDismissRequest = {},
            properties = DialogProperties(
                dismissOnBackPress = false,
                dismissOnClickOutside = false,
                usePlatformDefaultWidth = false
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.radialGradient(listOf(MineRed.copy(.38f), Color.Black, Color(0xFF070709))))
                    .border(1.dp, MineRedSoft.copy(.85f), RoundedCornerShape(24.dp))
                    .padding(horizontal = 24.dp, vertical = 30.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    trKey("congratulations_alert_won"),
                    color = Color.White,
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    fun resetBoard(refundActiveBet: Boolean = true) {
        val id = roundId
        if (refundActiveBet && started && id != null) {
            gameScope.launch {
                if (repository.cancelGame(id) != null) {
                    started = false; gameOver = false; won = false; showWinOverlay = false; revealed = emptySet(); collected = 0; cells = emptyList(); roundId = null
                }
            }
            return
        }
        started = false
        gameOver = false
        won = false
        showWinOverlay = false
        revealed = emptySet()
        collected = 0
        cells = emptyList()
        roundId = null
    }

    fun newGame() {
        if (started) return
        gameScope.launch {
            val r = repository.startGame("mines", bet, mineCount) ?: return@launch
            val id = r.optString("roundId").takeIf { it.isNotBlank() } ?: return@launch
            // Mine positions stay server-side until the round ends. The backend
            // returns them only after a loss/full-board win so the UI can reveal
            // the finished board without leaking the result at game start.
            roundId = id
            cells = (0 until 25).map { MineCell(false) }
            revealed = emptySet(); collected = 0; gameOver = false; won = false; showWinOverlay = false; started = true
        }
    }

    fun cashOut() {
        val id = roundId ?: return
        if (!started || gameOver || revealed.isEmpty()) return
        gameScope.launch {
            val r = repository.cashOutMines(id) ?: return@launch
            collected = r.optInt("payout", collected)
            won = true
            started = false
            roundId = null
        }
    }

    fun playOrReplay() {
        // A replay must work both after a win and after hitting a mine.
        // Clear the previous round first, then start a fresh board.
        if (gameOver || won) resetBoard(refundActiveBet = false)
        newGame()
    }

    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = { VGhostBottomNavBar(NavTab.GAME, onTabSelected) }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 12.dp, vertical = 5.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(Modifier.fillMaxWidth().height(42.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Color.Black.copy(.65f))
                        .border(1.dp, Color.White.copy(.16f), RoundedCornerShape(13.dp)).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.ArrowBack, trKey("back_3"), tint = Color.White, modifier = Modifier.size(25.dp)) }
                Spacer(Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(trKey("ghost"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Text(" "+trKey("mines_2"), color = MineRedSoft, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                }
                Spacer(Modifier.weight(1f))
                CoinPill(coins)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                CompactStat(trKey("ghost_coin_balance"), "💰 $coins", Modifier.weight(1f))
                CompactStat(trKey("last_reward"), if (won) "💰 +$collected" else "—", Modifier.weight(1f), if (won) Color(0xFF35F06D) else Color.White)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                CompactSelector(trKey("mines_2"), mineCount.toString(), com.vghost.app.i18n.VGhostLanguage.trKey("text_5"), Modifier.weight(1f)) {
                    if (!started) {
                        val mineOptions = listOf(3, 4, 5, 6)
                        mineCount = mineOptions[(mineOptions.indexOf(mineCount) + 1) % mineOptions.size]
                    }
                }
                CompactNextWin(nextWin, nextMultiplier, Modifier.weight(1.45f))
                CompactSelector(trKey("play_cost"), com.vghost.app.i18n.VGhostLanguage.trfKey("gc_2", bet), com.vghost.app.i18n.VGhostLanguage.trKey("g"), Modifier.weight(1f)) {
                    if (!started) {
                        val bets = listOf(10, 20, 30, 40, 50)
                        bet = bets[(bets.indexOf(bet) + 1) % bets.size]
                    }
                }
            }

            BoxWithConstraints(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                // The grid gets all remaining space, but is capped so the five rows
                // never become an oversized/tall section on short phones.
                val boardHeight = maxHeight.coerceAtMost(maxWidth * 1.02f)
                Box(
                    Modifier.fillMaxWidth().height(boardHeight)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.radialGradient(listOf(Color(0xFF190306), Color(0xFF070709), Color.Black)))
                        .border(1.dp, MineRed.copy(.75f), RoundedCornerShape(20.dp))
                        .padding(7.dp)
                ) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        repeat(5) { row ->
                            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                repeat(5) { col ->
                                    val index = row * 5 + col
                                    val cell = cells.getOrNull(index)
                                    MineGhostTile(
                                        cell = cell,
                                        revealed = index in revealed,
                                        showMine = gameOver || won,
                                        enabled = started && !gameOver && !won && cell != null,
                                        onClick = {
                                            if (!started || gameOver || won || index in revealed || cell == null) return@MineGhostTile
                                            val id = roundId ?: return@MineGhostTile
                                            gameScope.launch {
                                                audio.play("click")
                                                val r = repository.revealMines(id, index) ?: return@launch
                                                val isMine = r.optBoolean("mine", false)
                                                if (isMine) {
                                                    audio.play("boom")
                                                    val mineArray = r.optJSONArray("mines")
                                                    if (mineArray != null) {
                                                        val mineSet = buildSet { for (i in 0 until mineArray.length()) add(mineArray.optInt(i)) }
                                                        cells = (0 until 25).map { MineCell(it in mineSet) }
                                                    }
                                                    gameOver = true
                                                    started = false
                                                    collected = 0
                                                    roundId = null
                                                    return@launch
                                                }
                                                audio.play("safe")
                                                val a = r.optJSONArray("revealed")
                                                if (a != null) {
                                                    revealed = buildSet { for (i in 0 until a.length()) add(a.optInt(i)) }
                                                } else {
                                                    revealed = revealed + index
                                                }
                                                collected = r.optInt("payout", collected)
                                                val allSafeCellsOpened = revealed.size >= (25 - mineCount)
                                                if (r.optString("status") == "won" || allSafeCellsOpened) {
                                                    val mineArray = r.optJSONArray("mines")
                                                    if (mineArray != null) {
                                                        val mineSet = buildSet { for (i in 0 until mineArray.length()) add(mineArray.optInt(i)) }
                                                        cells = (0 until 25).map { MineCell(it in mineSet) }
                                                    }
                                                    won = true
                                                    started = false
                                                    roundId = null
                                                    showWinOverlay = true
                                                    gameScope.launch {
                                                        delay(10_000)
                                                        showWinOverlay = false
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (!gameError.isNullOrBlank() && !started) { Text(gameError!!, color = MineRedSoft, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }

            Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (!started) {
                    val canReplay = won || gameOver
                    val canStart = bet <= coins
                    ActionButton(
                        title = if (canReplay) trKey("play_again") else trKey("start_game_2"),
                        value = if (canStart) com.vghost.app.i18n.VGhostLanguage.trfKey("gc_2", bet) else trKey("not_enough_coins"),
                        modifier = Modifier.weight(2.15f),
                        enabled = true,
                        onClick = { playOrReplay() }
                    )
                } else {
                    ActionButton(
                        title = trKey("collect"), value = trfKey("h_daea34d6516f", if (currentWin > 0) currentWin else bet),
                        modifier = Modifier.weight(2.15f), enabled = revealed.isNotEmpty(), onClick = { cashOut() }
                    )
                }
                Box(
                    Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(.45f))
                        .border(1.dp, MineRed.copy(.65f), RoundedCornerShape(16.dp)).clickable(onClick = { resetBoard() }),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(trKey("reset_2"), color = MineRedSoft, fontSize = 9.sp, fontWeight = FontWeight.Black)
                        Icon(Icons.Outlined.Refresh, trKey("reset"), tint = MineRedSoft, modifier = Modifier.size(22.dp))
                    }
                }
            }
            Text(
                trKey("only_virtual_ghost_coin_bullet_no_real_money_value"), color = GhostTextMuted, fontSize = 8.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().height(14.dp)
            )
        }
    }
}

@Composable
fun VGhostPenaltyScreen(
    onBack: () -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val coins by repository.ghostCoins.collectAsState()
    val gameError by repository.lastGameError.collectAsState()
    val audio = rememberGameAudio(LocalContext.current, "penalty")
    val betOptions = listOf(10, 20, 30, 40, 50)
    val levelMultipliers = listOf(1.30, 2.60, 3.90, 5.20, 10.00)
    var bet by remember { mutableStateOf(10) }
    var roundId by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var keeper by remember { mutableStateOf<Int?>(null) }
    var playing by remember { mutableStateOf(false) }
    var resolving by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(1) }
    // Number of successfully completed levels. After every goal the player may cash out.
    var completedLevels by remember { mutableStateOf(0) }
    var cashingOut by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf(trKey("start_game_choose_spot_goal")) }
    val scope = rememberCoroutineScope()
    val multiplier = levelMultipliers[(level - 1).coerceIn(0, 4)]
    val goal = selected != null && keeper != null && selected != keeper
    val shotTarget = if (selected != null) 1f else 0f
    val shotProgress by animateFloatAsState(
        targetValue = shotTarget,
        animationSpec = tween(620),
        label = "penalty_shot"
    )

    fun resetPenalty() {
        scope.launch { roundId?.let { repository.cancelGame(it) } }
        roundId = null
        selected = null
        keeper = null
        playing = false
        resolving = false
        level = 1
        completedLevels = 0
        cashingOut = false
        message = trKey("game_reset_bullet_can_start_again")
    }

    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = { VGhostBottomNavBar(NavTab.GAME, onTabSelected) }
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(.42f)).border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable { onBack() }, contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.ArrowBack, null, tint = Color.White) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(trKey("ghost"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text(trKey("penalty"), color = MineRedSoft, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                }
                CoinPill(coins)
            }

            Text(
                text = message,
                color = when {
                    keeper == null -> GhostTextMuted
                    goal -> Color(0xFF70F5A1)
                    else -> MineRedSoft
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            PenaltyPitch(
                selected = selected,
                keeper = keeper,
                shotProgress = shotProgress,
                enabled = playing && !resolving && selected == null,
                onZoneClick = { index ->
                    if (!playing || resolving || selected != null) return@PenaltyPitch
                    selected = index
                    resolving = true
                    message = trfKey("level_bullet_shot_progress_football", level)
                    scope.launch {
                        audio.play("click")
                        val result = repository.shootPenalty(roundId ?: return@launch, index, multiplier)
                        if (result == null) {
                            selected = null
                            keeper = null
                            resolving = false
                            message = trKey("error_occurred_try_again")
                            return@launch
                        }
                        keeper = result.optInt("keeperIndex", -1).takeIf { it in 0..8 }
                        val won = result.optBoolean("goal", false)
                        val resultLevel = result.optInt("level", level).coerceIn(1, 5)
                        delay(700)
                        if (!won) {
                            playing = false
                            resolving = false
                            audio.play("miss")
                            message = trfKey("goalkeeper_saved_it_alert_stopped_level", resultLevel)
                        } else if (resultLevel >= 5 || result.optString("status") == "won" || completedLevels >= 4) {
                            playing = false
                            resolving = false
                            level = 5
                            completedLevels = 5
                            roundId = null
                            message = trKey("congratulations_alert_won")
                            scope.launch {
                                delay(10_000)
                                if (!playing && completedLevels >= 5) {
                                    message = trKey("game_reset_bullet_can_start_again")
                                }
                            }
                        } else {
                            completedLevels = resultLevel
                            level = resultLevel + 1
                            selected = null
                            keeper = null
                            resolving = false
                            playing = true
                            audio.play("goal")
                            message = trfKey("goal_alert_fire_passed_level_bullet_level_harder", resultLevel, resultLevel + 1)
                        }
                    }
                }
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CompactStat(trKey("play_cost"), com.vghost.app.i18n.VGhostLanguage.trfKey("gc_2", bet), Modifier.weight(1f))
                CompactStat(trKey("level_2"), "${if (completedLevels >= 5) 5 else level} / 5", Modifier.weight(1.18f), StarGold)
                CompactStat(trKey("balance"), "💰 $coins", Modifier.weight(1f), StarGold)
            }

            if (!gameError.isNullOrBlank() && !resolving) {
                Text(
                    gameError!!,
                    color = MineRedSoft,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Mines-style quick bet presets. Touch a value to increase the stake.
            Row(
                Modifier.fillMaxWidth().height(42.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                betOptions.forEach { amount ->
                    val active = bet == amount
                    Box(
                        Modifier.weight(1f).fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (active) MineRed.copy(.88f) else GhostSurface)
                            .border(1.dp, if (active) MineRedSoft else GhostBorder, RoundedCornerShape(12.dp))
                            .clickable(enabled = !playing && !resolving && amount <= coins) { bet = amount },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(trfKey("text_8", amount), color = if (amount <= coins) Color.White else GhostTextMuted.copy(.55f), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            // After every successful goal, the player can secure the current winnings.
            if (playing && completedLevels > 0) {
                val cashMultiplier = levelMultipliers[(completedLevels - 1).coerceIn(0, 4)]
                val cashAmount = (bet * cashMultiplier).roundToInt()
                Box(
                    Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF113622), Color(0xFF0A2115))))
                        .border(1.dp, Color(0xFF42E889).copy(.80f), RoundedCornerShape(14.dp))
                        .clickable(enabled = !resolving && !cashingOut) {
                            val id = roundId ?: return@clickable
                            cashingOut = true
                            resolving = true
                            scope.launch {
                                val r = repository.cashOutPenalty(id)
                                cashingOut = false
                                resolving = false
                                if (r != null) {
                                    val payout = r.optInt("payout", cashAmount)
                                    val m = r.optDouble("multiplier", cashMultiplier)
                                    playing = false
                                    roundId = null
                                    audio.play("cashout")
                                    message = trfKey("reward_gc_bullet_x_2_2f_2", payout, m)
                                } else {
                                    message = trKey("reward_failed_bullet_try_again")
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (cashingOut) trKey("collecting_reward") else trfKey("collect_bullet_gc_bullet_x_2_2f", cashAmount, cashMultiplier),
                        color = Color(0xFF70F5A1), fontSize = 12.sp, fontWeight = FontWeight.Black
                    )
                }
            }

            ActionButton(
                title = when {
                    resolving -> trKey("shot_progress")
                    playing -> trfKey("level_bullet_choose_spot_goal", level)
                    else -> trKey("start_game")
                },
                value = if (playing) trfKey("ui_game_playing", bet, level, String.format(Locale.US, "%.2f", multiplier)) else if (bet <= coins) trfKey("ui_game_ready", bet) else trfKey("ui_insufficient_balance", bet),
                modifier = Modifier.fillMaxWidth(),
                enabled = !playing && !resolving && selected == null,
                onClick = {
                    scope.launch {
                        val r = repository.startGame("penalty", bet)
                        if (r != null) {
                            roundId = r.optString("roundId")
                            selected = null
                            keeper = null
                            playing = true
                            resolving = false
                            level = 1
                            completedLevels = 0
                            cashingOut = false
                            audio.play("click")
                            message = trKey("football_level_1_5_bullet_choose_one_9_large_targets")
                        } else message = trKey("check_balance_connection")
                    }
                }
            )

            Box(
                Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(.32f))
                    .border(1.dp, MineRed.copy(.65f), RoundedCornerShape(14.dp))
                    .clickable(enabled = !resolving) { resetPenalty() },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Refresh, null, tint = MineRedSoft, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(trKey("restart"), color = MineRedSoft, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }

            Text(trKey("only_virtual_ghost_coin_bullet_no_real_money_value"), color = GhostTextMuted, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun PenaltyPitch(
    selected: Int?,
    keeper: Int?,
    shotProgress: Float,
    enabled: Boolean,
    onZoneClick: (Int) -> Unit
) {
    val glow = rememberInfiniteTransition(label = "penalty_glow")
    val pulse by glow.animateFloat(
        initialValue = 0.68f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1050), RepeatMode.Reverse),
        label = "target_pulse"
    )
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(340.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xFF061018))
            .border(1.dp, Color.White.copy(.16f), RoundedCornerShape(28.dp))
    ) {
        // Wide stadium art is centered and cropped by height, so the goal stays
        // proportionate inside the portrait card without stretching the image.
        Image(
            painter = painterResource(R.drawable.penalty_stadium_bg),
            contentDescription = trKey("penalty_stadium"),
            contentScale = ContentScale.Crop,
            alignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(.10f),
                        Color.Transparent,
                        Color.Black.copy(.20f)
                    )
                )
            )
        )

        fun zone(index: Int): Pair<Float, Float> {
            val row = index / 3
            val col = index % 3
            val xs = floatArrayOf(-0.29f, 0f, 0.29f)
            val ys = floatArrayOf(-0.20f, -0.02f, 0.15f)
            return xs[col] to ys[row]
        }

        val keeperZone = keeper?.let { zone(it) } ?: (0f to 0f)
        val keeperX = maxWidth * keeperZone.first * shotProgress
        val keeperY = maxHeight * keeperZone.second * shotProgress

        Image(
            painter = painterResource(R.drawable.penalty_ghost),
            contentDescription = trKey("ghost_goalkeeper"),
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(102.dp)
                .align(Alignment.Center)
                .offset(x = keeperX, y = keeperY + 18.dp)
        )

        // The football starts at the bottom-center and flies directly toward
        // the target the player selected. It never spins.
        val ballZone = selected?.let { zone(it) } ?: (0f to 0f)
        val ballStartOffsetY = -8f
        val ballTargetCenterY = maxHeight.value / 2f + (ballZone.second * maxHeight.value)
        val ballTargetOffsetY = ballTargetCenterY - (maxHeight.value - 38f)
        val ballX = maxWidth.value * ballZone.first * shotProgress
        val ballY = ballStartOffsetY + (ballTargetOffsetY - ballStartOffsetY) * shotProgress
        Image(
            painter = painterResource(R.drawable.penalty_ball),
            contentDescription = trKey("football_2"),
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(76.dp)
                .align(Alignment.BottomCenter)
                .offset(
                    x = ballX.dp,
                    y = ballY.dp
                )
        )

        Row(
            Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                .clip(RoundedCornerShape(50.dp))
                .background(Color.Black.copy(.60f))
                .border(1.dp, Color.White.copy(.18f), RoundedCornerShape(50.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(trKey("football"), fontSize = 14.sp)
            Spacer(Modifier.width(6.dp))
            Text(trKey("choose_one_9_targets_2"),
                color = Color.White.copy(.92f),
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.1.sp
            )
        }

        // Large premium 3×3 targets: intentionally roomy and easy to tap.
        if (enabled) {
            Column(
                Modifier
                    .fillMaxWidth(.86f)
                    .height(174.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = 102.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                repeat(3) { row ->
                    Row(
                        Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        repeat(3) { col ->
                            val i = row * 3 + col
                            val shape = RoundedCornerShape(15.dp)
                            Box(
                                Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .clip(shape)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Black.copy(.12f),
                                                MineRed.copy(.045f * pulse)
                                            )
                                        )
                                    )
                                    .border(
                                        1.4.dp,
                                        MineRed.copy(.52f * pulse),
                                        shape
                                    )
                                    .shadow(
                                        8.dp,
                                        shape,
                                        ambientColor = MineRed.copy(.10f * pulse),
                                        spotColor = MineRed.copy(.08f * pulse)
                                    )
                                    .clickable { onZoneClick(i) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(trKey("text_22"),
                                    color = Color.White.copy(.68f),
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }

        Text(
            if (enabled) trKey("choose_target") else if (selected != null) trKey("shot_complete") else trKey("ghost_penalty_arena"),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 9.dp),
            color = if (enabled) StarGold else Color.White.copy(.58f),
            fontSize = 8.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.8.sp
        )
    }
}

@Composable
private fun CompactStat(label: String, value: String, modifier: Modifier, valueColor: Color = Color.White) {
    Column(
        modifier.height(64.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(.55f))
            .border(1.dp, MineRed.copy(.55f), RoundedCornerShape(14.dp)).padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            label, color = GhostTextSecondary,
            fontSize = if (label.length > 13) 6.sp else 7.sp,
            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false
        )
        if (value.contains("GC") || value.startsWith("💰")) {
            val cleanValue = value.removePrefix("💰 ")
            VGhostCoinAmount(
                cleanValue,
                iconSize = 22.dp,
                color = valueColor,
                fontSize = if (cleanValue.length > 11) 13.sp else 15.sp,
                fontWeight = FontWeight.Black
            )
        } else {
            Text(
                value, color = valueColor,
                fontSize = if (value.length > 11) 13.sp else 15.sp,
                fontWeight = FontWeight.Black, maxLines = 1, softWrap = false
            )
        }
    }
}

@Composable
private fun CompactSelector(title: String, value: String, icon: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(60.dp).clip(RoundedCornerShape(15.dp)).background(Color.Black.copy(.62f))
            .border(1.dp, Color.White.copy(.15f), RoundedCornerShape(15.dp)).clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 6.dp)
    ) {
        Text(title, color = GhostTextSecondary, fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (value.contains("GC")) {
                VGhostCoinIcon(size = 21.dp)
                Spacer(Modifier.width(4.dp))
                Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
            } else {
                Text(icon, fontSize = 13.sp)
                Spacer(Modifier.width(4.dp))
                Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
            }
            Spacer(Modifier.weight(1f))
            Text(trKey("arrow_down"), color = GhostTextSecondary, fontSize = 17.sp)
        }
    }
}

@Composable
private fun CompactNextWin(value: Int, multiplier: Double, modifier: Modifier) {
    Column(
        modifier.height(60.dp).clip(RoundedCornerShape(15.dp)).background(Color.Black.copy(.70f))
            .border(1.dp, MineRed.copy(.62f), RoundedCornerShape(15.dp)).padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(trKey("next_reward"), color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = .6.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (value > 0) trfKey("h_daea34d6516f", value) else trKey("h_1b93795b9768"), color = Color(0xFFFFB51E), fontSize = 15.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(5.dp))
            Box(Modifier.clip(RoundedCornerShape(9.dp)).border(1.dp, Color(0xFFFFB51E).copy(.55f), RoundedCornerShape(9.dp)).padding(horizontal = 6.dp, vertical = 3.dp)) {
                Text(trfKey("h_4e63f921502f", multiplier), color = Color(0xFFFFB51E), fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun RowScope.MineGhostTile(
    cell: MineCell?, revealed: Boolean, showMine: Boolean, enabled: Boolean, onClick: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "tile_glow")
    val pulse by transition.animateFloat(.70f, 1f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "tile_pulse")
    val border = when {
        revealed -> StarGold.copy(.95f)
        showMine && cell?.mine == true -> MineRed.copy(.95f)
        else -> Color.White.copy(.18f)
    }
    Box(
        Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(11.dp))
            .background(
                when {
                    revealed -> Brush.radialGradient(listOf(Color(0xFF5B3A08), Color(0xFF17120A)))
                    showMine && cell?.mine == true -> Brush.radialGradient(listOf(Color(0xFF4B080D), Color(0xFF140608)))
                    else -> Brush.radialGradient(listOf(Color(0xFF1B1B20), MineTile))
                }
            )
            .border(if (revealed || (showMine && cell?.mine == true)) 1.6.dp else 1.dp, border, RoundedCornerShape(11.dp))
            .shadow(if (revealed || (showMine && cell?.mine == true)) 10.dp else 0.dp, RoundedCornerShape(11.dp), ambientColor = border.copy(.25f), spotColor = border.copy(.20f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        when {
            // Safe cells are a star, mines are an actual bomb.
            revealed -> Text(trKey("text_14"), fontSize = 25.sp, modifier = Modifier.graphicsLayer { alpha = pulse })
            showMine && cell?.mine == true -> Text(trKey("text_5"), fontSize = 24.sp)
            else -> { /* closed tile intentionally empty */ }
        }
    }
}

@Composable
private fun ActionButton(title: String, value: String, modifier: Modifier, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier.height(70.dp).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Brush.verticalGradient(listOf(MineRed, Color(0xFFB5001B))) else Brush.verticalGradient(listOf(Color(0xFF3A1118), Color(0xFF200A0E))))
            .border(1.dp, if (enabled) MineRedSoft else Color.White.copy(.10f), RoundedCornerShape(16.dp))
            .shadow(if (enabled) 15.dp else 0.dp, RoundedCornerShape(16.dp), ambientColor = MineRed.copy(.30f), spotColor = MineRed.copy(.25f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                title, color = Color.White,
                fontSize = when { title.length > 24 -> 10.sp; title.length > 18 -> 12.sp; else -> 15.sp },
                fontWeight = FontWeight.Black, maxLines = 1, softWrap = false,
                textAlign = TextAlign.Center
            )
            if (value.contains("GC")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VGhostCoinIcon(size = 21.dp)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        value, color = Color.White.copy(.90f),
                        fontSize = when { value.length > 30 -> 9.sp; value.length > 22 -> 11.sp; value.length > 16 -> 12.sp; else -> 13.sp },
                        fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Text(
                    value, color = Color.White.copy(.90f),
                    fontSize = when { value.length > 30 -> 9.sp; value.length > 22 -> 11.sp; value.length > 16 -> 12.sp; else -> 13.sp },
                    fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}


@Composable
fun VGhostRockfallScreen(
    repository: VGhostRepository = VGhostRepository.instance,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    DisposableEffect(activity) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        controller?.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    val coins by repository.ghostCoins.collectAsState()
    val error by repository.lastGameError.collectAsState()
    val audio = rememberGameAudio(LocalContext.current, "rockfall")
    val scope = rememberCoroutineScope()
    val pulse = rememberInfiniteTransition(label = "rockfall_pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "glow"
    )
    val sweep by pulse.animateFloat(
        initialValue = -0.2f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(2600), RepeatMode.Restart),
        label = "sweep"
    )

    var bet by remember { mutableStateOf(10) }
    var board by remember { mutableStateOf(List(64) { (it * 7 + 3) % 5 }) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var roundId by remember { mutableStateOf<String?>(null) }
    var moves by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var timeLeft by remember { mutableStateOf(75) }
    var multiplier by remember { mutableStateOf(1.0) }
    var combo by remember { mutableStateOf(0) }
    var cashoutPayout by remember { mutableStateOf(0) }
    var active by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf(trKey("h_ready_prompt")) }
    var showRoundIntro by remember { mutableStateOf(false) }
    var unlockedLevel by remember { mutableStateOf(1) }
    var selectedLevel by remember { mutableStateOf(1) }
    var bestScore by remember { mutableStateOf(0) }
    var showLevelPicker by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf(500) }
    var timeLimit by remember { mutableStateOf(75) }

    LaunchedEffect(Unit) {
        val progress = repository.rockfallProgress()
        if (progress != null) {
            unlockedLevel = progress.optInt("unlockedLevel", 1).coerceIn(1, 10)
            bestScore = progress.optInt("bestScore", 0).coerceAtLeast(0)
            selectedLevel = selectedLevel.coerceAtMost(unlockedLevel)
        }
    }

    fun start() {
        if (busy || active) return
        scope.launch {
            busy = true
            val r = repository.startGame("rockfall", bet, rockfallLevel = selectedLevel)
            busy = false
            if (r != null) {
                roundId = r.optString("roundId").ifBlank { null }
                val arr = r.optJSONArray("board")
                board = if (arr != null) List(arr.length()) { arr.optInt(it) } else List(64) { (it * 11 + 2) % 5 }
                moves = r.optInt("moves", 20)
                score = 0
                target = r.optInt("target", 300 + (selectedLevel - 1) * 175)
                timeLimit = r.optInt("timeLimit", 75 + (selectedLevel - 1) * 10)
                selectedLevel = r.optInt("level", selectedLevel).coerceIn(1, 10)
                timeLeft = r.optInt("timeLeft", timeLimit)
                multiplier = 1.0
                combo = 0
                cashoutPayout = 0
                selected = null
                active = true
                message = com.vghost.app.i18n.VGhostLanguage.trKey("tap_two_rocks_bullet_swap_their_positions")
                showRoundIntro = true
                delay(900)
                showRoundIntro = false
            } else {
                message = error ?: com.vghost.app.i18n.VGhostLanguage.trKey("game_could_not_start_bullet_no_server_response")
            }
        }
    }

    fun swipe(from: Int, dx: Float, dy: Float) {
        if (!active || busy || timeLeft <= 0) return
        val absX = kotlin.math.abs(dx)
        val absY = kotlin.math.abs(dy)
        if (kotlin.math.max(absX, absY) < 18f) return
        val row = from / 8
        val col = from % 8
        val to = when {
            absX > absY && dx > 0 && col < 7 -> from + 1
            absX > absY && dx < 0 && col > 0 -> from - 1
            absY > absX && dy > 0 && row < 7 -> from + 8
            absY > absX && dy < 0 && row > 0 -> from - 8
            else -> -1
        }
        if (to !in 0..63) return
        scope.launch {
            busy = true
            val r = repository.rockfallMove(roundId ?: return@launch, from, to)
            busy = false
            if (r != null) {
                val matched = r.optInt("matches", 0)
                if (matched > 0) audio.play(if (r.optInt("combo", 0) > 1) "combo" else "match") else audio.play("swap")
                val arr = r.optJSONArray("board")
                if (arr != null && arr.length() == 64) board = List(64) { arr.optInt(it) }
                moves = r.optInt("movesLeft", moves - 1)
                score = r.optInt("score", score)
                timeLeft = r.optInt("timeLeft", timeLeft)
                multiplier = r.optDouble("multiplier", multiplier)
                combo = r.optInt("combo", combo).coerceAtLeast(0)
                cashoutPayout = r.optInt("payout", cashoutPayout).coerceAtLeast(0)
                message = if (matched > 0) {
                    trfKey("h_a5571cc3cd2d", combo.coerceAtLeast(1), r.optInt("scoreGain", 0))
                } else com.vghost.app.i18n.VGhostLanguage.trKey("swap_did_not_match_bullet_choose_new_rocks")
                if (r.optString("status") == "won") {
                    active = false
                    roundId = null
                    audio.play("win")
                    val finishedLevel = r.optInt("level", selectedLevel).coerceIn(1, 10)
                    unlockedLevel = maxOf(unlockedLevel, minOf(10, finishedLevel + 1))
                    bestScore = maxOf(bestScore, score)
                    if (finishedLevel < 10) {
                        val nextLevel = (finishedLevel + 1).coerceAtMost(10)
                        selectedLevel = nextLevel
                        message = trKey("game_level_done").format(finishedLevel, nextLevel)

                        // Next level starts automatically after the completion banner.
                        // The server has already unlocked the next level with the winning move.
                        scope.launch {
                            delay(1200L)
                            if (!busy && !active) {
                                busy = true
                                val next = repository.startGame("rockfall", bet, rockfallLevel = nextLevel)
                                busy = false
                                if (next != null) {
                                    roundId = next.optString("roundId").ifBlank { null }
                                    val nextArr = next.optJSONArray("board")
                                    board = if (nextArr != null) List(nextArr.length()) { nextArr.optInt(it) } else List(64) { (it * 11 + 2) % 5 }
                                    moves = next.optInt("moves", 20 + (nextLevel - 1) * 3)
                                    score = 0
                                    target = next.optInt("target", 300 + (nextLevel - 1) * 175)
                                    timeLimit = next.optInt("timeLimit", 75 + (nextLevel - 1) * 10)
                                    selectedLevel = next.optInt("level", nextLevel).coerceIn(1, 10)
                                    timeLeft = next.optInt("timeLeft", timeLimit)
                                    multiplier = 1.0
                                    combo = 0
                                    cashoutPayout = 0
                                    selected = null
                                    active = true
                                    message = trKey("game_level_started").format(selectedLevel)
                                } else {
                                    message = error ?: trfKey("h_da73214c2304", nextLevel)
                                }
                            }
                        }
                    } else {
                        message = com.vghost.app.i18n.VGhostLanguage.trKey("all_levels_completed")
                    }
                } else if (r.optString("status") == "lost" || timeLeft <= 0) {
                    active = false
                    roundId = null
                    timeLeft = 0
                    audio.play("lose")
                    message = com.vghost.app.i18n.VGhostLanguage.trKey("time_up_bullet_level_not_completed")
                } else if (moves <= 0) {
                    active = false
                    roundId = null
                    message = com.vghost.app.i18n.VGhostLanguage.trKey("moves_over_bullet_level_not_completed")
                }
            } else {
                message = error?.toString() ?: com.vghost.app.i18n.VGhostLanguage.trKey("move_not_valid")
            }
        }
    }

    fun cashout() {
        val id = roundId ?: return
        scope.launch {
            busy = true
            val r = repository.rockfallCashOut(id)
            busy = false
            if (r != null) {
                active = false
                roundId = null
                cashoutPayout = r.optInt("payout", 0).coerceAtLeast(0)
                audio.play("cashout")
                message = trKey("game_cashout").format(cashoutPayout)
            }
        }
    }

    LaunchedEffect(active, roundId) {
        while (active && roundId != null && timeLeft > 0) {
            delay(1000L)
            if (active) {
                timeLeft = (timeLeft - 1).coerceAtLeast(0)
                if (timeLeft == 0) {
                    active = false
                    roundId = null
                    message = com.vghost.app.i18n.VGhostLanguage.trKey("time_up_bullet_level_not_completed")
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF050308))) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF09020E), Color(0xFF050308), Color(0xFF090313))))
            drawCircle(Color(0xFFFF1744).copy(alpha = 0.12f * glow), size.minDimension * 0.52f, Offset(size.width * 0.04f, size.height * 0.16f))
            drawCircle(Color(0xFF6D25FF).copy(alpha = 0.14f * glow), size.minDimension * 0.58f, Offset(size.width * 0.98f, size.height * 0.78f))
            for (x in 0..10) {
                val px = size.width * x / 10f
                drawLine(Color.White.copy(alpha = 0.018f), Offset(px, 0f), Offset(px, size.height), 1f)
            }
            for (y in 0..16) {
                val py = size.height * y / 16f
                drawLine(Color.White.copy(alpha = 0.014f), Offset(0f, py), Offset(size.width, py), 1f)
            }
            drawRoundRect(
                Brush.horizontalGradient(
                    listOf(Color.Transparent, Color(0xFFFF3152).copy(alpha = 0.22f), Color.Transparent),
                    startX = size.width * sweep - size.width * 0.35f,
                    endX = size.width * sweep + size.width * 0.35f
                ),
                topLeft = Offset(0f, size.height * 0.31f),
                size = androidx.compose.ui.geometry.Size(size.width, 2f)
            )
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp)
                        .clip(RoundedCornerShape(17.dp))
                        .background(Color.White.copy(.055f))
                        .border(1.dp, Color.White.copy(.13f), RoundedCornerShape(17.dp))
                        .clickable(enabled = !busy) { onBack() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.ArrowBack, null, tint = Color.White, modifier = Modifier.size(23.dp))
                }
                Column(Modifier.weight(1f).padding(start = 13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(trKey("vghost"), color = Color.White.copy(.55f), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 2.8.sp)
                        Spacer(Modifier.width(7.dp))
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFFF3152).copy(glow)))
                        Spacer(Modifier.width(5.dp))
                        Text(trKey("live"), color = Color(0xFFFF5270), fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = 1.3.sp)
                    }
                    Text(trKey("rockfall"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(trKey("ghost_coins"), color = GhostTextMuted, fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(trKey("g"), color = Color(0xFFFFC24D), fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(4.dp))
                        VGhostCoinAmount(coins.toString(), iconSize = 26.dp, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RockPremiumStat(trKey("game_score"), score.toString(), trKey("game_points"), Modifier.weight(1f))
                RockPremiumStat(trKey("game_combo"), "x${combo.coerceAtLeast(0)}", trKey("game_chain"), Modifier.weight(1f))
                RockPremiumStat(trKey("game_moves"), moves.toString(), trKey("game_left"), Modifier.weight(1f))
                RockPremiumStat(trKey("game_timer"), "%02d:%02d".format(timeLeft / 60, timeLeft % 60), trKey("game_seconds"), Modifier.weight(1f))
            }

            Spacer(Modifier.height(8.dp))
            Text(trfKey("level_10_bullet_m_qs_d_xal_bullet_sani_y_bullet_3_eyni_da", selectedLevel, target, timeLimit), Modifier.fillMaxWidth(), color = Color.White.copy(.55f), fontSize = 7.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, letterSpacing = .8.sp)
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF261033), Color(0xFF120A1A))))
                    .border(1.dp, Color(0xFFB86BFF).copy(.58f), RoundedCornerShape(16.dp))
                    .clickable(enabled = !active && !busy) { showLevelPicker = true }
                    .padding(horizontal = 12.dp, vertical = 9.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF9B4DFF).copy(.18f)), contentAlignment = Alignment.Center) {
                        Text(trKey("text_7"), color = Color(0xFFE4B8FF), fontSize = 18.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(trKey("rockfall_level"), color = Color.White.copy(.48f), fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                        Text(trfKey("level_bullet_10_unlocked", selectedLevel, unlockedLevel), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(trKey("best"), color = Color.White.copy(.35f), fontSize = 6.sp, fontWeight = FontWeight.Black)
                        Text(bestScore.toString(), color = Color(0xFFFFD76A), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(7.dp))
                    Text(trKey("text_10"), color = Color.White.copy(.65f), fontSize = 22.sp, fontWeight = FontWeight.Light)
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(.045f))
                    .border(1.dp, Color.White.copy(.08f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(trKey("oyun_m_rci"), color = GhostTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
                Spacer(Modifier.weight(1f))
                VGhostCoinAmount(trfKey("gc_2", bet), iconSize = 21.dp, color = Color(0xFFFFC24D), fontSize = 12.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(5.dp))
                Text(trKey("avtomati_k"), color = Color.White.copy(.38f), fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = .8.sp)
            }

            Spacer(Modifier.height(9.dp))
            // Full-height arena: the card now fills the entire middle area.
            // The board remains 8×8 (server contract), but every row/column
            // expands to use the available card space so there are no large
            // empty bands above or below the stones.
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
                Box(
                    Modifier.fillMaxSize()
                        .clip(RoundedCornerShape(28.dp))
                        .background(Brush.radialGradient(listOf(Color(0xFF251128), Color(0xFF0B0810), Color(0xFF07050A))))
                        .border(1.5.dp, Color(0xFFFF3152).copy(.45f), RoundedCornerShape(28.dp))
                        .padding(7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.matchParentSize()) {
                        drawRoundRect(Color(0xFFFF3152).copy(.035f), size = size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(28f, 28f))
                        drawCircle(Color(0xFFFF3152).copy(.08f), size.minDimension * .40f, Offset(size.width * .18f, size.height * .18f))
                        drawCircle(Color(0xFF7B36FF).copy(.08f), size.minDimension * .42f, Offset(size.width * .85f, size.height * .84f))
                    }

                    // Exactly 8 rows × 8 columns. Each row and tile receives
                    // equal space, so the arena is visually filled on tall screens.
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        for (row in 0 until 8) {
                            Row(
                                Modifier.fillMaxWidth().weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                for (col in 0 until 8) {
                                    val i = row * 8 + col
                                    val selectedNow = selected == i
                                    val tile = board.getOrElse(i) { 0 }.coerceIn(0, 4)
                                    RockPremiumTile(
                                        tile = tile,
                                        selected = selectedNow,
                                        active = active,
                                        busy = busy,
                                        modifier = Modifier.weight(1f).fillMaxSize(),
                                        onSwipe = { dx, dy -> swipe(i, dx, dy) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(message, Modifier.fillMaxWidth(), color = if (error != null) Color(0xFFFF5B73) else Color.White.copy(.90f), fontSize = 10.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Box(
                    Modifier.weight(1f).height(60.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFFFF123D), Color(0xFFFF345D))))
                        .border(1.dp, Color.White.copy(.12f), RoundedCornerShape(18.dp))
                        .clickable(enabled = !active && !busy) { start() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (active) trfKey("h_7a78aba73b4c", selectedLevel) else trfKey("h_bb4033c48479", selectedLevel), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = .5.sp)
                        Text(if (active) trKey("h_1dab244c0e66") else trfKey("h_85fe7ac6ef03", bet, target, timeLimit), color = Color.White.copy(.72f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                    }
                }
                Box(
                    Modifier.width(118.dp).height(60.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF1B1510), Color(0xFF0E0A0B))))
                        .border(1.dp, Color(0xFFFFC24D).copy(.75f), RoundedCornerShape(18.dp))
                        .clickable(enabled = active && !busy) { cashout() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(trKey("topla"), color = Color(0xFFFFD16B), fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.3.sp)
                        VGhostCoinAmount(trfKey("gc", cashoutPayout), iconSize = 25.dp, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(trKey("yaln_z_virtual_ghost_coin_bullet_real_pul_d_y_ri_yoxdur"), Modifier.fillMaxWidth(), color = GhostTextMuted.copy(.65f), fontSize = 7.sp, textAlign = TextAlign.Center)
        }

        if (showLevelPicker) {
            RockfallLevelPicker(
                unlockedLevel = unlockedLevel,
                selectedLevel = selectedLevel,
                onSelect = { selectedLevel = it; showLevelPicker = false },
                onDismiss = { showLevelPicker = false }
            )
        }

        if (showRoundIntro) {
            Box(
                Modifier.fillMaxSize()
                    .background(Color(0xFF050308).copy(.88f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(trKey("vghost"), color = Color.White.copy(.55f), fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(trKey("rockfall"), color = Color(0xFFFF3152), fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 2.5.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(trKey("round_ready"), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) { VGhostCoinIcon(size = 20.dp); Spacer(Modifier.width(4.dp)); Text(trfKey("gc_bullet_level_bullet_match_rocks", bet, selectedLevel), color = Color(0xFFFFC24D), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp) }
                }
            }
        }
    }
}

@Composable
private fun RockfallLevelPicker(
    unlockedLevel: Int,
    selectedLevel: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxWidth(.92f)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF21102E), Color(0xFF0B0710))))
                .border(1.5.dp, Color(0xFFB86BFF).copy(.62f), RoundedCornerShape(28.dp))
                .padding(18.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(trKey("vghost"), color = Color.White.copy(.42f), fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                Text(trKey("rockfall"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp)
                Spacer(Modifier.height(4.dp))
                Text(trKey("level_se"), color = Color(0xFFE4B8FF), fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Spacer(Modifier.height(14.dp))
                for (row in 0 until 5) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        for (col in 0 until 2) {
                            val level = row * 2 + col + 1
                            val unlocked = level <= unlockedLevel
                            val selected = level == selectedLevel
                            val levelTarget = 300 + (level - 1) * 175
                            val levelTime = 75 + (level - 1) * 10
                            Box(
                                Modifier.weight(1f).height(58.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        when {
                                            selected -> Brush.verticalGradient(listOf(Color(0xFFFF3152).copy(.42f), Color(0xFF5C1230).copy(.55f)))
                                            unlocked -> Brush.verticalGradient(listOf(Color.White.copy(.09f), Color.White.copy(.035f)))
                                            else -> Brush.verticalGradient(listOf(Color.Black.copy(.28f), Color.Black.copy(.20f)))
                                        }
                                    )
                                    .border(1.dp, if (selected) Color(0xFFFF6A82) else Color.White.copy(if (unlocked) .10f else .05f), RoundedCornerShape(16.dp))
                                    .clickable(enabled = unlocked) { onSelect(level) }
                                    .padding(horizontal = 10.dp, vertical = 7.dp)
                            ) {
                                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (unlocked) com.vghost.app.i18n.VGhostLanguage.trKey("text_7") else "🔒", fontSize = 17.sp)
                                    Spacer(Modifier.width(7.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(trfKey("level", level), color = if (unlocked) Color.White else Color.White.copy(.28f), fontSize = 10.sp, fontWeight = FontWeight.Black)
                                        Text(if (unlocked) trfKey("h_dedaff3044d8", levelTarget, levelTime) else trKey("h_a310daf10423"), color = if (unlocked) Color.White.copy(.42f) else Color.White.copy(.20f), fontSize = 7.sp, fontWeight = FontWeight.Bold)
                                    }
                                    if (selected) Text(trKey("check"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Spacer(Modifier.height(3.dp))
                Text(trKey("h_r_qalibiyy_t_n_vb_ti_level_i_r"), color = Color.White.copy(.36f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RockPremiumStat(label: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(15.dp))
            .background(Brush.verticalGradient(listOf(Color.White.copy(.075f), Color.White.copy(.025f))))
            .border(1.dp, Color.White.copy(.10f), RoundedCornerShape(15.dp))
            .padding(horizontal = 11.dp, vertical = 8.dp)
    ) {
        Text(label, color = Color.White.copy(.40f), fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
        Text(value, color = if (label == trKey("game_timer") && value.removePrefix("00:").toIntOrNull()?.let { it <= 10 } == true) Color(0xFFFF3152) else Color.White, fontSize = if (label == trKey("game_timer")) 18.sp else 16.sp, fontWeight = FontWeight.Black)
        Text(caption, color = Color(0xFFFF3152).copy(.75f), fontSize = 6.sp, fontWeight = FontWeight.Black, letterSpacing = .9.sp)
    }
}

@Composable
private fun RockPremiumTile(
    tile: Int,
    selected: Boolean,
    active: Boolean,
    busy: Boolean,
    modifier: Modifier = Modifier,
    tileSize: Dp = 54.dp,
    onSwipe: (Float, Float) -> Unit
) {
    val icons = listOf(com.vghost.app.i18n.VGhostLanguage.trKey("diamond"), "🛡️", "👑", "🔴", "💠")
    val scale by animateFloatAsState(if (selected) 1.06f else 1f, animationSpec = tween(180), label = "tile_scale")
    val border = when (tile) {
        0 -> Color(0xFF65D9FF)
        1 -> Color(0xFFBDEBFF)
        2 -> Color(0xFFFFD34E)
        3 -> Color(0xFFFF4560)
        else -> Color(0xFF58B8FF)
    }
    var totalDx = 0f
    var totalDy = 0f
    Box(
        modifier.padding(1.5.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color.White.copy(.105f), Color.White.copy(.025f))))
            .border(1.dp, if (selected) Color.White else border.copy(.42f), RoundedCornerShape(12.dp))
            .shadow(6.dp, RoundedCornerShape(12.dp), ambientColor = border.copy(.16f), spotColor = border.copy(.12f))
            .pointerInput(active, busy) {
                detectDragGestures(
                    onDragStart = { totalDx = 0f; totalDy = 0f },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        if (active && !busy) {
                            totalDx += dragAmount.x
                            totalDy += dragAmount.y
                        }
                    },
                    onDragEnd = {
                        if (active && !busy) onSwipe(totalDx, totalDy)
                        totalDx = 0f; totalDy = 0f
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Canvas(Modifier.matchParentSize()) {
                drawRoundRect(Color(0xFFFF3152).copy(.16f), size = size, cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f))
            }
        }
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            val iconSize = minOf(maxWidth.value, maxHeight.value) * 0.58f
            Text(icons[tile], fontSize = iconSize.coerceIn(20f, 34f).sp)
        }
    }
}


@Composable
fun VGhostTicTacToeScreen(
    repository: VGhostRepository = VGhostRepository.instance,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    DisposableEffect(activity) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        controller?.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    val coins by repository.ghostCoins.collectAsState()
    val error by repository.lastGameError.collectAsState()
    val scope = rememberCoroutineScope()
    var selectedBet by remember { mutableStateOf(10) }
    var mode by remember { mutableStateOf("AI") }
    var roundId by remember { mutableStateOf<String?>(null) }
    var roomCode by remember { mutableStateOf("") }
    var roomId by remember { mutableStateOf<String?>(null) }
    var yourMark by remember { mutableStateOf(com.vghost.app.i18n.VGhostLanguage.trKey("x")) }
    var board by remember { mutableStateOf(List(9) { "" }) }
    var myTurn by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(com.vghost.app.i18n.VGhostLanguage.trKey("ready_start")) }
    var opponent by remember { mutableStateOf("AI") }
    var busy by remember { mutableStateOf(false) }
    var wins by remember { mutableStateOf(0) }
    var losses by remember { mutableStateOf(0) }
    var draws by remember { mutableStateOf(0) }
    var lastRoomState by remember { mutableStateOf("") }

    fun applyRoom(r: org.json.JSONObject, joined: Boolean = false) {
        roomId = r.optString("roomId").takeIf { it.isNotBlank() }
        roomCode = r.optString("roomCode", roomCode)
        yourMark = r.optString("yourMark", yourMark)
        opponent = if (yourMark == com.vghost.app.i18n.VGhostLanguage.trKey("x")) r.optString("player2Nickname", com.vghost.app.i18n.VGhostLanguage.trKey("opponent")).ifBlank { com.vghost.app.i18n.VGhostLanguage.trKey("opponent") } else r.optString("player1Nickname", com.vghost.app.i18n.VGhostLanguage.trKey("opponent")).ifBlank { com.vghost.app.i18n.VGhostLanguage.trKey("opponent") }
        val arr = r.optJSONArray("board")
        if (arr != null) board = List(9) { arr.optString(it, "") }
        myTurn = r.optBoolean("yourTurn", false)
        val st = r.optString("status", "waiting")
        lastRoomState = st
        when (st) {
            "waiting" -> status = com.vghost.app.i18n.VGhostLanguage.trfKey("room_ready_bullet_code", roomCode)
            "active" -> status = if (myTurn) trfKey("h_4b761af256a3", yourMark) else trfKey("h_7bb73b9cdf3d", opponent)
            "finished" -> {
                val winner = r.optInt("winnerId", 0)
                val iWon = if (yourMark == com.vghost.app.i18n.VGhostLanguage.trKey("x")) winner == r.optInt("player1Id") else winner == r.optInt("player2Id")
                if (iWon) { wins++; status = com.vghost.app.i18n.VGhostLanguage.trKey("win_alert_bullet_online") } else { losses++; status = com.vghost.app.i18n.VGhostLanguage.trfKey("defeat_bullet", opponent) }
                roomId = null
            }
            "draw" -> { draws++; status = com.vghost.app.i18n.VGhostLanguage.trKey("draw_bullet_online"); roomId = null }
            "cancelled" -> { status = com.vghost.app.i18n.VGhostLanguage.trKey("room_cancelled"); roomId = null }
        }
        if (joined) status = if (myTurn) trfKey("h_4b761af256a3", yourMark) else com.vghost.app.i18n.VGhostLanguage.trKey("opponent_playing")
    }

    fun startAi() {
        val bet = selectedBet
        if (busy || roundId != null || bet <= 0) return
        busy = true
        scope.launch {
            val r = repository.startGame("tictactoe", bet)
            busy = false
            if (r != null) {
                roundId = r.optString("roundId")
                board = List(9) { "" }
                yourMark = com.vghost.app.i18n.VGhostLanguage.trKey("x")
                myTurn = true
                status = trKey("h_f7cabb0b5330")
            } else status = error ?: trKey("h_55fd7981c140")
        }
    }

    fun createRoom() {
        if (busy || roomId != null) return
        busy = true
        scope.launch {
            val r = repository.createTicTacToeRoom()
            busy = false
            if (r != null) { board = List(9) { "" }; applyRoom(r) ; status = com.vghost.app.i18n.VGhostLanguage.trfKey("room_ready_bullet_code", roomCode) }
            else status = error ?: com.vghost.app.i18n.VGhostLanguage.trKey("room_could_not_created")
        }
    }

    fun joinRoom() {
        val code = roomCode.trim().uppercase()
        if (busy || roomId != null || code.length != 6) return
        busy = true
        scope.launch {
            val r = repository.joinTicTacToeRoom(code)
            busy = false
            if (r != null) { board = List(9) { "" }; applyRoom(r, true) }
            else status = error ?: com.vghost.app.i18n.VGhostLanguage.trKey("could_not_join_room")
        }
    }

    fun move(index: Int) {
        if (busy || index !in 0..8 || board[index].isNotEmpty()) return
        if (mode == "AI") {
            val rid = roundId ?: return
            if (!myTurn) return
            busy = true
            scope.launch {
                val r = repository.ticTacToeMove(rid, index)
                busy = false
                if (r != null) {
                    r.optJSONArray("board")?.let { arr -> board = List(9) { arr.optString(it, "") } }
                    when (r.optString("status", "active")) {
                        "won" -> { wins++; myTurn=false; status=com.vghost.app.i18n.VGhostLanguage.trKey("win_alert_gc").format(r.optInt("payout",0)); roundId=null }
                        "lost" -> { losses++; myTurn=false; status=com.vghost.app.i18n.VGhostLanguage.trKey("ai_won"); roundId=null }
                        "draw" -> { draws++; myTurn=false; status=com.vghost.app.i18n.VGhostLanguage.trKey("draw_bullet_bet_returned"); roundId=null }
                        else -> { myTurn=true; status=trKey("ui_your_turn_x") }
                    }
                } else status = error ?: com.vghost.app.i18n.VGhostLanguage.trKey("move_failed")
            }
        } else {
            val rid = roomId ?: return
            if (!myTurn || lastRoomState != "active") return
            busy = true
            scope.launch {
                val r = repository.ticTacToeMultiplayerMove(rid, index)
                busy = false
                if (r != null) applyRoom(r) else status = error ?: com.vghost.app.i18n.VGhostLanguage.trKey("move_failed")
            }
        }
    }

    LaunchedEffect(mode, roomId) {
        if (mode != "MULTI") return@LaunchedEffect
        while (roomId != null) {
            delay(1300)
            val rid = roomId ?: break
            if (!busy) repository.ticTacToeRoomState(rid)?.let { applyRoom(it) }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.tictactoe_premium_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer(alpha = 0.86f)
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.30f)))

        Column(
            Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // PREMIUM HEADER — badge is kept below the title so it never gets squeezed vertically.
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .background(Color.Black.copy(.58f))
                        .border(1.7.dp, MineRed, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.ArrowBack, com.vghost.app.i18n.VGhostLanguage.trKey("back_3"), tint = Color.White, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(trKey("tic_tac_toe"), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 1.1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(trKey("number_3_3_neon_arena"), color = Color.White.copy(.62f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .9.sp)
                        Spacer(Modifier.width(7.dp))
                        Box(
                            Modifier.clip(RoundedCornerShape(50.dp))
                                .background(Brush.horizontalGradient(listOf(MineRed.copy(.28f), Color(0xFF5C0717).copy(.22f))))
                                .border(1.dp, MineRed.copy(.78f), RoundedCornerShape(50.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(trKey("premium_premium"), color = MineRedSoft, fontSize = 7.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp)
                        }
                    }
                }
                CoinPill(coins)
            }

            Spacer(Modifier.height(9.dp))

            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
                    .background(Color.Black.copy(.48f))
                    .border(1.dp, Color.White.copy(.11f), RoundedCornerShape(17.dp))
                    .padding(7.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                ModeChip(trKey("h_9bc7d2d81cca"), mode == "AI", Modifier.weight(1f)) {
                    if (roomId == null) { mode = "AI"; status = com.vghost.app.i18n.VGhostLanguage.trKey("ready_start") }
                }
                ModeChip(com.vghost.app.i18n.VGhostLanguage.trKey("number_2_players_bullet_online"), mode == "MULTI", Modifier.weight(1f)) {
                    if (roundId == null) { mode = "MULTI"; status = com.vghost.app.i18n.VGhostLanguage.trKey("create_online_room_join_code") }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                TicStat(trKey("h_82d578ce389c"), wins.toString(), Color(0xFF29A8FF), Modifier.weight(1f))
                TicStat(trKey("h_1101fd817be1"), draws.toString(), Color.White, Modifier.weight(1f))
                TicStat(if (mode == "AI") trKey("h_560040c54a3b") else com.vghost.app.i18n.VGhostLanguage.trKey("opponent"), losses.toString(), MineRedSoft, Modifier.weight(1f))
            }

            Spacer(Modifier.height(8.dp))
            if (mode == "MULTI") {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                        .background(Color.Black.copy(.46f))
                        .border(1.dp, Color(0xFF29A8FF).copy(.28f), RoundedCornerShape(13.dp))
                        .padding(vertical = 8.dp, horizontal = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(trKey("online_bullet_pulsuz_oyun_bullet_coin_m_rc_yoxdur"), color = Color(0xFF63C2FF), fontSize = 8.sp, fontWeight = FontWeight.Black, letterSpacing = .7.sp)
                }
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.OutlinedTextField(
                        value = roomCode,
                        onValueChange = { if (it.length <= 6) roomCode = it.uppercase() },
                        modifier = Modifier.weight(1f).height(54.dp),
                        singleLine = true,
                        label = { Text(trKey("otaq_kodu")) }
                    )
                    Spacer(Modifier.width(7.dp))
                    androidx.compose.material3.Button(
                        onClick = { createRoom() }, enabled = !busy && roomId == null,
                        modifier = Modifier.width(118.dp).height(48.dp),
                        shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(0.dp)
                    ) { Text(trKey("otaq_yarat"), fontSize = 9.sp, fontWeight = FontWeight.Black) }
                }
                Spacer(Modifier.height(5.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    androidx.compose.material3.Button(
                        onClick = { joinRoom() }, enabled = !busy && roomId == null && roomCode.length == 6,
                        modifier = Modifier.weight(1f).height(42.dp), shape = RoundedCornerShape(11.dp), contentPadding = PaddingValues(0.dp)
                    ) { Text(if (busy) com.vghost.app.i18n.VGhostLanguage.trKey("please_wait") else com.vghost.app.i18n.VGhostLanguage.trKey("join_code"), fontSize = 10.sp, fontWeight = FontWeight.Black) }
                    if (roomId != null) {
                        androidx.compose.material3.OutlinedButton(
                            onClick = { val rid = roomId; if (rid != null) scope.launch { repository.cancelTicTacToeRoom(rid); roomId = null; status = com.vghost.app.i18n.VGhostLanguage.trKey("room_closed") } },
                            modifier = Modifier.width(105.dp).height(42.dp), shape = RoundedCornerShape(11.dp), contentPadding = PaddingValues(0.dp)
                        ) { Text(trKey("ix"), fontSize = 10.sp, fontWeight = FontWeight.Black) }
                    }
                }
            } else {
                // Only the three preset bets — no ugly Coin input field.
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
                        .background(Color.Black.copy(.44f))
                        .border(1.dp, MineRed.copy(.25f), RoundedCornerShape(15.dp))
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(10, 50, 100).forEach { amount ->
                        Box(
                            Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (selectedBet == amount) Brush.verticalGradient(listOf(MineRed.copy(.42f), MineRed.copy(.18f))) else Brush.verticalGradient(listOf(Color.White.copy(.055f), Color.Black.copy(.24f))))
                                .border(1.3.dp, if (selectedBet == amount) MineRed else Color.White.copy(.10f), RoundedCornerShape(12.dp))
                                .clickable { selectedBet = amount },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(trKey("g"), color = if (selectedBet == amount) MineRedSoft else Color.White.copy(.45f), fontSize = 7.sp, fontWeight = FontWeight.Black)
                                Text(amount.toString(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                androidx.compose.material3.Button(
                    onClick = { startAi() }, enabled = !busy && roundId == null,
                    modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(0.dp)
                ) { Text(if (busy) com.vghost.app.i18n.VGhostLanguage.trKey("please_wait") else com.vghost.app.i18n.VGhostLanguage.trKey("play_start_game"), fontSize = 12.sp, fontWeight = FontWeight.Black, letterSpacing = .5.sp) }
            }

            Spacer(Modifier.height(8.dp))

            // Compact premium 3×3 arena. The board is intentionally tighter and visually richer.
            Box(
                Modifier.fillMaxWidth().weight(1f).shadow(24.dp, RoundedCornerShape(25.dp))
                    .clip(RoundedCornerShape(25.dp))
                    .background(Brush.radialGradient(listOf(Color(0xCC141827), Color(0xE607080E))))
                    .border(2.dp, MineRed.copy(.88f), RoundedCornerShape(25.dp))
                    .padding(10.dp)
            ) {
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(.06f), RoundedCornerShape(19.dp)).padding(7.dp)) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        for (row in 0..2) {
                            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                for (col in 0..2) {
                                    val i = row * 3 + col
                                    val mark = board[i]
                                    val active = (mode == "AI" && myTurn && roundId != null) || (mode == "MULTI" && myTurn && roomId != null && lastRoomState == "active")
                                    val borderColor = when (mark) {
                                        com.vghost.app.i18n.VGhostLanguage.trKey("x") -> Color(0xFF29A8FF)
                                        com.vghost.app.i18n.VGhostLanguage.trKey("o") -> MineRedSoft
                                        else -> if (active) Color.White.copy(.16f) else Color.White.copy(.07f)
                                    }
                                    Box(
                                        Modifier.weight(1f).fillMaxSize().shadow(if (mark.isNotEmpty()) 14.dp else 0.dp, RoundedCornerShape(18.dp))
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(Brush.verticalGradient(listOf(Color(0xD90E111B), Color(0xC8070910))))
                                            .border(1.6.dp, borderColor.copy(if (mark.isNotEmpty()) .95f else 1f), RoundedCornerShape(18.dp))
                                            .clickable(enabled = active && mark.isEmpty()) { move(i) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        when (mark) {
                                            com.vghost.app.i18n.VGhostLanguage.trKey("x") -> Text(trKey("text_13"), color = Color(0xFF36AEFF), fontSize = 58.sp, fontWeight = FontWeight.Black)
                                            com.vghost.app.i18n.VGhostLanguage.trKey("o") -> Text(trKey("text_24"), color = MineRedSoft, fontSize = 58.sp, fontWeight = FontWeight.Black)
                                            else -> Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White.copy(if (active) .20f else .035f)))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(7.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.Black.copy(.56f))
                    .border(1.dp, MineRed.copy(.38f), RoundedCornerShape(13.dp)).padding(vertical = 9.dp, horizontal = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(status, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center) }
            Spacer(Modifier.height(4.dp))
            Text(
                if (mode == "MULTI") trKey("h_37c5ea674024")
                else trKey("h_63f61ba1fb40"),
                color = GhostTextMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
            if (error != null) Text(error ?: "", color = MineRedSoft, fontSize = 8.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
        }
    }
}
@Composable
private fun ModeChip(label:String, selected:Boolean, modifier:Modifier, onClick:()->Unit){
    Box(modifier.clip(RoundedCornerShape(11.dp)).background(if(selected)MineRed.copy(.20f)else Color.White.copy(.035f)).border(1.dp,if(selected)MineRed.copy(.72f)else Color.White.copy(.09f),RoundedCornerShape(11.dp)).clickable(onClick=onClick).padding(vertical=9.dp),contentAlignment=Alignment.Center){Text(label,color=if(selected)Color.White else GhostTextMuted,fontSize=9.sp,fontWeight=FontWeight.Black)}
}

@Composable
private fun TicStat(label: String, value: String, color: Color, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF10111A)).border(1.dp, color.copy(.35f), RoundedCornerShape(14.dp)).padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = GhostTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text(value, color = color, fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
    }
}
