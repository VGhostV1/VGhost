package com.vghost.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as columnItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.UserListEntry
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.trKey
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.ProfileAvatarFrame
import com.vghost.app.ui.components.NeonVipName
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import kotlinx.coroutines.launch

@Composable
fun FindByNicknameScreen(
    onNavigateBack: () -> Unit,
    onUserSelected: (UserListEntry) -> Unit,
    onOpenChat: (String) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    onOpenVip: () -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var query by remember { mutableStateOf("") }
    var users by remember { mutableStateOf<List<UserListEntry>>(emptyList()) }
    var friends by remember { mutableStateOf<List<UserListEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var openSection by remember { mutableStateOf<UsersSection?>(null) }
    var page by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch {
            loading = true
            users = repository.getUsers()
            friends = repository.getFriends()
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }
    BackHandler { onNavigateBack() }

    val normalized = query.trim().removePrefix("@").lowercase()
    val filteredAllUsers = remember(users, normalized) {
        if (normalized.isBlank()) users else users.filter { it.nickname.lowercase().contains(normalized) || it.uid.contains(normalized) }
    }
    val vipUsers = remember(filteredAllUsers) {
        filteredAllUsers.filter { it.isVip }.sortedWith(compareByDescending<UserListEntry> { it.level }.thenBy { it.nickname.lowercase() })
    }
    val regularUsers = remember(filteredAllUsers) {
        filteredAllUsers.filterNot { it.isVip }.sortedWith(compareByDescending<UserListEntry> { it.level }.thenBy { it.nickname.lowercase() })
    }
    val filteredFriends = remember(friends, normalized) {
        val base = if (normalized.isBlank()) friends else friends.filter { it.nickname.lowercase().contains(normalized) || it.uid.contains(normalized) }
        base.sortedWith(compareByDescending<UserListEntry> { it.level }.thenBy { it.nickname.lowercase() })
    }

    val modalUsers = when (openSection) {
        UsersSection.VIP -> vipUsers
        UsersSection.USERS -> regularUsers
        UsersSection.FRIENDS -> filteredFriends
        null -> emptyList()
    }
    val modalPageSize = 27
    val modalPageCount = ((modalUsers.size + modalPageSize - 1) / modalPageSize).coerceAtLeast(1)
    val safePage = page.coerceIn(0, modalPageCount - 1)
    val modalPageItems = modalUsers.drop(safePage * modalPageSize).take(modalPageSize)

    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = { VGhostBottomNavBar(currentTab = NavTab.FIND, onTabSelected = onTabSelected) }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("find_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, trKey("back_3"), tint = GhostTextWhite)
                }
                Text(trKey("find_nickname"), color = GhostTextWhite, fontSize = 19.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                IconButton(onClick = onOpenVip, modifier = Modifier.testTag("users_vip_button")) {
                    Text("👑", fontSize = 24.sp)
                }
            }

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text(trKey("nickname_3"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = { Icon(Icons.Outlined.Search, null, tint = GhostTextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = GhostSurface.copy(alpha = .82f),
                    unfocusedContainerColor = GhostSurface.copy(alpha = .72f),
                    focusedBorderColor = GhostRedPrimary,
                    unfocusedBorderColor = GhostBorder,
                    focusedTextColor = GhostTextWhite,
                    unfocusedTextColor = GhostTextWhite,
                    cursorColor = GhostRedPrimary
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).testTag("find_nickname_input")
            )

            Spacer(Modifier.height(10.dp))

            if (loading) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(trKey("search_2") + "...", color = GhostTextSecondary, fontSize = 14.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    item {
                        UsersSectionButton(
                            icon = "👑",
                            title = trKey("users_vip_section"),
                            count = vipUsers.size,
                            preview = vipUsers.take(3),
                            accent = Color(0xFFFFC83D),
                            testTag = "users_vip_section_button",
                            onClick = { page = 0; openSection = UsersSection.VIP }
                        )
                    }
                    item {
                        UsersSectionButton(
                            icon = "👥",
                            title = trKey("users_all_section"),
                            count = regularUsers.size,
                            preview = regularUsers.take(3),
                            accent = Color(0xFF24D9FF),
                            testTag = "users_all_section_button",
                            onClick = { page = 0; openSection = UsersSection.USERS }
                        )
                    }
                    item {
                        UsersSectionButton(
                            icon = "❤️",
                            title = trKey("users_friends_section"),
                            count = filteredFriends.size,
                            preview = filteredFriends.take(3),
                            accent = Color(0xFFFF3D9A),
                            testTag = "users_friends_section_button",
                            onClick = { page = 0; openSection = UsersSection.FRIENDS }
                        )
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }
        }
    }

    if (openSection != null) {
        UsersSectionDialog(
            section = openSection!!,
            users = modalPageItems,
            page = safePage,
            pageCount = modalPageCount,
            totalCount = modalUsers.size,
            onPage = { page = it },
            onDismiss = { openSection = null },
            onUserSelected = onUserSelected,
            onOpenChat = onOpenChat
        )
    }
}

private enum class UsersSection { VIP, USERS, FRIENDS }

@Composable
private fun UsersSectionButton(
    icon: String,
    title: String,
    count: Int,
    preview: List<UserListEntry>,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = Modifier.fillMaxWidth().clip(shape).background(GhostSurface.copy(alpha = .84f))
            .border(1.2.dp, accent.copy(alpha = .72f), shape).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 22.sp)
            Spacer(Modifier.width(9.dp))
            Text(title, color = accent, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            Text(count.toString(), color = GhostTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text("›", color = accent, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
            preview.forEach { user ->
                PreviewUserMini(user = user, accent = accent, modifier = Modifier.weight(1f))
            }
            repeat(3 - preview.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun PreviewUserMini(user: UserListEntry, accent: Color, modifier: Modifier = Modifier) {
    val cardShape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .height(112.dp)
            .clip(cardShape)
            .background(Color(0xFF0D1016).copy(alpha = .96f))
            .border(1.2.dp, accent.copy(alpha = .62f), cardShape)
            .padding(horizontal = 5.dp, vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (user.isVip) {
                ProfileAvatarFrame(
                    size = 60.dp,
                    avatarId = user.avatarId,
                    avatarUrl = user.avatarUrl,
                    isVip = true,
                    vipHero = true,
                    vipFrameId = user.vipFrameId
                )
            } else {
                GhostAvatar(size = 50.dp, showBorder = true, avatarId = user.avatarId, avatarUrl = user.avatarUrl)
            }
            Box(
                modifier = Modifier.size(10.dp).clip(CircleShape)
                    .background(if (user.online) Color(0xFF18D64B) else GhostTextMuted)
                    .border(1.5.dp, Color(0xFF0D1016), CircleShape)
                    .align(Alignment.BottomEnd)
            )
        }
        Spacer(Modifier.height(4.dp))
        if (user.isVip) {
            NeonVipName(
                user.nickname,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 9.sp,
                textAlign = TextAlign.Center
            )
        } else {
            Text(
                user.nickname,
                color = GhostTextWhite,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(2.dp))
        Text("Lv.${user.level}", color = accent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun UsersSectionDialog(
    section: UsersSection,
    users: List<UserListEntry>,
    page: Int,
    pageCount: Int,
    totalCount: Int,
    onPage: (Int) -> Unit,
    onDismiss: () -> Unit,
    onUserSelected: (UserListEntry) -> Unit,
    onOpenChat: (String) -> Unit
) {
    val (icon, title, accent) = when (section) {
        UsersSection.VIP -> Triple("👑", trKey("users_vip_section"), Color(0xFFFFC83D))
        UsersSection.USERS -> Triple("👥", trKey("users_all_section"), Color(0xFF24D9FF))
        UsersSection.FRIENDS -> Triple("❤️", trKey("users_friends_section"), Color(0xFFFF3D9A))
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF111318),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 22.sp)
                Spacer(Modifier.width(8.dp))
                Text(title, color = accent, fontSize = 18.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Filled.Close, null, tint = GhostTextWhite)
                }
            }
        },
        text = {
            Column {
                Text("$totalCount • ${trKey("users_level")}", color = GhostTextSecondary, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                if (users.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                        Text(trKey(if (section == UsersSection.FRIENDS) "have_no_friends_yet" else if (section == UsersSection.VIP) "users_vip_empty" else "no_users_found"), color = GhostTextMuted, textAlign = TextAlign.Center)
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier.fillMaxWidth().height(500.dp),
                        contentPadding = PaddingValues(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        gridItems(users, key = { "dialog_${section.name}_${it.uid}" }) { user ->
                            UserGridCardV2(user = user, accent = accent, onOpenProfile = { onUserSelected(user) })
                        }
                    }
                }
                if (totalCount > 27) {
                    Spacer(Modifier.height(8.dp))
                    PaginationBarV2(page = page, pageCount = pageCount, accent = accent, onPage = onPage)
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = accent.copy(alpha = .18f), contentColor = accent)) {
                Text(trKey("back_3"), fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun UserGridCardV2(
    user: UserListEntry,
    accent: Color,
    onOpenProfile: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier = Modifier.fillMaxWidth().clip(shape).background(GhostSurface.copy(alpha = .9f))
            .border(1.dp, accent.copy(alpha = .48f), shape).clickable(onClick = onOpenProfile)
            .padding(horizontal = 4.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (user.isVip) {
                ProfileAvatarFrame(
                    size = 82.dp,
                    avatarId = user.avatarId,
                    avatarUrl = user.avatarUrl,
                    isVip = true,
                    vipHero = true,
                    vipFrameId = user.vipFrameId
                )
            } else {
                GhostAvatar(size = 62.dp, showBorder = true, avatarId = user.avatarId, avatarUrl = user.avatarUrl)
            }
            Box(
                modifier = Modifier.size(12.dp).clip(CircleShape)
                    .background(if (user.online) Color(0xFF18D64B) else GhostTextMuted)
                    .border(1.5.dp, GhostSurface, CircleShape).align(Alignment.BottomEnd)
            )
        }
        Spacer(Modifier.height(4.dp))
        if (user.isVip) {
            NeonVipName(user.nickname, fontSize = 11.sp, textAlign = TextAlign.Center)
        } else {
            Text(user.nickname, color = GhostTextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (user.online) "●" else "○", color = if (user.online) Color(0xFF18D64B) else GhostTextMuted, fontSize = 8.sp)
            Spacer(Modifier.width(3.dp))
            Text("Lv.${user.level}", color = accent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PaginationBarV2(page: Int, pageCount: Int, accent: Color, onPage: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        val visible = if (pageCount <= 7) (0 until pageCount).toList() else {
            linkedSetOf(0, pageCount - 1, page, page - 1, page + 1).filter { it in 0 until pageCount }.sorted()
        }
        var previous = -2
        visible.forEach { p ->
            if (previous >= 0 && p > previous + 1) Text("…", color = GhostTextMuted, modifier = Modifier.padding(horizontal = 3.dp))
            val selected = p == page
            Box(
                modifier = Modifier.size(30.dp).clip(CircleShape)
                    .background(if (selected) accent else Color.Transparent)
                    .border(1.dp, if (selected) accent else GhostBorder, CircleShape)
                    .clickable { onPage(p) },
                contentAlignment = Alignment.Center
            ) {
                Text("${p + 1}", color = if (selected) Color.Black else GhostTextSecondary, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
            }
            previous = p
        }
    }
}
