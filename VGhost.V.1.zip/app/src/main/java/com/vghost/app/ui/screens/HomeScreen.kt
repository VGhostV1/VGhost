package com.vghost.app.ui.screens
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import com.vghost.app.ui.components.premiumBackdrop
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.regex.Pattern
import com.vghost.app.data.model.ChatSummary
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.data.state.SessionState
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr
import com.vghost.app.i18n.AppLocale
import com.vghost.app.i18n.NotificationTranslations
import kotlinx.coroutines.launch

private val notificationTimeInput = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US)
private val notificationTimeOutput = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm", Locale.getDefault())

private fun formatNotificationTime(raw: String): String {
    val value = raw.trim()
    if (value.isBlank()) return ""
    return try {
        val local = if (value.endsWith("Z", true) || value.contains("T") && (value.contains("+") || value.lastIndexOf('-') > 10)) {
            Instant.parse(value.replace(" ", "T")).atZone(ZoneId.systemDefault()).toLocalDateTime()
        } else {
            // The backend stores created_at with UTC_TIMESTAMP(), without a timezone suffix.
            LocalDateTime.parse(value.take(19), notificationTimeInput)
                .atOffset(ZoneOffset.UTC)
                .atZoneSameInstant(ZoneId.systemDefault())
                .toLocalDateTime()
        }
        notificationTimeOutput.format(local)
    } catch (_: Throwable) {
        value.replace("T", " ").take(16)
    }
}

private fun cleanNotificationBody(raw: String): String {
    var body = raw.trim()
    // Older notification rows can contain raw metadata labels. Never show those
    // implementation labels to users; the localized notification templates remain
    // the primary display for known notification types.
    val labels = listOf(
        "Sender:", "Amount:",
        "Göndərən:", "Məbləğ:",
        "Gönderen:", "Tutar:",
        "Отправитель:", "Сумма:"
    )
    labels.forEach { label -> body = body.replace(Regex("(?i)\\b" + Pattern.quote(label) + "\\s*"), "") }
    return body.replace(Regex("\\s{2,}"), " ").trim()
}

@Composable
fun HomeScreen(
    onChatClicked: (String) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    onNotificationTarget: (VGhostRepository.AppNotification) -> Unit = {},
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val chats by repository.chats.collectAsState()
    val sessionState by repository.sessionState.collectAsState()
    val allNotifications by repository.notifications.collectAsState()
    val appLanguage by AppLocale.language.collectAsState()
    // Chat messages have their own Messages/Chat screen and must not pollute the
    // general notification center. Keep other notification types here.
    // Re-localize the already-loaded notification objects whenever the app
    // language changes. Notification text is therefore never frozen in the
    // language that was active when the notification was received.
    val notifications = remember(allNotifications, appLanguage) {
        allNotifications
            .filterNot { it.type.equals("message", ignoreCase = true) }
            .map { notification ->
                val localized = NotificationTranslations.localize(
                    notification.type,
                    notification.title,
                    notification.body,
                    mapOf(
                        "sender" to notification.senderNickname,
                        "senderNickname" to notification.senderNickname,
                        "amount" to notification.amount
                    )
                )
                notification.copy(title = localized.first, body = localized.second)
            }
    }
    val unreadNotifications = notifications.filter { !it.isRead }.sumOf { it.count.coerceAtLeast(1) }
    var showNotifications by remember { mutableStateOf(false) }
    var selectedFriendRequest by remember { mutableStateOf<VGhostRepository.AppNotification?>(null) }
    var friendActionLoading by remember { mutableStateOf(false) }
    var friendActionError by remember { mutableStateOf<String?>(null) }
    val screenScope = rememberCoroutineScope()

    LaunchedEffect(sessionState) {
        if (sessionState is SessionState.LoggedInNormalUser) {
            repository.startChatListSync()
            // Keep the in-app notification center fresh even when the push service
            // is unavailable or Android has temporarily delayed an FCM delivery.
            while (true) {
                repository.refreshNotifications()
                kotlinx.coroutines.delay(15_000L)
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = {
            VGhostBottomNavBar(
                currentTab = NavTab.CHATS,
                onTabSelected = onTabSelected
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // Messages page header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = trKey("messages_2"),
                        color = GhostTextWhite,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box {
                        IconButton(
                            onClick = {
                                repository.refreshNotifications()
                                showNotifications = true
                            },
                            modifier = Modifier.testTag("notifications_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsNone,
                                contentDescription = trKey("notifications"),
                                tint = GhostTextWhite,
                                modifier = Modifier.size(25.dp)
                            )
                        }
                        if (unreadNotifications > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 7.dp, end = 7.dp)
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(GhostRedPrimary)
                                    .border(1.dp, GhostBlack, CircleShape)
                            )
                        }
                    }
                }
            }

            if (showNotifications) {
                AlertDialog(
                    onDismissRequest = { showNotifications = false },
                    containerColor = GhostSurface,
                    titleContentColor = GhostTextWhite,
                    textContentColor = GhostTextSecondary,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsNone,
                                contentDescription = null,
                                tint = GhostRedPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(trKey("notifications_2"), fontWeight = FontWeight.Black)
                        }
                    },
                    text = {
                        if (notifications.isEmpty()) {
                            Text(trKey("no_notifications_yet"))
                        } else {
                            // AlertDialog's text slot is bounded; a normal Column cannot
                            // scroll here. LazyColumn makes the complete notification
                            // history accessible by swiping upward/downward.
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 500.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(notifications) { notification ->
                                    val icon = when (notification.type) {
                                        "gift", "story_gift" -> Icons.Outlined.CardGiftcard
                                        "coin_transfer", "coin_gift", "coin_received" -> Icons.Outlined.AccountBalanceWallet
                                        "welcome_bonus", "daily_bonus" -> Icons.Outlined.AccountBalanceWallet
                                        "admin", "broadcast" -> Icons.Outlined.Campaign
                                        "friend_request", "friend_accepted" -> Icons.Outlined.PersonAdd
                                        else -> Icons.Outlined.Person
                                    }
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (notification.isRead) Color.Transparent else GhostBlack.copy(alpha = 0.35f))
                                            .clickable {
                                                if (!notification.isRead) repository.markNotificationRead(notification.id)
                                                if (notification.type == "friend_request") {
                                                    selectedFriendRequest = notification
                                                    friendActionError = null
                                                } else if (notification.type.equals("gift", true) || notification.type.equals("story_gift", true)) {
                                                    showNotifications = false
                                                    repository.openGiftNotification(notification)
                                                } else {
                                                    showNotifications = false
                                                    onNotificationTarget(notification)
                                                }
                                            }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Icon(icon, null, tint = if (notification.isRead) GhostTextMuted else GhostRedPrimary, modifier = Modifier.size(22.dp))
                                        Spacer(modifier = Modifier.width(9.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text(notification.title, color = if (notification.isRead) GhostTextSecondary else GhostTextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (notification.count > 1) {
                                                        Text(trfKey("text_15", notification.count), color = GhostRedPrimary, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 6.dp))
                                                    }
                                                    Text(if (notification.isRead) trKey("read") else trKey("new_label"), color = if (notification.isRead) GhostTextMuted else GhostRedPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text(cleanNotificationBody(notification.body), color = GhostTextSecondary, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                            if (notification.createdAt.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(formatNotificationTime(notification.createdAt), color = GhostTextMuted, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        if (notifications.isNotEmpty()) {
                            Row {
                                if (unreadNotifications > 0) {
                                    TextButton(onClick = { repository.markAllNotificationsRead() }) {
                                        Text(trKey("mark_all_read"), color = GhostTextWhite, fontWeight = FontWeight.Bold)
                                    }
                                }
                                TextButton(onClick = { repository.clearInAppNotifications(); showNotifications = false }) {
                                    Text(trKey("clear"), color = GhostRedPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            TextButton(onClick = { showNotifications = false }) {
                                Text(trKey("close_3"), color = GhostRedPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                )
            }

            selectedFriendRequest?.let { request ->
                AlertDialog(
                    onDismissRequest = { if (!friendActionLoading) selectedFriendRequest = null },
                    containerColor = GhostSurface,
                    title = { Text(trKey("friend_request"), color = GhostTextWhite, fontWeight = FontWeight.Black) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(request.body.ifBlank { trKey("received_friend_request") }, color = GhostTextSecondary)
                            if (friendActionError != null) Text(friendActionError!!, color = GhostRedPrimary, fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(enabled = !friendActionLoading, onClick = {
                            val uid = request.targetValue.trim()
                            screenScope.launch {
                                friendActionLoading = true
                                val user = repository.findUserByNickname(uid)
                                val err = if (user == null) trKey("user_not_found") else repository.acceptFriend(user.uid)
                                friendActionLoading = false
                                if (err == null) { repository.removeInAppNotification(request.id); selectedFriendRequest = null; showNotifications = false } else friendActionError = err
                            }
                        }) { Text(if (friendActionLoading) trKey("please_wait") else trKey("accept"), color = GhostTextWhite, fontWeight = FontWeight.Bold) }
                    },
                    dismissButton = {
                        TextButton(enabled = !friendActionLoading, onClick = {
                            val nick = request.targetValue.trim()
                            screenScope.launch {
                                friendActionLoading = true
                                val user = repository.findUserByNickname(nick)
                                val err = if (user == null) trKey("user_not_found") else repository.rejectFriend(user.uid)
                                friendActionLoading = false
                                if (err == null) { repository.removeInAppNotification(request.id); selectedFriendRequest = null; showNotifications = false } else friendActionError = err
                            }
                        }) { Text(trKey("decline"), color = GhostRedPrimary, fontWeight = FontWeight.Bold) }
                    }
                )
            }

            if (chats.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = null,
                            tint = GhostTextMuted,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = trKey("no_messages_yet"),
                            color = GhostTextWhite,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = trKey("choose_someone_users_start_chat"),
                            color = GhostTextSecondary,
                            fontSize = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        TextButton(
                            onClick = { onTabSelected(NavTab.FIND) },
                            modifier = Modifier.testTag("messages_find_users_button")
                        ) {
                            Text(
                                text = trKey("find_users"),
                                color = GhostRedPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(chats, key = { it.id }) { chat ->
                        ChatItemRow(
                            chat = chat,
                            onClick = { onChatClicked(chat.nickname) }
                        )
                        HorizontalDivider(
                            thickness = 0.5.dp,
                            color = GhostBorder.copy(alpha = 0.5f),
                            modifier = Modifier.padding(start = 76.dp, end = 16.dp)
                        )
                    }
                }
            }
            }
        }
    }

@Composable
private fun ChatItemRow(
    chat: ChatSummary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("chat_item_${chat.nickname}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Ghost Avatar
        GhostAvatar(
            size = 62.dp,
            showBorder = true,
            avatarId = chat.avatarId
        )

        Spacer(modifier = Modifier.width(14.dp))

        // Nickname + Last Message
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = chat.nickname,
                color = GhostTextWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(3.dp))
            val previewText = (chat.messageTypePrefix ?: "") + chat.lastMessage
            Text(
                text = previewText,
                color = GhostTextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Time and Unread Badge
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = chat.time,
                color = GhostTextMuted,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (chat.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(GhostRedPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = chat.unreadCount.toString(),
                        color = GhostTextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
