package com.vghost.app.ui.screens
import com.vghost.app.ui.components.VGhostCoinAmount
import com.vghost.app.ui.components.VGhostCoinIcon
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository
import org.json.JSONArray

private data class AdminUser(val uid: String, val nickname: String, val banned: Boolean, val coinBalance: Long = 0L)
private data class AdminMessage(
    val id: String, val sender: String,
    val recipient: String, val text: String, val time: String
)
private data class AdminChatUser(val uid: String, val nickname: String)

private fun adminError(t: Throwable, fallback: String): String {
    val raw = t.message.orEmpty()
    return if (raw.isBlank()) fallback else com.vghost.app.i18n.BackendErrorTranslations.localize(raw, com.vghost.app.i18n.AppLocale.language.value)
}

@Composable
fun AdminScreen(onBack: () -> Unit, onAdminRejected: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { VGhostApi.init(context) }
    var authorized by remember { mutableStateOf<Boolean?>(null) }
    var users by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var messages by remember { mutableStateOf<List<AdminMessage>>(emptyList()) }
    var messageUsers by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var selectedMessageUser by remember { mutableStateOf<AdminUser?>(null) }
    var chatPartners by remember { mutableStateOf<List<AdminChatUser>>(emptyList()) }
    var selectedChatPartner by remember { mutableStateOf<AdminChatUser?>(null) }
    var messageSearch by remember { mutableStateOf("") }
    var usersCount by remember { mutableStateOf(0) }
    var messageCount by remember { mutableStateOf(0) }
    var adminRecoveryLogin by remember { mutableStateOf("") }
    var onlineCount by remember { mutableStateOf(0) }
    var selectedUserForCoins by remember { mutableStateOf<AdminUser?>(null) }
    var sendCoinsToAll by remember { mutableStateOf(false) }
    var coinGiftMessage by remember { mutableStateOf("") }
    var coinSearch by remember { mutableStateOf("") }
    var coinSearchResults by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var coinAmount by remember { mutableStateOf("100") }
    var totalCoins by remember { mutableStateOf(0L) }
    var coinOverviewUsers by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var coinOverviewSearch by remember { mutableStateOf("") }
    var coinOverviewSearchResults by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var selectedUserForCoinEdit by remember { mutableStateOf<AdminUser?>(null) }
    var editCoinBalance by remember { mutableStateOf("") }
    var coinConfirmCode by remember { mutableStateOf("") }
    var adminSecurityCode by remember { mutableStateOf("") }
    var broadcastLink by remember { mutableStateOf("") }
    var securityDialog by remember { mutableStateOf(false) }
    var securityBusy by remember { mutableStateOf(false) }
    var pendingSecurityAction by remember { mutableStateOf<((String) -> Unit)?>(null) }
    var showLogs by remember { mutableStateOf(false) }
    var showDataTools by remember { mutableStateOf(false) }
    var searchUsers by remember { mutableStateOf("") }
    var adminLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var title by remember { mutableStateOf("VGhost") }
    var body by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var pendingExport by remember { mutableStateOf<Pair<String, ByteArray>?>(null) }
    var pendingImportToken by remember { mutableStateOf<String?>(null) }
    var pendingImportSummary by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun requestAdminSecurity(action: (String) -> Unit) {
        pendingSecurityAction = action
        securityDialog = true
    }

    fun rejectAdminSecurity() {
        securityDialog = false
        pendingSecurityAction = null
        adminSecurityCode = ""
        android.widget.Toast.makeText(context, com.vghost.app.i18n.VGhostLanguage.trKey("not_admin"), android.widget.Toast.LENGTH_LONG).show()
        VGhostRepository.instance.logout()
        onAdminRejected()
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/gzip")) { uri ->
        val pending = pendingExport
        if (uri != null && pending != null) {
            scope.launch {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(pending.second) }
                        ?: throw IllegalStateException(trKey("backup_file_could_not_written"))
                    status = com.vghost.app.i18n.VGhostLanguage.trKey("backup_saved").format(pending.first)
                } catch (e: Throwable) { status = adminError(e, trKey("backup_was_not_saved")) }
                finally { pendingExport = null }
            }
        } else { pendingExport = null }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalStateException(trKey("backup_file_could_not_read"))
                    if (bytes.size > 512 * 1024 * 1024) throw IllegalStateException(trKey("backup_exceeds_512_mb_limit"))
                    status = trKey("checking_backup")
                    val name = "vghost-import.sql.gz"
                    val result = VGhostApi.adminBackupValidate(name, bytes, adminSecurityCode)
                    if (!result.optBoolean("valid")) throw IllegalStateException(trKey("backup_invalid"))
                    pendingImportToken = result.optString("confirmToken")
                    pendingImportSummary = trfKey("ui_sql_import_summary", result.optInt("statements"), result.optInt("tables"))
                    status = trKey("backup_checked_waiting_import_confirmation")
                } catch (e: Throwable) { status = adminError(e, trKey("backup_was_not_checked")) }
            }
        }
    }

    suspend fun loadData() {
        loading = true
        try {
            val dash = VGhostApi.adminDashboard()
            authorized = true
            usersCount = dash.optInt("users",0)
            onlineCount = dash.optInt("online",0)
            messageCount = dash.optInt("active_messages",0)
            totalCoins = dash.optLong("total_coins",0L)
            adminRecoveryLogin = dash.optString("email", "")
            val ua = VGhostApi.adminUsers(searchUsers).optJSONArray("users") ?: JSONArray()
            users = (0 until ua.length()).map { val o=ua.getJSONObject(it); AdminUser(o.optString("uid"),o.optString("nickname"),o.optBoolean("isBanned"),o.optLong("coinBalance",0L)) }
            try {
                val cj = VGhostApi.adminCoinsOverview()
                totalCoins = cj.optLong("totalCoins",0L)
                val ca = cj.optJSONArray("users") ?: JSONArray()
                coinOverviewUsers = (0 until ca.length()).map { i -> val o=ca.getJSONObject(i); AdminUser(o.optString("uid"),o.optString("nickname"),false,o.optLong("balance",0L)) }
            } catch (_: Throwable) {}
            val ma = VGhostApi.adminMessages().optJSONArray("messages") ?: JSONArray()
            messages = (0 until ma.length()).map { val o=ma.getJSONObject(it); AdminMessage(o.optString("id"),o.optString("senderNickname"),o.optString("receiverNickname"),o.optString("message"),o.optString("created_at")) }
            val byNickname = users.associateBy { it.nickname.lowercase() }
            val ids = linkedMapOf<String, AdminUser>()
            messages.forEach { m ->
                byNickname[m.sender.lowercase()]?.let { ids[it.uid] = it }
                byNickname[m.recipient.lowercase()]?.let { ids[it.uid] = it }
            }
            messageUsers = ids.values.toList()
            status = ""
        } catch (e: Throwable) { authorized=false; status=adminError(e, trKey("unable_load_admin_data")) } finally { loading=false }
    }

    LaunchedEffect(Unit) {
        try {
            val dash = VGhostApi.adminDashboard()
            authorized = true
            usersCount = dash.optInt("users",0)
            onlineCount = dash.optInt("online",0)
            messageCount = dash.optInt("active_messages",0)
            totalCoins = dash.optLong("total_coins",0L)
            adminRecoveryLogin = dash.optString("email", "")
            loading = false
        } catch (e: Exception) {
            authorized = false
            status = adminError(e, trKey("unable_load_admin_data"))
            loading = false
        }
    }

    LaunchedEffect(coinSearch) {
        val q = coinSearch.trim()
        if (q.isBlank()) {
            coinSearchResults = emptyList()
        } else {
            // Search the server while typing so users outside the initial 200-user
            // admin list are also found immediately.
            delay(220)
            try {
                val j = VGhostApi.adminUsers(q)
                val a = j.optJSONArray("users") ?: JSONArray()
                coinSearchResults = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    AdminUser(
                        o.optString("uid"),
                        o.optString("nickname"),
                        o.optBoolean("isBanned"),
                        o.optLong("coinBalance", 0L)
                    )
                }.take(20)
            } catch (_: Throwable) {
                // Keep local results as a fallback if the live search is offline.
                val lower = q.lowercase()
                coinSearchResults = users.filter {
                    it.nickname.lowercase().contains(lower) || it.uid.lowercase().contains(lower)
                }.take(20)
            }
        }
    }

    LaunchedEffect(coinOverviewSearch) {
        val q = coinOverviewSearch.trim()
        if (q.isBlank()) {
            coinOverviewSearchResults = emptyList()
        } else {
            delay(220)
            try {
                val j = VGhostApi.adminUsers(q)
                val a = j.optJSONArray("users") ?: JSONArray()
                coinOverviewSearchResults = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    AdminUser(
                        o.optString("uid"),
                        o.optString("nickname"),
                        o.optBoolean("isBanned"),
                        o.optLong("coinBalance", o.optLong("balance", 0L))
                    )
                }.take(20)
            } catch (_: Throwable) {
                val lower = q.lowercase()
                coinOverviewSearchResults = coinOverviewUsers.filter {
                    it.nickname.lowercase().contains(lower) || it.uid.lowercase().contains(lower)
                }.take(20)
            }
        }
    }

    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).premiumBackdrop()) {
        if (loading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        } else if (authorized != true) {
            Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(trKey("access_denied"), color = Color(0xFFFF2438), fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(8.dp))
                Text(trKey("super_admin_authorization_required"), color = Color.LightGray)
                Spacer(Modifier.height(18.dp))
                OutlinedButton(onClick = onBack) { Text(trKey("back_2")) }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, trKey("back_3"), tint = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(trKey("v_ghost"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(trKey("red_bullet_white_control_room"), color = Color(0xFFFF2438), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            scope.launch {
                                try {
                                    loadData()
                                    status = trKey("admin_data_updated")
                                } catch (e: Throwable) { status = adminError(e, trKey("unable_load_admin_data")) }
                            }
                        }) {
                            Icon(Icons.Filled.Refresh, trKey("ui_refresh"), tint = Color.White)
                        }
                        Icon(Icons.Filled.Visibility, trKey("ui_admin"), tint = Color(0xFFFF4B5C))
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(trKey("admin_users"), usersCount.toString(), Modifier.weight(1f))
                    StatCard(trKey("admin_online"), onlineCount.toString(), Modifier.weight(1f))
                    StatCard(trKey("admin_messages"), messageCount.toString(), Modifier.weight(1f))
                }
                if (status.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        status,
                        color = if (status.contains("failed", ignoreCase = true) || status.contains("error", ignoreCase = true)) Color(0xFFFF6675) else Color(0xFFD8D8DE),
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        NeonCard {
                            Text(trKey("broadcast_everyone"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                title, { title = it }, Modifier.fillMaxWidth(),
                                label = { Text(trKey("title")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                body, { body = it }, Modifier.fillMaxWidth().heightIn(min = 110.dp),
                                label = { Text(trKey("announcement")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                broadcastLink, { broadcastLink = it }, Modifier.fillMaxWidth(),
                                label = { Text(trKey("link_optional")) },
                                placeholder = { Text(trKey("text_17")) },
                                singleLine = true
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    val message = body.trim()
                                    if (message.isNotEmpty()) {
                                        requestAdminSecurity { code ->
                                            scope.launch {
                                                try {
                                                    val result = VGhostApi.adminBroadcast(title.trim().ifBlank { "VGhost" }, message, broadcastLink.trim(), code)
                                                    body = ""
                                                    broadcastLink = ""
                                                    val sent = result.optInt("pushSent", 0)
                                                    val total = result.optInt("totalDevices", 0)
                                                    val failed = result.optInt("failed", 0)
                                                    val delivery = result.optString("delivery")
                                                    val reason = result.optString("reason")
                                                    status = if (delivery == "fcm") trfKey("h_fbb89d9f7668", sent, total, if (failed > 0) trfKey("h_cab1a53c045a", failed) else "") else trfKey("h_8d286aca4907", reason.ifBlank { delivery })
                                                } catch (e: Exception) {
                                                    status = adminError(e, trKey("broadcast_failed"))
                                                } finally { adminSecurityCode = "" }
                                            }
                                        }
                                    }
                                },
                                enabled = body.isNotBlank()
                            ) { Icon(Icons.Filled.Send, null); Spacer(Modifier.width(6.dp)); Text(trKey("send_all_2")) }
                            Text(
                                if (status.isBlank()) trKey("registered_devices_receive_announcement_through_firebase_cloud_messaging")
                                else status,
                                color = Color(0xFFD8D8DE), fontSize = 11.sp
                            )
                        }
                    }
                    item {
                        NeonCard {
                            Text(trKey("admin_controls"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    if (showLogs) showLogs = false
                                    else {
                                        showLogs = true
                                        scope.launch {
                                            try {
                                                val logs = VGhostApi.adminLogs().optJSONArray("logs") ?: JSONArray()
                                                adminLogs = (0 until logs.length()).map { i -> val m=logs.getJSONObject(i); "${m.optString("action")} • target=${m.optString("targetNickname")} • actor=${m.optString("adminNickname")}" }
                                            } catch (e: Throwable) { status = adminError(e, trKey("unable_load_admin_logs")) }
                                        }
                                    }
                                }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.List, null); Spacer(Modifier.width(5.dp)); Text(trKey("logs"))
                                }
                                OutlinedButton(onClick = { showDataTools = !showDataTools }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.CloudUpload, null); Spacer(Modifier.width(5.dp)); Text(trKey("backup"))
                                }
                            }
                            if (showLogs) {
                                Spacer(Modifier.height(8.dp))
                                adminLogs.take(20).forEach { log ->
                                    Text(log, color = Color(0xFFD8D8DE), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                                }
                            }
                            if (showDataTools) {
                                Spacer(Modifier.height(8.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        requestAdminSecurity { code ->
                                            adminSecurityCode = code
                                            scope.launch {
                                                try {
                                                    status = trKey("preparing_backup")
                                                    pendingExport = VGhostApi.adminBackupExport(code)
                                                    exportLauncher.launch(pendingExport?.first ?: "vghost-backup.sql.gz")
                                                } catch (e: Throwable) { status = adminError(e, trKey("backup_export_failed")); adminSecurityCode = "" }
                                            }
                                        }
                                    }, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Filled.CloudUpload, null); Spacer(Modifier.width(4.dp)); Text(trKey("export"))
                                    }
                                    OutlinedButton(onClick = {
                                        requestAdminSecurity { code ->
                                            adminSecurityCode = code
                                            importLauncher.launch(arrayOf("application/gzip", "application/octet-stream"))
                                        }
                                    }, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Filled.CloudDownload, null); Spacer(Modifier.width(4.dp)); Text(trKey("import_label"))
                                    }
                                }
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Text(trKey("users_2"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = searchUsers,
                                onValueChange = { searchUsers = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(trKey("search_nickname_uid_2")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    try {
                                        val ua = VGhostApi.adminUsers(searchUsers).optJSONArray("users") ?: JSONArray()
                                        users = (0 until ua.length()).map { val o=ua.getJSONObject(it); AdminUser(o.optString("uid"),o.optString("nickname"),o.optBoolean("isBanned"),o.optLong("coinBalance",0L)) }
                                        status = trKey("user_list_updated")
                                    } catch (e: Throwable) { status = adminError(e, trKey("users_could_not_loaded")) }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text(trKey("load_users")) }
                            Spacer(Modifier.height(8.dp))
                            users.filter {
                                val q = searchUsers.trim().lowercase()
                                q.isBlank() || it.nickname.lowercase().contains(q) || it.uid.lowercase().contains(q)
                            }.take(100).forEach { u ->
                                UserRow(
                                    u,
                                    onError = { status = it },
                                    onBanStateChanged = { uid, banned ->
                                        users = users.map { if (it.uid == uid) it.copy(banned = banned) else it }
                                    },
                                    onDeleted = { uid ->
                                        users = users.filterNot { it.uid == uid }
                                        coinOverviewUsers = coinOverviewUsers.filterNot { it.uid == uid }
                                        // Re-read the dashboard count because the visible
                                        // list may currently be filtered by nickname/UID.
                                        scope.launch {
                                            try {
                                                val dash = VGhostApi.adminDashboard()
                                                usersCount = dash.optInt("users", usersCount)
                                                onlineCount = dash.optInt("online", onlineCount)
                                                totalCoins = dash.optLong("total_coins", totalCoins)
                                            } catch (_: Throwable) {}
                                        }
                                    },
                                    onCoins = { selectedUserForCoins = it },
                                    requestSecurity = ::requestAdminSecurity,
                                    securityCode = adminSecurityCode
                                )
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        VGhostCoinIcon(size = 30.dp)
                                        Spacer(Modifier.width(7.dp))
                                        Text(trKey("coin_coin_circulation"), color = Color(0xFFFFD54A), fontWeight = FontWeight.Bold)
                                    }
                                    Text(trKey("all_coins_circulation"), color = Color(0xFF8F8D9B), fontSize = 10.sp)
                                }
                                Text(trfKey("coin", totalCoins), color = Color(0xFFFFD54A), fontSize = 21.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = coinOverviewSearch,
                                onValueChange = { coinOverviewSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(trKey("search_user_bullet_coin_amount")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    try {
                                        val j = VGhostApi.adminCoinsOverview()
                                        totalCoins = j.optLong("totalCoins",0L)
                                        val a = j.optJSONArray("users") ?: JSONArray()
                                        coinOverviewUsers = (0 until a.length()).map { i ->
                                            val o=a.getJSONObject(i)
                                            AdminUser(o.optString("uid"),o.optString("nickname"),false,o.optLong("balance",0L))
                                        }
                                        status = com.vghost.app.i18n.VGhostLanguage.trKey("coin_circulation_updated")
                                    } catch(e:Throwable) { status=adminError(e, com.vghost.app.i18n.VGhostLanguage.trKey("coin_data_could_not_loaded")) }
                                }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(6.dp)); Text(trKey("update_coins"))
                            }
                            Spacer(Modifier.height(8.dp))
                            val q = coinOverviewSearch.trim()
                            if (q.isNotBlank()) {
                                if (coinOverviewSearchResults.isEmpty()) {
                                    Text(trKey("user_not_found"), color = Color(0xFF888894), fontSize = 12.sp)
                                }
                                coinOverviewSearchResults.take(20).forEach { u ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                            .background(Color(0x4416161C), RoundedCornerShape(12.dp))
                                            .clickable {
                                                coinOverviewSearch = u.nickname
                                                selectedUserForCoinEdit = u
                                                editCoinBalance = u.coinBalance.toString()
                                                coinConfirmCode = ""
                                            }
                                            .padding(horizontal = 12.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        VGhostCoinIcon(size = 26.dp)
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text(trfKey("uid", u.uid), color = Color(0xFF77758A), fontSize = 9.sp)
                                        }
                                        VGhostCoinAmount(trfKey("coin_2", u.coinBalance), iconSize = 20.dp, color = Color(0xFFFFD54A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else if (coinOverviewUsers.isNotEmpty()) {
                                coinOverviewUsers.take(100).forEach { u ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical=4.dp).background(Color(0x4416161C), RoundedCornerShape(12.dp)).padding(horizontal=12.dp,vertical=9.dp),
                                        verticalAlignment=Alignment.CenterVertically
                                    ) {
                                        VGhostCoinIcon(size = 26.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(u.nickname,color=Color.White,fontWeight=FontWeight.SemiBold)
                                            Text(trfKey("uid", u.uid),color=Color(0xFF77758A),fontSize=9.sp)
                                        }
                                        VGhostCoinAmount(trfKey("coin_2", u.coinBalance), iconSize = 21.dp, color=Color(0xFFFFD54A),fontWeight=FontWeight.Bold,fontSize=12.sp)
                                        Spacer(Modifier.width(6.dp))
                                        TextButton(onClick={ selectedUserForCoinEdit=u; editCoinBalance=u.coinBalance.toString(); coinConfirmCode="" }) { Text(trKey("edit")) }
                                    }
                                }
                            } else {
                                Text(trKey("it_will_appear_automatically_when_user_starts_searching"), color = Color(0xFF77758A), fontSize = 11.sp)
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Text(trKey("chat_message_list"), color = Color(0xFFFF4B5C), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = messageSearch,
                                onValueChange = { messageSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(trKey("search_users")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    try {
                                        val j = VGhostApi.adminMessages()
                                        messages = (0 until (j.optJSONArray("messages") ?: JSONArray()).length()).map { i -> val o=j.getJSONArray("messages").getJSONObject(i); AdminMessage(o.optString("id"),o.optString("senderNickname"),o.optString("receiverNickname"),o.optString("message"),o.optString("created_at")) }
                                        val byNickname = users.associateBy { it.nickname.lowercase() }
                                        val ids = linkedMapOf<String, AdminUser>()
                                        messages.forEach { m -> byNickname[m.sender.lowercase()]?.let { ids[it.uid] = it }; byNickname[m.recipient.lowercase()]?.let { ids[it.uid] = it } }
                                        messageUsers = ids.values.toList()
                                        status = trKey("messages_loaded")
                                    } catch (e: Throwable) { status = adminError(e, trKey("messages_could_not_loaded")) }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text(trKey("load_messages")) }
                            Spacer(Modifier.height(8.dp))
                            if (selectedMessageUser == null) {
                                messageUsers.filter { messageSearch.isBlank() || it.nickname.contains(messageSearch.trim(), true) || it.uid.contains(messageSearch.trim(), true) }.forEach { u ->
                                    MessageUserRow(u) {
                                        selectedMessageUser = u
                                        selectedChatPartner = null
                                        scope.launch {
                                            try {
                                                val j = VGhostApi.adminMessages(u.uid)
                                                val ca = j.optJSONArray("contacts") ?: JSONArray()
                                                chatPartners = (0 until ca.length()).map { i -> val o=ca.getJSONObject(i); AdminChatUser(o.optString("uid"),o.optString("nickname")) }
                                            } catch (e: Throwable) { status = adminError(e, com.vghost.app.i18n.VGhostLanguage.trKey("unable_load_conversations")) }
                                        }
                                    }
                                }
                            } else if (selectedChatPartner == null) {
                                Text(trfKey("sohbet_etti_i_ki_iler", selectedMessageUser!!.nickname), color = Color.LightGray, fontSize = 12.sp)
                                Spacer(Modifier.height(5.dp))
                                TextButton(onClick = { selectedMessageUser = null; chatPartners = emptyList() }) { Text(trKey("arrow_left_message_list")) }
                                chatPartners.forEach { partner ->
                                    MessageUserRow(AdminUser(partner.uid, partner.nickname, false)) {
                                        selectedChatPartner = partner
                                        scope.launch {
                                            try {
                                                val j = VGhostApi.adminMessages(selectedMessageUser!!.uid, partner.uid)
                                                val pa = j.optJSONArray("messages") ?: JSONArray()
                                                messages = (0 until pa.length()).map { i -> val o=pa.getJSONObject(i); AdminMessage(o.optString("id"),o.optString("senderNickname"),o.optString("receiverNickname"),o.optString("message"),o.optString("created_at")) }
                                            } catch (e: Throwable) { status = adminError(e, com.vghost.app.i18n.VGhostLanguage.trKey("unable_load_chat")) }
                                        }
                                    }
                                }
                            } else {
                                Text(trfKey("text_21", selectedMessageUser!!.nickname, selectedChatPartner!!.nickname), color = Color.White, fontWeight = FontWeight.Bold)
                                TextButton(onClick = { selectedChatPartner = null }) { Text(trKey("arrow_left_people_they_chatted")) }
                                messages.forEach { m ->
                                    MessageRow(
                                        m = m,
                                        onError = { status = it },
                                        refresh = {
                                            scope.launch {
                                                try {
                                                    val j = VGhostApi.adminMessages(
                                                        selectedMessageUser!!.uid,
                                                        selectedChatPartner!!.uid
                                                    )
                                                    val pa = j.optJSONArray("messages") ?: JSONArray()
                                                    messages = (0 until pa.length()).map { i ->
                                                        val o = pa.getJSONObject(i)
                                                        AdminMessage(
                                                            o.optString("id"),
                                                            o.optString("senderNickname"),
                                                            o.optString("receiverNickname"),
                                                            o.optString("message"),
                                                            o.optString("created_at")
                                                        )
                                                    }
                                                } catch (e: Throwable) {
                                                    status = adminError(e, com.vghost.app.i18n.VGhostLanguage.trKey("unable_refresh_chat"))
                                                }
                                            }
                                        },
                                        securityCode = adminSecurityCode,
                                        requestSecurity = ::requestAdminSecurity
                                    )
                                }
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                VGhostCoinIcon(size = 30.dp)
                                Spacer(Modifier.width(7.dp))
                                Text(trKey("coin_coin_transfer"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    selectedUserForCoins = null
                                    sendCoinsToAll = true
                                    coinAmount = "100"
                                    coinGiftMessage = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.People, null); Spacer(Modifier.width(6.dp)); Text(trKey("send_coins_all_users"))
                            }
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = coinSearch,
                                onValueChange = { coinSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(trKey("search_nickname_uid")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            if (coinSearch.trim().isNotBlank() && coinSearchResults.isEmpty()) {
                                Text(trKey("user_not_found"), color = Color(0xFF888894), fontSize = 12.sp)
                            }
                            coinSearchResults.take(20).forEach { u ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                        .background(Color(0x5516161C), RoundedCornerShape(12.dp))
                                        .clickable {
                                            selectedUserForCoins = u
                                            coinConfirmCode = ""
                                        }.padding(horizontal = 12.dp, vertical = 11.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    VGhostCoinIcon(size = 26.dp)
                                    Spacer(Modifier.width(9.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text(trfKey("uid", u.uid), color = Color(0xFF77758A), fontSize = 9.sp)
                                    }
                                    Text(trKey("click"), color = Color(0xFFFF4B5C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    }
                }
            }
        }

        if (selectedUserForCoinEdit != null) {
            val user = selectedUserForCoinEdit!!
            AlertDialog(
                onDismissRequest = { selectedUserForCoinEdit = null },
                title = { Text(trKey("coin_edit_coin_balance")) },
                text = {
                    Column {
                        Text(user.nickname, color = Color.White, fontWeight = FontWeight.Bold)
                        VGhostCoinAmount(trfKey("current_balance_coin", user.coinBalance), iconSize = 22.dp, color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = editCoinBalance,
                            onValueChange = { editCoinBalance = it.filter(Char::isDigit).take(12) },
                            label = { Text(trKey("new_coin_amount")) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(trKey("new_number_will_written_directly_balance"), color = Color(0xFF888894), fontSize = 10.sp)
                    }
                },
                confirmButton = {
                    Button(enabled=editCoinBalance.toLongOrNull()!=null, onClick={
                        requestAdminSecurity { code ->
                            scope.launch {
                                try {
                                    val balance=editCoinBalance.toLongOrNull() ?: 0L
                                    val r=VGhostApi.adminSetCoins(user.uid,balance,code)
                                    val newBal=r.optLong("balance",balance)
                                    // Re-read the authoritative server state so both the edited
                                    // wallet and total circulation are guaranteed to match DB.
                                    try {
                                        val fresh=VGhostApi.adminCoinsOverview()
                                        totalCoins=fresh.optLong("totalCoins",totalCoins)
                                        val fa=fresh.optJSONArray("users")
                                        if(fa!=null) coinOverviewUsers=(0 until fa.length()).map { i ->
                                            val o=fa.getJSONObject(i)
                                            AdminUser(o.optString("uid"),o.optString("nickname"),false,o.optLong("balance",0L))
                                        }
                                    } catch(_:Throwable) {
                                        coinOverviewUsers=coinOverviewUsers.map { if(it.uid==user.uid) it.copy(coinBalance=newBal) else it }
                                        totalCoins=coinOverviewUsers.sumOf { it.coinBalance }
                                    }
                                    users=users.map { if(it.uid==user.uid) it.copy(coinBalance=newBal) else it }
                                    status = trfKey("h_b5348913976d", user.nickname, newBal)
                                    selectedUserForCoinEdit=null
                                } catch(e:Throwable) { status=adminError(e, com.vghost.app.i18n.VGhostLanguage.trKey("coin_balance_was_not_changed")) }
                            }
                        }
                    }) { Text(trKey("save")) }
                },
                dismissButton = { TextButton(onClick={ selectedUserForCoinEdit=null }) { Text(trKey("cancel_2")) } }
            )
        }

        if (securityDialog) {
            var enteredCode by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { },
                title = { Text(trKey("admin_security")) },
                text = {
                    Column {
                        Text(trKey("enter_admin_confirmation_code_operation"), color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = enteredCode,
                            onValueChange = { enteredCode = it },
                            label = { Text(trKey("admin_code")) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        enabled = enteredCode.isNotBlank() && !securityBusy,
                        onClick = {
                            securityBusy = true
                            scope.launch {
                                try {
                                    VGhostApi.adminSecurityVerify(enteredCode.trim())
                                    val action = pendingSecurityAction
                                    pendingSecurityAction = null
                                    securityDialog = false
                                    val verifiedCode = enteredCode.trim()
                                    enteredCode = ""
                                    adminSecurityCode = verifiedCode
                                    action?.invoke(verifiedCode)
                                } catch (e: Throwable) {
                                    val msg = adminError(e, trKey("admin_code_incorrect"))
                                    status = if (msg.contains("INVALID_SECURITY_CODE", true)) {
                                        com.vghost.app.i18n.VGhostLanguage.trKey("admin_confirmation_code_incorrect_try_again")
                                    } else msg
                                    // Keep the dialog open on verification failure, but make
                                    // the server error immediately visible instead of leaving
                                    // it hidden behind the modal.
                                    android.widget.Toast.makeText(context, status, android.widget.Toast.LENGTH_LONG).show()
                                    if (msg.contains("SUPER_ADMIN_REQUIRED", true)) {
                                        securityDialog = false
                                        pendingSecurityAction = null
                                    }
                                } finally {
                                    securityBusy = false
                                }
                            }
                        }
                    ) { Text(trKey("confirm_2")) }
                },
                dismissButton = {
                    TextButton(onClick = { securityDialog = false; pendingSecurityAction = null }) { Text(trKey("cancel_2")) }
                }
            )
        }
        if (sendCoinsToAll) {
            AlertDialog(
                onDismissRequest = { sendCoinsToAll = false },
                title = { Text(trKey("coin_coins_all_users")) },
                text = {
                    Column {
                        Text(trKey("coins_will_added_all_active_users_accounts"), color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = coinAmount,
                            onValueChange = { coinAmount = it.filter { c -> c.isDigit() } },
                            label = { Text(trKey("coin_amount")) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = coinGiftMessage,
                            onValueChange = { coinGiftMessage = it },
                            label = { Text(trKey("text_gift_message")) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp)
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(trKey("m_s_l_n_yeni_iliniz_m_bar_k_alert_gift_bu_coinl_r_siz_h_diyy_dir"), color = Color(0xFFD8D8DE), fontSize = 10.sp)
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val amount = coinAmount.toLongOrNull()
                        val message = coinGiftMessage.trim()
                        if (amount == null || amount <= 0L) {
                            status = trKey("coin_amount_required")
                        } else if (message.isBlank()) {
                            status = trKey("add_message")
                        } else {
                            requestAdminSecurity { code ->
                                scope.launch {
                                    try {
                                        val result = VGhostApi.adminCoinsAll(amount, message, code)
                                        val count = result.optInt("usersCredited", 0)
                                        val notified = result.optInt("notificationsCreated", 0)
                                        status = trfKey("h_bbf2790f6d50", amount, count, notified)
                                        sendCoinsToAll = false
                                        coinGiftMessage = ""
                                        coinConfirmCode = ""
                                    } catch (e: Throwable) {
                                        status = adminError(e, trKey("coins_were_not_sent"))
                                    }
                                }
                            }
                        }
                    }) { Text(trKey("send_all")) }
                },
                dismissButton = { TextButton(onClick = { sendCoinsToAll = false }) { Text(trKey("cancel")) } }
            )
        }
        selectedUserForCoins?.let { user ->
            AlertDialog(
                onDismissRequest = { selectedUserForCoins = null },
                title = { Text(trfKey("send_coin_bullet", user.nickname)) },
                text = {
                    Column {
                        Text(trKey("enter_amount_admin_confirmation_code"), color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = coinAmount,
                            onValueChange = { coinAmount = it.filter { c -> c.isDigit() || c == '-' } },
                            label = { Text(trKey("coin_amount")) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            trKey("yola_g_nd_r_d_ym_sin_basanda_admin_t_sdiq_kodu_ayr_ca_soru_ulacaq"),
                            color = Color(0xFFD8D8DE), fontSize = 10.sp
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val amount = coinAmount.toLongOrNull()
                        if (amount == null || amount == 0L) {
                            status = trKey("coin_amount_required")
                        } else {
                            requestAdminSecurity { code ->
                                scope.launch {
                                    try {
                                        val result = VGhostApi.adminCoins(user.uid, amount, code)
                                        val newBalance = result.optLong("balance", -1L)
                                        status = if (newBalance >= 0L) {
                                            trfKey("h_c1504bbf4b95", user.nickname, amount, newBalance)
                                        } else {
                                            trfKey("h_5865614a19cc", user.nickname, amount)
                                        }
                                        // Reload the admin user data after the server confirms the wallet update.
                                        try {
                                            val refreshed = VGhostApi.adminUsers("", adminSecurityCode)
                                            val ua2 = refreshed.optJSONArray("users")
                                            if (ua2 != null) users = (0 until ua2.length()).map { val o=ua2.getJSONObject(it); AdminUser(o.optString("uid"),o.optString("nickname"),o.optBoolean("isBanned"),o.optLong("coinBalance",0L)) }
                                        } catch (_: Throwable) { }
                                        selectedUserForCoins = null
                                        coinConfirmCode = ""
                                    } catch (e: Throwable) {
                                        status = adminError(e, trKey("coins_were_not_sent"))
                                    }
                                }
                            }
                        }
                    }) { Text(trKey("send_2")) }
                },
                dismissButton = { TextButton(onClick = { selectedUserForCoins = null }) { Text(trKey("cancel")) } }
            )
        }
        pendingImportToken?.let { token ->
            AlertDialog(
                onDismissRequest = { pendingImportToken = null },
                title = { Text(trKey("full_import_confirmation")) },
                text = { Text(trfKey("bu_i_lem_mevcut_verileri_de_i_tirebilir_veya_zerine_yazabilir_devam_etmek_istiyor_musunuz", pendingImportSummary)) },
                confirmButton = {
                    Button(onClick = {
                        scope.launch {
                            try {
                                status = trKey("importing_backup")
                                val result = VGhostApi.adminBackupImport(token, adminSecurityCode)
                                pendingImportToken = null
                                status = trfKey("h_5ef73ec4a025", result.optInt("statements"))
                                loadData()
                            } catch (e: Throwable) { status = adminError(e, trKey("import_failed")); pendingImportToken = null }
                            finally { adminSecurityCode = "" }
                        }
                    }) { Text(trKey("confirm_import")) }
                },
                dismissButton = { OutlinedButton(onClick = { pendingImportToken = null }) { Text(trKey("cancel_2")) } }
            )
        }
    }

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.shadow(16.dp, RoundedCornerShape(18.dp))
            .background(Color(0xF20D0D12), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0x99FF2438), RoundedCornerShape(18.dp))
            .padding(16.dp)
            .then(modifier)
    ) {
        Text(label, color = Color(0xFFD8D8DE), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(20.dp))
            .background(Color(0xF20D0D12), RoundedCornerShape(20.dp))
            .border(1.dp, Color(0x99FF2438), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun UserRow(
    u: AdminUser,
    
    onError: (String) -> Unit,
    onBanStateChanged: (String, Boolean) -> Unit,
    onDeleted: (String) -> Unit,
    onCoins: (AdminUser) -> Unit,
    requestSecurity: (((String) -> Unit) -> Unit),
    securityCode: String
) {
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Row(
        Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.People, null, tint = if (u.banned) Color(0xFFFF2438) else Color(0xFFFF2438))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(u.uid, color = Color(0xFF77758A), fontSize = 9.sp)
        }
        TextButton(
            enabled = !busy,
            onClick = {
                requestSecurity { code ->
                    busy = true
                    scope.launch {
                        try {
                            VGhostApi.adminUserAction(u.uid, if (u.banned) "unban" else "ban", code, durationDays = 7)
                            val updated = !u.banned
                            onBanStateChanged(u.uid, updated)
                        } catch (e: Throwable) {
                            onError(adminError(e, if (u.banned) trKey("unban_failed") else trKey("ban_failed")))
                        } finally {
                            busy = false
                        }
                    }
                }
            }
        ) { Text(if (u.banned) trKey("unban") else trKey("ban")) }
        IconButton(enabled = !busy, onClick = { onCoins(u) }) {
            VGhostCoinIcon(size = 27.dp, contentDescription = com.vghost.app.i18n.VGhostLanguage.trKey("ghost_coins_2"))
        }
        TextButton(
            enabled = !busy,
            onClick = {
                requestSecurity { code ->
                    busy = true
                    scope.launch {
                        try {
                            VGhostApi.adminUserAction(u.uid, "delete", code)
                            onDeleted(u.uid)
                        } catch (e: Throwable) {
                            onError(adminError(e, trKey("delete_failed")))
                        } finally {
                            busy = false
                        }
                    }
                }
            }
        ) { Text(trKey("delete_2"), color = Color(0xFFFF2438)) }
    }
}

@Composable
private fun MessageUserRow(u: AdminUser, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Color(0x5516161C), RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.People, null, tint = Color(0xFFFF2438))
        Spacer(Modifier.width(9.dp))
        Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(trKey("click"), color = Color(0xFFFF4B5C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MessageRow(
    m: AdminMessage,
    onError: (String) -> Unit,
    refresh: suspend () -> Unit,
    securityCode: String,
    requestSecurity: (((String) -> Unit) -> Unit)
) {
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxWidth().padding(vertical = 7.dp)
            .background(Color(0x6616161C), RoundedCornerShape(12.dp))
            .padding(11.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(trfKey("arrow_right", m.sender, m.recipient), color = Color(0xFFFF2438), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(
                enabled = !busy,
                onClick = {
                    requestSecurity { code ->
                        busy = true
                        scope.launch {
                            try {
                                VGhostApi.adminDeleteMessage(m.id, code)
                                refresh()
                            } catch (e: Throwable) {
                                onError(adminError(e, trKey("message_delete_failed")))
                            } finally {
                                busy = false
                            }
                        }
                    }
                }
            ) { Icon(Icons.Filled.Delete, com.vghost.app.i18n.VGhostLanguage.trKey("delete_message"), tint = Color(0xFFFF2438)) }
        }
        Text(m.text, color = Color.White, fontSize = 13.sp)
        Text(m.time, color = Color(0xFF77758A), fontSize = 9.sp)
    }
}
