package com.vghost.app.i18n

import android.content.Context
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Resource-backed translation lookup. Existing tr()/trf() callers remain compatible. */
internal object TranslationResources {
    private val cache = ConcurrentHashMap<String, Int>()
    fun textKey(context: Context, key: String): String? {
        val localized = AppLocale.wrap(context)
        val id = cache.getOrPut(key) { localized.resources.getIdentifier(key, "string", localized.packageName) }
        if (id == 0) return null
        return runCatching { localized.getString(id) }.getOrNull()
    }

    fun text(context: Context, source: String): String? {
        val name = "t_" + MessageDigest.getInstance("SHA-1").digest(source.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }.take(12)
        val id = cache.getOrPut(name) { context.resources.getIdentifier(name, "string", context.packageName) }
        if (id == 0) return null
        return runCatching { context.getString(id) }.getOrNull()
    }
}
