package com.vghost.app.ui.components

import androidx.compose.runtime.Composable
import com.vghost.app.data.model.GiftItem

@Composable
fun GiftReceivedOverlay(gift: GiftItem, sender: String, eventToken: Long, onDismiss: () -> Unit) {
    GiftAnimationEngine(gift = gift, onFinished = onDismiss)
}
