package com.vghost.app.network

import android.content.Context
import android.util.Base64
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.vghost.app.BuildConfig
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.util.UUID
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.IOException

/** Thin cPanel PHP + MySQL API client. Core VGHOST data is server-side. */
object VGhostApi {
    private const val PREFS = "vghost_api"
    private const val KEY_TOKEN = "session_token"
    private const val DEFAULT_BASE = "https://vghost.site/api"
    private lateinit var app: Context
    @Volatile private var authFailureHandler: ((String) -> Unit)? = null
    fun setAuthFailureHandler(handler: ((String) -> Unit)?) { authFailureHandler = handler }
    fun init(context: Context) { app = context.applicationContext }
    private val prefs get() = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private const val KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "VGhostSessionKey"
    private fun secretKey(): SecretKey {
        val ks = java.security.KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        kg.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }
    private fun protect(value: String): String {
        // GCM Cipher instances are single-use: calling doFinal() twice on the
        // same encrypting cipher can fail with trKey("iv_has_already_been_used").
        // Encrypt exactly once and prepend that operation's IV.
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val out = ByteArray(iv.size + encrypted.size)
        System.arraycopy(iv, 0, out, 0, iv.size)
        System.arraycopy(encrypted, 0, out, iv.size, encrypted.size)
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }
    private fun unprotect(value: String): String? = try {
        val all = Base64.decode(value, Base64.NO_WRAP); val iv = all.copyOfRange(0,12); val data = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(data), Charsets.UTF_8)
    } catch (_: Throwable) { null }
    fun token(): String? {
        val stored = prefs.getString(KEY_TOKEN, null) ?: return null
        // Backward compatibility: older VGhost builds stored the session token
        // as plain text. If the user upgrades without logging in again, decrypt
        // will fail and every authenticated action (including gifts/coins) would
        // silently lose its Authorization header. Accept the legacy value once
        // and migrate it to the encrypted format immediately.
        unprotect(stored)?.let { return it }
        if (stored.isNotBlank()) {
            try {
                prefs.edit().putString(KEY_TOKEN, protect(stored)).apply()
            } catch (_: Throwable) {
                // Keep the legacy token usable even if keystore migration fails.
            }
            return stored
        }
        return null
    }
    fun setToken(token: String?) { prefs.edit().apply { if (token == null) remove(KEY_TOKEN) else putString(KEY_TOKEN, protect(token)) }.apply() }
    fun baseUrl(): String = BuildConfig.API_BASE_URL.trimEnd('/')
    fun deviceId(): String { val old=prefs.getString("device_id",null); if(old!=null)return old; val n=UUID.randomUUID().toString(); prefs.edit().putString("device_id",n).apply(); return n }

    suspend fun call(path:String, method:String="GET", data:JSONObject?=null, adminSecurityCode:String?=null, idempotencyKey:String?=null): JSONObject = withContext(Dispatchers.IO) {
        val cleanPath = path.trimStart('/')
        // Some cPanel/Apache installs expose the API through index.php/<route>
        // instead of clean URL rewrites. Try the normal route first, then the
        // front-controller route for every endpoint (not only games). This is
        // important for gifts/send and coins/send, which otherwise look like a
        // failed operation on servers where URL rewriting is disabled.
        val candidates = listOf(cleanPath, "index.php/$cleanPath").distinct()
        var lastError: Throwable? = null
        for ((attempt, route) in candidates.withIndex()) {
            try {
                val url=URL(baseUrl().trimEnd('/')+"/"+route)
                val c=(url.openConnection() as HttpURLConnection)
                c.instanceFollowRedirects=false
                c.requestMethod=method; c.connectTimeout=15000; c.readTimeout=45000
                c.setRequestProperty("Accept","application/json, text/plain;q=0.9, */*;q=0.8")
                c.setRequestProperty("User-Agent","VGhost-Android/1.2")
                c.setRequestProperty("X-VGhost-Client","android")
                token()?.let { c.setRequestProperty("Authorization","Bearer $it") }
                adminSecurityCode?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("X-Admin-Security-Code", it) }
                idempotencyKey?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("Idempotency-Key", it) }
                if(data!=null){ c.doOutput=true; c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.outputStream.use{it.write(data.toString().toByteArray())} }
                val code=try { c.responseCode } catch (e: SSLHandshakeException) {
                    c.disconnect(); throw IllegalStateException(trKey("h_3339f18e9e5c"), e)
                }
                val contentType = c.contentType.orEmpty()
                val stream=if(code in 200..299)c.inputStream else c.errorStream
                val text=stream?.bufferedReader()?.use{it.readText()}.orEmpty().trim(); c.disconnect()
                val out = try {
                    if (text.isBlank()) JSONObject() else JSONObject(text)
                } catch (_: Exception) {
                    val preview = text.replace(Regex("\\s+"), " ").take(300)
                    val kind = if (contentType.contains("text/html", ignoreCase = true) || text.startsWith("<", ignoreCase = true)) trKey("server_returned_html") else trKey("server_response_not_json")
                    throw IllegalStateException("$kind (HTTP $code). $preview")
                }
                if(code !in 200..299) {
                    val apiError = out.optString("error", out.optString("message", trKey("api_error").format(code)))
                    if (apiError.contains("USER_BANNED", true) || code == 401 || apiError.contains("UNAUTHORIZED", true)) {
                        authFailureHandler?.invoke(if (apiError.contains("USER_BANNED", true)) "banned" else "deleted")
                    }
                    // A clean-route 404 can be a hosting rewrite issue. The next candidate
                    // uses /index.php/<route>, which the backend explicitly supports.
                    if (attempt + 1 < candidates.size && code == 404) {
                        lastError = IllegalStateException("$apiError (HTTP $code)")
                        continue
                    }
                    throw IllegalStateException("$apiError (HTTP $code)")
                }
                return@withContext out
            } catch (e: IOException) {
                lastError = e
                if (attempt + 1 < candidates.size) continue
                throw IllegalStateException(trfKey("h_5c7ff34d0536", e.message ?: trKey("ui_network_error")), e)
            } catch (e: Throwable) {
                lastError = e
                if (attempt + 1 < candidates.size && e.message?.contains("HTTP 404") == true) continue
                throw e
            }
        }
        throw IllegalStateException("SERVER_CONNECTION_FAILED", lastError)
    }

    /**
     * Legacy-compatible transaction call for Gift/Coin sends.
     * The old working VGhost client followed server redirects and used the
     * plain /api/<route> URL. Keep that exact transport for wallet transfers
     * so gift/coin behavior is independent from the newer general API routing.
     */
    suspend fun legacyTransactionCall(path:String, method:String="POST", data:JSONObject?=null): JSONObject = withContext(Dispatchers.IO) {
        // Keep the legacy wallet-transfer transport exactly compatible with the
        // older working VGhost client: clean route first, front-controller fallback,
        // and normal redirect following. This is important on cPanel/Apache hosts
        // where /api/<route> may redirect before reaching the PHP router.
        val cleanPath = path.trimStart('/')
        val candidates = listOf(cleanPath, "index.php/$cleanPath").distinct()
        var lastError: Throwable? = null
        for ((attempt, route) in candidates.withIndex()) {
            try {
                val url=URL(baseUrl().trimEnd('/')+"/"+route)
                val c=(url.openConnection() as HttpURLConnection)
                c.instanceFollowRedirects=true
                c.requestMethod=method
                c.connectTimeout=15000
                c.readTimeout=20000
                c.setRequestProperty("Accept","application/json, text/plain;q=0.9, */*;q=0.8")
                c.setRequestProperty("User-Agent","VGhost-Android/1.2")
                c.setRequestProperty("X-VGhost-Client","android")
                token()?.let { c.setRequestProperty("Authorization","Bearer $it") }
                if(data!=null){
                    c.doOutput=true
                    c.setRequestProperty("Content-Type","application/json; charset=utf-8")
                    c.outputStream.use{it.write(data.toString().toByteArray(Charsets.UTF_8))}
                }
                val code=try { c.responseCode } catch (e: SSLHandshakeException) {
                    c.disconnect()
                    throw IllegalStateException(trKey("h_3339f18e9e5c"), e)
                }
                val contentType=c.contentType.orEmpty()
                val stream=if(code in 200..299)c.inputStream else c.errorStream
                val text=stream?.bufferedReader()?.use{it.readText()}.orEmpty().trim()
                c.disconnect()
                val out=try {
                    if(text.isBlank()) JSONObject() else JSONObject(text)
                } catch (_:Throwable) {
                    val preview=text.replace(Regex("\\s+")," ").take(300)
                    val kind=if(contentType.contains("text/html",true)||text.startsWith("<")) trKey("server_returned_html") else trKey("server_response_not_json")
                    throw IllegalStateException("$kind (HTTP $code). $preview")
                }
                if(code !in 200..299){
                    val apiError=out.optString("error",out.optString("message",trKey("api_error").format(code)))
                    if(attempt + 1 < candidates.size && code == 404){
                        lastError=IllegalStateException("$apiError (HTTP $code)")
                        continue
                    }
                    throw IllegalStateException("$apiError (HTTP $code)")
                }
                return@withContext out
            } catch (e: IOException) {
                lastError=e
                if(attempt + 1 < candidates.size) continue
                throw IllegalStateException(trfKey("h_5c7ff34d0536", e.message ?: trKey("ui_network_error")), e)
            } catch (e: Throwable) {
                lastError=e
                if(attempt + 1 < candidates.size && e.message?.contains("HTTP 404") == true) continue
                throw e
            }
        }
        throw IllegalStateException("SERVER_CONNECTION_FAILED", lastError)
    }

    suspend fun download(path:String, method:String="POST", adminSecurityCode:String?=null): Pair<String, ByteArray> = withContext(Dispatchers.IO) {
        val url=URL(baseUrl().trimEnd('/')+"/"+path.trimStart('/'))
        val c=(url.openConnection() as HttpURLConnection)
        c.requestMethod=method; c.instanceFollowRedirects=false; c.connectTimeout=30000; c.readTimeout=300000
        c.setRequestProperty("Accept","application/gzip, application/octet-stream")
        token()?.let { c.setRequestProperty("Authorization","Bearer $it") }
        adminSecurityCode?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("X-Admin-Security-Code", it) }
        if(method != "GET") { c.doOutput=true; c.outputStream.use{} }
        val code=c.responseCode
        val bytes=(if(code in 200..299)c.inputStream else c.errorStream)?.use{it.readBytes()} ?: ByteArray(0)
        val disposition=c.getHeaderField("Content-Disposition").orEmpty(); c.disconnect()
        if(code !in 200..299) throw IllegalStateException(trfKey("h_f439fc4a7a60", code))
        val name=Regex("filename=\"?([^\";]+)").find(disposition)?.groupValues?.getOrNull(1) ?: "vghost-backup.sql.gz"
        name to bytes
    }

    suspend fun uploadMultipart(path:String, fieldName:String, fileName:String, bytes:ByteArray, adminSecurityCode:String?=null, mimeType:String="application/gzip", extraFields:Map<String,String> = emptyMap(), onProgress: ((sentBytes:Long, totalBytes:Long) -> Unit)? = null): JSONObject = withContext(Dispatchers.IO) {
        val boundary="----VGhost"+UUID.randomUUID().toString().replace("-","")
        val cleanPath=path.trimStart('/')
        // PHP/cPanel installations can reject chunked multipart requests before
        // PHP populates $_FILES. Build the complete multipart framing size first
        // and force a fixed Content-Length. This is critical for Stories and voice.
        val prefix = buildString {
            append("--$boundary\r\n")
            append("Content-Disposition: form-data; name=\"$fieldName\"; filename=\"${fileName.replace("\"", "_")}\"\r\n")
            append("Content-Type: $mimeType\r\n\r\n")
        }.toByteArray(Charsets.UTF_8)
        val suffix = buildString {
            append("\r\n")
            for ((k,v) in extraFields) {
                append("--$boundary\r\n")
                append("Content-Disposition: form-data; name=\"$k\"\r\n\r\n")
                append(v)
                append("\r\n")
            }
            append("--$boundary--\r\n")
        }.toByteArray(Charsets.UTF_8)
        val totalBytes=prefix.size.toLong()+bytes.size.toLong()+suffix.size.toLong()
        if(totalBytes > Int.MAX_VALUE.toLong()) throw IllegalArgumentException("UPLOAD_TOO_LARGE")
        val candidates=listOf(cleanPath,"index.php/$cleanPath").distinct()
        var lastError:Throwable?=null
        for((attempt,route) in candidates.withIndex()) {
            try {
                val url=URL(baseUrl().trimEnd('/')+"/"+route)
                val c=(url.openConnection() as HttpURLConnection)
                c.instanceFollowRedirects=false
                c.requestMethod="POST"
                c.connectTimeout=30000
                c.readTimeout=300000
                c.doOutput=true
                c.setRequestProperty("Accept","application/json")
                c.setRequestProperty("Content-Type","multipart/form-data; boundary=$boundary")
                c.setRequestProperty("Content-Length",totalBytes.toString())
                c.setRequestProperty("User-Agent","VGhost-Android/1.2")
                c.setRequestProperty("X-VGhost-Client","android")
                token()?.let { c.setRequestProperty("Authorization","Bearer $it") }
                adminSecurityCode?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("X-Admin-Security-Code", it) }
                c.setFixedLengthStreamingMode(totalBytes)
                c.outputStream.use { out ->
                    var sentBytes=0L
                    fun writeTracked(data:ByteArray) {
                        if(data.isEmpty()) return
                        out.write(data)
                        sentBytes+=data.size.toLong()
                        onProgress?.invoke(sentBytes,totalBytes)
                    }
                    writeTracked(prefix)
                    val chunkSize=64*1024
                    var offset=0
                    while(offset<bytes.size) {
                        val count=minOf(chunkSize,bytes.size-offset)
                        out.write(bytes,offset,count)
                        offset+=count
                        sentBytes+=count.toLong()
                        onProgress?.invoke(sentBytes,totalBytes)
                    }
                    writeTracked(suffix)
                    out.flush()
                }
                val code=c.responseCode
                val stream=if(code in 200..299)c.inputStream else c.errorStream
                val text=stream?.bufferedReader()?.use{it.readText()}.orEmpty()
                val contentType=c.contentType.orEmpty()
                c.disconnect()
                val json=try{JSONObject(text)}catch(_:Throwable){
                    val preview=text.replace(Regex("\\s+")," ").trim().take(300)
                    throw IllegalStateException(if(preview.isBlank()) trfKey("h_6e3d702b4f25",code) else trfKey("h_72b33d5188f4",code,preview))
                }
                if(code !in 200..299) {
                    val msg=json.optString("error",json.optString("message",trKey("api_error").format(code)))
                    if(attempt+1<candidates.size && code==404) {
                        lastError=IllegalStateException("$msg (HTTP $code)")
                        continue
                    }
                    throw IllegalStateException("$msg (HTTP $code)")
                }
                return@withContext json
            } catch(e:Throwable) {
                lastError=e
                if(attempt+1<candidates.size && e.message?.contains("HTTP 404")==true) continue
                throw e
            }
        }
        throw IllegalStateException("SERVER_CONNECTION_FAILED",lastError)
    }

    suspend fun login(nickname:String,password:String): JSONObject = call("auth/login","POST",JSONObject().put("login",nickname).put("nickname",nickname).put("password",password))
    suspend fun register(nickname:String,email:String,password:String,gender:String="male"): JSONObject = call("auth/register","POST",JSONObject().put("nickname",nickname).put("email",email).put("password",password).put("gender",gender))
    suspend fun logout(){ try{call("auth/logout","POST")}finally{setToken(null)} }
    suspend fun updateStatus(online:Boolean)=call("users/status","POST",JSONObject().put("online",online))
    suspend fun setStealthMode(enabled:Boolean)=call("users/stealth","POST",JSONObject().put("enabled",enabled))
    suspend fun changePassword(current:String,newPassword:String): JSONObject = call("auth/change-password","POST",JSONObject().put("currentPassword",current).put("newPassword",newPassword))
    suspend fun changeEmail(currentPassword:String,newEmail:String): JSONObject = call("auth/change-email","POST",JSONObject().put("currentPassword",currentPassword).put("newEmail",newEmail))
    suspend fun conversations()=call("messages/conversations")
    suspend fun markMessageRead(id:String)=call("messages/read","POST",JSONObject().put("message_id",id))
    suspend fun deleteConversation(uid:String)=call("messages/conversation-delete","POST",JSONObject().put("user_id",uid))
    suspend fun adminDashboard()=call("admin/dashboard")
    suspend fun adminSecurityVerify(code:String)=call("admin/security/verify","POST",JSONObject().put("code",code),code)
    suspend fun adminUsers(q:String="", securityCode:String?=null)=call("admin/users"+(if(q.isBlank())"" else "?q="+java.net.URLEncoder.encode(q,"UTF-8")), "GET", null, securityCode)
    suspend fun adminMessages(userId:String?=null, otherId:String?=null, securityCode:String?=null)=call("admin/messages" + listOfNotNull(userId?.takeIf{it.isNotBlank()}?.let{"user_id="+java.net.URLEncoder.encode(it,"UTF-8")}, otherId?.takeIf{it.isNotBlank()}?.let{"other_id="+java.net.URLEncoder.encode(it,"UTF-8")}).joinToString("&").let { if(it.isBlank()) "" else "?"+it }, "GET", null, securityCode)
    suspend fun adminLogs(securityCode:String?=null)=call("admin/logs","GET",null,securityCode)
    suspend fun adminUserAction(uid:String,action:String,securityCode:String?=null,durationDays:Int=7)=call("admin/user-action","POST",JSONObject().put("user_id",uid).put("action",action).put("durationDays",durationDays).put("confirmCode",securityCode ?: ""),securityCode)
    suspend fun adminDeleteMessage(id:String,securityCode:String?=null)=call("admin/delete-message","POST",JSONObject().put("message_id",id).put("confirmCode",securityCode ?: ""),securityCode)
    suspend fun adminCoins(uid:String,amount:Long,confirmCode:String)=call("admin/coins","POST",JSONObject().put("uid",uid).put("recipientUid",uid).put("amount",amount).put("confirmCode",confirmCode),confirmCode)
    suspend fun adminCoinsOverview()=call("admin/coins-overview")
    suspend fun adminSetCoins(uid:String,balance:Long,confirmCode:String)=call("admin/coins-set","POST",JSONObject().put("uid",uid).put("balance",balance).put("confirmCode",confirmCode),confirmCode)
    suspend fun adminCoinsAll(amount:Long,message:String,confirmCode:String)=call("admin/coins-all","POST",JSONObject().put("amount",amount).put("message",message).put("confirmCode",confirmCode),confirmCode)
    suspend fun requestAdminCoinSecurityRecovery(login:String)=call("admin/coins-code-reset-request","POST",JSONObject().put("login",login))
    suspend fun adminBroadcast(title:String,body:String,link:String="",securityCode:String?=null)=call("admin/broadcast","POST",JSONObject().put("title",title).put("body",body).put("link",link).put("confirmCode",securityCode ?: ""),securityCode)
    suspend fun registerFcmToken(fcmToken:String, language:String)=call("devices/fcm","POST",JSONObject().put("token",fcmToken).put("deviceId",deviceId()).put("language",language))
    suspend fun getPushSetting()=call("settings/push")
    suspend fun setPushSetting(enabled:Boolean)=call("settings/push","POST",JSONObject().put("enabled",enabled))
    suspend fun notifications()=call("notifications/list")
    suspend fun readNotifications()=call("notifications/read","POST",JSONObject())
    suspend fun readNotification(id:Long)=call("notifications/read","POST",JSONObject().put("id",id))
    suspend fun clearNotifications()=call("notifications/clear","POST",JSONObject())
    suspend fun adminBackupExport(securityCode:String?=null)=download("admin/backup/export","POST",securityCode)
    suspend fun adminBackupValidate(fileName:String, bytes:ByteArray, securityCode:String?=null)=uploadMultipart("admin/backup/validate","backup",fileName,bytes,securityCode)
    suspend fun uploadVoice(receiverId:Long, fileName:String, bytes:ByteArray, duration:Int)=uploadMultipart("messages/voice","audio",fileName,bytes,mimeType="audio/mp4",extraFields=mapOf("receiver_id" to receiverId.toString(),"duration" to duration.toString()))
    suspend fun uploadAttachment(receiverId:Long, fileName:String, bytes:ByteArray, mimeType:String): JSONObject = uploadMultipart("messages/attachment","media",fileName,bytes,mimeType=mimeType,extraFields=mapOf("receiver_id" to receiverId.toString()))
    fun absoluteUrl(path:String):String = if(path.startsWith("http://") || path.startsWith("https://")) path else baseUrl().trimEnd('/') + "/" + path.trimStart('/')
    fun publicUrl(path:String):String {
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        val trimmed=path.trimStart('/')
        val api=baseUrl().trimEnd('/')
        val publicBase=api.removeSuffix("/api")
        return if(trimmed.startsWith("api/")) api+"/"+trimmed.removePrefix("api/") else publicBase+"/"+trimmed
    }
    suspend fun adminBackupImport(confirmToken:String, securityCode:String?=null)=call("admin/backup/import","POST",JSONObject().put("confirmToken",confirmToken).put("confirm",true).put("confirmCode",securityCode ?: ""),securityCode)
    // Full backend compatibility wrappers (request field names match api/endpoints).
    suspend fun me()=call("auth/me")
    suspend fun setAvatar(avatarId:String)=call("users/avatar","POST",JSONObject().put("avatarId",avatarId))
    suspend fun setVipFrame(frameId:String)=call("users/vip-frame","POST",JSONObject().put("vipFrameId",frameId))
    suspend fun requestPasswordReset(email:String)=call("auth/reset","POST",JSONObject().put("email",email))
    suspend fun panic()=call("auth/panic","POST",JSONObject())
    suspend fun userProfile()=call("users/profile")
    suspend fun profileLevel()=call("profile/level")
    suspend fun publicUsers()=call("users/public")
    suspend fun searchUsers(q:String)=call("users/search?q="+java.net.URLEncoder.encode(q,"UTF-8"))
    suspend fun onlineUsers()=call("users/online")
    suspend fun sendMessage(receiverId:Long, text:String)=call("messages/send","POST",JSONObject().put("receiver_id",receiverId).put("message",text))
    suspend fun messages(userId:Long)=call("messages/list?user_id=$userId")
    suspend fun deleteMessage(id:Long)=call("messages/delete","POST",JSONObject().put("message_id",id))
    suspend fun editMessage(id:Long,text:String)=call("messages/edit","POST",JSONObject().put("message_id",id).put("message",text))
    suspend fun setTyping(userId:Long,typing:Boolean)=call("messages/typing","POST",JSONObject().put("user_id",userId).put("typing",typing))
    suspend fun typingStatus(userId:Long)=call("messages/typing-status?user_id=$userId").optBoolean("typing",false)
    suspend fun reactToMessage(id:Long, reaction:String)=call("messages/react","POST",JSONObject().put("message_id",id).put("reaction",reaction))
    suspend fun friends()=call("friends/list")
    suspend fun addFriend(userId:Long)=call("friends/add","POST",JSONObject().put("user_id",userId))
    suspend fun acceptFriend(userId:Long)=call("friends/accept","POST",JSONObject().put("user_id",userId))
    suspend fun rejectFriend(fromUserId:Long)=call("friends/reject","POST",JSONObject().put("fromUserId",fromUserId))
    suspend fun removeFriend(userId:Long)=call("friends/remove","POST",JSONObject().put("user_id",userId))
    suspend fun blocks()=call("blocks/list")
    suspend fun addBlock(uid:Long)=call("blocks/add","POST",JSONObject().put("uid",uid))
    suspend fun removeBlock(uid:Long)=call("blocks/remove","POST",JSONObject().put("uid",uid))
    suspend fun viewProfile(uid:Long)=call("profile/view","POST",JSONObject().put("uid",uid))
    suspend fun profileVisitors()=call("profile/visitors")
    suspend fun walletBalance()=call("wallet/balance")
    suspend fun walletTransactions()=call("wallet/transactions")
    suspend fun addCoins(amount:Long)=call("wallet/coins","POST",JSONObject().put("amount",amount))
    suspend fun startGame(game:String, bet:Long, mineCount:Int?=null)=call("games/start","POST",JSONObject().put("game",game).put("bet",bet).apply{if(mineCount!=null)put("mineCount",mineCount)})
    suspend fun minesReveal(roundId:String,index:Int)=call("games/mines/reveal","POST",JSONObject().put("roundId",roundId).put("index",index))
    suspend fun minesCashout(roundId:String)=call("games/mines/cashout","POST",JSONObject().put("roundId",roundId))
    suspend fun jetCashout(roundId:String)=call("games/jet/cashout","POST",JSONObject().put("roundId",roundId))
    suspend fun penaltyShoot(roundId:String,index:Int)=call("games/penalty/shoot","POST",JSONObject().put("roundId",roundId).put("index",index))
    suspend fun penaltyCashOut(roundId:String)=call("games/penalty/cashout","POST",JSONObject().put("roundId",roundId))
    suspend fun cancelGame(roundId:String)=call("games/cancel","POST",JSONObject().put("roundId",roundId))
    suspend fun giftsProfile(uid:Long)=call("gifts/profile?uid=$uid")
    suspend fun stickers()=call("stickers/list")
    suspend fun gifs()=call("gifs/list")
    suspend fun stories()=call("stories/list")
    suspend fun viewStory(id:Long)=call("stories/view","POST",JSONObject().put("story_id",id))
    suspend fun likeStory(id:Long)=call("stories/like","POST",JSONObject().put("story_id",id))
    suspend fun commentStory(id:Long,text:String,parentCommentId:Long?=null)=call("stories/comment","POST",JSONObject().put("story_id",id).put("comment",text).apply { parentCommentId?.let { put("parent_comment_id",it) } })
    suspend fun storyComments(id:Long)=call("stories/comments?story_id=$id")
    suspend fun storyViewers(id:Long)=call("stories/viewers?story_id=$id")
    suspend fun deleteStoryComment(id:Long)=call("stories/comment-delete","POST",JSONObject().put("comment_id",id))
    suspend fun reportStory(id:Long,reason:String)=call("stories/report","POST",JSONObject().put("story_id",id).put("reason",reason))
    suspend fun followStoryUser(userId:Long)=call("stories/follow","POST",JSONObject().put("user_id",userId))
    suspend fun createStory(fileName:String, bytes:ByteArray, mimeType:String, visibility:String="all", caption:String="", onProgress: ((sentBytes:Long, totalBytes:Long) -> Unit)? = null)=uploadMultipart("stories/create","media",fileName,bytes,mimeType=mimeType,extraFields=mapOf("visibility" to visibility,"caption" to caption),onProgress=onProgress)
    suspend fun createStoryChunked(input: InputStream, totalSize: Long, mimeType: String, visibility: String = "all", caption: String = "", onProgress: ((sentBytes: Long, totalBytes: Long) -> Unit)? = null): JSONObject = withContext(Dispatchers.IO) {
        if (totalSize <= 0L || totalSize > 100L * 1024L * 1024L) throw IllegalArgumentException("INVALID_MEDIA_SIZE")
        val chunkSize = 4 * 1024 * 1024
        val totalChunks = ((totalSize + chunkSize - 1L) / chunkSize).toInt()
        val uploadId = UUID.randomUUID().toString().replace("-", "")
        var sentTotal = 0L
        val buffer = ByteArray(chunkSize)

        fun sendRaw(route: String, body: ByteArray, headers: Map<String, String>): JSONObject {
            val url = URL(baseUrl().trimEnd('/') + "/" + route)
            val c = (url.openConnection() as HttpURLConnection)
            c.instanceFollowRedirects = false
            c.requestMethod = "POST"
            c.connectTimeout = 30000
            c.readTimeout = 300000
            c.doOutput = true
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Content-Type", "application/octet-stream")
            c.setRequestProperty("Content-Length", body.size.toString())
            c.setRequestProperty("User-Agent", "VGhost-Android/1.2")
            c.setRequestProperty("X-VGhost-Client", "android")
            token()?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body); it.flush() }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            c.disconnect()
            val json = try { JSONObject(text) } catch (_: Throwable) {
                throw IllegalStateException("HTTP $code")
            }
            if (code !in 200..299) {
                val msg = json.optString("error", json.optString("message", "API_ERROR"))
                throw IllegalStateException("$msg (HTTP $code)")
            }
            return json
        }

        try {
            var index = 0
            while (index < totalChunks) {
                var read = 0
                val wanted = minOf(chunkSize.toLong(), totalSize - sentTotal).toInt()
                while (read < wanted) {
                    val n = input.read(buffer, read, wanted - read)
                    if (n < 0) break
                    if (n == 0) continue
                    read += n
                }
                if (read <= 0) throw IllegalStateException("UPLOAD_READ_FAILED")
                val chunk = if (read == buffer.size) buffer.copyOf() else buffer.copyOf(read)
                sendRaw("stories/upload-chunk", chunk, mapOf(
                    "X-VGhost-Upload-Id" to uploadId,
                    "X-VGhost-Chunk-Index" to index.toString(),
                    "X-VGhost-Total-Chunks" to totalChunks.toString(),
                    "X-VGhost-Total-Size" to totalSize.toString()
                ))
                sentTotal += read.toLong()
                onProgress?.invoke(sentTotal, totalSize)
                index++
            }
            if (sentTotal != totalSize) throw IllegalStateException("UPLOAD_SIZE_MISMATCH")
            sendRaw("stories/upload-finalize", ByteArray(0), mapOf(
                "X-VGhost-Upload-Id" to uploadId,
                "X-VGhost-Total-Size" to totalSize.toString(),
                "X-VGhost-Mime-Type" to mimeType,
                "X-VGhost-Visibility" to visibility,
                "X-VGhost-Caption" to caption
            ))
        } finally {
            try { input.close() } catch (_: Throwable) {}
        }
    }
    suspend fun deleteStory(id:Long)=call("stories/delete","POST",JSONObject().put("story_id",id))
    suspend fun giftStory(storyId:Long,giftId:String)=legacyTransactionCall("stories/gift","POST",JSONObject().put("story_id",storyId).put("giftId",giftId))
    suspend fun sendGift(receiverId:Long,giftId:String)=legacyTransactionCall("gifts/send","POST",JSONObject().put("receiverId",receiverId).put("giftId",giftId))

}
