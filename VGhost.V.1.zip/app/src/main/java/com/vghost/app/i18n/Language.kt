package com.vghost.app.i18n

import android.content.Context
import java.util.Locale

/** Resource-backed UI translation facade. Existing tr()/trf() callers remain compatible. */
object VGhostLanguage {
    @Volatile private var appContext: Context? = null

    internal fun init(context: Context) { appContext = context.applicationContext }
    internal fun context(): Context? = appContext

    fun trKey(key: String): String {
        val context = appContext ?: return key
        // Resolve the resource from the currently selected app locale. The old
        // implementation queried the base context and returned raw resource
        // keys whenever release resource shrinking removed dynamic lookups.
        val localized = AppLocale.wrap(context)
        val id = localized.resources.getIdentifier(key, "string", localized.packageName)
        return if (id == 0) key else runCatching { localized.getString(id) }.getOrDefault(key)
    }

    fun tr(source: String): String {
        val context = appContext ?: return source
        return TranslationResources.text(AppLocale.wrap(context), source) ?: source
    }

    fun trf(source: String, vararg args: Any): String =
        String.format(Locale.getDefault(), tr(source), *args)

    fun trfKey(key: String, vararg args: Any): String =
        String.format(Locale.getDefault(), trKey(key), *args)
}

fun tr(source: String): String = VGhostLanguage.tr(source)
fun trf(source: String, vararg args: Any): String = VGhostLanguage.trf(source, *args)

fun trfKey(key: String, vararg args: Any): String = VGhostLanguage.trfKey(key, *args)
fun trKey(key: String): String = VGhostLanguage.trKey(key)
