package com.vghost.app.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostRedGlow

/** Shared premium black/red/gold backdrop. Kept behind screen content only. */
fun Modifier.premiumBackdrop(): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF080205),
                GhostBlack,
                Color(0xFF050206)
            )
        )
    )

    // Large red atmospheric glow, matching the premium login aesthetic.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFFFF142F).copy(alpha = 0.16f),
                Color(0xFF8A0015).copy(alpha = 0.065f),
                Color.Transparent
            ),
            center = Offset(w * 0.50f, h * 0.20f),
            radius = w * 0.88f
        ),
        center = Offset(w * 0.50f, h * 0.20f),
        radius = w * 0.88f
    )

    // Corner glows create the fiery red edges visible in the reference design.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFF1B36).copy(alpha = 0.14f), Color.Transparent),
            center = Offset.Zero,
            radius = w * 0.72f
        ),
        center = Offset.Zero,
        radius = w * 0.72f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFF1B36).copy(alpha = 0.12f), Color.Transparent),
            center = Offset(w, h),
            radius = w * 0.78f
        ),
        center = Offset(w, h),
        radius = w * 0.78f
    )

    // Subtle gold aura keeps the premium emblem palette consistent across screens.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFFB52E).copy(alpha = 0.045f), Color.Transparent),
            center = Offset(w * 0.50f, h * 0.46f),
            radius = w * 0.62f
        ),
        center = Offset(w * 0.50f, h * 0.46f),
        radius = w * 0.62f
    )

    // Neon energy streaks. They are deterministic, so there is no animation overhead.
    val streaks = listOf(
        Triple(Offset(-w * 0.05f, h * 0.16f), Offset(w * 0.28f, -h * 0.02f), 0.20f),
        Triple(Offset(w * 0.72f, -h * 0.02f), Offset(w * 1.05f, h * 0.16f), 0.18f),
        Triple(Offset(-w * 0.06f, h * 0.86f), Offset(w * 0.25f, h * 1.04f), 0.16f),
        Triple(Offset(w * 0.76f, h * 1.04f), Offset(w * 1.06f, h * 0.84f), 0.15f)
    )
    streaks.forEach { (start, end, alpha) ->
        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, GhostRedGlow.copy(alpha = alpha), Color.Transparent),
                start = start,
                end = end
            ),
            start = start,
            end = end,
            strokeWidth = 2.2f
        )
    }

    // Thin gold/red arcs add the same ornate premium texture without obscuring content.
    drawArc(
        brush = Brush.sweepGradient(listOf(Color.Transparent, Color(0xFFFFB52E).copy(alpha = 0.12f), Color.Transparent)),
        startAngle = 198f,
        sweepAngle = 74f,
        useCenter = false,
        topLeft = Offset(-w * 0.10f, h * 0.58f),
        size = androidx.compose.ui.geometry.Size(w * 1.20f, w * 1.20f),
        style = Stroke(width = 2.2f)
    )

    // Deterministic embers.
    val particles = listOf(
        0.08f to 0.13f, 0.16f to 0.21f, 0.83f to 0.17f, 0.91f to 0.28f,
        0.27f to 0.08f, 0.73f to 0.10f, 0.12f to 0.54f, 0.88f to 0.62f,
        0.22f to 0.76f, 0.78f to 0.81f, 0.48f to 0.07f, 0.54f to 0.92f,
        0.05f to 0.40f, 0.95f to 0.48f, 0.34f to 0.94f, 0.67f to 0.90f
    )
    particles.forEachIndexed { i, (x, y) ->
        drawCircle(
            color = GhostRedGlow.copy(alpha = if (i % 3 == 0) 0.34f else 0.15f),
            radius = if (i % 4 == 0) 2.0f else 1.05f,
            center = Offset(w * x, h * y)
        )
    }
}
