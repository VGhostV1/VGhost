package com.vghost.app.data.model

import com.vghost.app.i18n.trKey

data class ChatSummary(
    val id: String,
    val nickname: String,
    val lastMessage: String,
    val time: String,
    val unreadCount: Int = 0,
    val isOnline: Boolean = true,
    val messageTypePrefix: String? = null,
    val avatarId: String = "male_01"
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isOutgoing: Boolean,
    val time: String,
    val isDelivered: Boolean = true,
    val isRead: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val senderNickname: String = "",
    val messageType: String = "text",
    val reactions: Map<String, Int> = emptyMap(),
    val myReaction: String? = null,
    val audioUrl: String? = null,
    val audioDuration: Int = 0,
    val stickerImageUrl: String? = null,
    val gifImageUrl: String? = null,
    val attachmentUrl: String? = null,
    val attachmentType: String? = null,
    val attachmentName: String? = null,
    val expiresAt: Long? = null,
    val linkPreviewUrl: String? = null,
    val linkPreviewTitle: String? = null,
    val linkPreviewDescription: String? = null,
    val linkPreviewImage: String? = null,
    val linkPreviewSite: String? = null,
    val linkPreviewType: String? = null,
    val replyToMessageId: String? = null,
    val replyToSenderNickname: String? = null,
    val replyToText: String? = null,
    val replyToMessageType: String? = null,
    val replyToAudioUrl: String? = null,
    val replyToAudioDuration: Int = 0,
    val replyToStickerImageUrl: String? = null,
    val replyToGifImageUrl: String? = null,
    val replyToAttachmentUrl: String? = null,
    val replyToAttachmentType: String? = null,
    val replyToAttachmentName: String? = null,
    val replyToLinkPreviewUrl: String? = null,
    val replyToLinkPreviewTitle: String? = null,
    val replyToLinkPreviewDescription: String? = null,
    val replyToLinkPreviewImage: String? = null,
    val replyToLinkPreviewSite: String? = null,
    val replyToLinkPreviewType: String? = null,
    /** Device-local audio path used while an outgoing voice message is uploading. */
    val localAudioPath: String? = null,
    /** Device-local attachment path used while an outgoing media upload is in flight. */
    val localAttachmentPath: String? = null,
    /** Direct video URL discovered from a link preview; used for in-app playback. */
    val linkPreviewVideo: String? = null,
    /** Direct video URL belonging to the original message referenced by a reply. */
    val replyToLinkPreviewVideo: String? = null
)

data class RecentSearch(
    val id: String,
    val nickname: String
)


data class OnlineUser(
    val uid: String,
    val nickname: String,
    val avatarId: String = "male_01"
)

data class UserListEntry(
    val uid: String,
    val nickname: String,
    val online: Boolean = false,
    val avatarId: String = "male_01",
    val avatarUrl: String? = null,
    val isVip: Boolean = false,
    val level: Int = 1,
    val vipFrameId: String = "vip_01"
)

data class GiftItem(
    val id: String,
    /** Translation resource key for catalog gifts, or a localized fallback for unknown gifts. */
    private val nameKey: String,
    val icon: String,
    val price: Int
) {
    /** Always resolves using the currently selected app language. */
    val name: String
        get() = com.vghost.app.i18n.VGhostLanguage.trKey(nameKey).let {
            if (it == nameKey) nameKey else it
        }
}

data class GiftCollectionItem(
    val giftId: String,
    val name: String,
    val icon: String,
    val price: Int,
    val count: Int
)

data object GiftCatalog {
    val items = listOf(
        // Keep translation keys stable. Resolving trKey() here would freeze the
        // catalog in whichever language was active when this object was first initialized.
        GiftItem("love", "gift_love", "❤️", 10),
        GiftItem("rose", "gift_rose", "🌹", 20),
        GiftItem("diamond", "gift_diamond", "💎", 50),
        GiftItem("crown", "gift_crown", "👑", 100),
        GiftItem("cake", "gift_cake", "🎂", 150),
        GiftItem("gift_box", "gift_box", "🎁", 200),
        GiftItem("money_bag", "money_bag", "💰", 300),
        GiftItem("butterfly", "gift_butterfly", "🦋", 400),
        GiftItem("fire", "gift_fire", "🔥", 500),
        GiftItem("rocket", "gift_rocket", "🚀", 750),
        GiftItem("dragon", "gift_dragon", "🐉", 1000),
        GiftItem("trophy", "gift_trophy", "🏆", 1500),
        GiftItem("thunder", "gift_thunder", "⚡", 2000),
        GiftItem("ghost", "gift_ghost", "👻", 3000),
        GiftItem("galaxy", "gift_galaxy", "🌌", 5000),
        GiftItem("ufo", "gift_ufo", "🛸", 7500),
        GiftItem("meteor", "gift_meteor", "☄️", 10000),
        GiftItem("castle", "gift_castle", "🏰", 15000),
        GiftItem("volcano", "gift_volcano", "🌋", 25000),
        GiftItem("vghost_royal", "vghost_royal", "👻💎", 50000)
    )
    fun find(id: String): GiftItem? = items.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: id.toIntOrNull()?.let { items.getOrNull(it - 1) }
}

data class PublicUserProfile(
    val uid: String,
    val nickname: String,
    val balance: Int,
    val online: Boolean,
    val ghostMode: Boolean,
    val friendStatus: String = "none",
    val blockedByMe: Boolean = false,
    val blockedMe: Boolean = false,
    val activityXp: Int = 0,
    val activityLevel: Int = 1,
    val giftXp: Int = 0,
    val giftLevel: Int = 1,
    val nextGiftLevelXp: Int = 100,
    val gifts: List<GiftCollectionItem> = emptyList(),
    val avatarId: String = "male_01",
    val avatarUrl: String? = null,
    val isVip: Boolean = false,
    val vipFrameId: String = "vip_01"
)
