package com.vghost.app.network

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.ConsumeParams
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Google Play Billing wrapper for non-renewing VIP time packs.
 * Products are consumable: the secure backend verifies the token, grants VIP time,
 * and the client consumes the Play purchase so the same pack can be purchased again.
 */
class VipBillingManager(
    context: Context,
    private val onVerifiedPurchase: suspend (productId: String, purchaseToken: String) -> Boolean,
    private val onError: (String) -> Unit
) {
    companion object {
        const val VIP_7D = "vghost_vip_7d"
        const val VIP_30D = "vghost_vip_30d"
        const val VIP_90D = "vghost_vip_90d"
        const val VIP_1Y = "vghost_vip_1y"
        val PRODUCT_IDS = listOf(VIP_7D, VIP_30D, VIP_90D, VIP_1Y)
    }

    private val _products = MutableStateFlow<Map<String, ProductDetails>>(emptyMap())
    val products: StateFlow<Map<String, ProductDetails>> = _products.asStateFlow()

    private val appContext = context.applicationContext
    private val processedTokens = HashSet<String>()
    private val listener = PurchasesUpdatedListener { result, purchases ->
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            purchases.forEach { processPurchase(it) }
        } else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
            onError(result.debugMessage.ifBlank { "BILLING_ERROR" })
        }
    }

    private val billingClient: BillingClient = BillingClient.newBuilder(appContext)
        .setListener(listener)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection()
        .build()

    fun start() {
        if (billingClient.isReady) {
            queryProducts()
            queryExistingPurchases()
            return
        }
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: com.android.billingclient.api.BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts()
                    queryExistingPurchases()
                } else {
                    onError(result.debugMessage.ifBlank { "BILLING_UNAVAILABLE" })
                }
            }

            override fun onBillingServiceDisconnected() {
                // PBL 8+ auto-reconnection handles the next API call.
            }
        })
    }

    private fun queryProducts() {
        val productList = PRODUCT_IDS.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()
        billingClient.queryProductDetailsAsync(params) { result, detailsResult ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                _products.value = detailsResult.productDetailsList.associateBy { it.productId }
            } else {
                onError(result.debugMessage.ifBlank { "PRODUCTS_UNAVAILABLE" })
            }
        }
    }

    private fun queryExistingPurchases() {
        val params = com.android.billingclient.api.QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        billingClient.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                purchases.forEach { processPurchase(it) }
            }
        }
    }

    fun launchPurchase(activity: Activity, productId: String) {
        val details = _products.value[productId]
        if (details == null) {
            onError("PRODUCT_NOT_AVAILABLE")
            start()
            return
        }
        val offers = details.oneTimePurchaseOfferDetailsList
        val offer = offers?.firstOrNull()
        if (offer == null) {
            onError("OFFER_NOT_AVAILABLE")
            return
        }
        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(details)
            .setOfferToken(offer.offerToken ?: run {
                onError("OFFER_TOKEN_MISSING")
                return
            })
            .build()
        val flow = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))
            .build()
        billingClient.launchBillingFlow(activity, flow)
    }

    private fun processPurchase(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return
        val token = purchase.purchaseToken
        if (!processedTokens.add(token)) return
        val productId = purchase.products.firstOrNull() ?: run {
            processedTokens.remove(token)
            onError("PURCHASE_PRODUCT_MISSING")
            return
        }
        if (productId !in PRODUCT_IDS) {
            processedTokens.remove(token)
            return
        }
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val granted = onVerifiedPurchase(productId, token)
                if (granted) consume(purchase)
                else processedTokens.remove(token)
            } catch (_: Throwable) {
                processedTokens.remove(token)
                onError("VIP_VERIFY_FAILED")
            }
        }
    }

    private fun consume(purchase: Purchase) {
        val params = ConsumeParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
        billingClient.consumeAsync(params) { result, _ ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK &&
                result.responseCode != BillingClient.BillingResponseCode.ITEM_NOT_OWNED) {
                processedTokens.remove(purchase.purchaseToken)
                onError("PURCHASE_CONSUME_RETRY")
            }
        }
    }

    fun close() {
        billingClient.endConnection()
    }
}
