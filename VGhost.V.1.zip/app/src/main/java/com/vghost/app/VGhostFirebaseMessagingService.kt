package com.vghost.app
import com.vghost.app.i18n.trKey

import com.vghost.app.i18n.tr

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.vghost.app.network.PushManager
import com.vghost.app.i18n.NotificationTranslations
import com.vghost.app.data.state.VGhostRepository
import kotlin.random.Random
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class VGhostFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        PushManager.syncToken(this, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val type = message.data["type"] ?: "general"
        // Admin broadcasts are mandatory announcements and bypass the user
        // push toggle. All other notification types respect the user setting.
        if (!type.equals("broadcast", true) && !PushManager.isPushEnabled(this)) return
        val rawTitle = message.notification?.title ?: message.data["title"] ?: "VGhost"
        val rawBody = message.notification?.body ?: message.data["body"] ?: trKey("new_notification")
        // FCM is data-only in this app, so localize at display time. This also
        // respects the app's saved language even when Android's system language differs.
        val localized = NotificationTranslations.localize(
            this,
            type,
            rawTitle,
            rawBody,
            message.data
        )
        val title = localized.first
        val body = localized.second
        val senderUid = message.data["senderUid"] ?: message.data["sender_uid"] ?: message.data["userId"] ?: ""
        val target = message.data["target"] ?: if (type == "message") "chat" else "home"
        val targetValue = message.data["targetValue"] ?: message.data["senderNickname"] ?: message.data["nickname"] ?: ""
        val notificationId = message.data["notificationId"] ?: message.messageId ?: ""
        VGhostRepository.instance.onPushNotification(title, body, type, target, targetValue, notificationId.toLongOrNull() ?: 0L, message.data)
        val isGift = type.equals("gift", true) || type.equals("story_gift", true)
        if (isGift && VGhostRepository.instance.isAppInForeground()) {
            VGhostRepository.instance.onGiftReceived(
                message.data["giftKey"] ?: message.data["giftId"] ?: message.data["gift_id"] ?: "",
                message.data["senderNickname"] ?: message.data["sender"] ?: ""
            )
        }
        when {
            type.equals("coin_transfer", true) || type.equals("coin_gift", true) || type.equals("coin_received", true) || type.equals("daily_bonus", true) || type.equals("welcome_bonus", true) || type.equals("welcome", true) -> CoroutineScope(Dispatchers.IO).launch { VGhostRepository.instance.refreshMyWallet() }
        }
        val senderNickname = message.data["senderNickname"] ?: message.data["sender"] ?: message.data["nickname"]
        val isMessageInOpenChat = type.equals("message", true) &&
            VGhostRepository.instance.isAppInForeground() &&
            VGhostRepository.instance.isChatOpenWith(senderNickname)

        // Only suppress a push when the exact chat is already open. Gifts and
        // other account events still get a visible Android notification while the
        // app is in the foreground, so they cannot silently disappear.
        if (!isMessageInOpenChat) {
            showNotification(title, body, senderNickname, message.data["conversationId"], notificationId, target, targetValue, type, senderUid, message.data["giftKey"] ?: message.data["giftId"] ?: message.data["gift_id"] ?: "", message.data["count"]?.toIntOrNull() ?: 1)
        }
    }

    private fun showNotification(title: String, body: String, senderNickname: String? = null, conversationId: String? = null, notificationKey: String? = null, target: String = "home", targetValue: String = "", type: String = "general", senderUid: String = "", giftId: String = "", notificationCount: Int = 1) {
        val channelId = "vghost_general"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val existing = manager.getNotificationChannel(channelId)
            if (existing == null) {
                manager.createNotificationChannel(
                    NotificationChannel(channelId, "VGhost", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = com.vghost.app.i18n.VGhostLanguage.trKey("vghost_announcements_notifications")
                        enableVibration(true)
                    }
                )
            }
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (target.equals("link", true) && targetValue.isNotBlank()) {
                try {
                    val uri = android.net.Uri.parse(targetValue)
                    if (uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) {
                        action = Intent.ACTION_VIEW
                        data = uri
                    }
                } catch (_: Throwable) { }
            } else if (target.equals("chat", true) && !senderNickname.isNullOrBlank()) {
                action = MainActivity.ACTION_OPEN_GHOST_CHAT
                putExtra(MainActivity.EXTRA_CHAT_NICKNAME, senderNickname)
            }
            if (!conversationId.isNullOrBlank()) putExtra(MainActivity.EXTRA_CONVERSATION_ID, conversationId)
            putExtra(MainActivity.EXTRA_NOTIFICATION_TARGET, target)
            putExtra(MainActivity.EXTRA_NOTIFICATION_TARGET_VALUE, targetValue)
            putExtra("vghost_push_type", type)
            putExtra("vghost_friend_sender_uid", senderUid)
            putExtra(MainActivity.EXTRA_PUSH_TYPE, type)
            putExtra(MainActivity.EXTRA_GIFT_ID, giftId)
            putExtra(MainActivity.EXTRA_GIFT_SENDER, senderNickname.orEmpty())
            notificationKey?.toLongOrNull()?.let { putExtra(MainActivity.EXTRA_NOTIFICATION_ID, it) }
        }
        val requestCode = (notificationKey ?: title + body + System.currentTimeMillis()).hashCode()
        val pendingIntent = PendingIntent.getActivity(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val largeIcon = BitmapFactory.decodeResource(resources, R.drawable.vghost_logo_asset)
        val notification = NotificationCompat.Builder(this, channelId)
            // Android status-bar icons must be monochrome/transparent masks.
            .setSmallIcon(if (type.equals("coin_transfer", true) || type.equals("coin_gift", true) || type.equals("coin_received", true)) R.drawable.ic_stat_coin else R.drawable.ic_stat_vghost)
            // The full VGhost artwork is shown as the notification's large icon.
            .setLargeIcon(largeIcon)
            .setContentTitle(title)
            .setContentText(body)
            .setNumber(notificationCount.coerceAtLeast(1))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(
                when {
                    type.equals("message", true) -> NotificationCompat.CATEGORY_MESSAGE
                    type.equals("friend_request", true) || type.equals("friend_accepted", true) -> NotificationCompat.CATEGORY_SOCIAL
                    type.equals("coin_transfer", true) || type.equals("coin_gift", true) || type.equals("coin_received", true) || type.equals("daily_bonus", true) || type.equals("welcome_bonus", true) || type.equals("welcome", true) -> NotificationCompat.CATEGORY_STATUS
                    else -> NotificationCompat.CATEGORY_EVENT
                }
            )
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        val stableId = notificationKey?.toLongOrNull()?.hashCode() ?: (notificationKey ?: title + body).hashCode()
        manager.notify(stableId, notification)
    }
}
