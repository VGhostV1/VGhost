package com.vghost.app
import com.vghost.app.i18n.trKey

import com.vghost.app.i18n.tr

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/** Shows the one-time welcome reward notification after Firebase confirms the grant. */
object WelcomeNotificationHelper {
    private const val CHANNEL_ID = "vghost_rewards"

    fun show(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    trKey("vghost_bonuses"),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = trKey("bonus_reward_notifications_vghost_account")
                }
            )
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            "welcome_reward".hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_vghost)
            .setContentTitle(trKey("welcome_alert"))
            .setContentText(trKey("number_1000_gc_added_account_heart"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        manager.notify("welcome_reward".hashCode(), notification)
    }
}
