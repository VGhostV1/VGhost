package com.vghost.app.data.state
import com.vghost.app.i18n.trKey

import org.json.JSONObject

import com.vghost.app.i18n.NotificationTranslations

import com.vghost.app.network.PushManager
import android.content.Context
import android.util.Base64
import com.vghost.app.data.model.*
import com.vghost.app.i18n.tr
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

sealed interface SessionState { data object LoggedOut:SessionState; data class LoggedInNormalUser(val nickname:String):SessionState; }

/** Production repository: PHP/MySQL owns identity, sessions, chat, wallet and social data. FCM is push-only. */
class VGhostRepository private constructor() {
    companion object { val instance: VGhostRepository by lazy { VGhostRepository() }; private const val DAY=86400000L; private const val RESTORE_TIMEOUT_MS=5000L; private const val PREF_LAST_NICKNAME="last_logged_in_nickname"; private const val PREF_STEALTH_MODE = "stealth_mode"
    private const val PREF_AVATAR_ID="avatar_id"; private const val PREF_AVATAR_URL="avatar_url"; private const val PREF_VIP_FRAME_ID="vip_frame_id"; private const val PREF_LAST_WALLET_BALANCE_PREFIX="last_wallet_balance_" }
    private lateinit var appContext: Context
    private var initialized=false
    private val prefs get()=appContext.getSharedPreferences("vghost_device_security",Context.MODE_PRIVATE)
    private val apiScope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private val _sessionState=MutableStateFlow<SessionState>(SessionState.LoggedOut); val sessionState=_sessionState.asStateFlow()
    private val _forcedLogoutMessage=MutableStateFlow<String?>(null); val forcedLogoutMessage=_forcedLogoutMessage.asStateFlow()
    private val _sessionRestoring=MutableStateFlow(true); val sessionRestoring=_sessionRestoring.asStateFlow()
    private val _chats=MutableStateFlow<List<ChatSummary>>(emptyList()); val chats=_chats.asStateFlow()
    private val _messages=MutableStateFlow<Map<String,List<ChatMessage>>>(emptyMap()); val messages=_messages.asStateFlow()
    private val pendingOutgoing=mutableMapOf<String, MutableList<ChatMessage>>()
    // Sending, polling and UI coroutines can touch this cache concurrently. Keep
    // every read/write atomic so rapid consecutive sends cannot crash the app with
    // ConcurrentModificationException or race a list mutation.
    private inline fun <T> withPendingLock(block: () -> T): T = synchronized(pendingOutgoing) { block() }
    private fun pendingSnapshot(key:String): List<ChatMessage> = withPendingLock { pendingOutgoing[key]?.toList().orEmpty() }
    private fun addPending(key:String, message:ChatMessage) = withPendingLock { pendingOutgoing.getOrPut(key){mutableListOf()}.add(message) }
    private fun updatePendingId(key:String, oldId:String, newMessage:ChatMessage) = withPendingLock {
        pendingOutgoing[key]?.let { list ->
            val idx=list.indexOfFirst { it.id==oldId }
            if(idx>=0) list[idx]=newMessage
        }
    }
    private fun removePending(key:String, id:String) = withPendingLock {
        pendingOutgoing[key]?.removeAll { it.id==id }
        if(pendingOutgoing[key].isNullOrEmpty()) pendingOutgoing.remove(key)
    }
    private val _recentSearches=MutableStateFlow<List<RecentSearch>>(emptyList()); val recentSearches=_recentSearches.asStateFlow()
    private val _isPanicActivated=MutableStateFlow(false); val isPanicActivated=_isPanicActivated.asStateFlow()
    private val _isGhostMode=MutableStateFlow(false); val isGhostMode=_isGhostMode.asStateFlow()
    private val _currentUserNickname=MutableStateFlow(""); val currentUserNickname=_currentUserNickname.asStateFlow()
    private val _currentUserStatus=MutableStateFlow(com.vghost.app.i18n.VGhostLanguage.trKey("offline_2")); val currentUserStatus=_currentUserStatus.asStateFlow()
    private val _currentUserAvatarId=MutableStateFlow("male_01"); val currentUserAvatarId=_currentUserAvatarId.asStateFlow(); private val _currentUserAvatarUrl=MutableStateFlow<String?>(null); val currentUserAvatarUrl=_currentUserAvatarUrl.asStateFlow()
    private val _currentUserVip=MutableStateFlow(false); val currentUserVip=_currentUserVip.asStateFlow(); private val _currentUserVipFrameId=MutableStateFlow("vip_01"); val currentUserVipFrameId=_currentUserVipFrameId.asStateFlow()
    private val _currentUserVipExpiresAt=MutableStateFlow<String?>(null); val currentUserVipExpiresAt=_currentUserVipExpiresAt.asStateFlow()
    private val _isAppLocked=MutableStateFlow(false); val isAppLocked=_isAppLocked.asStateFlow()
    private val _appLockEnabled=MutableStateFlow(false); val appLockEnabled=_appLockEnabled.asStateFlow()
    private val _appPin=MutableStateFlow(""); val appPin=_appPin.asStateFlow()
    private val _ghostCoins=MutableStateFlow(0); val ghostCoins=_ghostCoins.asStateFlow()
    data class LevelUpEvent(val level:Int, val coins:Int = 100, val token:Long = System.currentTimeMillis())
    private val _levelUpEvent=MutableStateFlow<LevelUpEvent?>(null); val levelUpEvent=_levelUpEvent.asStateFlow()
    private var knownActivityLevel:Int?=null
    data class AppNotification(
        val id: Long = 0,
        val type: String = "general",
        val title: String,
        val body: String,
        val isRead: Boolean = false,
        val createdAt: String = "",
        val target: String = "home",
        val targetValue: String = "",
        val giftId: String = "",
        val giftKey: String = "",
        val senderNickname: String = "",
        val amount: String = "",
        val count: Int = 1
    )
    private val _notifications=MutableStateFlow<List<AppNotification>>(emptyList()); val notifications=_notifications.asStateFlow()
    data class GiftReceivedEvent(val giftId:String, val sender:String, val token:Long=System.currentTimeMillis())
    private val _giftReceivedEvent=MutableStateFlow<GiftReceivedEvent?>(null); val giftReceivedEvent=_giftReceivedEvent.asStateFlow()
    val unreadNotificationCount = notifications.map { list -> list.filter { !it.isRead }.sumOf { it.count.coerceAtLeast(1) } }.stateIn(apiScope, SharingStarted.Eagerly, 0)
    private val _isSuperAdmin=MutableStateFlow(false); val isSuperAdmin=_isSuperAdmin.asStateFlow()
    private val syncJobs=mutableMapOf<String,Job>()
    private var chatListSyncJob:Job?=null
    private var presenceHeartbeatJob:Job?=null
    private var activityLevelSyncJob:Job?=null
    @Volatile private var appInForeground=false
    @Volatile private var activeChatNickname: String? = null
    // Chat performance: cache nickname -> numeric user id and serialize per-chat loads.
    private val chatUidCache=mutableMapOf<String,Int>()
    private val chatLoadLocks=mutableMapOf<String,kotlinx.coroutines.sync.Mutex>()
    // Prevent stale async responses from a previous account/session from overwriting the active wallet.
    @Volatile private var walletSessionEpoch=0L
    @Volatile private var sessionEpoch=0L
    private fun invalidateWalletSession(){ walletSessionEpoch++ }
    private fun resetSessionState(){
        walletSessionEpoch++; sessionEpoch++
        _ghostCoins.value=0; _isSuperAdmin.value=false
        _chats.value=emptyList(); _messages.value=emptyMap(); _recentSearches.value=emptyList(); withPendingLock { pendingOutgoing.clear() }
        _notifications.value=emptyList(); _isGhostMode.value=false
        knownActivityLevel=null; _levelUpEvent.value=null
        syncJobs.values.forEach { it.cancel() }; syncJobs.clear(); chatListSyncJob?.cancel(); chatListSyncJob=null; presenceHeartbeatJob?.cancel(); presenceHeartbeatJob=null; activityLevelSyncJob?.cancel(); activityLevelSyncJob=null
        chatUidCache.clear(); chatLoadLocks.clear()
        _currentUserNickname.value=""; _currentUserStatus.value=com.vghost.app.i18n.VGhostLanguage.trKey("offline_2"); _currentUserAvatarId.value="male_01"; _currentUserAvatarUrl.value=null; _currentUserVip.value=false; _currentUserVipFrameId.value="vip_01"; _currentUserVipExpiresAt.value=null
    }

    fun initialize(context:Context){
        if(initialized)return; appContext=context.applicationContext; VGhostApi.init(appContext); initialized=true
        VGhostApi.setAuthFailureHandler { reason -> forceServerLogout(reason) }
        _appLockEnabled.value=prefs.getBoolean("lock_enabled",false)
        val token=VGhostApi.token()
        if(!token.isNullOrBlank()) {
            // The token is already persisted, so restore the last known identity
            // synchronously. This lets the launcher enter Game immediately while
            // auth/me refreshes the authoritative session in the background.
            val cachedNickname=prefs.getString(PREF_LAST_NICKNAME, "").orEmpty().trim()
            if(cachedNickname.isNotBlank()) {
                _sessionState.value=SessionState.LoggedInNormalUser(cachedNickname)
                _currentUserNickname.value=cachedNickname
                loadCachedWalletBalance(cachedNickname)
            } else {
                // A valid persisted token is enough to open the game optimistically.
                // restoreSession() will replace this state with the server identity.
                _sessionState.value=SessionState.LoggedInNormalUser("")
            }
            _currentUserAvatarId.value=prefs.getString(PREF_AVATAR_ID,"male_01").orEmpty().ifBlank { "male_01" }; _currentUserAvatarUrl.value=prefs.getString(PREF_AVATAR_URL,null)
            _isGhostMode.value=prefs.getBoolean(PREF_STEALTH_MODE,false)
            _currentUserStatus.value=if(_isGhostMode.value) com.vghost.app.i18n.VGhostLanguage.trKey("ui_ghost") else com.vghost.app.i18n.VGhostLanguage.trKey("online")
            _isAppLocked.value=_appLockEnabled.value
            apiScope.launch { restoreSession() }
        } else _sessionRestoring.value=false
    }
    private fun forceServerLogout(reason:String){
        val message = if (reason.equals("banned", true))
            trKey("h_b5c489c3003e")
        else
            trKey("h_faa31f98c45d")
        // A server-enforced ban/session logout is NOT account deletion.
        // Do not wipe the device profile/cache here: doing so made a later
        // successful login appear as an empty/default profile. Only invalidate
        // the session and clear transient in-memory state. Full local wiping
        // remains reserved for explicit account deletion/panic wipe.
        try { VGhostApi.setToken(null) } catch (_: Throwable) {}
        try { appContext.getSharedPreferences("vghost_api", Context.MODE_PRIVATE).edit().clear().commit() } catch (_: Throwable) {}
        _appLockEnabled.value=false
        _isAppLocked.value=false
        _forcedLogoutMessage.value=message
        resetSessionState()
        _sessionState.value=SessionState.LoggedOut
    }

    fun consumeForcedLogoutMessage(){ _forcedLogoutMessage.value=null }
    private suspend fun restoreSession(){
        val epoch=sessionEpoch
        try {
            // Never keep the first screen blank behind a slow server request.
            val r=withTimeout(RESTORE_TIMEOUT_MS){ VGhostApi.call("auth/me") }
            val u=r.optJSONObject("user") ?: throw IllegalStateException("INVALID_SESSION")
            if(u.optBoolean("is_banned")) throw IllegalStateException("banned")
            val n=u.optString("nickname")
            if(n.isBlank()) throw IllegalStateException("INVALID_SESSION")
            if(epoch!=sessionEpoch || !hasAccount()) return
            _sessionState.value=SessionState.LoggedInNormalUser(n)
            _currentUserNickname.value=n
            loadCachedWalletBalance(n)
            val avatarId=u.optString("avatarId", prefs.getString(PREF_AVATAR_ID,"male_01").orEmpty()).ifBlank { "male_01" }
            val avatarUrl=u.optString("avatarUrl", prefs.getString(PREF_AVATAR_URL,null)).takeIf { it.isNotBlank() && it != "null" }?.let { VGhostApi.publicUrl(it) }
            _currentUserAvatarId.value=avatarId
            _currentUserAvatarUrl.value=avatarUrl
            _currentUserVip.value=u.optBoolean("isVip", false)
            val vipFrameId=u.optString("vipFrameId", prefs.getString(PREF_VIP_FRAME_ID,"vip_01").orEmpty()).ifBlank { "vip_01" }
            _currentUserVipFrameId.value=vipFrameId
            _currentUserVipExpiresAt.value=u.optString("vipExpiresAt").takeIf { it.isNotBlank() && it != "null" }
            val serverStealth=u.optBoolean("ghostMode", prefs.getBoolean(PREF_STEALTH_MODE,false))
            _isGhostMode.value=serverStealth
            prefs.edit().putBoolean(PREF_STEALTH_MODE,serverStealth).putString(PREF_LAST_NICKNAME,n).putString(PREF_AVATAR_ID,avatarId).putString(PREF_VIP_FRAME_ID,vipFrameId).apply { if(avatarUrl==null) remove(PREF_AVATAR_URL) else putString(PREF_AVATAR_URL,avatarUrl) }.apply()
            _currentUserStatus.value=if(serverStealth) com.vghost.app.i18n.VGhostLanguage.trKey("ui_ghost") else com.vghost.app.i18n.VGhostLanguage.trKey("online")
            // auth/me already contains the authoritative wallet. Apply it immediately so
            // stealth mode can never leave the game header temporarily stuck at 0.
            applyWalletFromResponse(r)
            _isAppLocked.value=_appLockEnabled.value
            // Release the UI immediately; secondary server sync must never block startup.
            _sessionRestoring.value=false
            apiScope.launch { refreshMyWallet() }
            apiScope.launch { refreshAdminStatus() }
            apiScope.launch { updateStatus(true) }
            startChatListSync()
            PushManager.syncToken(appContext)
            startPresenceHeartbeat()
            startActivityLevelSync()
            refreshNotifications()
        } catch(t:Throwable){
            // Network/offline errors must NEVER log the user out. Keep the saved
            // session token and restore the last known identity locally. Only a
            // server-confirmed invalid/banned session forces logout.
            val m=t.message.orEmpty()
            val invalid = m.contains("INVALID_SESSION",true) || m.contains("UNAUTHORIZED",true) || m.contains("banned",true)
            if(invalid){
                forceServerLogout(if (m.contains("banned", true)) "banned" else "deleted")
            } else {
                val n=prefs.getString(PREF_LAST_NICKNAME,"").orEmpty().trim()
                if(n.isNotBlank() && !VGhostApi.token().isNullOrBlank()){
                    _sessionState.value=SessionState.LoggedInNormalUser(n)
                    _currentUserNickname.value=n
                    _isGhostMode.value=prefs.getBoolean(PREF_STEALTH_MODE,false)
                    _currentUserStatus.value=if(_isGhostMode.value) com.vghost.app.i18n.VGhostLanguage.trKey("ui_ghost") else com.vghost.app.i18n.VGhostLanguage.trKey("offline_2")
                    _isAppLocked.value=_appLockEnabled.value
                    startChatListSync()
                    startPresenceHeartbeat()
                    startActivityLevelSync()
                } else {
                    _sessionState.value=SessionState.LoggedOut
                }
            }
        } finally { _sessionRestoring.value=false }
    }
    private fun walletCacheKey(nickname:String):String = PREF_LAST_WALLET_BALANCE_PREFIX + nickname.trim().lowercase(Locale.ROOT)
    private fun cacheWalletBalance(nickname:String, balance:Int){
        if(nickname.isBlank() || balance<0) return
        try { prefs.edit().putInt(walletCacheKey(nickname), balance).apply() } catch(_:Throwable){}
    }
    private fun loadCachedWalletBalance(nickname:String){
        if(nickname.isBlank()) return
        try {
            val cached=prefs.getInt(walletCacheKey(nickname), -1)
            if(cached>=0 && hasAccount()) _ghostCoins.value=cached
        } catch(_:Throwable){}
    }
    private fun normalize(s:String)=s.trim().removePrefix("@").trim()
    private fun validNick(s:String)=Regex("[A-Za-z0-9_]{3,32}").matches(s)
    private fun b64(bytes:ByteArray)=Base64.encodeToString(bytes,Base64.NO_WRAP)
    private fun hash(s:String,salt:ByteArray):String= b64(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(s.toCharArray(),salt,120000,256)).encoded)
    private fun constant(a:String,b:String)=MessageDigest.isEqual(a.toByteArray(),b.toByteArray())
    private fun error(t:Throwable): String = com.vghost.app.i18n.BackendErrorTranslations.localize(t.message, com.vghost.app.i18n.AppLocale.language.value)

    fun hasAccount()=initialized && !VGhostApi.token().isNullOrBlank()
    fun register(nickname:String,password:String):String? { return if(validNick(normalize(nickname))&&password.length>=8) null else com.vghost.app.i18n.VGhostLanguage.trKey("enter_information_correctly") }
    fun login(nickname:String,password:String):String?=com.vghost.app.i18n.VGhostLanguage.trKey("internet_account_login_used_operation")

    suspend fun registerOnline(nickname:String,email:String,password:String,gender:String="male"):String? {
        val n=normalize(nickname); if(!validNick(n))return trKey("nickname_must_3_32_characters_letters_numbers_only")
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches())return com.vghost.app.i18n.VGhostLanguage.trKey("enter_valid_email")
        if(password.length<8)return com.vghost.app.i18n.VGhostLanguage.trKey("password_must_least_8_characters")
        return try {
            // Registration is successful once the server has created the account and
            // returned a session token. Do not turn a successful registration into
            // a false error just because a non-critical post-login sync fails.
            val r=VGhostApi.register(n,email.trim(),password,gender)
            val token=r.optString("token").trim()
            val user=r.optJSONObject("user")
            if(token.isBlank() || user==null) {
                VGhostApi.setToken(null)
                return@registerOnline com.vghost.app.i18n.VGhostLanguage.trKey("account_could_not_created")
            }
            VGhostApi.setToken(token)
            runCatching { finishLogin(user,null) }
            runCatching { applyWalletFromResponse(r) }
            null
        } catch(t:Throwable){error(t)}
    }
    suspend fun loginOnline(nickname:String,password:String):String? {
        val n=normalize(nickname); if(n.isBlank())return com.vghost.app.i18n.VGhostLanguage.trKey("enter_nickname")
        return try { val r=VGhostApi.login(n,password); VGhostApi.setToken(r.optString("token")); finishLogin(r.optJSONObject("user")?:return com.vghost.app.i18n.VGhostLanguage.trKey("login_failed"),null); applyWalletFromResponse(r); null } catch(t:Throwable){error(t)}
    }
    private suspend fun finishLogin(u:org.json.JSONObject,pin:String?){
        resetSessionState()
        _ghostCoins.value=0
        val n=u.optString("nickname")
        _sessionState.value=SessionState.LoggedInNormalUser(n)
        _currentUserNickname.value=n
        loadCachedWalletBalance(n)
        val avatarId=u.optString("avatarId", prefs.getString(PREF_AVATAR_ID,"male_01").orEmpty()).ifBlank { "male_01" }
        val avatarUrl=u.optString("avatarUrl", prefs.getString(PREF_AVATAR_URL,null)).takeIf { it.isNotBlank() && it != "null" }?.let { VGhostApi.publicUrl(it) }
        _currentUserAvatarId.value=avatarId
        _currentUserAvatarUrl.value=avatarUrl
        val vipFrameId=u.optString("vipFrameId", prefs.getString(PREF_VIP_FRAME_ID,"vip_01").orEmpty()).ifBlank { "vip_01" }
        _currentUserVipFrameId.value=vipFrameId
        _currentUserVip.value=u.optBoolean("isVip", false)
        _currentUserVipExpiresAt.value=u.optString("vipExpiresAt").takeIf { it.isNotBlank() && it != "null" }
        prefs.edit().putString(PREF_LAST_NICKNAME,n).putString(PREF_AVATAR_ID,avatarId).putString(PREF_VIP_FRAME_ID,vipFrameId).apply { if(avatarUrl==null) remove(PREF_AVATAR_URL) else putString(PREF_AVATAR_URL,avatarUrl) }.apply()
        val loginStealth=u.optBoolean("ghostMode", prefs.getBoolean(PREF_STEALTH_MODE,false))
        _isGhostMode.value=loginStealth
        prefs.edit().putBoolean(PREF_STEALTH_MODE,loginStealth).apply()
        _currentUserStatus.value=if(loginStealth) com.vghost.app.i18n.VGhostLanguage.trKey("ui_ghost") else com.vghost.app.i18n.VGhostLanguage.trKey("online")
        _isPanicActivated.value=false
        if(pin!=null)setAppPin(pin)
        _isAppLocked.value=false
        // Navigation may continue immediately; these are background refreshes.
        apiScope.launch { refreshMyWallet() }
        apiScope.launch { refreshAdminStatus() }
        apiScope.launch { updateStatus(true) }
        startChatListSync()
        PushManager.syncToken(appContext)
        startPresenceHeartbeat()
        startActivityLevelSync()
        refreshNotifications()
    }

    suspend fun refreshAdminStatus(){
        val epoch=sessionEpoch
        val result=try{
            val me=VGhostApi.call("auth/me")
            val user=me.optJSONObject("user")
            user?.optBoolean("isSuperAdmin",false) == true || user?.optBoolean("isAdmin",false) == true
        }catch(_:Throwable){
            try{ VGhostApi.adminDashboard(); true }catch(_:Throwable){ false }
        }
        if(epoch==sessionEpoch && hasAccount()) _isSuperAdmin.value=result
    }

    fun recordActivity(){ if(hasAccount()) apiScope.launch {
        updateStatus(true)
        verifyServerSession()
    } }

    /**
     * Re-check the authoritative account state. A ban is intentionally different
     * from a temporary network failure: only a server response that explicitly
     * says the account is banned (or the session is invalid) can force a logout.
     * This makes an admin ban actually remove the user from the app instead of
     * leaving the cached session usable after the push notification arrives.
     */
    private suspend fun verifyServerSession(){
        if(!hasAccount()) return
        val epoch=sessionEpoch
        try {
            val r=VGhostApi.call("auth/me")
            val user=r.optJSONObject("user") ?: return
            if(epoch!=sessionEpoch || !hasAccount()) return
            if(user.optBoolean("is_banned", false)){
                forceServerLogout("banned")
            }
        } catch(t:Throwable){
            // Keep the account usable while offline. VGhostApi's auth-failure
            // handler already handles server-confirmed invalid sessions.
            val m=t.message.orEmpty()
            if(m.contains("INVALID_SESSION", true) || m.contains("UNAUTHORIZED", true)){
                forceServerLogout("deleted")
            }
        }
    }

    /** Server-backed presence. Only one heartbeat job may run at a time. */
    fun startPresenceHeartbeat(){
        presenceHeartbeatJob?.cancel()
        if(!hasAccount()) return
        presenceHeartbeatJob=apiScope.launch {
            var sessionCheckAt=0L
            while(isActive && hasAccount()){
                updateStatus(true)
                val now=System.currentTimeMillis()
                if(now >= sessionCheckAt){
                    verifyServerSession()
                    sessionCheckAt=now + 15_000L
                }
                delay(5_000L)
            }
        }
    }
    /** App foreground/background is the presence source of truth for this mobile client. */
    fun setAppPresence(foreground:Boolean){
        appInForeground=foreground
        if(!hasAccount()) return
        if(foreground){
            apiScope.launch {
                updateStatus(true)
                verifyServerSession()
            }
            startPresenceHeartbeat()
        } else {
            presenceHeartbeatJob?.cancel(); presenceHeartbeatJob=null
            apiScope.launch { updateStatus(false) }
        }
    }
    fun isAppInForeground():Boolean=appInForeground
    /** The chat currently visible on screen. Used to avoid duplicate system push alerts. */
    fun setActiveChat(nickname: String?) {
        activeChatNickname = nickname?.trim()?.removePrefix("@")?.trim()?.takeIf { it.isNotBlank() }
    }
    fun isChatOpenWith(nickname: String?): Boolean {
        val active = activeChatNickname ?: return false
        val incoming = nickname?.trim()?.removePrefix("@")?.trim()?.takeIf { it.isNotBlank() } ?: return false
        return active.equals(incoming, ignoreCase = true)
    }
    private suspend fun updateStatus(online:Boolean){try{VGhostApi.updateStatus(online)}catch(_:Throwable){}}
    fun toggleStealthMode(){
        if(!hasAccount()) return
        val target=!_isGhostMode.value
        apiScope.launch{
            try { val r=VGhostApi.setStealthMode(target); val enabled=r.optBoolean("ghostMode",target); _isGhostMode.value=enabled; prefs.edit().putBoolean(PREF_STEALTH_MODE,enabled).apply(); _currentUserStatus.value=if(enabled)com.vghost.app.i18n.VGhostLanguage.trKey("ui_ghost") else com.vghost.app.i18n.VGhostLanguage.trKey("online") }
            catch(_:Throwable){ /* server rejected: keep current server-confirmed state */ }
        }
    }

    fun clearInAppNotifications(){
        _notifications.value=emptyList()
        if(initialized && hasAccount()) apiScope.launch { try { VGhostApi.clearNotifications() } catch(_:Throwable){} }
    }
    fun markNotificationRead(id:Long){
        if(id<=0L) return
        _notifications.value=_notifications.value.map { if(it.id==id) it.copy(isRead=true) else it }
        if(initialized && hasAccount()) apiScope.launch { try { VGhostApi.readNotification(id) } catch(_:Throwable){ refreshNotifications() } }
    }
    fun markAllNotificationsRead(){
        _notifications.value=_notifications.value.map { it.copy(isRead=true) }
        if(initialized && hasAccount()) apiScope.launch { try { VGhostApi.readNotifications() } catch(_:Throwable){ refreshNotifications() } }
    }
    /** Removes one handled notification from the in-app list immediately. */
    fun removeInAppNotification(id:Long){
        if(id<=0L) return
        _notifications.value=_notifications.value.filterNot { it.id==id }
    }
    private fun notificationTarget(type:String,data:org.json.JSONObject):Pair<String,String>{
        val explicit=data.optString("target", "").trim()
        val value=data.optString("targetValue", data.optString("url", data.optString("nickname", data.optString("userId", "")))).trim()
        if(explicit.isNotBlank()) return explicit to value
        return when(type){
            "message" -> "chat" to data.optString("senderNickname", data.optString("nickname", ""))
            "friend_request", "friend_accepted" -> "profile" to data.optString("nickname", "")
            "welcome", "welcome_bonus", "daily_bonus", "gift", "story_follow", "coin_transfer", "coin_gift", "coin_received", "coin_bonus", "admin_ban", "admin_unban" -> "profile" to data.optString("targetValue", data.optString("nickname", data.optString("userId", "")))
            "story_like", "story_comment", "story_reply", "story_view", "story_gift" -> "story" to data.optString("targetValue", data.optString("storyId", data.optString("story_id", "")))
            "admin" -> "home" to ""
            "broadcast" -> if(data.optString("url", "").isNotBlank()) "link" to data.optString("url", "") else "home" to ""
            else -> "home" to ""
        }
    }
    fun refreshNotifications(){
        if(!initialized || !hasAccount()) return
        val epoch=sessionEpoch
        apiScope.launch { try {
            val r=VGhostApi.notifications(); val a=r.optJSONArray("notifications")
            val list=buildList { if(a!=null) for(i in 0 until a.length()){
                val n=a.optJSONObject(i)?:continue
                val data=try{
                    val obj=n.optJSONObject("data")
                    if(obj!=null) obj else {
                        val raw=n.optString("data_json", "")
                        if(raw.isBlank()) org.json.JSONObject() else org.json.JSONObject(raw)
                    }
                }catch(_:Throwable){ org.json.JSONObject() }
                val type=n.optString("type","general")
                val target=notificationTarget(type,data)
                // Some backend versions store notification metadata inside data/data_json,
                // while older rows put sender/amount/gift fields directly on the notification.
                // Read both forms so placeholders such as {sender}/{amount} never reach UI.
                fun meta(vararg keys:String):String {
                    for (key in keys) {
                        val value=data.optString(key, "").trim()
                        if (value.isNotBlank()) return value
                        val direct=n.optString(key, "").trim()
                        if (direct.isNotBlank()) return direct
                    }
                    return ""
                }
                val senderRaw=meta("senderNickname","sender","nickname","sender_name","fromNickname","from")
                val sender=if(senderRaw.isNotBlank()) senderRaw else when(type) {
                    "friend_request", "friend_accepted", "profile_visit" -> data.optString("targetValue", "").trim().takeIf { it.isNotBlank() && !it.all(Char::isDigit) }.orEmpty()
                    else -> ""
                }
                val amountRaw=meta("amount","coins","coinAmount","coin_amount","value","coinCost","coin_cost","price")
                val amount=if(amountRaw.isNotBlank()) amountRaw else when(type) {
                    "daily_bonus" -> "500"
                    "welcome_bonus" -> "1000"
                    else -> ""
                }
                val giftId=meta("giftId","gift_id","giftKey","gift_key")
                val giftKey=meta("giftKey","gift_key")
                val count=meta("count").toIntOrNull()?.coerceAtLeast(1) ?: 1
                val localized=NotificationTranslations.localize(type, n.optString("title"), n.optString("body"), mapOf(
                    "sender" to sender, "senderNickname" to sender, "amount" to amount
                ))
                add(AppNotification(
                    id=n.optLong("id",0L), type=type, title=localized.first, body=localized.second,
                    isRead=n.optInt("is_read",0)==1 || n.optBoolean("is_read",false) || n.optBoolean("isRead",false), createdAt=n.optString("created_at", n.optString("createdAt", "")),
                    target=target.first, targetValue=target.second,
                    giftId=giftId,
                    giftKey=giftKey,
                    senderNickname=sender,
                    amount=amount,
                    count=count
                ))
            } }
            if(epoch==sessionEpoch && hasAccount()) _notifications.value=list
        } catch(_:Throwable){} }
    }
    fun onGiftReceived(giftId:String, sender:String){ if(giftId.isNotBlank()) _giftReceivedEvent.value=GiftReceivedEvent(giftId,sender) }
    fun openGiftNotification(notification:AppNotification){ val id=notification.giftKey.ifBlank { notification.giftId }; if(id.isNotBlank()) onGiftReceived(id, notification.senderNickname) }
    fun clearGiftReceived(token:Long){ if(_giftReceivedEvent.value?.token==token) _giftReceivedEvent.value=null }

    fun onPushNotification(title:String,body:String,type:String="general",target:String="home",targetValue:String="",notificationId:Long=0L,data:Map<String,String> = emptyMap()){
        if(initialized) {
            val sender=data["senderNickname"]?.takeIf { it.isNotBlank() }
                ?: data["sender"]?.takeIf { it.isNotBlank() }
                ?: data["nickname"]?.takeIf { it.isNotBlank() }
                ?: targetValue
            val amount=data["amount"]?.takeIf { it.isNotBlank() }
                ?: data["coins"]?.takeIf { it.isNotBlank() }
                ?: data["coinAmount"]?.takeIf { it.isNotBlank() }
                ?: data["coin_amount"]?.takeIf { it.isNotBlank() }
                ?: data["value"]?.takeIf { it.isNotBlank() }
                ?: ""
            val notificationData=data + mapOf("sender" to sender, "senderNickname" to sender, "amount" to amount)
            val localized=NotificationTranslations.localize(type,title,body,notificationData)
            val local=AppNotification(
                id=notificationId,type=type,title=localized.first,body=localized.second,isRead=false,
                createdAt=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()),
                target=target,targetValue=targetValue,
                giftId=data["giftId"] ?: data["gift_id"] ?: "",
                giftKey=data["giftKey"] ?: data["gift_key"] ?: "",
                senderNickname=sender,
                amount=amount,
                count=data["count"]?.toIntOrNull()?.coerceAtLeast(1) ?: 1
            )
            _notifications.value=(listOf(local)+_notifications.value.filter { notificationId<=0L || it.id!=notificationId }).take(100)
            refreshNotifications()
        }
    }
    suspend fun refreshMyWallet(){
        // Capture the current identity/session generation. A response from an old session
        // must never update the new user's visible balance.
        val epoch=walletSessionEpoch
        if(!hasAccount()) return
        try {
            val response=VGhostApi.call("wallet/balance")
            // Backends may return the wallet balance either at the root or inside
            // data/wallet/user.wallet. Accept all supported response shapes.
            val balance = response.optLong("balance", Long.MIN_VALUE).let { root ->
                if (root != Long.MIN_VALUE) root else {
                    val data = response.optJSONObject("data")
                    val wallet = response.optJSONObject("wallet")
                        ?: data?.optJSONObject("wallet")
                        ?: response.optJSONObject("user")?.optJSONObject("wallet")
                    wallet?.optLong("balance", Long.MIN_VALUE)
                        ?: data?.optLong("balance", Long.MIN_VALUE)
                        ?: Long.MIN_VALUE
                }
            }
            if(balance==Long.MIN_VALUE || balance<0L || balance>Int.MAX_VALUE.toLong()) return
            if(epoch==walletSessionEpoch && hasAccount()) {
                val value=balance.toInt()
                _ghostCoins.value=value
                cacheWalletBalance(_currentUserNickname.value,value)
            }
        } catch(_:Throwable){ /* keep last server-confirmed value while offline */ }
    }
    /** Apply the authoritative wallet from any supported API response shape. */
    private fun applyWalletFromResponse(r:org.json.JSONObject) {
        val candidates = listOfNotNull(
            r.optJSONObject("wallet"),
            r.optJSONObject("data")?.optJSONObject("wallet"),
            r.optJSONObject("user")?.optJSONObject("wallet")
        )
        var balance=Long.MIN_VALUE
        for(wallet in candidates){
            if(wallet.has("balance") && !wallet.isNull("balance")){ balance=wallet.optLong("balance",Long.MIN_VALUE); break }
        }
        if(balance==Long.MIN_VALUE){
            val data=r.optJSONObject("data")
            balance=when{
                r.has("balance") && !r.isNull("balance") -> r.optLong("balance",Long.MIN_VALUE)
                data?.has("balance")==true && !data.isNull("balance") -> data.optLong("balance",Long.MIN_VALUE)
                r.has("coinBalance") && !r.isNull("coinBalance") -> r.optLong("coinBalance",Long.MIN_VALUE)
                r.optJSONObject("user")?.has("coinBalance")==true -> r.optJSONObject("user")!!.optLong("coinBalance",Long.MIN_VALUE)
                else -> Long.MIN_VALUE
            }
        }
        if(balance in 0L..Int.MAX_VALUE.toLong() && hasAccount()){
            val value=balance.toInt()
            _ghostCoins.value=value
            cacheWalletBalance(_currentUserNickname.value,value)
        }
    }
    /** The server wallet is authoritative. Never mutate the displayed balance locally. */
    private fun applyServerBalance(r:org.json.JSONObject):org.json.JSONObject {
        if(r.has("balance") && !r.isNull("balance")) {
            val balance=r.optLong("balance", Long.MIN_VALUE)
            if(balance in 0L..Int.MAX_VALUE.toLong()) {
                val value=balance.toInt()
                _ghostCoins.value=value
                cacheWalletBalance(_currentUserNickname.value,value)
            }
        }
        return r
    }
    /** Client-side coin creation is intentionally disabled. Credits only come from server-owned rewards/games/admin actions. */
    fun addGhostCoins(amount:Int){ /* no-op by design: never trust the APK with coin credits */ }
    suspend fun spendGhostCoins(amount:Int):Boolean = try{ if(amount<=0) false else { applyServerBalance(VGhostApi.call("wallet/coins","POST",org.json.JSONObject().put("amount",-amount))); true } }catch(_:Throwable){ refreshMyWallet(); false }
    private val _lastGameError = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)
    val lastGameError = _lastGameError
    suspend fun startGame(game:String,bet:Int,mineCount:Int=4,rockfallLevel:Int=1):org.json.JSONObject?=try{
        _lastGameError.value = null
        if(bet <= 0){ _lastGameError.value = trKey("m_rc_m_bl_i_d_zg_n_deyil"); return null }
        // The UI can briefly show a stale/zero wallet after locale or screen recreation.
        // Refresh once before rejecting a valid start request.
        if(hasAccount()){
            // Always sync the server wallet before Game 4 starts. This fixes the
            // case where login succeeded but the game screen still holds a stale 0 balance.
            refreshMyWallet()
        }

        if(hasAccount() && _ghostCoins.value < bet){
            refreshMyWallet()
            if(_ghostCoins.value < bet){ _lastGameError.value=trKey("insufficient_balance_bullet_gc").format(bet); return null }
        }
        val startPath = if (game == "rockfall") "games/rockfall/start" else "games/start"
        try {
            val payload=org.json.JSONObject().put("game",game).put("bet",bet).put("mineCount",mineCount)
            if(game=="rockfall") payload.put("level",rockfallLevel.coerceIn(1,10))
            val r=VGhostApi.call(startPath,"POST",payload)
            applyServerBalance(r)
            r
        } catch(first:Throwable){
            // Login can finish just before the game screen opens; refresh the authoritative
            // session/wallet once and retry the exact start request instead of showing a false
            // balance error caused by a stale UI state.
            if(hasAccount()){
                refreshMyWallet()
                try {
                    val retryPayload=org.json.JSONObject().put("game",game).put("bet",bet).put("mineCount",mineCount)
                    if(game=="rockfall") retryPayload.put("level",rockfallLevel.coerceIn(1,10))
                    val retry=VGhostApi.call(startPath,"POST",retryPayload)
                    applyServerBalance(retry)
                    retry
                } catch(second:Throwable){ throw second }
            } else throw first
        }
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun rockfallProgress():org.json.JSONObject?=try{

        if(!hasAccount()) return null
        VGhostApi.call("games/rockfall/progress")
    }catch(t:Throwable){ _lastGameError.value=error(t); null }

    suspend fun rockfallMove(roundId:String,from:Int,to:Int):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/rockfall/move","POST",org.json.JSONObject().put("roundId",roundId).put("from",from).put("to",to)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value=error(t); null }





    suspend fun rockfallCashOut(roundId:String):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/rockfall/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun revealMines(roundId:String,index:Int):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/mines/reveal","POST",org.json.JSONObject().put("roundId",roundId).put("index",index)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun cashOutMines(roundId:String):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/mines/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun shootPenalty(roundId:String,index:Int,multiplier:Double=1.30):org.json.JSONObject?=try{
        if(index !in 0..8) return null
        
        val r=VGhostApi.call(
            "games/penalty/shoot",
            "POST",
            org.json.JSONObject()
                .put("roundId",roundId)
                .put("index",index)
                .put("multiplier",multiplier)
        )
        applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun cashOutPenalty(roundId:String):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/penalty/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }

    suspend fun cashOutJet(roundId:String):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/jet/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun ticTacToeMove(roundId:String,index:Int):org.json.JSONObject?=try{
        if(index !in 0..8) return null
        
        val r=VGhostApi.call("games/tictactoe/move","POST",org.json.JSONObject().put("roundId",roundId).put("index",index)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun tttMulti(action:String, roomId:String?=null, roomCode:String?=null, bet:Int?=null, index:Int?=null):org.json.JSONObject?=try{
        val payload=org.json.JSONObject().put("action",action)
        roomId?.let{payload.put("roomId",it)}; roomCode?.let{payload.put("roomCode",it)}; bet?.let{payload.put("bet",it)}; index?.let{payload.put("index",it)}
        val r=VGhostApi.call("games/tictactoe/multiplayer","POST",payload); applyServerBalance(r); r
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun createTicTacToeRoom()=tttMulti("create")
    suspend fun joinTicTacToeRoom(code:String)=tttMulti("join",roomCode=code)
    suspend fun ticTacToeRoomState(roomId:String)=tttMulti("state",roomId=roomId)
    suspend fun ticTacToeMultiplayerMove(roomId:String,index:Int)=tttMulti("move",roomId=roomId,index=index)
    suspend fun cancelTicTacToeRoom(roomId:String)=tttMulti("cancel",roomId=roomId)
    suspend fun cancelGame(roundId:String):org.json.JSONObject?=try{
        
        val r=VGhostApi.call("games/cancel","POST",org.json.JSONObject().put("roundId",roundId));
        _ghostCoins.value=r.optInt("balance",_ghostCoins.value); r
    }catch(t:Throwable){ _lastGameError.value = error(t); null }

    suspend fun sendPasswordResetEmail(value:String):String?=try{
        val login=value.trim()
        if(login.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("enter_email_nickname_2")
        // Always send one neutral `login` field. Backend resolves nickname ->
        // account -> registered email automatically, or accepts a direct email.
        val r=VGhostApi.call("auth/reset","POST",org.json.JSONObject().put("login",login))
        when {
            !r.optBoolean("ok", false) -> r.optString("error", com.vghost.app.i18n.VGhostLanguage.trKey("password_reset_link_could_not_sent"))
            r.has("email_found") && !r.optBoolean("email_found", true) -> com.vghost.app.i18n.VGhostLanguage.trKey("no_account_recovery_email_was_found_nickname_email")
            else -> null
        }
    }catch(t:Throwable){error(t)}
    suspend fun changeLoginPassword(currentPassword:String,newPassword:String,confirmPassword:String):String?=if(newPassword!=confirmPassword)com.vghost.app.i18n.VGhostLanguage.trKey("passwords_do_not_match") else try { val r=VGhostApi.changePassword(currentPassword,newPassword); VGhostApi.setToken(r.optString("token")); null } catch(t:Throwable){error(t)}
    fun changeAppPin(newPin:String,confirmPin:String):String?{if(!Regex("\\d{4}").matches(newPin)||newPin!=confirmPin)return com.vghost.app.i18n.VGhostLanguage.trKey("invalid_pin");setAppPin(newPin);return null}
    fun setAppPin(pin:String):Boolean{if(!Regex("\\d{4}").matches(pin))return false;val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};prefs.edit().putString("pin_salt",b64(salt)).putString("pin_hash",hash(pin,salt)).putBoolean("lock_enabled",true).apply();_appLockEnabled.value=true;return true}
    fun unlock(pin:String):Boolean{val salt=prefs.getString("pin_salt",null)?.let{Base64.decode(it,Base64.NO_WRAP)}?:return false;val h=prefs.getString("pin_hash","")?:return false;val ok=constant(hash(pin,salt),h);if(ok){_isAppLocked.value=false;recordActivity()};return ok}
    fun lockApp(){if(_appLockEnabled.value)_isAppLocked.value=true}
    fun logoutAndClearLocalPin(){logout();prefs.edit().remove("pin_salt").remove("pin_hash").putBoolean("lock_enabled",false).apply();_appLockEnabled.value=false}
    fun logout(){
        // Explicit user logout clears the local session identity. A network
        // outage must never call this method automatically.
        resetSessionState(); _sessionState.value=SessionState.LoggedOut; _isAppLocked.value=false
        prefs.edit().remove(PREF_LAST_NICKNAME).apply()
        
        apiScope.launch{try{VGhostApi.updateStatus(false);VGhostApi.logout()}catch(_:Throwable){}}
        VGhostApi.setToken(null)
    }

    fun getMessagesForUser(nickname:String)=_messages.value[normalize(nickname)].orEmpty().filter{System.currentTimeMillis()-it.createdAt<DAY}
    /** Keeps the messages inbox current even when no conversation screen is open. */
    fun startChatListSync(){
        chatListSyncJob?.cancel()
        chatListSyncJob=apiScope.launch{
            while(isActive && hasAccount() && _sessionState.value is SessionState.LoggedInNormalUser){
                refreshChats()
                delay(3000L)
            }
        }
    }
    fun stopChatListSync(){ chatListSyncJob?.cancel(); chatListSyncJob=null }

    fun startChatSync(recipientNickname:String){
        val n=normalize(recipientNickname)
        syncJobs[n]?.cancel()
        syncJobs[n]=apiScope.launch{
            // Resolve the recipient before polling. If navigation races session restore,
            // keep retrying instead of permanently giving up on the conversation.
            var uid:Int?=null
            while(isActive && hasAccount() && _sessionState.value is SessionState.LoggedInNormalUser && uid==null){
                uid=resolveUid(n)
                if(uid==null) delay(1000L)
            }
            while(isActive && hasAccount() && _sessionState.value is SessionState.LoggedInNormalUser){
                loadMessages(n)
                // Keep the active chat feeling live. The UI is optimistic, while
                // this short poll closes the gap to the server quickly.
                delay(900L)
            }
        }
    }
    fun stopChatSync(recipientNickname:String){syncJobs.remove(normalize(recipientNickname))?.cancel()}
    private suspend fun resolveUid(n:String):Int?{
        val key=normalize(n)
        chatUidCache[key]?.let{return it}
        return try{
            // Existing conversations already contain the authoritative numeric other_id.
            // Prefer that over fuzzy user search; this is especially important for names
            // such as "VGhost" that may have similarly named accounts.
            val conversations=VGhostApi.call("messages/conversations").optJSONArray("conversations")
            if(conversations!=null){
                for(i in 0 until conversations.length()){
                    val c=conversations.getJSONObject(i)
                    if(c.optString("nickname").trim().equals(key,true)){
                        val existing=c.optString("other_id").toIntOrNull()
                        if(existing!=null && existing>0){
                            chatUidCache[key]=existing
                            return existing
                        }
                    }
                }
            }
            // Fall back to exact user search. The backend returns both id and uid as
            // strings, so do not rely on JSONObject.optInt() converting them.
            val users=VGhostApi.call("users/search?q="+java.net.URLEncoder.encode(key,"UTF-8"))
                .optJSONArray("users")
            var uid:Int?=null
            if(users!=null){
                for(i in 0 until users.length()){
                    val u=users.getJSONObject(i)
                    val nick=u.optString("nickname").trim()
                    if(nick.equals(key,true)){
                        uid=(u.optString("uid").toIntOrNull() ?: u.optString("id").toIntOrNull())
                        if(uid!=null && uid>0) break
                    }
                }
                if(uid==null && users.length()>0){
                    val u=users.getJSONObject(0)
                    uid=(u.optString("uid").toIntOrNull() ?: u.optString("id").toIntOrNull())
                }
            }
            if(uid!=null && uid>0) chatUidCache[key]=uid
            uid?.takeIf{it>0}
        }catch(_:Throwable){null}
    }
    private fun parseCreatedAt(raw:String):Long{
        val value=raw.trim()
        if(value.isBlank()) return System.currentTimeMillis()
        val formats=listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'"
        )
        for(pattern in formats){
            try{
                val sdf=SimpleDateFormat(pattern,Locale.US)
                if(pattern.contains("'Z'")) sdf.timeZone=TimeZone.getTimeZone("UTC")
                return sdf.parse(value)?.time ?: continue
            }catch(_:Throwable){}
        }
        return value.toLongOrNull()?.let{if(it<100000000000L)it*1000 else it} ?: System.currentTimeMillis()
    }
    private suspend fun refreshChats(){
        try{
            val a=VGhostApi.conversations().optJSONArray("conversations")?:return
            val out=mutableListOf<ChatSummary>()
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                val nick=normalize(o.optString("nickname"))
                out+=ChatSummary(o.optString("conversation_id"),nick,o.optString("message"),o.optString("created_at"),o.optInt("unread_count"),true,"male_01",o.optString("avatarId","male_01").ifBlank { "male_01" })
            }
            // Keep a just-sent message visible in the chat list until the backend
            // conversation endpoint catches up with the write.
            val pendingByChat = withPendingLock { pendingOutgoing.mapValues { it.value.toList() } }
            pendingByChat.forEach { (nick, pending) ->
                val last=pending.lastOrNull() ?: return@forEach
                val existing=out.firstOrNull{it.nickname.equals(nick,true)}
                if(existing==null){
                    out+=ChatSummary("local-$nick",nick,last.text,last.time,0,true,"male_01")
                }else if(existing.lastMessage != last.text){
                    val idx=out.indexOf(existing)
                    out[idx]=existing.copy(lastMessage=last.text,time=last.time)
                }
            }
            _chats.value=out
        }catch(_:Throwable){}
    }
    private suspend fun loadMessages(n:String){
        val key=normalize(n)
        val lock=chatLoadLocks.getOrPut(key){kotlinx.coroutines.sync.Mutex()}
        lock.lock()
        try{
            val uid=resolveUid(key)?:return
            val response=VGhostApi.call("messages/list?user_id=$uid")
            val a=response.optJSONArray("messages") ?: org.json.JSONArray()
            val list=mutableListOf<ChatMessage>()
            val unreadIds=mutableListOf<String>()
            for(i in a.length()-1 downTo 0){
                try{
                    val m=a.getJSONObject(i)
                    val created=parseCreatedAt(m.optString("created_at"))
                    val senderId=m.optString("sender_id").toIntOrNull() ?: m.optInt("sender_id",0)
                    val outgoing=senderId!=uid
                val read=m.optInt("is_read")!=0
                val reactionObj=m.optJSONObject("reactions")
                val reactionMap=mutableMapOf<String,Int>(); if(reactionObj!=null){ val it=reactionObj.keys(); while(it.hasNext()){val k=it.next(); reactionMap[k]=reactionObj.optInt(k,0)} }
                    val lp=m.optJSONObject("link_preview")
                    list+=ChatMessage(m.optString("id"),m.optString("message"),outgoing,SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(created)),true,read,created,m.optString("senderNickname",_currentUserNickname.value),m.optString("message_type","text"),reactionMap,m.optString("myReaction").takeIf{it.isNotBlank() && it!="null"},m.optString("audio_url").takeIf{it.isNotBlank() && it!="null"},m.optInt("audio_duration",0),m.optJSONObject("sticker")?.optString("image_url")?.takeIf{it.isNotBlank()},m.optJSONObject("gif")?.optString("image_url")?.takeIf{it.isNotBlank()},m.optString("attachment_url").takeIf{it.isNotBlank() && it!="null"},m.optString("attachment_type").takeIf{it.isNotBlank() && it!="null"},m.optString("attachment_name").takeIf{it.isNotBlank() && it!="null"},m.optString("expires_at").takeIf{it.isNotBlank()}?.let{parseCreatedAt(it)},lp?.optString("url")?.takeIf{it.isNotBlank()},lp?.optString("title")?.takeIf{it.isNotBlank()},lp?.optString("description")?.takeIf{it.isNotBlank()},lp?.optString("image")?.takeIf{it.isNotBlank()},lp?.optString("site")?.takeIf{it.isNotBlank()},lp?.optString("type")?.takeIf{it.isNotBlank()},m.optString("replyToMessageId").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToSenderNickname").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToText").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToMessageType").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAudioUrl").takeIf{it.isNotBlank() && it!="null"},m.optInt("replyToAudioDuration",0),m.optString("replyToStickerImageUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToGifImageUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAttachmentUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAttachmentType").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAttachmentName").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewTitle").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewDescription").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewImage").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewSite").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewType").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToLinkPreviewVideo").takeIf{it.isNotBlank() && it!="null"})
                    if(!outgoing&&!read) unreadIds+=m.optString("id")
                }catch(_:Throwable){
                    // One malformed row must never hide the rest of the conversation.
                }
            }
            val serverIds=list.map{it.id}.toSet()
            // Reconcile optimistic messages with the authoritative server list.
            // A polling refresh can race with messages/send: in that window the
            // optimistic bubble still has its local id while the server copy has
            // already arrived, which used to render the same message twice.
            val pendingForChat = pendingSnapshot(key)
            val stillPending=pendingForChat.filter { p ->
                if (serverIds.contains(p.id)) return@filter false
                val duplicateOnServer = list.any { m ->
                    m.isOutgoing &&
                    m.text == p.text &&
                    m.messageType == p.messageType &&
                    kotlin.math.abs(m.createdAt - p.createdAt) <= 15_000L
                }
                !duplicateOnServer
            }
            val merged=(list + stillPending)
                .distinctBy { it.id }
                .sortedBy{it.createdAt}
            if(stillPending.isEmpty()) withPendingLock { pendingOutgoing.remove(key) }
            _messages.value=_messages.value.toMutableMap().apply{put(key,merged)}
            merged.lastOrNull()?.let{
                _chats.value=(_chats.value.filterNot{it.nickname.equals(key,true)}+ChatSummary(it.id,key,it.text,it.time,0,true,"male_01"))
            }
            // Mark reads after the UI state is updated; do not block rendering on these requests.
            unreadIds.forEach { id-> apiScope.launch{try{VGhostApi.markMessageRead(id)}catch(_:Throwable){}} }
        }catch(_:Throwable){}
        finally{lock.unlock()}
    }
    suspend fun setTyping(recipientNickname:String, typing:Boolean){
        if(!hasAccount()) return
        try { resolveUid(normalize(recipientNickname))?.let { VGhostApi.setTyping(it.toLong(), typing) } } catch(_:Throwable) {}
    }
    suspend fun getTyping(recipientNickname:String):Boolean {
        if(!hasAccount()) return false
        return try { resolveUid(normalize(recipientNickname))?.let { VGhostApi.typingStatus(it.toLong()) } ?: false } catch(_:Throwable) { false }
    }
    fun apiScopeLaunchTypingClear(recipientNickname:String) {
        if (!hasAccount()) return
        apiScope.launch {
            try { setTyping(recipientNickname, false) } catch (_: Throwable) { }
        }
    }
    suspend fun sendVoice(recipientNickname:String, fileName:String, bytes:ByteArray, duration:Int):String? {
        if(!hasAccount()) return com.vghost.app.i18n.VGhostLanguage.trKey("log_send_voice_message")
        if(bytes.isEmpty()) return com.vghost.app.i18n.VGhostLanguage.trKey("voice_recording_empty")
        val n=normalize(recipientNickname)
        val optimisticId="local-${java.util.UUID.randomUUID()}"
        // Persist a short-lived local copy so the voice bubble is visible and
        // playable immediately, before the multipart upload reaches cPanel.
        val localPath = try {
            val dir=java.io.File(appContext.cacheDir,"voice_outbox").apply { mkdirs() }
            val safe=fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")
            val f=java.io.File(dir,"$optimisticId-$safe")
            f.writeBytes(bytes)
            f.absolutePath
        } catch(_:Throwable) { null }
        val optimistic=ChatMessage(
            id=optimisticId, text=com.vghost.app.i18n.VGhostLanguage.trKey("voice_message_3"), isOutgoing=true,
            time=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date()),
            isDelivered=true, isRead=false, createdAt=System.currentTimeMillis(),
            senderNickname=_currentUserNickname.value, messageType="voice",
            audioDuration=duration.coerceAtLeast(0), localAudioPath=localPath
        )
        _messages.value=_messages.value.toMutableMap().apply { put(n,get(n).orEmpty()+optimistic) }
        addPending(n,optimistic)
        _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary(optimisticId,n,com.vghost.app.i18n.VGhostLanguage.trKey("sec").format(duration.coerceAtLeast(0)),optimistic.time,0,true,"male_01"))
        return try {
            val uid=resolveUid(n) ?: throw IllegalStateException(com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found"))
            val response=VGhostApi.uploadVoice(uid.toLong(),fileName,bytes,duration)
            val sm=response.optJSONObject("message")
            val serverId=sm?.optString("id")?.takeIf{it.isNotBlank()} ?: optimisticId
            val audioUrl=sm?.optString("audio_url")?.takeIf{it.isNotBlank()}
            _messages.value=_messages.value.toMutableMap().apply {
                put(n,get(n).orEmpty().map { if(it.id==optimisticId) it.copy(id=serverId,isDelivered=true,audioUrl=audioUrl) else it }.distinctBy{it.id})
            }
            updatePendingId(n,optimisticId,optimistic.copy(id=serverId,isDelivered=true,audioUrl=audioUrl))
            _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary(serverId,n,com.vghost.app.i18n.VGhostLanguage.trKey("sec").format(duration.coerceAtLeast(0)),optimistic.time,0,true,"male_01"))
            try { localPath?.let { java.io.File(it).delete() } } catch(_:Throwable) {}
            apiScope.launch { try { loadMessages(n) } catch(_:Throwable){} }
            null
        } catch(t:Throwable) {
            _messages.value=_messages.value.toMutableMap().apply { put(n,get(n).orEmpty().filterNot{it.id==optimisticId}) }
            removePending(n,optimisticId)
            try { localPath?.let { java.io.File(it).delete() } } catch(_:Throwable) {}
            error(t)
        }
    }

    suspend fun editMessage(recipientNickname:String, messageId:String, text:String):String? {
        if(!hasAccount()) return com.vghost.app.i18n.VGhostLanguage.trKey("log_edit_message")
        return try {
            VGhostApi.editMessage(messageId.toLongOrNull() ?: return com.vghost.app.i18n.VGhostLanguage.trKey("message_not_found"), text.trim())
            val key=normalize(recipientNickname)
            _messages.value=_messages.value.toMutableMap().apply { put(key, get(key).orEmpty().map { if(it.id==messageId) it.copy(text=text.trim(), messageType="text") else it }) }
            apiScope.launch { try { loadMessages(key) } catch(_:Throwable){} }
            null
        } catch(t:Throwable){ error(t) }
    }
    suspend fun deleteMessageForBoth(recipientNickname:String, messageId:String):String? {
        if(!hasAccount()) return com.vghost.app.i18n.VGhostLanguage.trKey("log_delete_message")
        return try {
            VGhostApi.deleteMessage(messageId.toLongOrNull() ?: return com.vghost.app.i18n.VGhostLanguage.trKey("message_not_found"))
            val key=normalize(recipientNickname)
            _messages.value=_messages.value.toMutableMap().apply { put(key, get(key).orEmpty().filterNot { it.id==messageId }) }
            // The server response is authoritative: the same shared row is now gone
            // for both participants, not merely hidden on this device.
            apiScope.launch { try { loadMessages(key) } catch(_:Throwable){} }
            null
        } catch(t:Throwable){ error(t) }
    }

    suspend fun reactToMessage(recipientNickname:String, messageId:String, reaction:String):String? {
        if(!hasAccount()) return com.vghost.app.i18n.VGhostLanguage.trKey("log_react_message")
        val id = messageId.toLongOrNull() ?: return com.vghost.app.i18n.VGhostLanguage.trKey("message_not_found")
        val key = normalize(recipientNickname)
        val current = _messages.value[key].orEmpty()
        val target = current.firstOrNull { it.id == messageId } ?: return com.vghost.app.i18n.VGhostLanguage.trKey("message_not_found")
        val oldReaction = target.myReaction
        val oldCounts = target.reactions

        // Optimistic UI: show the reaction immediately, including on voice messages.
        fun applyReaction() {
            val latest = _messages.value[key].orEmpty()
            _messages.value = _messages.value.toMutableMap().apply {
                put(key, latest.map { message ->
                    if (message.id != messageId) return@map message
                    val counts = message.reactions.toMutableMap()
                    message.myReaction?.let { old ->
                        if (old != reaction) {
                            val oldCount = (counts[old] ?: 0) - 1
                            if (oldCount > 0) counts[old] = oldCount else counts.remove(old)
                        }
                    }
                    if (message.myReaction != reaction) counts[reaction] = (counts[reaction] ?: 0) + 1
                    message.copy(reactions = counts, myReaction = reaction)
                })
            }
        }

        return try {
            applyReaction()
            VGhostApi.reactToMessage(id, reaction)
            // Do not immediately reload the whole chat here. A fast background
            // reload could briefly return stale reaction data and erase the
            // optimistic voice-message reaction from the screen.
            null
        } catch(t:Throwable) {
            // Roll back only this message when the server rejects the reaction.
            val latest = _messages.value[key].orEmpty()
            _messages.value = _messages.value.toMutableMap().apply {
                put(key, latest.map { message ->
                    if (message.id == messageId) message.copy(reactions = oldCounts, myReaction = oldReaction) else message
                })
            }
            error(t)
        }
    }

    private fun isEmojiOnlyMessage(value: String): Boolean {
        if (value.isBlank()) return false
        var sawEmoji = false
        var i = 0
        while (i < value.length) {
            val cp = value.codePointAt(i)
            i += Character.charCount(cp)
            when {
                Character.isWhitespace(cp) -> Unit
                cp == 0x200D || cp == 0xFE0F || cp == 0x20E3 || (cp in 0x1F3FB..0x1F3FF) -> Unit
                cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2300..0x23FF || cp in 0x2B00..0x2BFF || cp in 0x2190..0x21FF -> sawEmoji = true
                cp in 0x1F1E6..0x1F1FF -> sawEmoji = true
                else -> return false
            }
        }
        return sawEmoji
    }

    suspend fun sendMessage(recipientNickname:String,text:String, stickerImageUrl:String?=null, gifImageUrl:String?=null, replyToMessage:ChatMessage?=null):String?{
        // Do not compare with the previous message: sending the exact same text twice is valid.
        val body=text.trim()
        if(body.isBlank())return com.vghost.app.i18n.VGhostLanguage.trKey("message_cannot_empty")
        val messageType = when {
            body.startsWith("__VG_STICKER__:") -> "sticker"
            body.startsWith("__VG_GIF__:") -> "gif"
            isEmojiOnlyMessage(body) -> "emoji"
            else -> "text"
        }
        if(!hasAccount())return com.vghost.app.i18n.VGhostLanguage.trKey("log_send_message")
        val n=normalize(recipientNickname)
        val optimisticId="local-${java.util.UUID.randomUUID()}"
        val optimistic=ChatMessage(
            id=optimisticId, text=body, isOutgoing=true,
            time=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date()),
            isDelivered=true, isRead=false, createdAt=System.currentTimeMillis(),
            senderNickname=_currentUserNickname.value, messageType=messageType, stickerImageUrl=stickerImageUrl, gifImageUrl=gifImageUrl,
            replyToMessageId=replyToMessage?.id, replyToSenderNickname=replyToMessage?.senderNickname,
            replyToText=replyToMessage?.text, replyToMessageType=replyToMessage?.messageType,
            replyToAudioUrl=replyToMessage?.audioUrl, replyToAudioDuration=replyToMessage?.audioDuration ?: 0,
            replyToStickerImageUrl=replyToMessage?.stickerImageUrl, replyToGifImageUrl=replyToMessage?.gifImageUrl,
            replyToAttachmentUrl=replyToMessage?.attachmentUrl, replyToAttachmentType=replyToMessage?.attachmentType,
            replyToAttachmentName=replyToMessage?.attachmentName,
            replyToLinkPreviewUrl=replyToMessage?.linkPreviewUrl, replyToLinkPreviewTitle=replyToMessage?.linkPreviewTitle,
            replyToLinkPreviewDescription=replyToMessage?.linkPreviewDescription, replyToLinkPreviewImage=replyToMessage?.linkPreviewImage,
            replyToLinkPreviewSite=replyToMessage?.linkPreviewSite, replyToLinkPreviewType=replyToMessage?.linkPreviewType,
            replyToLinkPreviewVideo=replyToMessage?.linkPreviewVideo
        )
        // Render locally before touching the network. The message is marked undelivered
        // until the API accepts it, so a slow connection never makes the chat feel frozen.
        _messages.value=_messages.value.toMutableMap().apply {
            val current=get(n).orEmpty()
            put(n,current+optimistic)
        }
        addPending(n, optimistic)
        _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary("local-$n",n,body,optimistic.time,0,true,"male_01"))
        return try{
            val uid=resolveUid(n)?:throw IllegalStateException(com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found"))
            val response=VGhostApi.call("messages/send","POST",org.json.JSONObject().put("receiver_id",uid).put("message",body).put("message_type",messageType).apply {
                replyToMessage?.id?.toLongOrNull()?.let { put("reply_to_message_id", it) }
            })
            val serverMessage=response.optJSONObject("message")
            val serverId=serverMessage?.optString("id")?.takeIf{!it.isNullOrBlank()}
            val lp=serverMessage?.optJSONObject("link_preview")
            // Mark the optimistic bubble as delivered immediately. A background refresh
            // then replaces it with the authoritative server copy.
            val deliveredId=serverId ?: optimisticId
            _messages.value=_messages.value.toMutableMap().apply {
                // A poll may already contain the server copy while send() is finishing.
                // Replace the optimistic row, then de-duplicate by the authoritative id.
                put(n,get(n).orEmpty().map { if(it.id==optimisticId) it.copy(id=deliveredId,isDelivered=true,isRead=false,
                    linkPreviewUrl=lp?.optString("url")?.takeIf{v->v.isNotBlank()},
                    linkPreviewTitle=lp?.optString("title")?.takeIf{v->v.isNotBlank()},
                    linkPreviewDescription=lp?.optString("description")?.takeIf{v->v.isNotBlank()},
                    linkPreviewImage=lp?.optString("image")?.takeIf{v->v.isNotBlank()},
                    linkPreviewSite=lp?.optString("site")?.takeIf{v->v.isNotBlank()},
                    linkPreviewType=lp?.optString("type")?.takeIf{v->v.isNotBlank()},
                    linkPreviewVideo=lp?.optString("video")?.takeIf{v->v.isNotBlank()},
                    replyToMessageId=serverMessage?.optString("replyToMessageId")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.id,
                    replyToSenderNickname=serverMessage?.optString("replyToSenderNickname")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.senderNickname,
                    replyToText=serverMessage?.optString("replyToText")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.text,
                    replyToMessageType=serverMessage?.optString("replyToMessageType")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.messageType,
                    replyToAudioUrl=serverMessage?.optString("replyToAudioUrl")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.audioUrl,
                    replyToAudioDuration=(serverMessage?.optInt("replyToAudioDuration",0) ?: 0).takeIf { it > 0 } ?: (replyToMessage?.audioDuration ?: 0),
                    replyToStickerImageUrl=serverMessage?.optString("replyToStickerImageUrl")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.stickerImageUrl,
                    replyToGifImageUrl=serverMessage?.optString("replyToGifImageUrl")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.gifImageUrl,
                    replyToAttachmentUrl=serverMessage?.optString("replyToAttachmentUrl")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.attachmentUrl,
                    replyToAttachmentType=serverMessage?.optString("replyToAttachmentType")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.attachmentType,
                    replyToAttachmentName=serverMessage?.optString("replyToAttachmentName")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.attachmentName,
                    replyToLinkPreviewUrl=serverMessage?.optString("replyToLinkPreviewUrl")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewUrl,
                    replyToLinkPreviewTitle=serverMessage?.optString("replyToLinkPreviewTitle")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewTitle,
                    replyToLinkPreviewDescription=serverMessage?.optString("replyToLinkPreviewDescription")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewDescription,
                    replyToLinkPreviewImage=serverMessage?.optString("replyToLinkPreviewImage")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewImage,
                    replyToLinkPreviewSite=serverMessage?.optString("replyToLinkPreviewSite")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewSite,
                    replyToLinkPreviewType=serverMessage?.optString("replyToLinkPreviewType")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewType,
                    replyToLinkPreviewVideo=serverMessage?.optString("replyToLinkPreviewVideo")?.takeIf{v->v.isNotBlank()} ?: replyToMessage?.linkPreviewVideo) else it }.distinctBy { it.id })
            }
            updatePendingId(n, optimisticId, optimistic.copy(id=deliveredId,isDelivered=true,isRead=false))
            _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary(deliveredId,n,body,optimistic.time,0,true,"male_01"))
            apiScope.launch { try { loadMessages(n) } catch(_:Throwable){} }
            null
        }catch(t:Throwable){
            // Never leave a fake message behind when the server rejected the send.
            _messages.value=_messages.value.toMutableMap().apply { put(n,get(n).orEmpty().filterNot{it.id==optimisticId}) }
            removePending(n, optimisticId)
            error(t)
        }
    }
    suspend fun sendAttachment(recipientNickname:String, fileName:String, mimeType:String, bytes:ByteArray):String?{
        if(!hasAccount()) return com.vghost.app.i18n.VGhostLanguage.trKey("log_send_file")
        if(bytes.isEmpty()) return com.vghost.app.i18n.VGhostLanguage.trKey("file_empty")
        val n=normalize(recipientNickname)
        val attachmentType=when { mimeType.startsWith("image/") -> "image"; mimeType.startsWith("video/") -> "video"; mimeType.startsWith("audio/") -> "audio"; else -> "file" }
        val optimisticId="local-${UUID.randomUUID()}"
        val localPath = try {
            val dir=java.io.File(appContext.cacheDir,"attachment_outbox").apply { mkdirs() }
            val safe=fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")
            val f=java.io.File(dir,"$optimisticId-$safe")
            f.writeBytes(bytes)
            f.absolutePath
        } catch(_:Throwable) { null }
        val optimistic=ChatMessage(
            id=optimisticId, text=fileName, isOutgoing=true,
            time=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date()),
            isDelivered=true, isRead=false, createdAt=System.currentTimeMillis(),
            senderNickname=_currentUserNickname.value, messageType="attachment",
            attachmentType=attachmentType, attachmentName=fileName, localAttachmentPath=localPath
        )
        _messages.value=_messages.value.toMutableMap().apply { put(n,get(n).orEmpty()+optimistic) }
        addPending(n, optimistic)
        _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary(optimisticId,n,fileName,optimistic.time,0,true,"male_01"))
        return try {
            val uid=resolveUid(n) ?: throw IllegalStateException(com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found"))
            val response=VGhostApi.uploadAttachment(uid.toLong(), fileName, bytes, mimeType)
            val sm=response.optJSONObject("message")
            val serverId=sm?.optString("id")?.takeIf{it.isNotBlank()} ?: optimisticId
            val attachmentUrl=sm?.optString("attachment_url")?.takeIf{it.isNotBlank()}
            _messages.value=_messages.value.toMutableMap().apply {
                // The poller may have inserted the server row already; never expose
                // duplicate LazyColumn keys during that race.
                put(n,get(n).orEmpty().map { if(it.id==optimisticId) it.copy(id=serverId,isDelivered=true,attachmentUrl=attachmentUrl,localAttachmentPath=null) else it }.distinctBy { it.id })
            }
            updatePendingId(n, optimisticId, optimistic.copy(id=serverId,isDelivered=true,attachmentUrl=attachmentUrl,localAttachmentPath=null))
            try { localPath?.let { java.io.File(it).delete() } } catch(_:Throwable) {}
            _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary(serverId,n,fileName,optimistic.time,0,true,"male_01"))
            apiScope.launch { try { loadMessages(n) } catch(_:Throwable){} }
            null
        } catch(t:Throwable) {
            _messages.value=_messages.value.toMutableMap().apply { put(n,get(n).orEmpty().filterNot{it.id==optimisticId}) }
            removePending(n, optimisticId)
            try { localPath?.let { java.io.File(it).delete() } } catch(_:Throwable) {}
            error(t)
        }
    }
    fun cleanupExpiredRemoteMessages(){/* cPanel cron owns expiry cleanup */}
    fun clearChat(nickname:String){
        val n=normalize(nickname)
        if(!hasAccount()){
            _messages.value=_messages.value.toMutableMap().apply{remove(n)}
            _chats.value=_chats.value.filterNot{it.nickname.equals(n,true)}
            return
        }
        apiScope.launch {
            try {
                val uid=resolveUid(n) ?: throw IllegalStateException(com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found"))
                VGhostApi.deleteConversation(uid.toString())
                // The backend hard-deletes the shared conversation, so the local
                // cache is cleared only after the server confirms both-side deletion.
                _messages.value=_messages.value.toMutableMap().apply{remove(n)}
                _chats.value=_chats.value.filterNot{it.nickname.equals(n,true)}
            } catch (_:Throwable) {
                // Keep the local cache intact when the server did not confirm deletion.
            }
        }
    }
    fun removeRecentSearch(id:String){_recentSearches.value=_recentSearches.value.filterNot{it.id==id}}
    fun addRecentSearch(nickname:String){val n=normalize(nickname);_recentSearches.value=listOf(RecentSearch(UUID.randomUUID().toString(),n))+_recentSearches.value.filterNot{it.nickname.equals(n,true)}}

    suspend fun refreshVipStatus():Boolean {
        return try {
            val r = VGhostApi.call("vip/status")
            val active = r.optBoolean("isVip", false)
            _currentUserVip.value = active
            _currentUserVipExpiresAt.value = r.optString("vipExpiresAt").takeIf { it.isNotBlank() && it != "null" }
            active
        } catch (_: Throwable) {
            _currentUserVip.value
        }
    }
    suspend fun getUsers():List<UserListEntry>{return try{val a=VGhostApi.call("users/list").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("uid",o.optString("id")),o.optString("nickname"),o.optBoolean("online",false),o.optString("avatarId","male_01").ifBlank { "male_01" },o.optString("avatarUrl").takeIf { it.isNotBlank() && it!="null" }?.let { VGhostApi.publicUrl(it) },o.optBoolean("isVip",false),o.optInt("level",1),o.optString("vipFrameId","vip_01").ifBlank { "vip_01" })}}catch(_:Throwable){emptyList()}}
    suspend fun getOnlineUsers():List<OnlineUser>{if(_isGhostMode.value)return emptyList();return try{val a=VGhostApi.call("users/online").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);OnlineUser(o.optString("uid"),o.optString("nickname"),o.optString("avatarId","male_01").ifBlank { "male_01" })}}catch(_:Throwable){emptyList()}}
    suspend fun getFriends():List<UserListEntry>{return try{val a=VGhostApi.call("friends/list").optJSONArray("friends")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("id"),o.optString("nickname"),o.optString("status")=="active",o.optString("avatarId","male_01").ifBlank { "male_01" },o.optString("avatarUrl").takeIf { it.isNotBlank() && it!="null" }?.let { VGhostApi.publicUrl(it) },o.optBoolean("isVip",false),o.optInt("level",1),o.optString("vipFrameId","vip_01").ifBlank { "vip_01" })}}catch(_:Throwable){emptyList()}}
    suspend fun getBlockedUsers():List<UserListEntry>{return try{val a=VGhostApi.call("blocks/list").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("id"),o.optString("nickname"),false,o.optString("avatarId","male_01").ifBlank { "male_01" },o.optString("avatarUrl").takeIf { it.isNotBlank() && it!="null" }?.let { VGhostApi.publicUrl(it) })}}catch(_:Throwable){emptyList()}}
    suspend fun findUserByNickname(nickname:String):UserListEntry?{
        return try{
            val normalized=normalize(nickname)
            val a=VGhostApi.call("users/search?q="+java.net.URLEncoder.encode(normalized,"UTF-8")).optJSONArray("users")?:return null
            var first:UserListEntry?=null
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                val entry=UserListEntry(o.optString("uid",o.optString("id")),o.optString("nickname"),o.optBoolean("online",false),o.optString("avatarId","male_01").ifBlank { "male_01" },o.optString("avatarUrl").takeIf { it.isNotBlank() && it!="null" }?.let { VGhostApi.publicUrl(it) },o.optBoolean("isVip",false),o.optInt("level",1))
                if(first==null) first=entry
                if(entry.nickname.trim().equals(normalized,true)) return entry
            }
            first
        }catch(_:Throwable){null}
    }
    suspend fun recordProfileView(targetUid:String)=try{VGhostApi.call("profile/view","POST",org.json.JSONObject().put("uid",targetUid));true}catch(_:Throwable){false}
    suspend fun getProfileVisitors():List<UserListEntry>{return try{val a=VGhostApi.call("profile/visitors").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("id"),o.optString("nickname"),o.optString("status")=="active",o.optString("avatarId","male_01").ifBlank { "male_01" },o.optString("avatarUrl").takeIf { it.isNotBlank() && it!="null" }?.let { VGhostApi.publicUrl(it) },o.optBoolean("isVip",false),o.optInt("level",1))}}catch(_:Throwable){emptyList()}}
    suspend fun setAvatar(avatarId:String):String? = try {
        val id = avatarId.lowercase().trim()
        val preset = Regex("(?:male|female)_0[1-6]").matches(id)
        if (!preset) throw IllegalArgumentException("INVALID_AVATAR")
        val r = VGhostApi.setAvatar(id)
        val saved = r.optString("avatarId", id).ifBlank { id }
        _currentUserAvatarId.value = saved
        _currentUserAvatarUrl.value = null
        prefs.edit().putString(PREF_AVATAR_ID, saved).remove(PREF_AVATAR_URL).apply()
        null
    } catch(t:Throwable) { error(t) }
    suspend fun setVipFrame(frameId:String):String? = try {
        val id=frameId.lowercase().trim()
        val allowed=setOf("vip_01","vip_02","vip_03","vip_04","vip_05","vip_06","vip_07","vip_08","vip_09")
        if(id !in allowed) throw IllegalArgumentException("INVALID_VIP_FRAME")
        if(!_currentUserVip.value) throw IllegalStateException("VIP_REQUIRED")
        val r=VGhostApi.setVipFrame(id)
        val saved=r.optString("vipFrameId",id).ifBlank { id }
        _currentUserVipFrameId.value=saved
        prefs.edit().putString(PREF_VIP_FRAME_ID,saved).apply()
        null
    } catch(t:Throwable) { error(t) }

    suspend fun getPublicUserProfile(nickname:String): PublicUserProfile? {
        return try {
            val encoded = java.net.URLEncoder.encode(normalize(nickname), "UTF-8")
            val u = VGhostApi.call("users/public?nickname=" + encoded).optJSONObject("user") ?: return null
            val ga = u.optJSONArray("gifts")
            val gifts: List<GiftCollectionItem> = if (ga == null) {
                emptyList()
            } else {
                List(ga.length()) { index ->
                    val g = ga.getJSONObject(index)
                    val gid = g.optString("giftId")
                    val catalogGift = GiftCatalog.find(gid)
                    GiftCollectionItem(
                        giftId = gid,
                        // Catalog IDs are the source of truth for display names.
                        // The backend name may be stored in another language, so never
                        // use it when a known catalog gift exists.
                        name = catalogGift?.name
                            ?: g.optString("name").takeIf { it.isNotBlank() }
                            ?: com.vghost.app.i18n.VGhostLanguage.trKey("gift_2"),
                        icon = catalogGift?.icon ?: g.optString("icon").takeIf { it.isNotBlank() } ?: com.vghost.app.i18n.VGhostLanguage.trKey("gift"),
                        price = g.optInt("price").takeIf { it > 0 } ?: (catalogGift?.price ?: 0),
                        count = g.optInt("count")
                    )
                }
            }
            PublicUserProfile(
                uid = u.optString("uid"),
                nickname = u.optString("nickname"),
                balance = u.optInt("balance"),
                online = u.optBoolean("online"),
                ghostMode = u.optBoolean("ghostMode"),
                friendStatus = u.optString("friendStatus", "none"),
                blockedByMe = u.optBoolean("blockedByMe"),
                blockedMe = u.optBoolean("blockedMe"),
                activityXp = u.optInt("activityXp", 0),
                activityLevel = u.optInt("activityLevel", 1),
                giftXp = u.optInt("giftXp"),
                giftLevel = u.optInt("giftLevel", 1),
                nextGiftLevelXp = u.optInt("nextGiftLevelXp", 100),
                gifts = gifts,
                avatarId = u.optString("avatarId", "male_01").ifBlank { "male_01" },
                avatarUrl = u.optString("avatarUrl").takeIf { it.isNotBlank() && it != "null" },
                isVip = u.optBoolean("isVip", false),
                vipFrameId = u.optString("vipFrameId", "vip_01").ifBlank { "vip_01" }
            )
        } catch (_: Throwable) {
            null
        }
    }
    suspend fun getUserOnlineStatus(nickname:String):Boolean? = try {
        val encoded=java.net.URLEncoder.encode(normalize(nickname),"UTF-8")
        val u=VGhostApi.call("users/public?nickname="+encoded).optJSONObject("user") ?: return null
        u.optBoolean("online",false)
    } catch(_:Throwable){ null }
    
    suspend fun getMyActivityLevel(): Pair<Int,Int> = try { val r=VGhostApi.call("profile/level"); Pair(r.optInt("xp",0),r.optInt("level",1)) } catch(_:Throwable){ Pair(0,1) }

    fun clearLevelUpEvent(token:Long){ if(_levelUpEvent.value?.token==token) _levelUpEvent.value=null }

    fun startActivityLevelSync(){
        activityLevelSyncJob?.cancel()
        if(!hasAccount()) return
        val epoch=sessionEpoch
        activityLevelSyncJob=apiScope.launch {
            while(isActive && epoch==sessionEpoch && hasAccount()){
                try {
                    val r=VGhostApi.call("profile/level")
                    val level=r.optInt("level",1).coerceAtLeast(1)
                    val previous=knownActivityLevel
                    if(epoch==sessionEpoch && hasAccount()){
                        if(previous!=null && level>previous){
                            _levelUpEvent.value=LevelUpEvent(level=level,coins=(level-previous)*100)
                            refreshMyWallet()
                        }
                        knownActivityLevel=level
                    }
                } catch(_:Throwable){}
                delay(3000)
            }
        }
    }
    suspend fun getPrivacySettings(): Pair<String,String> = try {
        val p=VGhostApi.call("settings/privacy").optJSONObject("privacy") ?: return "everyone" to "everyone"
        p.optString("messagePermission","everyone") to p.optString("friendPermission","everyone")
    } catch(_:Throwable) { "everyone" to "everyone" }

    suspend fun updatePrivacySettings(messagePermission:String, friendPermission:String):String? = try {
        if(messagePermission !in setOf("everyone","friends","nobody")) return com.vghost.app.i18n.VGhostLanguage.trKey("yanl_mesaj_m_xfilik_se_imi")
        if(friendPermission !in setOf("everyone","nobody")) return com.vghost.app.i18n.VGhostLanguage.trKey("yanl_dostluq_m_xfilik_se_imi")
        VGhostApi.call("settings/privacy","POST",org.json.JSONObject().put("messagePermission",messagePermission).put("friendPermission",friendPermission))
        null
    } catch(t:Throwable) { error(t) }

suspend fun getMyGiftProfile():Triple<Int,Int,List<GiftCollectionItem>> = try{
        val r=VGhostApi.call("gifts/profile")
        val a=r.optJSONArray("collection")
        val gifts=if(a==null) emptyList() else List(a.length()){
            val g=a.getJSONObject(it)
            val giftId=g.optString("gift_id",g.optString("giftId"))
            val serverName=g.optString("name")
            val serverIcon=g.optString("icon")
            val catalog=GiftCatalog.find(giftId) ?: GiftCatalog.items.firstOrNull{it.id.equals(serverName,ignoreCase=true)}
            GiftCollectionItem(
                giftId,
                // Always prefer the catalog translation for known gift IDs.
                catalog?.name ?: serverName.ifBlank { com.vghost.app.i18n.VGhostLanguage.trKey("gift") },
                catalog?.icon ?: serverIcon.takeIf{it.isNotBlank()} ?: com.vghost.app.i18n.VGhostLanguage.trKey("gift"),
                g.optInt("price").takeIf { it > 0 } ?: (catalog?.price ?: 0),
                g.optInt("count")
            )
        }
        Triple(r.optInt("giftXp"),r.optInt("giftLevel",1),gifts)
    }catch(_:Throwable){Triple(0,1,emptyList())}
    suspend fun addFriend(recipientUid:String):String?=social("friends/add","user_id",recipientUid,com.vghost.app.i18n.VGhostLanguage.trKey("friend_request_was_not_sent"))
    suspend fun acceptFriend(senderUid:String):String?=social("friends/accept","user_id",senderUid,com.vghost.app.i18n.VGhostLanguage.trKey("friend_request_was_not_accepted"))
    suspend fun rejectFriend(senderUid:String):String?=social("friends/reject","user_id",senderUid,com.vghost.app.i18n.VGhostLanguage.trKey("friend_request_was_not_rejected"))
    suspend fun removeFriend(recipientUid:String):String?=social("friends/remove","user_id",recipientUid,com.vghost.app.i18n.VGhostLanguage.trKey("friend_could_not_removed"))
    suspend fun blockUser(blockedUid:String):String?=social("blocks/add","uid",blockedUid,com.vghost.app.i18n.VGhostLanguage.trKey("user_was_not_blocked"))
    suspend fun unblockUser(blockedUid:String):String?=social("blocks/remove","uid",blockedUid,com.vghost.app.i18n.VGhostLanguage.trKey("block_could_not_removed"))
    private suspend fun social(path:String,key:String,value:String,msg:String)=try{VGhostApi.call(path,"POST",org.json.JSONObject().put(key,value));null}catch(_:Throwable){msg}
    suspend fun giftStory(storyId:Long,giftId:String):String?=try{
        if(storyId<=0L) return com.vghost.app.i18n.VGhostLanguage.trKey("story_not_found")
        if(giftId.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("no_gift_selected")
        val r=VGhostApi.giftStory(storyId,giftId)
        applyServerBalance(r)
        null
    }catch(t:Throwable){refreshMyWallet();error(t)}
    suspend fun sendGift(recipientUid:String,giftId:String):String?=try{
        val uid=recipientUid.toIntOrNull()?:return com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found")
        if(giftId.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("no_gift_selected")
        // Catalog IDs are stable symbolic names (love, rose, ...). The backend resolves
        // both names and numeric IDs, so never reject a valid symbolic ID on the client.
        val r=VGhostApi.legacyTransactionCall("gifts/send","POST",org.json.JSONObject().put("recipientUid",uid).put("giftId",giftId))
        applyServerBalance(r); null
    }catch(t:Throwable){refreshMyWallet();error(t)}
    suspend fun sendCoins(recipientUid:String,amount:Int):String?=try{
        val uid=recipientUid.toIntOrNull()?:return com.vghost.app.i18n.VGhostLanguage.trKey("user_not_found")
        if(amount<=0) return com.vghost.app.i18n.VGhostLanguage.trKey("invalid_coin_amount")
        val r=VGhostApi.legacyTransactionCall("coins/send","POST",org.json.JSONObject().put("recipientUid",uid).put("amount",amount))
        applyServerBalance(r); null
    }catch(t:Throwable){refreshMyWallet();error(t)}
    /** Remove account/session/device secrets stored locally after a permanent server-side delete. */
    private fun purgeLocalAccountData() {
        try { VGhostApi.setToken(null) } catch (_: Throwable) {}
        // Account deletion is a true local wipe: remove every app-private data
        // directory that can contain account/session/chat/media cache data.
        // The APK itself is not touched and Android recreates these directories.
        try { appContext.filesDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.cacheDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.noBackupFilesDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.codeCacheDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.externalCacheDir?.deleteRecursively() } catch (_: Throwable) {}
        try {
            val dataDir = appContext.dataDir
            dataDir.listFiles()?.forEach { child ->
                if (child.name !in setOf("lib")) child.deleteRecursively()
            }
        } catch (_: Throwable) {}
        // Clear known preferences again after the directory wipe; recreate only
        // what the running process needs. No account credential/cache is retained.
        try { appContext.getSharedPreferences("vghost_api", Context.MODE_PRIVATE).edit().clear().commit() } catch (_: Throwable) {}
        try { appContext.getSharedPreferences("vghost_push", Context.MODE_PRIVATE).edit().clear().commit() } catch (_: Throwable) {}
        try { prefs.edit().clear().commit() } catch (_: Throwable) {}
    }

    suspend fun deleteAccount(password:String):String? {
        // Separate account-deletion flow. PANIC is intentionally untouched.

        if (password.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("enter_password")
        try {
            if (hasAccount() && !_isGhostMode.value) {
                val nickname = _currentUserNickname.value.trim()
                if (nickname.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("user_information_not_found")
                // Delete directly with the same credentials used by the web deletion flow.
                // This avoids a separate login/token step and keeps account deletion working
                // even when the current app session is stale or missing.
                val result = VGhostApi.call(
                    "auth/web-delete-account",
                    "POST",
                    JSONObject().put("login", nickname).put("password", password)
                )
                if (!result.optBoolean("deleted", false)) return com.vghost.app.i18n.VGhostLanguage.trKey("account_could_not_deleted")
            }
        } catch (t:Throwable) {
            return error(t)
        }
        purgeLocalAccountData(); resetSessionState(); _sessionState.value=SessionState.LoggedOut; _isPanicActivated.value=false; _appLockEnabled.value=false; _isAppLocked.value=false
        return null
    }

    suspend fun activatePanicWipe(password:String, adminPanic:Boolean=false):String? {

        if (password.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("enter_password")
        try {
            if (hasAccount() && !_isGhostMode.value) {
                val nickname = _currentUserNickname.value.trim()
                if (nickname.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("user_information_not_found")
                val verified = VGhostApi.login(nickname, password)
                val verifiedToken = verified.optString("token")
                if (verifiedToken.isBlank()) return com.vghost.app.i18n.VGhostLanguage.trKey("password_verification_failed")
                VGhostApi.setToken(verifiedToken)
                VGhostApi.call("auth/panic", "POST")
            }
        } catch (t:Throwable) {
            return error(t)
        }
        purgeLocalAccountData(); resetSessionState(); _sessionState.value=SessionState.LoggedOut; _isPanicActivated.value=true; _appLockEnabled.value=false; _isAppLocked.value=false
        return null
    }
}
