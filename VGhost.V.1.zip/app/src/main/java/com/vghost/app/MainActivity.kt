package com.vghost.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.AppLocale
import android.content.Context
import android.view.WindowManager
import com.vghost.app.ui.screens.PinLockScreen
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.vghost.app.navigation.AppNavigation
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private var notificationRefreshJob: Job? = null
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLocale.wrap(newBase))
    }

    private var pendingChatNickname by mutableStateOf<String?>(null)
    private var pendingNotificationTarget by mutableStateOf<String?>(null)
    private var pendingNotificationTargetValue by mutableStateOf<String?>(null)

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Keep IME resizing stable after locale/configuration recreation.
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        VGhostRepository.instance.initialize(applicationContext)
        // Keep the whole app cache bounded. Media is disposable and can always be downloaded again.
        runCatching {
            CacheManager.trimCache(applicationContext)
            CacheManager.trimPrefix(
                applicationContext, "vghost_preview_",
                CacheManager.MAX_EXTERNAL_PREVIEW_BYTES,
                CacheManager.TRIM_EXTERNAL_PREVIEW_BYTES
            )
            StoryMediaCache.removeLegacyFiles(applicationContext)
        }
        // Mark foreground immediately; ProcessLifecycle callbacks can arrive a moment later.
        VGhostRepository.instance.setAppPresence(true)
        handleNotificationIntent(intent)
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStop(owner: LifecycleOwner) {
                notificationRefreshJob?.cancel()
                notificationRefreshJob = null
                VGhostRepository.instance.setAppPresence(false)
                VGhostRepository.instance.lockApp()
            }
            override fun onStart(owner: LifecycleOwner) {
                VGhostRepository.instance.setAppPresence(true)
                VGhostRepository.instance.recordActivity()
                // Re-bind FCM and refresh the server notification inbox whenever
                // the app returns to the foreground. This covers token rotation
                // and notifications that arrived while the app was backgrounded.
                com.vghost.app.network.PushManager.syncToken(applicationContext)
                lifecycleScope.launch {
                    VGhostRepository.instance.refreshMyWallet()
                }
                VGhostRepository.instance.refreshNotifications()
                if (notificationRefreshJob?.isActive != true) {
                    notificationRefreshJob = lifecycleScope.launch {
                        while (isActive) {
                            delay(15_000L)
                            if (isActive) VGhostRepository.instance.refreshNotifications()
                        }
                    }
                }
            }
        })
        requestNotificationPermissionIfNeeded()
        setContent {
            MyApplicationTheme {
                val locked by VGhostRepository.instance.isAppLocked.collectAsState()
                val restoring by VGhostRepository.instance.sessionRestoring.collectAsState()
                Surface(modifier = Modifier.fillMaxSize(), color = GhostBlack) {
                    if (locked) {
                        // Keep the security gate visible even while the account is
                        // restored in the background. No startup loading screen is
                        // shown for an already authenticated account.
                        PinLockScreen(onUnlockSuccess = { })
                    } else if (restoring && !VGhostRepository.instance.hasAccount()) {
                        // Only a genuinely unknown session (no persisted token) may
                        // use the startup fallback. Authenticated launches go straight
                        // to Game; GameScreen renders its own non-blocking neon loader.
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                        }
                    } else {
                        AppNavigation(initialChatNickname = pendingChatNickname, initialNotificationTarget = pendingNotificationTarget, initialNotificationTargetValue = pendingNotificationTargetValue)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(intent: Intent?) {
        if (intent == null) return
        val notificationId = intent.getLongExtra(EXTRA_NOTIFICATION_ID, 0L)
        if (notificationId > 0L) VGhostRepository.instance.markNotificationRead(notificationId)
        if (intent.getStringExtra(EXTRA_PUSH_TYPE).equals("gift", true) || intent.getStringExtra(EXTRA_PUSH_TYPE).equals("story_gift", true)) {
            val giftId = intent.getStringExtra(EXTRA_GIFT_ID).orEmpty()
            val sender = intent.getStringExtra(EXTRA_GIFT_SENDER).orEmpty()
            if (giftId.isNotBlank()) VGhostRepository.instance.onGiftReceived(giftId, sender)
        }
        if (intent.action == ACTION_OPEN_GHOST_CHAT) {
            val nickname = intent.getStringExtra(EXTRA_CHAT_NICKNAME).orEmpty()
            if (nickname.isNotBlank()) pendingChatNickname = nickname
        }
        val target = intent.getStringExtra(EXTRA_NOTIFICATION_TARGET).orEmpty()
        val targetValue = intent.getStringExtra(EXTRA_NOTIFICATION_TARGET_VALUE).orEmpty()
        if (target.equals("link", true) && targetValue.isNotBlank()) {
            try {
                val uri = android.net.Uri.parse(targetValue)
                if (uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    pendingNotificationTarget = null
                    pendingNotificationTargetValue = null
                    return
                }
            } catch (_: Throwable) { }
        }
        if (target.isNotBlank()) {
            pendingNotificationTarget = target
            pendingNotificationTargetValue = targetValue
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    companion object {
        const val ACTION_OPEN_GHOST_CHAT = "com.vghost.app.action.OPEN_GHOST_CHAT"
        const val EXTRA_CHAT_NICKNAME = "extra_chat_nickname"
        const val EXTRA_CONVERSATION_ID = "extra_conversation_id"
        const val EXTRA_NOTIFICATION_TARGET = "extra_notification_target"
        const val EXTRA_NOTIFICATION_TARGET_VALUE = "extra_notification_target_value"
        const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
        const val EXTRA_PUSH_TYPE = "extra_push_type"
        const val EXTRA_GIFT_ID = "extra_gift_id"
        const val EXTRA_GIFT_SENDER = "extra_gift_sender"
    }
}
