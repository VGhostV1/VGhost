package com.vghost.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.OnlineUser
import com.vghost.app.data.model.UserListEntry
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.trKey
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import kotlinx.coroutines.delay

@Composable
fun AllUsersScreen(
    friendsMode: Boolean,
    onNavigateBack: () -> Unit,
    onUserSelected: (UserListEntry) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var onlineUsers by remember { mutableStateOf<List<OnlineUser>>(emptyList()) }
    var allUsers by remember { mutableStateOf<List<UserListEntry>>(emptyList()) }
    var friends by remember { mutableStateOf<List<UserListEntry>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var page by remember { mutableStateOf(0) }
    val pageSize = 9

    LaunchedEffect(friendsMode) {
        while (true) {
            repository.recordActivity()
            onlineUsers = repository.getOnlineUsers()
            allUsers = repository.getUsers()
            friends = repository.getFriends()
            delay(30_000L)
        }
    }

    val displayUsers = remember(allUsers, friends, friendsMode) {
        if (friendsMode) {
            friends
        } else {
            allUsers
        }.sortedWith(compareByDescending<UserListEntry> { it.isVip }.thenBy { it.nickname.lowercase() })
    }
    val filtered = remember(displayUsers, query) {
        val q = query.trim().removePrefix("@").lowercase()
        if (q.isBlank()) displayUsers else displayUsers.filter { it.nickname.lowercase().contains(q) }
    }
    val pageCount = ((filtered.size + pageSize - 1) / pageSize).coerceAtLeast(1)
    val currentPage = page.coerceIn(0, pageCount - 1)
    val pageItems = filtered.drop(currentPage * pageSize).take(pageSize)

    BackHandler { onNavigateBack() }

    Scaffold(
        modifier = modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = {
            VGhostBottomNavBar(currentTab = NavTab.FIND, onTabSelected = onTabSelected)
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("all_users_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, trKey("back_3"), tint = GhostTextWhite)
                }
                Spacer(Modifier.width(6.dp))
                Text(
                    text = if (friendsMode) trKey("friends") else trKey("users"),
                    color = GhostTextWhite,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedTextField(
                value = query,
                onValueChange = { query = it; page = 0 },
                singleLine = true,
                placeholder = { Text(trKey("search_users_here"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = { Icon(Icons.Outlined.Search, null, tint = GhostTextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = GhostSurface,
                    unfocusedContainerColor = GhostSurface,
                    focusedBorderColor = GhostRedPrimary,
                    unfocusedBorderColor = GhostBorder,
                    focusedTextColor = GhostTextWhite,
                    unfocusedTextColor = GhostTextWhite,
                    cursorColor = GhostRedPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).testTag("all_users_search")
            )

            Spacer(Modifier.height(10.dp))

            if (pageItems.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (friendsMode) trKey("have_no_friends_yet") else trKey("no_users_found"),
                        color = GhostTextMuted,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(pageItems, key = { it.uid }) { user ->
                        AllUserGridCard(user = user, onOpenProfile = { onUserSelected(user) })
                    }
                }
            }

            if (filtered.isNotEmpty()) {
                PaginationBar(page = page, pageCount = pageCount, onPage = { page = it })
            }
        }
    }
}

@Composable
private fun AllUserGridCard(user: UserListEntry, onOpenProfile: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier.fillMaxWidth().clip(shape).background(GhostSurface)
            .border(1.dp, GhostBorder.copy(alpha = 0.65f), shape)
            .clickable(onClick = onOpenProfile).padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (user.isVip) Text("👑", fontSize = 12.sp)
            Text(
                text = user.nickname,
                color = if (user.isVip) Color(0xFFFFD45A) else GhostTextWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 3.dp).weight(1f, fill = false)
            )
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = if (user.isVip) Modifier.border(2.dp, Color(0xFFFFC83D), CircleShape).padding(2.dp) else Modifier
        ) {
            GhostAvatar(size = 72.dp, showBorder = true, avatarId = user.avatarId)
            Box(
                modifier = Modifier.size(13.dp).clip(CircleShape)
                    .background(if (user.online) Color(0xFF18D64B) else GhostTextMuted)
                    .border(2.dp, GhostSurface, CircleShape).align(Alignment.BottomEnd)
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            text = if (user.online) trKey("online") else trKey("offline_2"),
            color = if (user.online) Color(0xFF18D64B) else GhostTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun PaginationBar(page: Int, pageCount: Int, onPage: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val visible = if (pageCount <= 7) (0 until pageCount).toList() else {
            val set = linkedSetOf(0, pageCount - 1, page, page - 1, page + 1)
            set.filter { it in 0 until pageCount }.sorted()
        }
        var previous = -2
        visible.forEach { p ->
            if (previous >= 0 && p > previous + 1) {
                Text("…", color = GhostTextMuted, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp))
            }
            val selected = p == page
            Box(
                modifier = Modifier.size(34.dp).clip(CircleShape)
                    .background(if (selected) GhostRedPrimary else Color.Transparent)
                    .border(1.dp, if (selected) GhostRedPrimary else GhostBorder, CircleShape)
                    .clickable { onPage(p) },
                contentAlignment = Alignment.Center
            ) {
                Text((p + 1).toString(), color = if (selected) GhostTextWhite else GhostTextSecondary, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
            }
            previous = p
        }
    }
}
