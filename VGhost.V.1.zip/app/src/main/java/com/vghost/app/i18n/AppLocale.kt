package com.vghost.app.i18n

import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow

object AppLocale {
    private const val PREFS = "vghost_preferences"
    private const val KEY_LANGUAGE = "app_language"
    const val SYSTEM = "system"

    // Compose-observable app language. Updating this forces every screen to
    // rebuild from the translation table immediately, without relying only on
    // Activity recreation.
    val language = MutableStateFlow("en")

    val supported = listOf("en", "az", "tr", "ru")

    fun current(context: Context): String {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, null)
        if (saved != null && saved in supported) return saved

        // No explicit app language yet: follow the device/system language.
        // Only the four supported app languages are selected; everything else
        // falls back safely to English.
        val locales = context.resources.configuration.locales
        for (i in 0 until locales.size()) {
            val tag = locales[i].toLanguageTag().lowercase(Locale.ROOT)
            val language = tag.substringBefore('-')
            if (language in supported) return language
        }
        return "en"
    }

    fun set(context: Context, language: String) {
        VGhostLanguage.init(context)
        require(language in supported)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, language).apply()
        val locale = Locale(language)
        Locale.setDefault(locale)
        this.language.value = language
        if (Build.VERSION.SDK_INT >= 33) {
            context.getSystemService(android.app.LocaleManager::class.java).applicationLocales = android.os.LocaleList.forLanguageTags(language)
        }
    }

    fun wrap(context: Context): ContextWrapper {
        val language = current(context)
        val locale = Locale(language)
        VGhostLanguage.init(context)
        Locale.setDefault(locale)
        this.language.value = language
        val config = android.content.res.Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLocales(android.os.LocaleList(locale))
        return ContextWrapper(context.createConfigurationContext(config))
    }
}
