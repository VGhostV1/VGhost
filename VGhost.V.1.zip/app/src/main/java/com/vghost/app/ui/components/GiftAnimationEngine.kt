package com.vghost.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.GiftItem
import com.vghost.app.i18n.VGhostLanguage
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class Particle(
    val angle: Float,
    val distance: Float,
    val size: Float,
    val phase: Float,
    val speed: Float,
    val star: Boolean
)

/**
 * Full-screen procedural Gift Animation Engine.
 *
 * No GIF/MP4/Lottie files are required. The gift catalog remains the source of truth and each
 * gift gets a themed scene. This keeps the APK small and makes the animation system extensible:
 * a future remote/local asset renderer can be plugged in without changing sendGift().
 */
@Composable
fun GiftAnimationEngine(gift: GiftItem, onFinished: () -> Unit) {
    val duration = when {
        gift.id == "vghost_royal" -> 7200
        gift.price >= 15000 -> 6500
        gift.price >= 5000 -> 6000
        else -> 4600
    }
    var target by remember(gift.id) { mutableFloatStateOf(0f) }
    val progress by animateFloatAsState(
        targetValue = target,
        animationSpec = tween(duration, easing = LinearEasing),
        label = "gift_timeline"
    )

    val seed = remember(gift.id) { gift.id.hashCode() * 31 + gift.price }
    val random = remember(seed) { Random(seed) }
    val particles = remember(seed) {
        List(if (gift.price >= 5000) 96 else 64) {
            Particle(
                angle = random.nextFloat() * 6.2831855f,
                distance = .10f + random.nextFloat() * .95f,
                size = 2f + random.nextFloat() * 7f,
                phase = random.nextFloat(),
                speed = .45f + random.nextFloat() * 1.8f,
                star = random.nextFloat() > .42f
            )
        }
    }

    LaunchedEffect(gift.id) {
        target = 1f
        delay(duration.toLong())
        onFinished()
    }

    val theme = themeFor(gift)
    val premium = gift.price >= 1000
    val legendary = gift.price >= 5000
    val royal = gift.id == "vghost_royal"
    val enter = (progress / .14f).coerceIn(0f, 1f)
    val exit = ((1f - progress) / .14f).coerceIn(0f, 1f)
    val pulse = 1f + sin(progress * 26f) * if (legendary) .045f else .025f
    val scale = (FastOutSlowInEasing.transform(enter) * .30f + .70f) * pulse
    val alpha = enter * exit

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        theme.primary.copy(alpha = if (royal) .42f else .27f),
                        theme.secondary.copy(alpha = .12f),
                        Color.Black.copy(alpha = .95f)
                    ),
                    radius = 1050f
                )
            )
            .pointerInput(gift.id) { detectTapGestures { onFinished() } }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawAtmosphere(theme, progress, alpha, legendary, royal)
            drawParticles(theme, particles, progress, alpha, gift.id)
            drawGiftScene(gift.id, theme, progress, alpha, royal)
        }

        Column(
            Modifier
                .align(Alignment.Center)
                .graphicsLayer {
                    this.scaleX = scale
                    this.scaleY = scale
                    this.alpha = alpha
                    this.translationY = sceneOffsetY(gift.id, progress)
                    this.rotationZ = sceneRotation(gift.id, progress, premium)
                }
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = gift.icon,
                fontSize = if (royal) 124.sp else if (legendary) 112.sp else if (premium) 100.sp else 88.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = VGhostLanguage.trKey("gift_gift_sent"),
                color = Color.White,
                fontSize = if (legendary) 26.sp else 21.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(Modifier.height(5.dp))
            Text(
                text = gift.name,
                color = theme.primary,
                fontSize = if (legendary) 25.sp else 21.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "${gift.price} coins",
                color = Color.White.copy(alpha = .70f),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

private data class GiftTheme(val primary: Color, val secondary: Color)

private fun themeFor(gift: GiftItem): GiftTheme = when (gift.id) {
    "love", "rose", "cake" -> GiftTheme(Color(0xFFFF4D82), Color(0xFFFFB3CB))
    "diamond" -> GiftTheme(Color(0xFF79E8FF), Color(0xFF6C7BFF))
    "crown", "trophy", "castle", "vghost_royal" -> GiftTheme(Color(0xFFFFD45A), Color(0xFFFF8D3B))
    "money_bag" -> GiftTheme(Color(0xFF56E38A), Color(0xFFD9FF75))
    "butterfly" -> GiftTheme(Color(0xFFB779FF), Color(0xFF58E9FF))
    "fire", "volcano" -> GiftTheme(Color(0xFFFF8A32), Color(0xFFFFD447))
    "rocket", "thunder" -> GiftTheme(Color(0xFFA98CFF), Color(0xFF5ED9FF))
    "dragon", "ghost" -> GiftTheme(Color(0xFFB879FF), Color(0xFFFF65C7))
    "galaxy", "ufo" -> GiftTheme(Color(0xFF6FD9FF), Color(0xFF9E75FF))
    "meteor" -> GiftTheme(Color(0xFFFF754D), Color(0xFFFFD05A))
    else -> GiftTheme(Color(0xFFBBA7FF), Color(0xFF6EE7FF))
}

private fun sceneOffsetY(id: String, p: Float): Float = when (id) {
    "rocket", "meteor", "ufo" -> (1f - p) * 180f
    "fire", "volcano" -> -(1f - p) * 45f
    "butterfly" -> sin(p * 18f) * 14f
    "dragon" -> sin(p * 10f) * 20f
    else -> sin(p * 8f) * 4f
}

private fun sceneRotation(id: String, p: Float, premium: Boolean): Float = when (id) {
    "rocket", "meteor" -> -8f + p * 16f
    "butterfly" -> sin(p * 14f) * 7f
    "ufo" -> sin(p * 9f) * 5f
    else -> sin(p * 12f) * if (premium) 3.5f else 2f
}

private fun DrawScope.drawAtmosphere(theme: GiftTheme, p: Float, alpha: Float, legendary: Boolean, royal: Boolean) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = (180f + p * 560f) * (if (royal) 1.2f else 1f)
    drawCircle(theme.primary.copy(alpha = alpha * .13f), radius, center)
    drawCircle(theme.secondary.copy(alpha = alpha * .09f), radius * .62f, center)

    if (legendary) {
        val ring = radius * (.72f + .12f * sin(p * 12f))
        drawCircle(theme.primary.copy(alpha = alpha * .34f), ring, center, style = Stroke(3.5f))
        drawCircle(Color.White.copy(alpha = alpha * .13f), ring * .74f, center, style = Stroke(1.5f))
    }
}

private fun DrawScope.drawParticles(
    theme: GiftTheme,
    particles: List<Particle>,
    p: Float,
    alpha: Float,
    id: String
) {
    val center = Offset(size.width / 2f, size.height / 2f)
    particles.forEachIndexed { index, part ->
        val local = ((p * part.speed + part.phase) % 1f)
        val burst = when {
            p < .22f -> (p / .22f).coerceIn(0f, 1f)
            else -> 1f
        }
        val distance = part.distance * minOf(size.width, size.height) * .58f * burst
        var x = center.x + cos(part.angle) * distance
        var y = center.y + sin(part.angle) * distance
        when (id) {
            "fire", "volcano" -> y -= local * size.height * .45f
            "rocket", "meteor" -> x += (local - .5f) * size.width * .75f
            "ufo" -> y += sin(local * 12f + index) * 16f
            "butterfly" -> x += sin(local * 16f) * 42f
        }
        val fade = alpha * if (local < .10f) local / .10f else if (local > .84f) (1f - local) / .16f else 1f
        val r = part.size * (1f + sin(local * 20f + index) * .28f)
        if (part.star) {
            drawCircle(theme.primary.copy(alpha = fade.coerceIn(0f, 1f)), r, Offset(x, y))
            drawCircle(Color.White.copy(alpha = (fade * .9f).coerceIn(0f, 1f)), r * .25f, Offset(x, y))
        } else {
            drawCircle(theme.secondary.copy(alpha = fade.coerceIn(0f, 1f)), r * .72f, Offset(x, y))
        }
    }
}

private fun DrawScope.drawGiftScene(id: String, theme: GiftTheme, p: Float, alpha: Float, royal: Boolean) {
    val c = Offset(size.width / 2f, size.height / 2f)
    when (id) {
        "rocket", "meteor" -> {
            repeat(10) { i ->
                val t = (p + i * .035f).coerceIn(0f, 1f)
                val x = c.x - (t - .5f) * size.width * .72f
                val y = c.y + (1f - t) * size.height * .38f
                drawCircle(theme.secondary.copy(alpha = alpha * (1f - i / 11f)), 5f + i * 1.6f, Offset(x, y))
            }
        }
        "ufo" -> {
            drawOval(
                brush = Brush.radialGradient(listOf(theme.primary.copy(alpha = alpha * .45f), Color.Transparent)),
                topLeft = Offset(c.x - 180f, c.y + 60f),
                size = Size(360f, 90f)
            )
        }
        "galaxy" -> {
            repeat(3) { i ->
                val r = 110f + i * 55f + sin(p * 7f + i) * 8f
                drawArc(theme.primary.copy(alpha = alpha * (.24f - i * .04f)), -50f + p * 90f, 240f, false, Offset(c.x - r, c.y - r), Size(r * 2f, r * 2f), style = Stroke(5f + i))
            }
        }
        "thunder" -> {
            val w = 34f
            val points = listOf(
                Offset(c.x + w, c.y - 180f), Offset(c.x - w, c.y - 25f),
                Offset(c.x + 12f, c.y - 25f), Offset(c.x - w * 1.8f, c.y + 180f)
            )
            for (i in 0 until points.lastIndex) {
                drawLine(theme.primary.copy(alpha = alpha * .8f), points[i], points[i + 1], strokeWidth = 8f, cap = StrokeCap.Round)
                drawLine(Color.White.copy(alpha = alpha * .7f), points[i], points[i + 1], strokeWidth = 2f, cap = StrokeCap.Round)
            }
        }
        "fire", "volcano" -> {
            repeat(7) { i ->
                val x = c.x + (i - 3) * 30f + sin(p * 12f + i) * 20f
                val y = c.y + 120f - ((p * (160f + i * 13f)) % 250f)
                drawCircle(theme.primary.copy(alpha = alpha * .45f), 13f + (i % 3) * 6f, Offset(x, y))
            }
        }
        "castle", "crown", "trophy" -> {
            drawCircle(theme.primary.copy(alpha = alpha * .18f), 180f + sin(p * 8f) * 10f, c, style = Stroke(5f))
        }
        "dragon" -> {
            drawOval(theme.secondary.copy(alpha = alpha * .12f), Offset(c.x - 230f, c.y - 100f), Size(460f, 230f), style = Stroke(4f))
        }
        "ghost" -> {
            repeat(5) { i ->
                val a = alpha * (.12f - i * .015f)
                drawCircle(theme.secondary.copy(alpha = a.coerceAtLeast(0f)), 120f + i * 32f, Offset(c.x, c.y - i * 12f))
            }
        }
        "vghost_royal" -> {
            val ring = 220f + sin(p * 9f) * 18f
            drawCircle(theme.primary.copy(alpha = alpha * .28f), ring, c, style = Stroke(8f))
            drawCircle(Color.White.copy(alpha = alpha * .16f), ring * .84f, c, style = Stroke(2f))
            repeat(12) { i ->
                val a = p * 6.2831855f + i * .5236f
                val pos = Offset(c.x + cos(a) * ring, c.y + sin(a) * ring)
                drawCircle(theme.secondary.copy(alpha = alpha * .9f), 6f, pos)
            }
        }
    }
}
