package com.vghost.app.network

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.vghost.app.i18n.AppLocale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** FCM token is always re-bound to the currently authenticated account. */
object PushManager {
    private const val PREFS = "vghost_push"
    private const val KEY_TOKEN = "last_fcm_token"
    private const val KEY_ENABLED = "push_enabled"

    fun hasLocalPushSetting(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(KEY_ENABLED)

    fun isPushEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setPushEnabledLocal(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun syncToken(context: Context) {
        try {
            if (FirebaseApp.initializeApp(context) == null) return
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                syncToken(context, token)
            }
        } catch (_: Throwable) {}
    }

    fun syncToken(context: Context, token: String) {
        if (token.isBlank() || VGhostApi.token().isNullOrBlank()) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TOKEN, token).apply()
        CoroutineScope(Dispatchers.IO).launch {
            try { VGhostApi.registerFcmToken(token, AppLocale.current(context)) } catch (_: Throwable) {}
        }
    }
}
