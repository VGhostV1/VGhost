package com.vghost.app.ui.screens
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.*
import java.util.Locale
import androidx.compose.ui.platform.LocalContext
import android.app.Activity
import android.content.Intent
import android.net.Uri
import com.vghost.app.i18n.AppLocale
import com.vghost.app.network.PushManager
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenLanguage: () -> Unit = {}, onOpenPrivacy: () -> Unit = {}, onOpenPrivacyPolicy: () -> Unit = {}, onOpenTerms: () -> Unit = {}, onAccountDeleted: () -> Unit = {}) {
    val context = LocalContext.current
    var selectedLanguage by remember { mutableStateOf(AppLocale.current(context)) }
    var pushEnabled by remember { mutableStateOf(PushManager.isPushEnabled(context)) }
    var pushSaving by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var deletePassword by remember { mutableStateOf("") }
    var deleteError by remember { mutableStateOf<String?>(null) }
    var isDeletingAccount by remember { mutableStateOf(false) }
    var showChangeEmailDialog by remember { mutableStateOf(false) }
    var currentEmail by remember { mutableStateOf("") }
    var newEmail by remember { mutableStateOf("") }
    var emailPassword by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var isChangingEmail by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        try {
            val me = VGhostApi.me().optJSONObject("user")
            currentEmail = me?.optString("email", "").orEmpty()
        } catch (_: Throwable) { }
    }

    LaunchedEffect(Unit) {
        // Read the server value only on first install. After the user explicitly
        // changes the switch, the local preference is the source of truth so a
        // stale/failed GET can never silently turn Push back ON.
        if (!PushManager.hasLocalPushSetting(context)) {
            try {
                val server = VGhostApi.getPushSetting()
                val enabled = server.optBoolean("pushEnabled", true)
                pushEnabled = enabled
                PushManager.setPushEnabledLocal(context, enabled)
            } catch (_: Throwable) {
                PushManager.setPushEnabledLocal(context, pushEnabled)
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(GhostSurface.copy(alpha=.78f))
                        .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable(onClick=onBack),
                    contentAlignment=Alignment.Center
                ) {
                    Icon(Icons.Outlined.ArrowBack, trKey("back"), tint=GhostTextWhite)
                }
                Spacer(Modifier.width(12.dp))
                Text(trKey("settings"), color=GhostTextWhite, fontSize=24.sp, fontWeight=FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(12.dp))
            SettingsItem(Icons.Outlined.Lock, trKey("privacy"), trKey("message_friend_settings"), onClick = onOpenPrivacy)
            SettingsItem(
                Icons.Outlined.Notifications,
                trKey("notifications"),
                if (pushEnabled) trKey("push_notifications_enabled") else trKey("push_notifications_disabled"),
                trailing = {
                    androidx.compose.material3.Switch(
                        checked = pushEnabled,
                        enabled = !pushSaving,
                        onCheckedChange = { enabled ->
                            val previous = pushEnabled
                            pushEnabled = enabled
                            pushSaving = true
                            scope.launch {
                                try {
                                    VGhostApi.setPushSetting(enabled)
                                    // Persist only after the server confirms the change.
                                    PushManager.setPushEnabledLocal(context, enabled)
                                } catch (_: Throwable) {
                                    pushEnabled = previous
                                    PushManager.setPushEnabledLocal(context, previous)
                                } finally { pushSaving = false }
                            }
                        }
                    )
                }
            )
            SettingsItem(
                Icons.Outlined.Language,
                trKey("language"),
                languageSummary(selectedLanguage),
                onClick = onOpenLanguage
            )
            SettingsItem(
                Icons.Outlined.Description,
                trKey("privacy_policy"),
                trKey("read_privacy_policy"),
                onClick = onOpenPrivacyPolicy
            )
            SettingsItem(
                Icons.Outlined.Gavel,
                trKey("terms_conditions"),
                trKey("read_terms_conditions"),
                onClick = onOpenTerms
            )
            SettingsItem(
                Icons.Outlined.DeleteForever,
                trKey("delete_account"),
                trKey("permanently_delete_account_related_data"),
                onClick = { if (!isDeletingAccount) { deleteError = null; deletePassword = ""; showDeleteAccountDialog = true } }
            )
            SettingsItem(
                Icons.Outlined.Email,
                trKey("change_current_gmail"),
                currentEmail.ifBlank { trKey("update_gmail_address") },
                onClick = {
                    if (!isChangingEmail) {
                        emailError = null
                        newEmail = ""
                        emailPassword = ""
                        showChangeEmailDialog = true
                    }
                }
            )
        }
    }

    if (showChangeEmailDialog) {
        AlertDialog(
            onDismissRequest = { if (!isChangingEmail) { showChangeEmailDialog = false; newEmail = ""; emailPassword = ""; emailError = null } },
            icon = { Icon(Icons.Outlined.Email, contentDescription = null, tint = GhostTextWhite) },
            title = { Text(trKey("change_current_gmail"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (currentEmail.isBlank()) trKey("replace_current_gmail_address_new_one")
                        else trfKey("m_vcud_gmail_yeni_gmail_nvan_n_daxil_edin", currentEmail),
                        color = GhostTextSecondary
                    )
                    androidx.compose.material3.OutlinedTextField(
                        value = newEmail,
                        onValueChange = { newEmail = it.trim(); emailError = null },
                        label = { Text(trKey("new_gmail")) },
                        placeholder = { Text(trKey("example_gmail_com")) },
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email),
                        isError = emailError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isChangingEmail
                    )
                    androidx.compose.material3.OutlinedTextField(
                        value = emailPassword,
                        onValueChange = { emailPassword = it; emailError = null },
                        label = { Text(trKey("account_password")) },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        isError = emailError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isChangingEmail
                    )
                    emailError?.let { Text(it, color = GhostTextRed, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        scope.launch {
                            isChangingEmail = true
                            emailError = null
                            try {
                                val result = VGhostApi.changeEmail(emailPassword, newEmail)
                                currentEmail = result.optString("email", newEmail)
                                showChangeEmailDialog = false
                                newEmail = ""
                                emailPassword = ""
                            } catch (t: Throwable) {
                                emailError = t.message ?: trKey("gmail_was_not_changed")
                            } finally { isChangingEmail = false }
                        }
                    },
                    enabled = newEmail.isNotBlank() && emailPassword.isNotBlank() && !isChangingEmail
                ) { Text(if (isChangingEmail) trKey("verifying") else trKey("change_2")) }
            },
            dismissButton = {
                TextButton(onClick = { showChangeEmailDialog = false; newEmail = ""; emailPassword = ""; emailError = null }, enabled = !isChangingEmail) { Text(trKey("cancel_3")) }
            },
            containerColor = GhostSurface
        )
    }

    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { if (!isDeletingAccount) { showDeleteAccountDialog = false; deletePassword = ""; deleteError = null } },
            icon = { Icon(Icons.Outlined.DeleteForever, contentDescription = null, tint = GhostRedPrimary) },
            title = { Text(trKey("delete_account"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(trKey("action_will_permanently_delete_account_related_data_enter_account_password_continue"), color = GhostTextSecondary)
                    androidx.compose.material3.OutlinedTextField(
                        value = deletePassword,
                        onValueChange = { deletePassword = it; deleteError = null },
                        label = { Text(trKey("account_password")) },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        isError = deleteError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isDeletingAccount
                    )
                    deleteError?.let { Text(it, color = GhostTextRed, fontSize = 12.sp) }
                    TextButton(
                        onClick = {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://vghost.site/delete-account.php"))
                            )
                        },
                        enabled = !isDeletingAccount
                    ) {
                        Text(trKey("external_account_deletion"))
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        scope.launch {
                            isDeletingAccount = true
                            deleteError = null
                            val error = VGhostRepository.instance.deleteAccount(deletePassword)
                            isDeletingAccount = false
                            if (error == null) {
                                showDeleteAccountDialog = false
                                deletePassword = ""
                                onAccountDeleted()
                            } else {
                                deleteError = error
                            }
                        }
                    },
                    enabled = deletePassword.isNotBlank() && !isDeletingAccount,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                ) {
                    Text(if (isDeletingAccount) trKey("verifying") else trKey("confirm_delete"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountDialog = false; deletePassword = ""; deleteError = null }, enabled = !isDeletingAccount) { Text(trKey("cancel_3")) }
            },
            containerColor = GhostSurface
        )
    }


}

private fun languageSummary(code: String): String = when (code) {
    "az" -> trKey("lang_az")
    "tr" -> trKey("lang_tr")
    "en" -> trKey("lang_en")
    "ru" -> trKey("lang_ru")
    else -> trKey("lang_en")
}

@Composable
private fun SettingsItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit = {},
    trailing: @Composable (() -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical=5.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(GhostSurface.copy(alpha=.82f))
            .border(1.dp, GhostBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(15.dp),
        verticalAlignment=Alignment.CenterVertically
    ) {
        Icon(icon, title, tint=GhostTextWhite, modifier=Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color=GhostTextWhite, fontSize=16.sp, fontWeight=FontWeight.Bold)
            Text(subtitle, color=GhostTextMuted, fontSize=12.sp)
        }
        if (trailing != null) trailing() else Icon(Icons.Outlined.ChevronRight, null, tint=GhostTextMuted)
    }
}
