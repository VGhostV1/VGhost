package com.vghost.app.ui.screens
import com.vghost.app.ui.components.VGhostCoinAmount
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.trfKey

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.i18n.AppLocale
import com.vghost.app.R
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.data.model.GiftItem
import com.vghost.app.ui.components.GiftAnimationEngine
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.FlyingGhost
import com.vghost.app.ui.components.ProfileAvatarFrame
import com.vghost.app.ui.components.NeonVipName
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.avatarPainterId
import com.vghost.app.ui.components.vipFramePainterId
import com.vghost.app.ui.components.vipFramePreviewPainterId
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.ui.theme.GhostGoldText
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
    onTabSelected: (NavTab) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenLanguage: () -> Unit,
    onLogout: () -> Unit,
    onOpenPanic: () -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    // Observe the locale so received gift names update without refetching the profile.
    val appLanguage by AppLocale.language.collectAsState()
    val nickname by repository.currentUserNickname.collectAsState()
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var pinError by remember { mutableStateOf<String?>(null) }
    var changingPassword by remember { mutableStateOf(false) }
    var blockedUsers by remember { mutableStateOf(emptyList<com.vghost.app.data.model.UserListEntry>()) }
    var showBlockedDialog by remember { mutableStateOf(false) }
    var blockedLoading by remember { mutableStateOf(false) }
    var secretTaps by remember { mutableStateOf(0) }
    var lastSecretTap by remember { mutableStateOf(0L) }
    val stealthMode by repository.isGhostMode.collectAsState()
    val currentAvatarId by repository.currentUserAvatarId.collectAsState()
    val currentAvatarUrl by repository.currentUserAvatarUrl.collectAsState()
    val currentUserVip by repository.currentUserVip.collectAsState()
    val currentUserVipFrameId by repository.currentUserVipFrameId.collectAsState()
    var displayAvatarId by remember { mutableStateOf(currentAvatarId) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var avatarSaving by remember { mutableStateOf(false) }
    var avatarSaveError by remember { mutableStateOf<String?>(null) }
    var avatarTab by remember { mutableStateOf("male") }
    var showVipFrameDialog by remember { mutableStateOf(false) }
    var displayVipFrameId by remember { mutableStateOf(currentUserVipFrameId) }
    var vipFrameSaving by remember { mutableStateOf(false) }
    var vipFrameSaveError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var visitors by remember { mutableStateOf(emptyList<com.vghost.app.data.model.UserListEntry>()) }
    var showVisitorsDialog by remember { mutableStateOf(false) }
    var visitorsLoading by remember { mutableStateOf(false) }
    var myActivityXp by remember { mutableStateOf(0) }
    var myActivityLevel by remember { mutableStateOf(1) }
    var myGifts by remember { mutableStateOf(emptyList<com.vghost.app.data.model.GiftCollectionItem>()) }
    var myGiftLevel by remember { mutableStateOf(1) }
    var giftsLoading by remember { mutableStateOf(true) }
    var giftAnimation by remember { mutableStateOf<GiftItem?>(null) }


    LaunchedEffect(Unit) {
        repository.refreshVipStatus()
        blockedUsers = repository.getBlockedUsers()
        val activityLevel = repository.getMyActivityLevel()
        myActivityXp = activityLevel.first
        myActivityLevel = activityLevel.second
        val giftProfile = repository.getMyGiftProfile()
        myGiftLevel = giftProfile.second
        myGifts = giftProfile.third
        giftsLoading = false
    }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize().background(GhostBlack),
            containerColor = Color.Transparent,
        bottomBar = {
            VGhostBottomNavBar(currentTab = NavTab.PROFILE, onTabSelected = onTabSelected)
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(64.dp).background(Color.Black).padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(trKey("profile"), color = GhostTextWhite, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(GhostBlack.copy(alpha = .72f))
                        .border(1.5.dp, GhostBorder, CircleShape)
                        .clickable(onClick = onOpenSettings),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = trKey("settings"),
                        tint = GhostTextWhite,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Compact, fixed-height profile header: no scrolling on the
                // main profile screen. The layout is intentionally kept small
                // so all actions remain visible on common phone sizes.
                // Avatar + frame + username share one layered area. The frame/image
                // stays behind the username instead of sitting above it.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (currentUserVip) 446.dp else 360.dp)
                        .background(GhostBlack)
                        .clickable {
                            val now = System.currentTimeMillis()
                            val withinWindow = now - lastSecretTap <= 1500L
                            secretTaps = if (withinWindow) secretTaps + 1 else 1
                            lastSecretTap = now
                            if (secretTaps >= 7) {
                                repository.toggleStealthMode()
                                secretTaps = 0
                                lastSecretTap = 0L
                            }
                        },
                    contentAlignment = Alignment.TopCenter
                ) {
                    ProfileAvatarFrame(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = (-20).dp),
                        size = if (currentUserVip) 418.dp else 290.dp,
                        avatarId = displayAvatarId,
                        avatarUrl = currentAvatarUrl,
                        isVip = currentUserVip,
                        vipHero = true,
                        vipFrameId = currentUserVipFrameId
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .padding(top = if (currentUserVip) 398.dp else 286.dp, start = 8.dp, end = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(if (stealthMode) Color.White else Color(0xFF16D64A))
                            )
                            Spacer(Modifier.width(7.dp))
                            if (currentUserVip) {
                                Text("👑", fontSize = 24.sp)
                                Spacer(Modifier.width(5.dp))
                            }
                            if (currentUserVip) {
                                NeonVipName(
                                    nickname.ifBlank { trKey("ui_ghost") },
                                    modifier = Modifier.weight(1f),
                                    fontSize = 40.sp
                                )
                            } else {
                                Text(
                                    nickname.ifBlank { trKey("ui_ghost") },
                                    color = GhostTextWhite,
                                    fontSize = 40.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(GhostBlack.copy(alpha = 0.78f))
                                    .border(1.5.dp, GhostBorder, CircleShape)
                                    .clickable {
                                        displayAvatarId = currentAvatarId
                                        avatarSaveError = null
                                        showAvatarDialog = true
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Outlined.Edit, contentDescription = trKey("avatar_d_yi"), tint = GhostTextWhite, modifier = Modifier.size(22.dp))
                            }
                            if (currentUserVip) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF3A2208).copy(alpha = .95f))
                                        .border(1.5.dp, Color(0xFFFFC83D), CircleShape)
                                        .clickable {
                                            displayVipFrameId = currentUserVipFrameId
                                            vipFrameSaveError = null
                                            showVipFrameDialog = true
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(id = vipFramePainterId(currentUserVipFrameId)),
                                        contentDescription = "VIP Ramka",
                                        tint = Color.Unspecified,
                                        modifier = Modifier.size(38.dp)
                                    )
                                }
                            }
                        }
                    }
                    /* name + status are now directly beneath the frame, sharing the row with the two profile icons */
                }

                // Replaces the old Profile Admin slot with the user's visible level system.
                ProfileLevelCard(
                    level = myActivityLevel,
                    xp = myActivityXp
                )

                // Minimal profile action dock: cards/text are intentionally removed.
                // Five actions remain: visitors, blocked users, password, PIN, and logout.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 10.dp),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Five actions in a clean 3 + 2 layout.
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProfileActionLogo(
                                icon = Icons.Outlined.Visibility,
                                tint = Color(0xFF2F7CFF),
                                contentDescription = trKey("profile_visitors_2")
                            ) {
                                visitorsLoading = true
                                scope.launch {
                                    visitors = repository.getProfileVisitors()
                                    visitorsLoading = false
                                    showVisitorsDialog = true
                                }
                            }
                            ProfileActionLogo(
                                icon = Icons.Outlined.Block,
                                tint = GhostTextWhite,
                                contentDescription = trKey("blocked_users")
                            ) {
                                blockedLoading = true
                                scope.launch {
                                    blockedUsers = repository.getBlockedUsers()
                                    blockedLoading = false
                                    showBlockedDialog = true
                                }
                            }
                            ProfileActionLogo(
                                icon = Icons.Outlined.Lock,
                                tint = Color(0xFF2F7CFF),
                                contentDescription = trKey("login_password")
                            ) {
                                passwordError = null
                                showPasswordDialog = true
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(34.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProfileActionLogo(
                                    icon = Icons.Outlined.Lock,
                                    tint = Color(0xFFA855F7),
                                    contentDescription = trKey("app_pin")
                                ) {
                                    pinError = null
                                    showPinDialog = true
                                }
                                ProfileActionLogo(
                                    icon = Icons.Outlined.Shield,
                                    tint = GhostRedPrimary,
                                    contentDescription = trKey("panik")
                                ) { onOpenPanic() }
                                ProfileActionLogo(
                                    icon = Icons.Outlined.Logout,
                                    tint = GhostRedPrimary,
                                    contentDescription = trKey("logout")
                                ) { onLogout() }
                            }
                        }
                    }
                }

                // 🎁 Alınan hədiyyələr — yalnız serverdə bu istifadəçi üçün
                // gift_transactions ilə qeyd olunan real hədiyyələr göstərilir.
                Spacer(Modifier.height(14.dp))
                MyProfileReceivedGiftsSection(
                    gifts = myGifts,
                    isLoading = giftsLoading,
                    level = myGiftLevel,
                    onGiftClick = { gift ->
                        giftAnimation = GiftCatalog.find(gift.giftId)
                            ?: GiftItem(gift.giftId, gift.name, gift.icon, gift.price)
                    }
                )
                Spacer(Modifier.height(18.dp))

            }
        }

        // Keep the animation above the entire Scaffold; otherwise the Scaffold
        // surface can cover it when a gift card is tapped.
        giftAnimation?.let { gift ->
            GiftAnimationEngine(gift = gift) { giftAnimation = null }
        }
    }

    if (showBlockedDialog) {
        AlertDialog(
            onDismissRequest = { if (!blockedLoading) showBlockedDialog = false },
            title = { Text(trKey("blocked_users"), fontWeight = FontWeight.Bold) },
            text = {
                if (blockedUsers.isEmpty()) {
                    Text(trKey("have_no_blocked_users_right_now"), color = GhostTextSecondary)
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(blockedUsers, key = { it.uid }) { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(GhostSurface)
                                    .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                GhostAvatar(size = 55.dp, showBorder = true, avatarId = user.avatarId, avatarUrl = user.avatarUrl)
                                Spacer(Modifier.width(10.dp))
                                Text(user.nickname, color = GhostTextWhite, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                TextButton(
                                    enabled = !blockedLoading,
                                    onClick = {
                                        blockedLoading = true
                                        scope.launch {
                                            val result = repository.unblockUser(user.uid)
                                            if (result == null) {
                                                blockedUsers = repository.getBlockedUsers()
                                            }
                                            blockedLoading = false
                                        }
                                    }
                                ) {
                                    Text(trKey("unblock"), color = GhostRedPrimary, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBlockedDialog = false }) { Text(trKey("close")) }
            }
        )
    }

    if (showVisitorsDialog) {
        AlertDialog(
            onDismissRequest = { if (!visitorsLoading) showVisitorsDialog = false },
            title = { Text(trKey("profile_visitors"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                if (visitorsLoading) {
                    Box(Modifier.fillMaxWidth().height(90.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else if (visitors.isEmpty()) {
                    Text(trKey("no_one_has_viewed_profile_yet"), color = GhostTextSecondary)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(visitors, key = { it.uid }) { visitor ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                GhostAvatar(size = 55.dp, showBorder = true, avatarId = visitor.avatarId, avatarUrl = visitor.avatarUrl)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(visitor.nickname, color = GhostTextWhite, fontWeight = FontWeight.Bold)
                                    Text(if (visitor.online) trKey("online") else trKey("last_visit"), color = GhostTextMuted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVisitorsDialog = false }) { Text(trKey("close")) }
            }
        )
        }
    }

    if (showAvatarDialog) {
        val maleAvatars = (1..6).map { "male_${it.toString().padStart(2,'0')}" }
        val femaleAvatars = (1..6).map { "female_${it.toString().padStart(2,'0')}" }
        AlertDialog(
            onDismissRequest = { if (!avatarSaving) { avatarSaveError = null; showAvatarDialog = false } },
            title = { Text(trKey("avatar_se_imi"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("male" to trKey("ki_i"), "female" to trKey("qad_n")).forEach { (tab,label) ->
                            Box(
                                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                                    .background(if (avatarTab == tab) GhostRedPrimary.copy(alpha = .18f) else Color.Transparent)
                                    .border(1.5.dp, if (avatarTab == tab) GhostRedPrimary else GhostBorder, RoundedCornerShape(14.dp))
                                    .clickable(enabled=!avatarSaving){ avatarTab=tab }
                                    .padding(vertical=10.dp), contentAlignment=Alignment.Center
                            ){ Text(label, color=GhostTextWhite, fontWeight=FontWeight.Bold) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier=Modifier.fillMaxWidth().heightIn(max=330.dp),
                        horizontalArrangement=Arrangement.spacedBy(8.dp),
                        verticalArrangement=Arrangement.spacedBy(8.dp)
                    ) {
                        items(if (avatarTab=="male") maleAvatars else femaleAvatars, key={it}) { id ->
                            Box(
                                Modifier.size(96.dp)
                                    .clip(CircleShape)
                                    .background(GhostBlack.copy(alpha=.35f))
                                    .border(1.5.dp, if(displayAvatarId.equals(id,true)) GhostRedPrimary else GhostBorder, CircleShape)
                                    .clickable(enabled=!avatarSaving){ displayAvatarId=id; avatarSaveError=null },
                                contentAlignment=Alignment.Center
                            ) { GhostAvatar(size=114.dp, showBorder=true, avatarId=id) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (avatarSaveError != null) { Spacer(Modifier.height(4.dp)); Text(avatarSaveError ?: "", color=GhostRedPrimary, fontSize=12.sp, textAlign=TextAlign.Center) }
                    if (avatarSaving) { Spacer(Modifier.height(4.dp)); CircularProgressIndicator(color=GhostRedPrimary, modifier=Modifier.size(22.dp)) }
                }
            },
            confirmButton = {
                TextButton(enabled=!avatarSaving, onClick={
                    if (displayAvatarId.equals(currentAvatarId,true) && currentAvatarUrl.isNullOrBlank()) {
                        showAvatarDialog=false
                    } else {
                        avatarSaving=true; avatarSaveError=null
                        scope.launch { val err=repository.setAvatar(displayAvatarId); avatarSaving=false; if(err==null) showAvatarDialog=false else avatarSaveError=err }
                    }
                }) { Text(trKey("saxla"), color=GhostTextWhite) }
            },
            containerColor = GhostSurface
        )
    }

    if (showVipFrameDialog && currentUserVip) {
        val vipFrames = listOf(
            "vip_01" to "VIP 1",
            "vip_02" to "VIP 2",
            "vip_03" to "VIP 3",
            "vip_04" to "VIP 4",
            "vip_05" to "VIP 5",
            "vip_06" to "VIP 6",
            "vip_07" to "VIP 7",
            "vip_08" to "VIP 8",
            "vip_09" to "VIP 9"
        )
        AlertDialog(
            onDismissRequest = { if (!vipFrameSaving) { vipFrameSaveError = null; showVipFrameDialog = false } },
            title = { Text("VIP Ramka Seçimi", color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Yalnız VIP istifadəçilər üçün", color = GhostTextMuted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 430.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(vipFrames, key = { it.first }) { (id, label) ->
                            Column(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (displayVipFrameId.equals(id, true)) GhostRedPrimary.copy(alpha = .16f) else GhostBlack.copy(alpha = .35f))
                                    .border(1.5.dp, if (displayVipFrameId.equals(id, true)) GhostRedPrimary else GhostBorder, RoundedCornerShape(16.dp))
                                    .clickable(enabled = !vipFrameSaving) { displayVipFrameId = id; vipFrameSaveError = null }
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(Modifier.size(125.dp), contentAlignment = Alignment.Center) {
                                    Image(
                                        painter = painterResource(id = avatarPainterId(displayAvatarId)),
                                        contentDescription = null,
                                        modifier = Modifier.size(80.dp).clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                    Image(
                                        painter = painterResource(id = vipFramePreviewPainterId(id)),
                                        contentDescription = label,
                                        modifier = Modifier.matchParentSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                Text(label, color = GhostTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    vipFrameSaveError?.let { Text(it, color = GhostRedPrimary, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)) }
                    if (vipFrameSaving) { CircularProgressIndicator(color = GhostRedPrimary, modifier = Modifier.size(22.dp).padding(top = 4.dp)) }
                }
            },
            confirmButton = {
                TextButton(enabled = !vipFrameSaving, onClick = {
                    vipFrameSaving = true; vipFrameSaveError = null
                    scope.launch {
                        val err = repository.setVipFrame(displayVipFrameId)
                        vipFrameSaving = false
                        if (err == null) showVipFrameDialog = false else vipFrameSaveError = err
                    }
                }) { Text(trKey("saxla"), color = GhostTextWhite) }
            },
            containerColor = GhostSurface
        )
    }

    if (showPasswordDialog) {
        var current by remember { mutableStateOf("") }
        var next by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { if (!changingPassword) showPasswordDialog = false },
            title = { Text(trKey("change_login_password"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(current, { current = it }, label = { Text(trKey("current_password")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fieldColors())
                    OutlinedTextField(next, { next = it }, label = { Text(trKey("new_password")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fieldColors())
                    OutlinedTextField(confirm, { confirm = it }, label = { Text(trKey("repeat_new_password")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fieldColors())
                    passwordError?.let { Text(it, color = GhostRedPrimary, fontSize = 13.sp) }
                }
            },
            confirmButton = {
                Button(
                    enabled = !changingPassword,
                    onClick = {
                        changingPassword = true
                        passwordError = null
                        scope.launch {
                            val result = repository.changeLoginPassword(current, next, confirm)
                            changingPassword = false
                            if (result == null) showPasswordDialog = false else passwordError = result
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                ) { if (changingPassword) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Text(trKey("change")) }
            },
            dismissButton = { TextButton(enabled = !changingPassword, onClick = { showPasswordDialog = false }) { Text(trKey("cancel_4")) } }
        )
    }

    if (showPinDialog) {
        var next by remember { mutableStateOf("") }
        var confirm by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text(trKey("change_app_pin"), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(next, { next = it }, label = { Text(trKey("new_pin_2")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fieldColors())
                    OutlinedTextField(confirm, { confirm = it }, label = { Text(trKey("repeat_new_pin")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), colors = fieldColors())
                    pinError?.let { Text(it, color = GhostRedPrimary, fontSize = 13.sp) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    pinError = repository.changeAppPin(next, confirm)
                    if (pinError == null) showPinDialog = false
                }, colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)) { Text(trKey("change")) }
            },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text(trKey("cancel_4")) } }
        )
    }
}

@Composable
private fun ProfileGridCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier,
    dangerBorder: Boolean = false,
    goldBorder: Boolean = false,
    fullWidth: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = when {
        dangerBorder -> GhostRedPrimary.copy(alpha = .72f)
        goldBorder -> GhostGoldText.copy(alpha = .68f)
        else -> GhostBorder
    }
    Row(
        modifier = modifier
            .height(if (fullWidth) 72.dp else 78.dp)
            .clip(shape)
            .background(GhostSurface.copy(alpha = .82f))
            .border(1.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(if (fullWidth) 42.dp else 36.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = .10f))
                .border(1.dp, iconTint.copy(alpha = .38f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = title, tint = iconTint, modifier = Modifier.size(if (fullWidth) 25.dp else 22.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                title,
                color = if (dangerBorder) GhostRedPrimary else if (goldBorder) GhostGoldText else GhostTextWhite,
                fontSize = if (fullWidth) 15.sp else 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2
            )
            Text(
                subtitle,
                color = GhostTextMuted,
                fontSize = if (fullWidth) 11.sp else 9.sp,
                maxLines = 2
            )
        }
        Text(trKey("text_10"), color = GhostTextWhite, fontSize = 24.sp, fontWeight = FontWeight.Light)
    }

}


@Composable
private fun ProfileLevelCard(
    level: Int,
    xp: Int
) {
    val safeLevel = level.coerceAtLeast(1)
    val safeXp = xp.coerceAtLeast(0)
    // Activity level advances every 100 XP; show progress inside the current level.
    val nextXp = safeLevel * 100
    val currentLevelXp = (safeLevel - 1) * 100
    val progress = ((safeXp - currentLevelXp).toFloat() / 100f).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(GhostSurface.copy(alpha = 0.92f))
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color(0xFF34343D),
                        Color(0xFF7A3CFF).copy(alpha = .75f),
                        Color(0xFF34343D)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Premium level badge with crown + level number.
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF101016))
                    .border(
                        1.5.dp,
                        Brush.verticalGradient(
                            listOf(Color(0xFF5A35A8), Color(0xFF252530))
                        ),
                        RoundedCornerShape(14.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        trKey("level_2"),
                        color = GhostTextWhite,
                        fontSize = 6.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(trfKey("text_25", safeLevel),
                        color = GhostTextWhite,
                        fontSize = 18.sp,
                        lineHeight = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(trfKey("text_12", safeXp),
                        color = GhostGoldText,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(trfKey("xp", nextXp),
                        color = GhostTextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(Modifier.height(7.dp))

                // Gradient XP bar matching the supplied reference image.
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(11.dp)
                ) {
                    val radius = size.height / 2f
                    drawRoundRect(
                        color = Color(0xFF07070B),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color(0xFFFF304D),
                                Color(0xFFFF1493),
                                Color(0xFF7B2CFF),
                                Color(0xFFB45CFF)
                            )
                        ),
                        size = androidx.compose.ui.geometry.Size(
                            width = size.width * progress,
                            height = size.height
                        ),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                    drawRoundRect(
                        color = Color.White.copy(alpha = .15f),
                        style = Stroke(width = 1.2f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                }
            }

            Spacer(Modifier.width(10.dp))

            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.width(48.dp)
            ) {
                Text(
                    trKey("next"),
                    color = GhostTextSecondary,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black
                )
                Text(trfKey("text", safeLevel),
                    color = Color(0xFFA855F7),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun MyProfileReceivedGiftsSection(
    gifts: List<com.vghost.app.data.model.GiftCollectionItem>,
    isLoading: Boolean,
    level: Int,
    onGiftClick: (com.vghost.app.data.model.GiftCollectionItem) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = trKey("gift_received_gifts"),
            color = GhostGoldText,
            fontSize = 17.sp,
            fontWeight = FontWeight.Black
        )

        when {
            isLoading -> {
                Text(
                    text = trKey("loading_gifts"),
                    color = GhostTextMuted,
                    fontSize = 13.sp
                )
            }
            gifts.isEmpty() -> {
                Text(
                    text = trKey("no_gifts_received_yet"),
                    color = GhostTextMuted,
                    fontSize = 13.sp
                )
            }
            else -> {
                Text(
                    text = trfKey("gifts_bullet_level", gifts.sumOf { it.count }, level),
                    color = GhostTextMuted,
                    fontSize = 13.sp
                )

                gifts.forEach { gift ->
                    MyProfileGiftCard(gift, onClick = { onGiftClick(gift) })
                }
            }
        }
    }
}

@Composable
private fun MyProfileGiftCard(
    gift: com.vghost.app.data.model.GiftCollectionItem,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(GhostSurface.copy(alpha = .82f))
            .border(1.dp, GhostBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(gift.icon, fontSize = 38.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = GiftCatalog.find(gift.giftId)?.name ?: gift.name,
                color = GhostTextWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(3.dp))
            VGhostCoinAmount(
                text = trfKey("gc_value", gift.price),
                iconSize = 23.dp,
                color = GhostTextMuted,
                fontSize = 14.sp
            )
        }
        Text(
            text = "×${gift.count}",
            color = GhostGoldText,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun ProfileActionLogo(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    contentDescription: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(GhostBlack.copy(alpha = .72f))
            .border(1.5.dp, tint.copy(alpha = .72f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(27.dp)
        )
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = GhostRedPrimary,
    unfocusedBorderColor = GhostBorder,
    focusedLabelColor = GhostRedPrimary,
    unfocusedLabelColor = GhostTextMuted,
    cursorColor = GhostRedPrimary
)
