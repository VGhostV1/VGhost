package com.vghost.app.ui.screens

import android.content.Context
import com.vghost.app.R

data class LocalPrivacySection(val title: String, val body: String)
data class LocalPrivacyDocument(val title: String, val intro: String, val sections: List<LocalPrivacySection>)

object VGhostLocalPrivacyPolicy {
    fun get(context: Context): LocalPrivacyDocument {
        fun s(id: Int) = context.getString(id)
        val sections = (1..8).map { i ->
            LocalPrivacySection(
                s(context.resources.getIdentifier("privacy_s${i}_title", "string", context.packageName)),
                s(context.resources.getIdentifier("privacy_s${i}_body", "string", context.packageName))
            )
        }
        return LocalPrivacyDocument(
            s(R.string.privacy_title),
            s(R.string.privacy_intro),
            sections
        )
    }
}
