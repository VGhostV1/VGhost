package com.vghost.app

import android.content.Context
import java.io.File

/**
 * Single LRU-style policy for all disposable app media.
 * Nothing here is user content: every file can be downloaded/created again.
 */
object CacheManager {
    private const val MAX_CACHE_BYTES = 128L * 1024L * 1024L
    private const val TRIM_TO_BYTES = 96L * 1024L * 1024L
    private const val MAX_CACHE_AGE_MS = 3L * 24L * 60L * 60L * 1000L

    // Category limits (all are disposable cache; user content is not stored here).
    const val MAX_EXTERNAL_PREVIEW_BYTES = 30L * 1024L * 1024L
    const val TRIM_EXTERNAL_PREVIEW_BYTES = 24L * 1024L * 1024L

    @Synchronized
    fun trimCache(context: Context, keep: Set<File> = emptySet()) {
        val root = context.cacheDir
        if (!root.exists()) return
        val now = System.currentTimeMillis()
        val files = allFiles(root).filter { it.isFile }

        // First remove stale disposable media. Never remove an explicitly kept file.
        files.filter { it !in keep && now - it.lastModified() > MAX_CACHE_AGE_MS }
            .forEach { runCatching { it.delete() } }

        val remaining = allFiles(root).filter { it.isFile }
        var total = remaining.sumOf { it.length() }
        if (total <= MAX_CACHE_BYTES) {
            pruneEmptyDirs(root)
            return
        }

        // Oldest first, while preserving files currently needed by the caller.
        val candidates = remaining.filter { it !in keep }.sortedBy { it.lastModified() }
        for (file in candidates) {
            if (total <= TRIM_TO_BYTES) break
            val len = file.length()
            if (runCatching { file.delete() }.getOrDefault(false)) total -= len
        }
        pruneEmptyDirs(root)
    }


    /** Keeps a named root-cache category bounded independently of the global cache. */
    @Synchronized
    fun trimPrefix(
        context: Context,
        prefix: String,
        maxBytes: Long,
        trimToBytes: Long,
        keep: Set<File> = emptySet()
    ) {
        val root = context.cacheDir
        if (!root.exists()) return
        val files = allFiles(root)
            .filter { it.isFile && it.name.startsWith(prefix) }
            .sortedBy { it.lastModified() }
        var total = files.sumOf { it.length() }
        if (total <= maxBytes) return
        for (file in files) {
            if (file in keep) continue
            if (total <= trimToBytes) break
            val len = file.length()
            if (runCatching { file.delete() }.getOrDefault(false)) total -= len
        }
    }

    fun trimAfterWrite(context: Context, keep: File? = null) {
        if (keep == null) trimCache(context) else trimCache(context, setOf(keep))
    }

    private fun allFiles(dir: File): List<File> = buildList {
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) addAll(allFiles(child)) else if (child.isFile) add(child)
        }
    }

    private fun pruneEmptyDirs(dir: File) {
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                pruneEmptyDirs(child)
                runCatching { child.delete() }
            }
        }
    }
}
