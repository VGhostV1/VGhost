package com.vghost.app.ui.screens

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.*
import java.util.Locale
import androidx.compose.ui.platform.LocalContext
import android.app.Activity
import android.content.Intent
import android.net.Uri
import com.vghost.app.i18n.AppLocale
import com.vghost.app.network.PushManager
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenLanguage: () -> Unit = {}, onOpenPrivacy: () -> Unit = {}, onOpenPrivacyPolicy: () -> Unit = {}, onOpenTerms: () -> Unit = {}, onAccountDeleted: () -> Unit = {}) {
    val context = LocalContext.current
    var selectedLanguage by remember { mutableStateOf(AppLocale.current(context)) }
    var pushEnabled by remember { mutableStateOf(PushManager.isPushEnabled(context)) }
    var pushSaving by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var deletePassword by remember { mutableStateOf("") }
    var deleteError by remember { mutableStateOf<String?>(null) }
    var isDeletingAccount by remember { mutableStateOf(false) }
    var showChangeEmailDialog by remember { mutableStateOf(false) }
    var currentEmail by remember { mutableStateOf("") }
    var newEmail by remember { mutableStateOf("") }
    var emailPassword by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf<String?>(null) }
    var isChangingEmail by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        try {
            val me = VGhostApi.me().optJSONObject("user")
            currentEmail = me?.optString("email", "").orEmpty()
        } catch (_: Throwable) { }
    }

    LaunchedEffect(Unit) {
        // Read the server value only on first install. After the user explicitly
        // changes the switch, the local preference is the source of truth so a
        // stale/failed GET can never silently turn Push back ON.
        if (!PushManager.hasLocalPushSetting(context)) {
            try {
                val server = VGhostApi.getPushSetting()
                val enabled = server.optBoolean("pushEnabled", true)
                pushEnabled = enabled
                PushManager.setPushEnabledLocal(context, enabled)
            } catch (_: Throwable) {
                PushManager.setPushEnabledLocal(context, pushEnabled)
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(GhostSurface.copy(alpha=.78f))
                        .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable(onClick=onBack),
                    contentAlignment=Alignment.Center
                ) {
                    Icon(Icons.Outlined.ArrowBack, tr("Geri"), tint=GhostTextWhite)
                }
                Spacer(Modifier.width(12.dp))
                Text(tr("Ayarlar"), color=GhostTextWhite, fontSize=24.sp, fontWeight=FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(12.dp))
            SettingsItem(Icons.Outlined.Lock, tr("Məxfilik"), tr("Mesaj və dost sistemi seçimləri"), onClick = onOpenPrivacy)
            SettingsItem(
                Icons.Outlined.Notifications,
                tr("Bildirişlər"),
                if (pushEnabled) tr("Push bildirişləri aktivdir") else tr("Push bildirişləri söndürülüb"),
                trailing = {
                    androidx.compose.material3.Switch(
                        checked = pushEnabled,
                        enabled = !pushSaving,
                        onCheckedChange = { enabled ->
                            val previous = pushEnabled
                            pushEnabled = enabled
                            pushSaving = true
                            scope.launch {
                                try {
                                    VGhostApi.setPushSetting(enabled)
                                    // Persist only after the server confirms the change.
                                    PushManager.setPushEnabledLocal(context, enabled)
                                } catch (_: Throwable) {
                                    pushEnabled = previous
                                    PushManager.setPushEnabledLocal(context, previous)
                                } finally { pushSaving = false }
                            }
                        }
                    )
                }
            )
            SettingsItem(
                Icons.Outlined.Language,
                tr("Dil"),
                languageSummary(selectedLanguage),
                onClick = onOpenLanguage
            )
            SettingsItem(
                Icons.Outlined.Description,
                tr("Privacy Policy"),
                tr("Məxfilik siyasətini oxu"),
                onClick = onOpenPrivacyPolicy
            )
            SettingsItem(
                Icons.Outlined.Gavel,
                tr("Terms & Conditions"),
                tr("İstifadə şərtlərini oxu"),
                onClick = onOpenTerms
            )
            SettingsItem(
                Icons.Outlined.DeleteForever,
                tr("Delete Account"),
                tr("Hesabınızı və əlaqəli məlumatları həmişəlik silin"),
                onClick = { if (!isDeletingAccount) { deleteError = null; deletePassword = ""; showDeleteAccountDialog = true } }
            )
            SettingsItem(
                Icons.Outlined.Email,
                tr("Mövcud Gmaili Dəyiş"),
                currentEmail.ifBlank { tr("Gmail ünvanını yenilə") },
                onClick = {
                    if (!isChangingEmail) {
                        emailError = null
                        newEmail = ""
                        emailPassword = ""
                        showChangeEmailDialog = true
                    }
                }
            )
        }
    }

    if (showChangeEmailDialog) {
        AlertDialog(
            onDismissRequest = { if (!isChangingEmail) { showChangeEmailDialog = false; newEmail = ""; emailPassword = ""; emailError = null } },
            icon = { Icon(Icons.Outlined.Email, contentDescription = null, tint = GhostTextWhite) },
            title = { Text(tr("Mövcud Gmaili Dəyiş"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (currentEmail.isBlank()) tr("Mövcud Gmail ünvanınızı yenisi ilə əvəz edin.")
                        else trf("Mövcud Gmail: %s\nYeni Gmail ünvanını daxil edin.", currentEmail),
                        color = GhostTextSecondary
                    )
                    androidx.compose.material3.OutlinedTextField(
                        value = newEmail,
                        onValueChange = { newEmail = it.trim(); emailError = null },
                        label = { Text(tr("Yeni Gmail")) },
                        placeholder = { Text("example@gmail.com") },
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email),
                        isError = emailError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isChangingEmail
                    )
                    androidx.compose.material3.OutlinedTextField(
                        value = emailPassword,
                        onValueChange = { emailPassword = it; emailError = null },
                        label = { Text(tr("Hesab şifrəsi")) },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        isError = emailError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isChangingEmail
                    )
                    emailError?.let { Text(it, color = GhostTextRed, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        scope.launch {
                            isChangingEmail = true
                            emailError = null
                            try {
                                val result = VGhostApi.changeEmail(emailPassword, newEmail)
                                currentEmail = result.optString("email", newEmail)
                                showChangeEmailDialog = false
                                newEmail = ""
                                emailPassword = ""
                            } catch (t: Throwable) {
                                emailError = t.message ?: tr("Gmail dəyişdirilmədi.")
                            } finally { isChangingEmail = false }
                        }
                    },
                    enabled = newEmail.isNotBlank() && emailPassword.isNotBlank() && !isChangingEmail
                ) { Text(if (isChangingEmail) tr("Yoxlanılır...") else tr("DƏYİŞDİR")) }
            },
            dismissButton = {
                TextButton(onClick = { showChangeEmailDialog = false; newEmail = ""; emailPassword = ""; emailError = null }, enabled = !isChangingEmail) { Text(tr("Cancel")) }
            },
            containerColor = GhostSurface
        )
    }

    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { if (!isDeletingAccount) { showDeleteAccountDialog = false; deletePassword = ""; deleteError = null } },
            icon = { Icon(Icons.Outlined.DeleteForever, contentDescription = null, tint = GhostRedPrimary) },
            title = { Text(tr("Delete Account"), color = GhostTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(tr("Bu əməliyyat hesabınızı və ona bağlı məlumatları geri dönməz şəkildə siləcək. Davam etmək üçün hesab şifrənizi daxil edin."), color = GhostTextSecondary)
                    androidx.compose.material3.OutlinedTextField(
                        value = deletePassword,
                        onValueChange = { deletePassword = it; deleteError = null },
                        label = { Text(tr("Hesab şifrəsi")) },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        isError = deleteError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isDeletingAccount
                    )
                    deleteError?.let { Text(it, color = GhostTextRed, fontSize = 12.sp) }
                    TextButton(
                        onClick = {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://vghost.site/delete-account.php"))
                            )
                        },
                        enabled = !isDeletingAccount
                    ) {
                        Text(tr("External Account Deletion"))
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        scope.launch {
                            isDeletingAccount = true
                            deleteError = null
                            val error = VGhostRepository.instance.deleteAccount(deletePassword)
                            isDeletingAccount = false
                            if (error == null) {
                                showDeleteAccountDialog = false
                                deletePassword = ""
                                onAccountDeleted()
                            } else {
                                deleteError = error
                            }
                        }
                    },
                    enabled = deletePassword.isNotBlank() && !isDeletingAccount,
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
                ) {
                    Text(if (isDeletingAccount) tr("Yoxlanılır...") else tr("TƏSDİQLƏ VƏ SİL"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountDialog = false; deletePassword = ""; deleteError = null }, enabled = !isDeletingAccount) { Text(tr("Cancel")) }
            },
            containerColor = GhostSurface
        )
    }


}

private fun languageSummary(code: String): String = when (code) {
    "az" -> "Azərbaycan"
    "tr" -> "Türkçe"
    "en" -> "English"
    "ru" -> "Русский"
    "es" -> "Español"
    "fr" -> "Français"
    "de" -> "Deutsch"
    "it" -> "Italiano"
    "pt" -> "Português"
    "ar" -> "العربية"
    "fa" -> "فارسی"
    "hi" -> "हिन्दी"
    "ja" -> "日本語"
    "ko" -> "한국어"
    "zh" -> "中文"
    "id" -> "Bahasa Indonesia"
    "nl" -> "Nederlands"
    "pl" -> "Polski"
    "uk" -> "Українська"
    "vi" -> "Tiếng Việt"
    else -> "English"
}

@Composable
private fun SettingsItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit = {},
    trailing: @Composable (() -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical=5.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(GhostSurface.copy(alpha=.82f))
            .border(1.dp, GhostBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(15.dp),
        verticalAlignment=Alignment.CenterVertically
    ) {
        Icon(icon, title, tint=GhostTextWhite, modifier=Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color=GhostTextWhite, fontSize=16.sp, fontWeight=FontWeight.Bold)
            Text(subtitle, color=GhostTextMuted, fontSize=12.sp)
        }
        if (trailing != null) trailing() else Icon(Icons.Outlined.ChevronRight, null, tint=GhostTextMuted)
    }
}
