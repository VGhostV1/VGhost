package com.vghost.app.ui.screens

import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.vghost.app.ui.components.GhostLogo
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostBorderLight
import com.vghost.app.ui.theme.GhostRedHover
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite

import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.graphics.Brush
import com.vghost.app.ui.theme.GhostRedGlow
import com.vghost.app.i18n.tr

@Composable
fun LoginScreen(
    onLoginSuccess: (String) -> Unit,
    onNavigateToRegister: () -> Unit,
    onOpenLanguage: () -> Unit,
    onEnterGhostMode: () -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var nickname by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    var isSubmitting by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var resetInput by remember { mutableStateOf("") }
    var resetMessage by remember { mutableStateOf<String?>(null) }
    var resetSubmitting by remember { mutableStateOf(false) }
    val forcedLogoutMessage by repository.forcedLogoutMessage.collectAsState()
    LaunchedEffect(forcedLogoutMessage) {
        if (!forcedLogoutMessage.isNullOrBlank()) {
            errorMessage = forcedLogoutMessage
            repository.consumeForcedLogoutMessage()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .imePadding()
    ) {
        Box(Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 8.dp, end = 12.dp)
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(GhostBlack.copy(alpha = .72f))
                    .border(1.5.dp, GhostBorder, CircleShape)
                    .zIndex(10f)
                    .clickable(onClick = onOpenLanguage),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Language,
                    contentDescription = tr("Dil"),
                    tint = GhostTextWhite,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // Small Glowing Logo
            GhostLogo(
                size = 110.dp,
                showHaloRing = true,
                animateGlow = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // App Title
            Text(
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(color = GhostRedPrimary, fontWeight = FontWeight.Black)) {
                        append("V ")
                    }
                    withStyle(style = SpanStyle(color = GhostTextWhite, fontWeight = FontWeight.Bold)) {
                        append("GHOST")
                    }
                },
                fontSize = 24.sp,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = tr("Welcome back"),
                color = GhostTextWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = tr("Login to continue"),
                color = GhostTextSecondary,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Nickname Field
            OutlinedTextField(
                value = nickname,
                onValueChange = {
                    nickname = it
                    errorMessage = null
                },
                placeholder = {
                    Text(tr("Nickname or Email"), color = GhostTextMuted, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = tr("Nickname Icon"),
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = GhostSurface,
                    unfocusedContainerColor = GhostSurface,
                    focusedBorderColor = GhostRedPrimary,
                    unfocusedBorderColor = GhostBorder,
                    focusedTextColor = GhostTextWhite,
                    unfocusedTextColor = GhostTextWhite,
                    cursorColor = GhostRedPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_nickname_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Password Field with Eye Toggle
            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    errorMessage = null
                },
                placeholder = {
                    Text(tr("Password"), color = GhostTextMuted, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Lock,
                        contentDescription = tr("Password Icon"),
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = { isPasswordVisible = !isPasswordVisible },
                        modifier = Modifier.testTag("toggle_password_visibility")
                    ) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = if (isPasswordVisible) tr("Hide Password") else tr("Show Password"),
                            tint = GhostTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = GhostSurface,
                    unfocusedContainerColor = GhostSurface,
                    focusedBorderColor = GhostRedPrimary,
                    unfocusedBorderColor = GhostBorder,
                    focusedTextColor = GhostTextWhite,
                    unfocusedTextColor = GhostTextWhite,
                    cursorColor = GhostRedPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_password_input")
            )

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = tr("Forgot password?"),
                color = GhostRedPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .align(Alignment.End)
                    .clickable {
                        resetInput = nickname.trim()
                        resetMessage = null
                        showResetDialog = true
                    }
                    .testTag("forgot_password_button")
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage ?: "",
                    color = GhostRedPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))


            // Login Button
            Button(
                onClick = {
                    if (isSubmitting) return@Button
                    focusManager.clearFocus()
                    isSubmitting = true
                    scope.launch {
                        errorMessage = repository.loginOnline(nickname.trim(), password)
                        isSubmitting = false
                        if (errorMessage == null) onLoginSuccess(nickname.trim())
                    }
                },
                enabled = !isSubmitting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GhostRedPrimary,
                    contentColor = GhostTextWhite
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("login_button")
            ) {
                Text(
                    text = tr("LOGIN"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Don't have an account? Register
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("Don't have an account?"),
                    color = GhostTextSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = tr("Register"),
                    color = GhostRedPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToRegister() }
                        .testTag("login_register_link")
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Secondary Action: CONTINUE AS GHOST
            OutlinedButton(
                onClick = {
                    focusManager.clearFocus()
                    onEnterGhostMode()
                },
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = GhostSurface.copy(alpha = 0.6f),
                    contentColor = GhostRedPrimary
                ),
                border = BorderStroke(1.dp, GhostRedPrimary.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("continue_as_ghost_button")
            ) {
                Text(
                    text = "👣 " + tr("Qonaq rejimi"),
                    color = GhostRedPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { if (!resetSubmitting) showResetDialog = false },
                title = { Text(tr("Reset password"), color = GhostTextWhite) },
                text = {
                    Column {
                        Text(
                            text = tr("Enter the email or nickname linked to your account."),
                            color = GhostTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = resetInput,
                            onValueChange = { resetInput = it; resetMessage = null },
                            placeholder = { Text(tr("Email or Nickname"), color = GhostTextMuted) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = GhostSurface,
                                unfocusedContainerColor = GhostSurface,
                                focusedBorderColor = GhostRedPrimary,
                                unfocusedBorderColor = GhostBorder,
                                focusedTextColor = GhostTextWhite,
                                unfocusedTextColor = GhostTextWhite,
                                cursorColor = GhostRedPrimary
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("reset_password_input")
                        )
                        resetMessage?.let {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = it,
                                color = if (it.startsWith("✓")) GhostTextWhite else GhostRedPrimary,
                                fontSize = 12.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = !resetSubmitting,
                        onClick = {
                            if (resetSubmitting) return@TextButton
                            resetSubmitting = true
                            scope.launch {
                                val result = repository.sendPasswordResetEmail(resetInput)
                                resetSubmitting = false
                                resetMessage = result?.let { it } ?: "✓ ${tr("Password reset link sent. Check your email.")}"
                                if (result == null) resetInput = ""
                            }
                        }
                    ) { Text(tr("SEND LINK"), color = GhostRedPrimary) }
                },
                dismissButton = {
                    TextButton(enabled = !resetSubmitting, onClick = { showResetDialog = false }) {
                        Text(tr("Cancel"), color = GhostTextSecondary)
                    }
                },
                containerColor = GhostBlack,
                titleContentColor = GhostTextWhite,
                textContentColor = GhostTextSecondary
            )
        }
        }
    }
}
