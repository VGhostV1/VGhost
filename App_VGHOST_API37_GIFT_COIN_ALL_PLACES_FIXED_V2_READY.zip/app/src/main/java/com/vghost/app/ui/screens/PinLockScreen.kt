package com.vghost.app.ui.screens

import androidx.activity.compose.BackHandler
import com.vghost.app.ui.components.premiumBackdrop
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedBannerBg
import com.vghost.app.ui.theme.GhostRedGlow
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostSurfaceElevated
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr

@Composable
fun PinLockScreen(
    onUnlockSuccess: () -> Unit,
    onNavigateBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var enteredPin by remember { mutableStateOf("") }
    var isPinError by remember { mutableStateOf(false) }

    val handleKeyClick: (String) -> Unit = { digit ->
        if (enteredPin.length < 4) {
            val newPin = enteredPin + digit
            enteredPin = newPin
            isPinError = false
            if (newPin.length == 4) {
                // Check PIN or auto-unlock
                if (repository.unlock(newPin)) {
                    onUnlockSuccess()
                } else {
                    isPinError = true
                    // Reset after quick pause or allow re-entry
                }
            }
        }
    }

    val handleBackspace: () -> Unit = {
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
            isPinError = false
        }
    }

    BackHandler(enabled = onNavigateBack != null) { onNavigateBack?.invoke() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onNavigateBack != null) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("pin_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = tr("Back"),
                            tint = GhostTextWhite
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(48.dp))
                }

                Spacer(modifier = Modifier.weight(1f))

                Text(
                    text = tr("Enter App PIN"),
                    color = GhostTextWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(48.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Glowing Lock Icon
            Box(
                modifier = Modifier.size(110.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    GhostRedGlow.copy(alpha = 0.35f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(GhostRedBannerBg)
                        .border(1.5.dp, GhostRedPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = tr("Lock"),
                        tint = GhostRedPrimary,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = tr("Enter your PIN to continue"),
                color = GhostTextSecondary,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // PIN Indicator Dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(4) { index ->
                    val isFilled = index < enteredPin.length
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isPinError -> GhostRedPrimary
                                    isFilled -> GhostRedPrimary
                                    else -> Color.Transparent
                                }
                            )
                            .border(
                                width = 1.5.dp,
                                color = if (isPinError || isFilled) GhostRedPrimary else GhostBorder,
                                shape = CircleShape
                            )
                    )
                }
            }

            if (isPinError) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = tr("Incorrect PIN. Try again"),
                    color = GhostRedPrimary,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Numeric Keypad:
            // 1 2 3
            // 4 5 6
            // 7 8 9
            //   0 ⌫
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                KeypadRow(listOf("1", "2", "3"), handleKeyClick)
                KeypadRow(listOf("4", "5", "6"), handleKeyClick)
                KeypadRow(listOf("7", "8", "9"), handleKeyClick)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Empty left spot
                    Spacer(modifier = Modifier.size(68.dp))

                    KeypadButton(text = "0", onClick = { handleKeyClick("0") })

                    // Backspace Button
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .clickable { handleBackspace() }
                            .testTag("pin_keypad_backspace"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Backspace,
                            contentDescription = tr("Backspace"),
                            tint = GhostTextWhite,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = tr("Hesabdan Çıxış"),
                color = GhostRedPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable {
                        repository.logoutAndClearLocalPin()
                        onNavigateBack?.invoke()
                    }
                    .padding(horizontal = 18.dp, vertical = 12.dp)
                    .testTag("pin_forgot_exit_button")
            )
        }
    }
}

@Composable
private fun KeypadRow(
    keys: List<String>,
    onKeyClick: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        keys.forEach { digit ->
            KeypadButton(text = digit, onClick = { onKeyClick(digit) })
        }
    }
}

@Composable
private fun KeypadButton(
    text: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .background(GhostSurfaceElevated)
            .border(1.dp, GhostBorder, CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("pin_key_$text"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = GhostTextWhite,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
