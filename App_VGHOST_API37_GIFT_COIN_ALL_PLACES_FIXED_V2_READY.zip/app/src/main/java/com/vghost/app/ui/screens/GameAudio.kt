package com.vghost.app.ui.screens

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import com.vghost.app.R

class GameAudioController(private val context: Context, private val musicRes: Int? = null) {
    private var music: MediaPlayer? = null
    private val pool: SoundPool = SoundPool.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .setMaxStreams(6).build()
    private val sounds = mutableMapOf<String, Int>()

    init {
        val ids = mapOf(
            "click" to R.raw.sfx_click, "safe" to R.raw.sfx_mine_safe, "boom" to R.raw.sfx_mine_boom,
            "jet_start" to R.raw.sfx_jet_start, "jet_cashout" to R.raw.sfx_jet_cashout, "jet_crash" to R.raw.sfx_jet_crash,
            "goal" to R.raw.sfx_goal, "miss" to R.raw.sfx_miss, "swap" to R.raw.sfx_rock_swap,
            "match" to R.raw.sfx_match, "combo" to R.raw.sfx_combo, "win" to R.raw.sfx_win,
            "cashout" to R.raw.sfx_cashout, "lose" to R.raw.sfx_lose
        )
        ids.forEach { (key, res) -> sounds[key] = pool.load(context, res, 1) }
    }

    fun startMusic() {
        val res = musicRes ?: return
        if (music != null) return
        music = MediaPlayer.create(context, res)?.apply {
            isLooping = true
            setVolume(0.52f, 0.52f)
            start()
        }
    }

    fun play(name: String) { sounds[name]?.let { pool.play(it, 1.0f, 1.0f, 1, 0, 1f) } }

    fun release() {
        music?.runCatching { stop() }
        music?.release(); music = null
        pool.release()
    }
}

@Composable
fun rememberGameAudio(context: Context, game: String): GameAudioController {
    // Background music files were intentionally removed to reduce APK size.
    // Keep the audio controller and all SFX intact; music simply stays disabled.
    val controller = remember(game) { GameAudioController(context.applicationContext, null) }
    DisposableEffect(controller) {
        controller.startMusic()
        onDispose { controller.release() }
    }
    return controller
}
