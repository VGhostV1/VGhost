package com.vghost.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.Whatshot
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.i18n.tr


enum class NavTab { GAME, CHATS, FIND, STORY, PANIC, PROFILE }

@Composable
fun VGhostBottomNavBar(
    currentTab: NavTab,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(20.dp)
            .background(GhostBlack.copy(alpha = 0.84f))
    ) {
        HorizontalDivider(thickness = 1.dp, color = GhostBorder)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .height(72.dp)
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                icon = Icons.Outlined.SportsEsports,
                title = tr("Game"),
                neonColor = androidx.compose.ui.graphics.Color.White,
                isSelected = currentTab == NavTab.GAME,
                testTag = "nav_game",
                onClick = { onTabSelected(NavTab.GAME) }
            )

            NavItem(
                icon = Icons.Outlined.Whatshot,
                title = tr("Story"),
                neonColor = GhostRedPrimary,
                iconColor = GhostRedPrimary,
                selectedBorderColor = GhostRedPrimary,
                selectedBackground = GhostRedPrimary.copy(alpha = 0.14f),
                isSelected = currentTab == NavTab.STORY,
                testTag = "nav_story",
                onClick = { onTabSelected(NavTab.STORY) }
            )

            NavItem(
                icon = Icons.Outlined.People,
                title = tr("İstifadəçilər"),
                neonColor = androidx.compose.ui.graphics.Color.White,
                isSelected = currentTab == NavTab.FIND,
                testTag = "nav_find",
                onClick = { onTabSelected(NavTab.FIND) }
            )

            NavItem(
                icon = Icons.Outlined.ChatBubbleOutline,
                title = tr("Söhbət"),
                neonColor = androidx.compose.ui.graphics.Color.White,
                isSelected = currentTab == NavTab.CHATS,
                testTag = "nav_chats",
                onClick = { onTabSelected(NavTab.CHATS) }
            )

            NavItem(
                icon = Icons.Outlined.Person,
                title = tr("Profil"),
                neonColor = GhostRedPrimary,
                isSelected = currentTab == NavTab.PROFILE,
                testTag = "nav_profile",
                onClick = { onTabSelected(NavTab.PROFILE) }
            )

        }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    title: String,
    neonColor: androidx.compose.ui.graphics.Color,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit,
    iconColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White,
    selectedBorderColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White,
    selectedBackground: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.08f)
) {
    val shape = RoundedCornerShape(18.dp)
    val contentColor = androidx.compose.ui.graphics.Color.White
    Box(
        modifier = Modifier
            .size(width = 54.dp, height = 44.dp)
            .clip(shape)
            .then(
                if (isSelected) Modifier
                    .background(selectedBackground)
                    .border(1.dp, selectedBorderColor.copy(alpha = 0.90f), shape)
                else Modifier
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = title,
            tint = iconColor,
            modifier = Modifier
                .size(30.dp)
                .shadow(10.dp, CircleShape, ambientColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.18f), spotColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.18f))
        )
    }
}

@Composable
private fun StoryNavItem(
    title: String,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val storyColor = GhostRedPrimary
    val shape = RoundedCornerShape(18.dp)
    val background = storyColor.copy(alpha = if (isSelected) 0.18f else 0.08f)
    val border = storyColor.copy(alpha = if (isSelected) 0.98f else 0.72f)

    Box(
        modifier = Modifier
            .size(width = 54.dp, height = 44.dp)
            .clip(shape)
            .background(background)
            .border(1.dp, border, shape)
            .shadow(
                14.dp,
                shape,
                ambientColor = storyColor.copy(alpha = if (isSelected) 0.60f else 0.18f),
                spotColor = storyColor.copy(alpha = if (isSelected) 0.60f else 0.18f)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.Whatshot,
            contentDescription = title,
            tint = storyColor,
            modifier = Modifier.size(30.dp)
        )
    }
}
