package com.vghost.app.data.model

data class ChatSummary(
    val id: String,
    val nickname: String,
    val lastMessage: String,
    val time: String,
    val unreadCount: Int = 0,
    val isOnline: Boolean = true,
    val messageTypePrefix: String? = null,
    val avatarId: String = "ghost"
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isOutgoing: Boolean,
    val time: String,
    val isDelivered: Boolean = true,
    val isRead: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val senderNickname: String = "",
    val messageType: String = "text",
    val reactions: Map<String, Int> = emptyMap(),
    val myReaction: String? = null,
    val audioUrl: String? = null,
    val audioDuration: Int = 0,
    val stickerImageUrl: String? = null,
    val gifImageUrl: String? = null,
    val attachmentUrl: String? = null,
    val attachmentType: String? = null,
    val attachmentName: String? = null,
    val expiresAt: Long? = null,
    val linkPreviewUrl: String? = null,
    val linkPreviewTitle: String? = null,
    val linkPreviewDescription: String? = null,
    val linkPreviewImage: String? = null,
    val linkPreviewSite: String? = null,
    val linkPreviewType: String? = null,
    val replyToMessageId: String? = null,
    val replyToSenderNickname: String? = null,
    val replyToText: String? = null,
    val replyToMessageType: String? = null,
    val replyToAudioUrl: String? = null,
    val replyToAudioDuration: Int = 0,
    val replyToStickerImageUrl: String? = null,
    val replyToGifImageUrl: String? = null,
    val replyToAttachmentUrl: String? = null,
    val replyToAttachmentType: String? = null,
    val replyToAttachmentName: String? = null,
    val replyToLinkPreviewUrl: String? = null,
    val replyToLinkPreviewTitle: String? = null,
    val replyToLinkPreviewDescription: String? = null,
    val replyToLinkPreviewImage: String? = null,
    val replyToLinkPreviewSite: String? = null,
    val replyToLinkPreviewType: String? = null,
    /** Device-local audio path used while an outgoing voice message is uploading. */
    val localAudioPath: String? = null,
    /** Device-local attachment path used while an outgoing media upload is in flight. */
    val localAttachmentPath: String? = null,
    /** Direct video URL discovered from a link preview; used for in-app playback. */
    val linkPreviewVideo: String? = null,
    /** Direct video URL belonging to the original message referenced by a reply. */
    val replyToLinkPreviewVideo: String? = null
)

data class RecentSearch(
    val id: String,
    val nickname: String
)


data class OnlineUser(
    val uid: String,
    val nickname: String,
    val avatarId: String = "ghost"
)

data class UserListEntry(
    val uid: String,
    val nickname: String,
    val online: Boolean = false,
    val avatarId: String = "ghost"
)

data class GiftItem(
    val id: String,
    val name: String,
    val icon: String,
    val price: Int
)

data class GiftCollectionItem(
    val giftId: String,
    val name: String,
    val icon: String,
    val price: Int,
    val count: Int
)

data object GiftCatalog {
    val items = listOf(
        GiftItem("love", "Love", "❤️", 10),
        GiftItem("rose", "Rose", "🌹", 20),
        GiftItem("diamond", "Diamond", "💎", 50),
        GiftItem("crown", "Crown", "👑", 100),
        GiftItem("cake", "Cake", "🎂", 150),
        GiftItem("gift_box", "Gift Box", "🎁", 200),
        GiftItem("money_bag", "Money Bag", "💰", 300),
        GiftItem("butterfly", "Butterfly", "🦋", 400),
        GiftItem("fire", "Fire", "🔥", 500),
        GiftItem("rocket", "Rocket", "🚀", 750),
        GiftItem("dragon", "Dragon", "🐉", 1000),
        GiftItem("trophy", "Trophy", "🏆", 1500),
        GiftItem("thunder", "Thunder", "⚡", 2000),
        GiftItem("ghost", "Ghost", "👻", 3000),
        GiftItem("galaxy", "Galaxy", "🌌", 5000),
        GiftItem("ufo", "UFO", "🛸", 7500),
        GiftItem("meteor", "Meteor", "☄️", 10000),
        GiftItem("castle", "Castle", "🏰", 15000),
        GiftItem("volcano", "Volcano", "🌋", 25000),
        GiftItem("vghost_royal", "VGhost Royal", "👻💎", 50000)
    )
    fun find(id: String): GiftItem? = items.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: id.toIntOrNull()?.let { items.getOrNull(it - 1) }
}

data class PublicUserProfile(
    val uid: String,
    val nickname: String,
    val balance: Int,
    val online: Boolean,
    val ghostMode: Boolean,
    val friendStatus: String = "none",
    val blockedByMe: Boolean = false,
    val blockedMe: Boolean = false,
    val activityXp: Int = 0,
    val activityLevel: Int = 1,
    val giftXp: Int = 0,
    val giftLevel: Int = 1,
    val nextGiftLevelXp: Int = 100,
    val gifts: List<GiftCollectionItem> = emptyList(),
    val avatarId: String = "ghost",
    val avatarUrl: String? = null
)
