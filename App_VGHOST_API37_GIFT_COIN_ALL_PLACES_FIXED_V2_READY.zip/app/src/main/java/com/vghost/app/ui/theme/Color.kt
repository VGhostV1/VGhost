package com.vghost.app.ui.theme

import androidx.compose.ui.graphics.Color

// Premium cyber / privacy palette. Existing semantic names are preserved
// so the visual upgrade does not change app behavior.
val GhostBlack = Color(0xFF07070A)
val GhostDarkBackground = Color(0xFF0A0A10)
val GhostSurface = Color(0xFF111119)
val GhostSurfaceElevated = Color(0xFF171720)
val GhostSurfaceHighlight = Color(0xFF22222D)
val GhostBorder = Color(0xFF262631)
val GhostBorderLight = Color(0xFF363645)

// Neon red accent palette
val GhostRedPrimary = Color(0xFFFF1F2D)
val GhostRedHover = Color(0xFFD90A17)
val GhostRedDark = Color(0xFF7E0710)
val GhostRedGlow = Color(0xFFFF2B38)
val GhostRedBannerBg = Color(0xFF1B0B10)
val GhostRedBannerBorder = Color(0xFF5A111A)

// Extra visual-depth colors used by the premium polish
val GhostSurfaceGlass = Color(0xFF15151E)
val GhostSurfaceGlassStrong = Color(0xFF1A1A25)
val GhostNeonSoft = Color(0xFFFF6870)
val GhostNeonDim = Color(0xFF8A1820)
val GhostShadowRed = Color(0x990B0002)
val GhostWhiteSoft = Color(0xFFF7F7FA)

// Typography & content colors
val GhostTextWhite = Color(0xFFF9F9FB)
val GhostTextSecondary = Color(0xFFB0B0BE)
val GhostTextMuted = Color(0xFF777784)
val GhostTextRed = Color(0xFFFF5A62)

// Status & encrypted badges
val GhostStatusOnline = Color(0xFF22C55E)
val GhostStatusOffline = Color(0xFFFFFFFF)
val GhostGoldBg = Color(0xFF1A170F)
val GhostGoldBorder = Color(0xFF383018)
val GhostGoldText = Color(0xFFFFD166)
