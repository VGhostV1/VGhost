package com.vghost.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = GhostRedPrimary,
    onPrimary = GhostTextWhite,
    primaryContainer = GhostRedDark,
    onPrimaryContainer = GhostTextWhite,
    secondary = GhostNeonSoft,
    onSecondary = GhostBlack,
    background = GhostBlack,
    onBackground = GhostTextWhite,
    surface = GhostSurface,
    onSurface = GhostTextWhite,
    surfaceVariant = GhostSurfaceElevated,
    onSurfaceVariant = GhostTextSecondary,
    outline = GhostBorder,
    outlineVariant = GhostBorderLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
