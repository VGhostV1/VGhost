package com.vghost.app.ui.components

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Full-screen overlay layer is intentionally NOT a notification. */
@Composable
fun LevelUpOverlay(level:Int, coins:Int, eventToken:Long, onDismiss:()->Unit){
    LaunchedEffect(eventToken){
        delay(10000)
        onDismiss()
    }
    Box(
        Modifier.fillMaxSize().padding(top=12.dp),
        contentAlignment=Alignment.TopCenter
    ){
        AnimatedVisibility(
            visible=true,
            enter=slideInVertically(initialOffsetY={ -it }) + fadeIn(),
            exit=slideOutVertically(targetOffsetY={ -it }) + fadeOut()
        ){
            Column(
                modifier=Modifier
                    .fillMaxWidth()
                    .padding(horizontal=14.dp)
                    .shadow(20.dp,RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF18090D),Color(0xFF09090D))),
                        RoundedCornerShape(24.dp)
                    )
                    .border(1.5.dp,Color(0xFFFF2638),RoundedCornerShape(24.dp))
                    .padding(horizontal=20.dp,vertical=16.dp),
                horizontalAlignment=Alignment.CenterHorizontally
            ){
                Text(tr("LEVEL UP!"),color=Color(0xFFFFD43B),fontSize=24.sp,fontWeight=FontWeight.Black)
                Spacer(Modifier.height(3.dp))
                Text(trf("LEVEL %d", level),color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text(trf("+%d COIN", coins.coerceAtLeast(0)),color=Color(0xFFFFD43B),fontSize=20.sp,fontWeight=FontWeight.Black)
                Spacer(Modifier.height(3.dp))
                Text(tr("Yeni səviyyə mükafatı"),color=Color.LightGray,fontSize=12.sp)
            }
        }
    }
}
