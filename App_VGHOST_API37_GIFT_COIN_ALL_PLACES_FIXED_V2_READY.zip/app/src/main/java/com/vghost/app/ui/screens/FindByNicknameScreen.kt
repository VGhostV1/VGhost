package com.vghost.app.ui.screens

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.OnlineUser
import com.vghost.app.data.model.UserListEntry
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr

@Composable
fun FindByNicknameScreen(
    onNavigateBack: () -> Unit,
    onUserSelected: (UserListEntry) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var searchQuery by remember { mutableStateOf("") }
    var searchError by remember { mutableStateOf<String?>(null) }
    var searching by remember { mutableStateOf(false) }
    var searchResult by remember { mutableStateOf<UserListEntry?>(null) }
    var onlineUsers by remember { mutableStateOf<List<OnlineUser>>(emptyList()) }
    var friends by remember { mutableStateOf<List<UserListEntry>>(emptyList()) }
    val focusManager = LocalFocusManager.current

    LaunchedEffect(Unit) {
        while (true) {
            repository.recordActivity()
            onlineUsers = repository.getOnlineUsers()
            friends = repository.getFriends()
            delay(30_000L)
        }
    }
    val scope = rememberCoroutineScope()
    BackHandler { onNavigateBack() }

    val executeSearch = {
        if (searchQuery.isNotBlank() && !searching) {
            val nick = searchQuery.trim().removePrefix("@").trim()
            searching = true
            searchError = null
            searchResult = null
            scope.launch {
                val result = repository.findUserByNickname(nick)
                searching = false
                if (result == null) {
                    searchError = tr("No registered user found with this nickname.")
                } else {
                    // Search only finds the user. Do NOT open the profile here.
                    // The user must tap the result card to open the profile.
                    searchResult = result
                }
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = {
            VGhostBottomNavBar(
                currentTab = NavTab.FIND,
                onTabSelected = onTabSelected
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("find_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = tr("Back"),
                        tint = GhostTextWhite
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = tr("Find by Nickname"),
                    color = GhostTextWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    // Compact search layout: keep the header, then place the search
                    // and result sections directly underneath without the large hero logo.
                    Spacer(modifier = Modifier.height(8.dp))

                    // Search Field with Red Button inside / adjacent
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(tr("Nickname"), color = GhostTextMuted, fontSize = 14.sp)
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.Search,
                                    contentDescription = null,
                                    tint = GhostTextSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            trailingIcon = {
                                Box(
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(GhostRedPrimary)
                                        .clickable {
                                            focusManager.clearFocus()
                                            executeSearch()
                                        }
                                        .testTag("find_search_submit_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Search,
                                        contentDescription = tr("Search Submit"),
                                        tint = GhostTextWhite,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                focusManager.clearFocus()
                                executeSearch()
                            }),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = GhostSurface,
                                unfocusedContainerColor = GhostSurface,
                                focusedBorderColor = GhostRedPrimary,
                                unfocusedBorderColor = GhostBorder,
                                focusedTextColor = GhostTextWhite,
                                unfocusedTextColor = GhostTextWhite,
                                cursorColor = GhostRedPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("find_nickname_input")
                        )
                    }

                    searchError?.let { error ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = error,
                            color = GhostRedPrimary,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (searching) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = tr("Search") + "...",
                            color = GhostTextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }

                    searchResult?.let { result ->
                        Spacer(modifier = Modifier.height(14.dp))
                        SearchResultCard(
                            nickname = result.nickname,
                            avatarId = result.avatarId,
                            onOpenProfile = { onUserSelected(result) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Online Users: card list directly under the nickname search.
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(androidx.compose.ui.graphics.Color(0xFF18D64B))
                        )
                        Spacer(modifier = Modifier.width(9.dp))
                        Text(
                            text = tr("ONLINE USERS"),
                            color = GhostTextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = onlineUsers.size.toString(),
                            color = GhostRedPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (onlineUsers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(GhostSurface)
                                .border(1.dp, GhostBorder.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tr("No users are online right now."),
                                color = GhostTextMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        onlineUsers.forEach { user ->
                            OnlineUserCard(
                                user = user,
                                onOpenProfile = { onUserSelected(UserListEntry(user.uid, user.nickname, true, user.avatarId)) }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tr("DOSTLAR"),
                            color = GhostTextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = friends.size.toString(),
                            color = GhostRedPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (friends.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(GhostSurface)
                                .border(1.dp, GhostBorder.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tr("Hələ dostun yoxdur."),
                                color = GhostTextMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        friends.forEach { friend ->
                            FriendUserCard(
                                user = friend,
                                onOpenProfile = { onUserSelected(friend) }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(
    nickname: String,
    avatarId: String,
    onOpenProfile: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(GhostSurface)
            .border(1.dp, GhostRedPrimary.copy(alpha = 0.72f), shape)
            .clickable(onClick = onOpenProfile)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GhostAvatar(size = 46.dp, showBorder = true, avatarId = avatarId)
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = nickname,
                color = GhostTextWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "@${nickname}",
                color = GhostTextSecondary,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = tr("Tap to open profile"),
                color = GhostRedPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = tr("Open profile"),
            tint = GhostRedPrimary,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
private fun OnlineUserCard(
    user: OnlineUser,
    onOpenProfile: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(GhostSurface)
            .border(1.dp, GhostBorder.copy(alpha = 0.70f), shape)
            .clickable(onClick = onOpenProfile)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            GhostAvatar(size = 44.dp, showBorder = true, avatarId = user.avatarId)
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(androidx.compose.ui.graphics.Color(0xFF18D64B))
                    .border(2.dp, GhostSurface, androidx.compose.foundation.shape.CircleShape)
                    .align(Alignment.BottomEnd)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = user.nickname,
                color = GhostTextWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "@${user.nickname}",
                color = GhostTextSecondary,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = tr("Online"),
                color = androidx.compose.ui.graphics.Color(0xFF18D64B),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }

        IconButton(
            onClick = onOpenProfile,
            modifier = Modifier
                .size(40.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .border(1.2.dp, GhostRedPrimary.copy(alpha = 0.82f), androidx.compose.foundation.shape.CircleShape)
                .testTag("online_user_message_${user.nickname}")
        ) {
            Icon(
                imageVector = Icons.Outlined.ChatBubbleOutline,
                contentDescription = tr("Message"),
                tint = GhostTextWhite,
                modifier = Modifier.size(19.dp)
            )
        }
    }
}

@Composable
private fun FriendUserCard(
    user: UserListEntry,
    onOpenProfile: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(GhostSurface)
            .border(1.dp, GhostRedPrimary.copy(alpha = 0.38f), shape)
            .clickable(onClick = onOpenProfile)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            GhostAvatar(size = 44.dp, showBorder = true, avatarId = user.avatarId)
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(if (user.online) androidx.compose.ui.graphics.Color(0xFF18D64B) else GhostTextMuted)
                    .border(2.dp, GhostSurface, androidx.compose.foundation.shape.CircleShape)
                    .align(Alignment.BottomEnd)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(user.nickname, color = GhostTextWhite, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(if (user.online) tr("Online") else tr("Offline"), color = if (user.online) androidx.compose.ui.graphics.Color(0xFF18D64B) else GhostTextMuted, fontSize = 12.sp)
        }
        IconButton(
            onClick = onOpenProfile,
            modifier = Modifier
                .size(40.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .border(1.2.dp, GhostRedPrimary.copy(alpha = 0.82f), androidx.compose.foundation.shape.CircleShape)
        ) {
            Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = tr("Message"), tint = GhostTextWhite, modifier = Modifier.size(19.dp))
        }
    }
}
