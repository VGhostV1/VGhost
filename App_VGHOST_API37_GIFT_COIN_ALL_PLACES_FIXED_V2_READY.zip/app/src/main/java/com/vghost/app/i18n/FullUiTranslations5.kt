package com.vghost.app.i18n

internal object FullUiTranslations5 {
    val map: Map<String, Map<String, String>> = mapOf(
        "Only virtual Ghost Coin • no real-money value" to mapOf("en" to "Only virtual Ghost Coin • no real-money value", "az" to "Yalnız virtual Ghost Coin • real pul dəyəri yoxdur", "tr" to "Yalnızca sanal Ghost Coin • gerçek para değeri yok", "ru" to "Только виртуальные Ghost Coin • без реальной денежной стоимости", "es" to "Solo Ghost Coin virtuales • sin valor monetario real", "fr" to "Ghost Coin virtuels uniquement • sans valeur monétaire réelle", "de" to "Nur virtuelle Ghost Coin • kein echter Geldwert", "it" to "Solo Ghost Coin virtuali • nessun valore monetario reale", "pt" to "Apenas Ghost Coin virtuais • sem valor monetário real", "ar" to "Ghost Coin افتراضية فقط • بلا قيمة مالية حقيقية", "fa" to "فقط Ghost Coin مجازی • بدون ارزش پول واقعی", "hi" to "केवल वर्चुअल Ghost Coin • कोई वास्तविक धन मूल्य नहीं")
    )
}
