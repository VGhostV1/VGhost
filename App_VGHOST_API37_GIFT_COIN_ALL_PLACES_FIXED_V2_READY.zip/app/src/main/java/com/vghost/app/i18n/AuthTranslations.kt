package com.vghost.app.i18n

/** Authentication / account UI translations shared by Login and Register screens. */
internal object AuthTranslations {
    val map: Map<String, Map<String, String>> = mapOf(
        "Email" to mapOf(
            "en" to "Email", "az" to "Email", "tr" to "E-posta", "ru" to "Электронная почта",
            "es" to "Correo electrónico", "fr" to "E-mail", "de" to "E-Mail", "it" to "E-mail",
            "pt" to "E-mail", "ar" to "البريد الإلكتروني", "fa" to "ایمیل", "hi" to "ईमेल"
        ),
        "Forgot password?" to mapOf(
            "en" to "Forgot password?", "az" to "Parolu unutmusan?", "tr" to "Şifreni mi unuttun?", "ru" to "Забыли пароль?",
            "es" to "¿Olvidaste tu contraseña?", "fr" to "Mot de passe oublié ?", "de" to "Passwort vergessen?", "it" to "Password dimenticata?",
            "pt" to "Esqueceu a senha?", "ar" to "هل نسيت كلمة المرور؟", "fa" to "رمز عبور را فراموش کرده‌اید؟", "hi" to "पासवर्ड भूल गए?"
        ),
        "Reset password" to mapOf(
            "en" to "Reset password", "az" to "Parolu sıfırla", "tr" to "Şifreyi sıfırla", "ru" to "Сбросить пароль",
            "es" to "Restablecer contraseña", "fr" to "Réinitialiser le mot de passe", "de" to "Passwort zurücksetzen", "it" to "Reimposta password",
            "pt" to "Redefinir senha", "ar" to "إعادة تعيين كلمة المرور", "fa" to "بازنشانی رمز عبور", "hi" to "पासवर्ड रीसेट करें"
        ),
        "Enter the email or nickname linked to your account." to mapOf(
            "en" to "Enter the email or nickname linked to your account.", "az" to "Hesabına bağlı email və ya ləqəbi daxil et.", "tr" to "Hesabınıza bağlı e-posta veya takma adı girin.", "ru" to "Введите электронную почту или никнейм, связанный с аккаунтом.",
            "es" to "Introduce el correo o apodo vinculado a tu cuenta.", "fr" to "Saisissez l’e-mail ou le pseudo lié à votre compte.", "de" to "Gib die mit deinem Konto verknüpfte E-Mail oder deinen Spitznamen ein.", "it" to "Inserisci l’e-mail o il soprannome collegato al tuo account.",
            "pt" to "Digite o e-mail ou apelido vinculado à sua conta.", "ar" to "أدخل البريد الإلكتروني أو اللقب المرتبط بحسابك.", "fa" to "ایمیل یا نام مستعار مرتبط با حساب خود را وارد کنید.", "hi" to "अपने खाते से जुड़ा ईमेल या उपनाम दर्ज करें।"
        ),
        "Email or Nickname" to mapOf(
            "en" to "Email or Nickname", "az" to "Email və ya Ləqəb", "tr" to "E-posta veya Takma Ad", "ru" to "Электронная почта или никнейм",
            "es" to "Correo o apodo", "fr" to "E-mail ou pseudo", "de" to "E-Mail oder Spitzname", "it" to "E-mail o soprannome",
            "pt" to "E-mail ou apelido", "ar" to "البريد الإلكتروني أو اللقب", "fa" to "ایمیل یا نام مستعار", "hi" to "ईमेल या उपनाम"
        ),
        "SEND LINK" to mapOf(
            "en" to "SEND LINK", "az" to "LINK GÖNDƏR", "tr" to "BAĞLANTIYI GÖNDER", "ru" to "ОТПРАВИТЬ ССЫЛКУ",
            "es" to "ENVIAR ENLACE", "fr" to "ENVOYER LE LIEN", "de" to "LINK SENDEN", "it" to "INVIA LINK",
            "pt" to "ENVIAR LINK", "ar" to "إرسال الرابط", "fa" to "ارسال لینک", "hi" to "लिंक भेजें"
        ),
        "Password reset link sent. Check your email." to mapOf(
            "en" to "Password reset link sent. Check your email.", "az" to "Parol sıfırlama linki email-ə göndərildi. Emailini yoxla.", "tr" to "Şifre sıfırlama bağlantısı gönderildi. E-postanı kontrol et.", "ru" to "Ссылка для сброса пароля отправлена. Проверьте почту.",
            "es" to "Se envió el enlace para restablecer la contraseña. Revisa tu correo.", "fr" to "Le lien de réinitialisation a été envoyé. Consultez votre e-mail.", "de" to "Der Link zum Zurücksetzen des Passworts wurde gesendet. Prüfe deine E-Mail.", "it" to "Il link per reimpostare la password è stato inviato. Controlla l’e-mail.",
            "pt" to "O link para redefinir a senha foi enviado. Verifique seu e-mail.", "ar" to "تم إرسال رابط إعادة تعيين كلمة المرور. تحقق من بريدك الإلكتروني.", "fa" to "لینک بازنشانی رمز عبور ارسال شد. ایمیل خود را بررسی کنید.", "hi" to "पासवर्ड रीसेट लिंक भेज दिया गया है। अपना ईमेल देखें।"
        ),
        "Enter your email or nickname." to mapOf(
            "en" to "Enter your email or nickname.", "az" to "Email və ya ləqəbini daxil et.", "tr" to "E-posta veya takma adınızı girin.", "ru" to "Введите электронную почту или никнейм.",
            "es" to "Introduce tu correo o apodo.", "fr" to "Saisissez votre e-mail ou pseudo.", "de" to "Gib deine E-Mail oder deinen Spitznamen ein.", "it" to "Inserisci la tua e-mail o il soprannome.",
            "pt" to "Digite seu e-mail ou apelido.", "ar" to "أدخل بريدك الإلكتروني أو لقبك.", "fa" to "ایمیل یا نام مستعار خود را وارد کنید.", "hi" to "अपना ईमेल या उपनाम दर्ज करें।"
        ),
        "Enter a valid email address." to mapOf(
            "en" to "Enter a valid email address.", "az" to "Düzgün email ünvanı daxil et.", "tr" to "Geçerli bir e-posta adresi girin.", "ru" to "Введите действительный адрес электронной почты.",
            "es" to "Introduce una dirección de correo válida.", "fr" to "Saisissez une adresse e-mail valide.", "de" to "Gib eine gültige E-Mail-Adresse ein.", "it" to "Inserisci un indirizzo e-mail valido.",
            "pt" to "Digite um endereço de e-mail válido.", "ar" to "أدخل عنوان بريد إلكتروني صالحًا.", "fa" to "یک آدرس ایمیل معتبر وارد کنید.", "hi" to "मान्य ईमेल पता दर्ज करें।"
        ),
        "Enter a valid email or nickname." to mapOf(
            "en" to "Enter a valid email or nickname.", "az" to "Düzgün email və ya ləqəb daxil et.", "tr" to "Geçerli bir e-posta veya takma ad girin.", "ru" to "Введите действительный адрес электронной почты или никнейм.",
            "es" to "Introduce un correo o apodo válido.", "fr" to "Saisissez un e-mail ou pseudo valide.", "de" to "Gib eine gültige E-Mail oder einen gültigen Spitznamen ein.", "it" to "Inserisci un’e-mail o un soprannome valido.",
            "pt" to "Digite um e-mail ou apelido válido.", "ar" to "أدخل بريدًا إلكترونيًا أو لقبًا صالحًا.", "fa" to "یک ایمیل یا نام مستعار معتبر وارد کنید.", "hi" to "मान्य ईमेल या उपनाम दर्ज करें।"
        ),
        "No recovery email is configured for this account." to mapOf(
            "en" to "No recovery email is configured for this account.", "az" to "Bu hesab üçün bərpa email-i qurulmayıb.", "tr" to "Bu hesap için kurtarma e-postası ayarlanmamış.", "ru" to "Для этого аккаунта не настроен резервный адрес электронной почты.",
            "es" to "No hay un correo de recuperación configurado para esta cuenta.", "fr" to "Aucune adresse e-mail de récupération n’est configurée pour ce compte.", "de" to "Für dieses Konto ist keine Wiederherstellungs-E-Mail eingerichtet.", "it" to "Per questo account non è configurata un’e-mail di recupero.",
            "pt" to "Nenhum e-mail de recuperação está configurado para esta conta.", "ar" to "لم يتم إعداد بريد إلكتروني للاسترداد لهذا الحساب.", "fa" to "برای این حساب ایمیل بازیابی تنظیم نشده است.", "hi" to "इस खाते के लिए कोई रिकवरी ईमेल सेट नहीं किया गया है।"
        )
    )
}
