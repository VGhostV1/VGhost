package com.vghost.app.ui.screens

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.PersonRemove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.R
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.data.model.GiftItem
import com.vghost.app.data.model.PublicUserProfile
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.FlyingGhost
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostGoldText
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.ui.theme.GhostStatusOnline
import com.vghost.app.ui.theme.GhostStatusOffline
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OtherProfileScreen(
    nickname: String,
    initialUid: String? = null,
    initialOnline: Boolean = false,
    onNavigateBack: () -> Unit,
    onOpenChat: (String) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    // The search result already contains the real UID. Show a safe local profile
    // immediately so the screen never becomes an empty "user not found" page
    // just because the optional public-profile Function is unavailable/not deployed.
    var profile by remember(nickname, initialUid, initialOnline) {
        mutableStateOf(
            initialUid?.takeIf { it.isNotBlank() }?.let {
                PublicUserProfile(
                    uid = it,
                    nickname = nickname,
                    balance = 0,
                    online = initialOnline,
                    ghostMode = false
                )
            }
        )
    }
    var loading by remember(nickname, initialUid, initialOnline) { mutableStateOf(initialUid.isNullOrBlank()) }
    var error by remember(nickname) { mutableStateOf<String?>(null) }
    var showGiftDialog by remember { mutableStateOf(false) }
    var showBlockDialog by remember { mutableStateOf(false) }
    var showRemoveFriendDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }
    var actionLoading by remember { mutableStateOf(false) }
    var friendAddLoading by remember { mutableStateOf(false) }
    var friendRequestDenied by remember { mutableStateOf(false) }
    var selectedGift by remember { mutableStateOf<GiftItem?>(null) }
    var coinAmountText by remember { mutableStateOf("") }
    var sendCoinsMode by remember { mutableStateOf(false) }
    var gifting by remember { mutableStateOf(false) }
    var giftAnimation by remember { mutableStateOf<GiftItem?>(null) }
    val scope = rememberCoroutineScope()
    val myBalance by repository.ghostCoins.collectAsState()

    suspend fun reloadProfile() {
        loading = true
        error = null
        val remote = repository.getPublicUserProfile(nickname)
        if (remote != null) {
            profile = remote
        } else if (profile == null) {
            error = tr("İstifadəçi tapılmadı.")
        }
        loading = false
    }

    LaunchedEffect(nickname) {
        reloadProfile()
    }

    // Keep a sent friend request in sync with the recipient's decision.
    // pending_sent = yellow (waiting), friends = green (accepted), none = blue (declined/cancelled).
    LaunchedEffect(profile?.uid, profile?.friendStatus) {
        while (profile?.friendStatus == "pending_sent") {
            kotlinx.coroutines.delay(60_000)
            reloadProfile()
        }
    }

    val isStealth by repository.isGhostMode.collectAsState()
    LaunchedEffect(profile?.uid, isStealth) {
        val uid = profile?.uid ?: return@LaunchedEffect
        if (!isStealth) repository.recordProfileView(uid)
    }
    BackHandler { onNavigateBack() }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize().premiumBackdrop(),
            containerColor = Color.Transparent,
            bottomBar = { VGhostBottomNavBar(currentTab = NavTab.FIND, onTabSelected = onTabSelected) }
        ) { innerPadding ->
            Column(Modifier.fillMaxSize().padding(innerPadding).windowInsetsPadding(WindowInsets.statusBars)) {
                Row(
                    modifier = Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("Geri"), tint = GhostTextWhite)
                    }
                    Text(tr("Profil"), color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
                HorizontalDivider(color = GhostBorder)

                if (loading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = GhostRedPrimary)
                    }
                } else if (profile == null) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(error ?: tr("İstifadəçi tapılmadı."), color = GhostTextMuted, fontSize = 15.sp)
                    }
                } else {
                    val p = profile!!
                    val contactBlocked = p.blockedByMe || p.blockedMe
                    LaunchedEffect(p.friendStatus) {
                        if (p.friendStatus != "none") friendRequestDenied = false
                    }
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp).verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Match My Profile: large fixed Ghost avatar, nickname and status.
                        Box(
                            modifier = Modifier
                                .size(168.dp),
                            contentAlignment = Alignment.Center
                        ) { FlyingGhost(size = 152.dp, avatarId = p.avatarId) }

                        Text(
                            p.nickname,
                            color = GhostTextWhite,
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(
                                    if (p.ghostMode) GhostStatusOffline
                                    else if (p.online) GhostStatusOnline
                                    else GhostStatusOffline
                                )
                        )

                        // Other-user actions use the same clean icon-only dock as My Profile.
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 8.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                when (p.friendStatus) {
                                    "friends" -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonRemove,
                                        tint = Color(0xFF22C55E),
                                        contentDescription = tr("Dostluqdan çıxar"),
                                        enabled = !actionLoading
                                    ) {
                                        showRemoveFriendDialog = true
                                    }
                                    "pending_sent" -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonAdd,
                                        tint = Color(0xFFFFC107),
                                        contentDescription = tr("Sorğu gözləyir"),
                                        enabled = !actionLoading
                                    ) {
                                        showRemoveFriendDialog = true
                                    }
                                    "pending_received" -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonAdd,
                                        tint = Color(0xFF2F7CFF),
                                        contentDescription = tr("Dostluğa qəbul et"),
                                        enabled = !actionLoading
                                    ) {
                                        actionLoading = true
                                        scope.launch {
                                            actionMessage = repository.acceptFriend(p.uid)
                                            actionLoading = false
                                            if (actionMessage == null) reloadProfile()
                                        }
                                    }
                                    else -> OtherProfileActionLogo(
                                        icon = Icons.Outlined.PersonAdd,
                                        tint = when {
                                            friendRequestDenied -> Color(0xFFE53935)
                                            friendAddLoading -> Color(0xFFFFC107)
                                            else -> Color(0xFF2F7CFF)
                                        },
                                        contentDescription = if (friendRequestDenied) tr("Dostluq sorğuları bağlıdır") else tr("Dost əlavə et"),
                                        enabled = !contactBlocked && !actionLoading && !friendAddLoading,
                                        loading = friendAddLoading
                                    ) {
                                        friendAddLoading = true
                                        actionMessage = null
                                        scope.launch {
                                            val result = repository.addFriend(p.uid)
                                            actionMessage = result
                                            friendAddLoading = false
                                            if (result == null) {
                                                friendRequestDenied = false
                                                reloadProfile()
                                            } else {
                                                // A privacy restriction (or any rejected friend request)
                                                // is shown as a red + instead of silently staying blue.
                                                friendRequestDenied = true
                                            }
                                        }
                                    }
                                }
                                OtherProfileActionLogo(
                                    icon = Icons.Outlined.ChatBubbleOutline,
                                    tint = Color(0xFF2F7CFF),
                                    contentDescription = tr("Mesaj yaz"),
                                    enabled = !contactBlocked && !actionLoading
                                ) { onOpenChat(p.nickname) }
                                OtherProfileActionLogo(
                                    icon = Icons.Outlined.CardGiftcard,
                                    tint = GhostGoldText,
                                    contentDescription = tr("Hədiyyə göndər"),
                                    enabled = !contactBlocked && !actionLoading
                                ) { actionMessage = null; showGiftDialog = true }
                                OtherProfileActionLogo(
                                    icon = if (p.blockedByMe) Icons.Outlined.PersonRemove else Icons.Outlined.Block,
                                    tint = if (p.blockedByMe) Color(0xFF18D64B) else GhostRedPrimary,
                                    contentDescription = if (p.blockedByMe) tr("Blokdan çıxar") else tr("İstifadəçini blokla"),
                                    enabled = !actionLoading
                                ) {
                                    if (p.blockedByMe) {
                                        actionLoading = true
                                        scope.launch {
                                            actionMessage = repository.unblockUser(p.uid)
                                            actionLoading = false
                                            if (actionMessage == null) reloadProfile()
                                        }
                                    } else showBlockDialog = true
                                }
                            }
                    }

                    // Premium activity level — shown under the four profile actions.
                    OtherProfileLevelCard(
                        level = p.activityLevel,
                        xp = p.activityXp
                    )

                    // Bu profilin aldığı hədiyyələr. Hədiyyələr serverdə receiver_id ilə saxlanılır.
                    if (p.gifts.isNotEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(tr("🎁 ALINAN HƏDİYYƏLƏR"), color = GhostGoldText, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            Text(trf("%d gifts • Level %d", p.gifts.sumOf { it.count }, p.giftLevel), color = GhostTextMuted, fontSize = 11.sp)
                            p.gifts.forEach { gift ->
                                GiftCollectionRow(gift.icon, gift.name, gift.count, gift.price)
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(tr("🎁 ALINAN HƏDİYYƏLƏR"), color = GhostGoldText, fontSize = 15.sp, fontWeight = FontWeight.Black)
                            Text(tr("Hələ hədiyyə almayıb."), color = GhostTextMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                        }
                    }

                    if (p.blockedMe) {
                        Text(tr("Bu istifadəçi səni bloklayıb."), color = GhostRedPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    actionMessage?.let { msg ->
                        Text(msg, color = if (msg.startsWith("Uğur")) Color(0xFF18D64B) else GhostRedPrimary, fontSize = 9.sp)
                    }
                }
            }
        }
    }


    AnimatedVisibility(
        visible = giftAnimation != null,
        enter = fadeIn(tween(180)) + scaleIn(tween(300)),
        exit = fadeOut(tween(220)),
        modifier = Modifier.fillMaxSize()
    ) {
        giftAnimation?.let { GiftSendAnimationOverlay(it) }
    }
}

if (showRemoveFriendDialog && profile != null) {
    AlertDialog(
        onDismissRequest = { if (!actionLoading) showRemoveFriendDialog = false },
        title = { Text(tr("Dostluğu ləğv et?"), fontWeight = FontWeight.Bold) },
        text = { Text(trf("%s ilə dostluğu ləğv etmək istədiyinə əminsən?", profile!!.nickname)) },
        confirmButton = {
            Button(
                enabled = !actionLoading,
                onClick = {
                    actionLoading = true
                    scope.launch {
                        actionMessage = repository.removeFriend(profile!!.uid)
                        actionLoading = false
                        if (actionMessage == null) {
                            showRemoveFriendDialog = false
                            reloadProfile()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)
            ) {
                if (actionLoading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(tr("Ləğv et"))
            }
        },
        dismissButton = {
            TextButton(enabled = !actionLoading, onClick = { showRemoveFriendDialog = false }) {
                Text(tr("Geri"))
            }
        }
    )
}

if (showBlockDialog && profile != null) {
    AlertDialog(
        onDismissRequest = { if (!actionLoading) showBlockDialog = false },
        title = { Text(tr("İstifadəçini blokla?"), fontWeight = FontWeight.Bold) },
        text = { Text(trf("%s cannot message, gift, or add you as a friend.", profile!!.nickname)) },
        confirmButton = {
            Button(enabled = !actionLoading, onClick = {
                actionLoading = true
                scope.launch {
                    actionMessage = repository.blockUser(profile!!.uid)
                    actionLoading = false
                    showBlockDialog = false
                    if (actionMessage == null) reloadProfile()
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)) { Text(tr("Blokla")) }
        },
        dismissButton = { TextButton(enabled = !actionLoading, onClick = { showBlockDialog = false }) { Text(tr("Ləğv")) } }
    )
}

if (showGiftDialog && profile != null) {
    AlertDialog(
        onDismissRequest = { if (!gifting) { showGiftDialog = false; selectedGift = null } },
        title = { Text(tr("🎁 HƏDİYYƏ MAĞAZASI"), fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(trf("Alıcı: %s", profile!!.nickname), color = GhostTextSecondary)
                Text(trf("Sənin balansın: %d GC", myBalance), color = GhostGoldText, fontWeight = FontWeight.Black)
                if (selectedGift == null && !sendCoinsMode) {
                    Button(onClick = { sendCoinsMode = true }) { Text(tr("🪙 COIN HƏDİYYƏ ET")) }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxWidth().height(410.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(GiftCatalog.items, key = { it.id }) { gift -> GiftChoiceCard(gift) { selectedGift = gift } }
                    }
                } else if (sendCoinsMode) {
                    OutlinedTextField(value = coinAmountText, onValueChange = { coinAmountText = it.filter(Char::isDigit) }, label = { Text(tr("Göndəriləcək GC")) })
                    Text(trf("Send coins to %s", profile!!.nickname), color = GhostTextSecondary)
                } else {
                    val gift = selectedGift!!
                    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(gift.icon, fontSize = 66.sp)
                            Text(gift.name, color = GhostTextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text(trf("%d GC", gift.price), color = GhostGoldText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(trf("Do you want to send this gift to %s?", profile!!.nickname), color = GhostTextSecondary)
                }
                actionMessage?.let { Text(it, color = GhostRedPrimary, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            if (selectedGift != null || sendCoinsMode) {
                Button(enabled = !gifting, onClick = {
                    val gift = selectedGift
                    gifting = true
                    scope.launch {
                        val result = if (sendCoinsMode) repository.sendCoins(profile!!.uid, coinAmountText.toIntOrNull() ?: 0) else repository.sendGift(profile!!.uid, gift!!.id)
                        gifting = false
                        if (result == null) {
                            actionMessage = if (sendCoinsMode) "Uğurla coin göndərildi" else "Uğurla göndərildi: ${gift!!.name}"
                            profile = repository.getPublicUserProfile(profile!!.nickname)
                            showGiftDialog = false
                            selectedGift = null
                            if (!sendCoinsMode) { giftAnimation = gift; delay(1500); giftAnimation = null }
                            sendCoinsMode = false
                            coinAmountText = ""
                        } else actionMessage = result
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = GhostRedPrimary)) {
                    if (gifting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp) else Text(tr("🎁 GÖNDƏR"))
                }
            }
        },
        dismissButton = {
            TextButton(enabled = !gifting, onClick = {
                if (sendCoinsMode) { sendCoinsMode = false; coinAmountText = "" } else if (selectedGift != null) selectedGift = null else showGiftDialog = false
            }) { Text(if (selectedGift != null || sendCoinsMode) "← Geri" else tr("Bağla")) }
        }
    )
}
}


@Composable
private fun GiftCollectionRow(icon: String, name: String, count: Int, price: Int) {
Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(GhostSurface.copy(alpha = .72f)).border(1.dp, GhostBorder, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
    Text(icon, fontSize = 30.sp)
    Spacer(Modifier.width(12.dp))
    Column(Modifier.weight(1f)) {
        Text(name, color = GhostTextWhite, fontWeight = FontWeight.Bold)
        Text(trf("%d GC value", price), color = GhostTextMuted, fontSize = 11.sp)
    }
    Text("×$count", color = GhostGoldText, fontSize = 17.sp, fontWeight = FontWeight.Black)
}
}

@Composable
private fun GiftChoiceCard(gift: GiftItem, onClick: () -> Unit) {
Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(GhostSurface.copy(alpha = .9f)).border(1.dp, GhostRedPrimary.copy(alpha = .45f), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
    Text(gift.icon, fontSize = 36.sp)
    Text(gift.name, color = GhostTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Text(trf("%d GC", gift.price), color = GhostGoldText, fontSize = 11.sp, fontWeight = FontWeight.Black)
}
}

@Composable
private fun GiftSendAnimationOverlay(gift: GiftItem) {
var entered by remember { mutableStateOf(false) }
LaunchedEffect(Unit) { entered = true }
val scale by animateFloatAsState(targetValue = if (entered) 1f else .72f, animationSpec = tween(650), label = "giftScale")
Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .72f)), contentAlignment = Alignment.Center) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.graphicsLayer(scaleX = scale, scaleY = scale)) {
        Box(Modifier.size(150.dp).clip(CircleShape).background(GhostRedPrimary.copy(alpha = .18f)).border(2.dp, GhostGoldText.copy(alpha = .8f), CircleShape), contentAlignment = Alignment.Center) {
            Text(gift.icon, fontSize = 76.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text(tr("🎁 HƏDİYYƏ GÖNDƏRİLDİ"), color = GhostTextWhite, fontSize = 19.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(5.dp))
        Text(gift.name, color = GhostGoldText, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(trf("%d GC", gift.price), color = GhostTextSecondary, fontSize = 13.sp)
    }
}
}

@Composable
private fun OtherProfileLevelCard(
    level: Int,
    xp: Int
) {
    val safeLevel = level.coerceAtLeast(1)
    val safeXp = xp.coerceAtLeast(0)
    val nextXp = safeLevel * 100
    val currentLevelXp = (safeLevel - 1) * 100
    val progress = ((safeXp - currentLevelXp).toFloat() / 100f).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Color(0xFF0D0D13).copy(alpha = .96f))
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF292932),
                        Color(0xFF8B5CF6).copy(alpha = .65f),
                        Color(0xFF292932)
                    )
                ),
                RoundedCornerShape(17.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Color(0xFF11111A))
                    .border(1.dp, Color(0xFF6D45B8).copy(alpha = .75f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tr("LEVEL"), color = GhostTextMuted, fontSize = 6.sp, fontWeight = FontWeight.Black)
                    Text("$safeLevel", color = GhostTextWhite, fontSize = 17.sp, lineHeight = 17.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(Modifier.width(10.dp))

            Column(Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("$safeXp", color = GhostGoldText, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text(trf(" / %d XP", nextXp), color = GhostTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(5.dp))
                Canvas(Modifier.fillMaxWidth().height(9.dp)) {
                    val radius = size.height / 2f
                    drawRoundRect(
                        color = Color(0xFF050507),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xFFFF3D5A), Color(0xFFB02CFF), Color(0xFF8F7CFF))
                        ),
                        size = androidx.compose.ui.geometry.Size(size.width * progress, size.height),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                    drawRoundRect(
                        color = Color.White.copy(alpha = .12f),
                        style = Stroke(width = 1.dp.toPx()),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius, radius)
                    )
                }
            }

            Spacer(Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(tr("NEXT"), color = GhostTextSecondary, fontSize = 7.sp, fontWeight = FontWeight.Black)
                Text("${safeLevel + 1}", color = Color(0xFFA855F7), fontSize = 17.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun OtherProfileActionLogo(
icon: androidx.compose.ui.graphics.vector.ImageVector,
tint: Color,
contentDescription: String,
enabled: Boolean = true,
loading: Boolean = false,
onClick: () -> Unit
) {
val ring = RoundedCornerShape(18.dp)
Box(
    modifier = Modifier
        .size(58.dp)
        .clip(ring)
        .background(GhostBlack.copy(alpha = .35f))
        .border(1.5.dp, tint.copy(alpha = if (enabled) .8f else .25f), ring)
        .clickable(enabled = enabled, onClick = onClick),
    contentAlignment = Alignment.Center
) {
    if (loading) {
        CircularProgressIndicator(
            modifier = Modifier.size(28.dp),
            color = tint,
            strokeWidth = 3.dp
        )
    } else {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = if (enabled) tint else GhostTextMuted,
            modifier = Modifier.size(30.dp)
        )
    }
}
}
