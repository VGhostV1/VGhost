package com.vghost.app.i18n

/** Final UI strings audited from Compose source. Every supported locale has an explicit value. */
internal object FinalUiTranslations {
    val map: Map<String, Map<String, String>> = mapOf(
        "Sorğu gözləyir" to all(
            "Request pending", "Sorğu gözləyir", "İstek bekliyor", "Запрос ожидает", "Solicitud pendiente", "Demande en attente", "Anfrage ausstehend", "Richiesta in attesa", "Pedido pendente", "الطلب قيد الانتظار", "درخواست در انتظار", "درخواست در انتظار", "リクエスト待ち", "요청 대기 중", "请求待处理", "Permintaan tertunda", "Verzoek in behandeling", "Oczekujące zaproszenie", "Запит очікує", "Yêu cầu đang chờ"
        ),
        "Səsli mesaj" to all(
            "Voice message", "Səsli mesaj", "Sesli mesaj", "Голосовое сообщение", "Mensaje de voz", "Message vocal", "Sprachnachricht", "Messaggio vocale", "Mensagem de voz", "رسالة صوتية", "پیام صوتی", "वॉइस मैसेज", "ボイスメッセージ", "음성 메시지", "语音消息", "Pesan suara", "Spraakbericht", "Wiadomość głosowa", "Голосове повідомлення", "Tin nhắn thoại"
        ),
        "Mesaj" to all(
            "Message", "Mesaj", "Mesaj", "Сообщение", "Mensaje", "Message", "Nachricht", "Messaggio", "Mensagem", "رسالة", "پیام", "संदेश", "メッセージ", "메시지", "消息", "Pesan", "Bericht", "Wiadomość", "Повідомлення", "Tin nhắn"
        ),
        "🎙️ Yazılır... %ds" to all(
            "🎙️ Recording... %ds", "🎙️ Yazılır... %ds", "🎙️ Kaydediliyor... %ds", "🎙️ Запись... %d с", "🎙️ Grabando... %ds", "🎙️ Enregistrement... %ds", "🎙️ Aufnahme... %ds", "🎙️ Registrazione... %ds", "🎙️ Gravando... %ds", "🎙️ جارٍ التسجيل... %dث", "🎙️ در حال ضبط... %d ثانیه", "🎙️ रिकॉर्ड हो रहा है... %d सेकंड", "🎙️ 録音中... %d秒", "🎙️ 녹음 중... %d초", "🎙️ 录音中... %d秒", "🎙️ Merekam... %d dtk", "🎙️ Opnemen... %d sec", "🎙️ Nagrywanie... %d s", "🎙️ Запис... %d с", "🎙️ Đang ghi... %d giây"
        ),
        "Football" to all(
            "Football", "Futbol", "Futbol", "Футбол", "Fútbol", "Football", "Fußball", "Calcio", "Futebol", "كرة القدم", "فوتبال", "फुटबॉल", "サッカー", "축구", "足球", "Sepak bola", "Voetbal", "Piłka nożna", "Футбол", "Bóng đá"
        ),
        "Dövriyyədə olan bütün Coin" to all(
            "All Coins in circulation", "Dövriyyədə olan bütün Coin", "Dolaşımdaki tüm Coin", "Все монеты в обращении", "Todas las monedas en circulación", "Toutes les pièces en circulation", "Alle Coins im Umlauf", "Tutte le monete in circolazione", "Todas as moedas em circulação", "جميع العملات المتداولة", "تمام سکه‌های در گردش", "संचार में सभी कॉइन", "流通中のすべてのコイン", "유통 중인 모든 코인", "流通中的所有金币", "Semua koin yang beredar", "Alle munten in omloop", "Wszystkie monety w obiegu", "Усі монети в обігу", "Tất cả Coin đang lưu hành"
        ),
        "İstifadəçi tapılmadı." to all(
            "User not found.", "İstifadəçi tapılmadı.", "Kullanıcı bulunamadı.", "Пользователь не найден.", "Usuario no encontrado.", "Utilisateur introuvable.", "Benutzer nicht gefunden.", "Utente non trovato.", "Utilizador não encontrado.", "المستخدم غير موجود.", "کاربر پیدا نشد.", "उपयोगकर्ता नहीं मिला।", "ユーザーが見つかりません。", "사용자를 찾을 수 없습니다.", "未找到用户。", "Pengguna tidak ditemukan.", "Gebruiker niet gevonden.", "Nie znaleziono użytkownika.", "Користувача не знайдено.", "Không tìm thấy người dùng."
        ),
        "İstifadəçi axtarışa başlayanda avtomatik görünəcək." to all(
            "The user will appear automatically when you start searching.", "İstifadəçi axtarışa başlayanda avtomatik görünəcək.", "Aramaya başladığınızda kullanıcı otomatik olarak görünecek.", "Пользователь появится автоматически, когда вы начнете поиск.", "El usuario aparecerá automáticamente al comenzar la búsqueda.", "L’utilisateur apparaîtra automatiquement lorsque vous commencerez la recherche.", "Der Benutzer wird automatisch angezeigt, sobald du die Suche startest.", "L’utente apparirà automaticamente quando inizi la ricerca.", "O utilizador aparecerá automaticamente quando começar a pesquisar.", "سيظهر المستخدم تلقائيًا عند بدء البحث.", "با شروع جستجو، کاربر به‌طور خودکار نمایش داده می‌شود.", "खोज शुरू करते ही उपयोगकर्ता अपने आप दिखाई देगा।", "検索を開始するとユーザーが自動的に表示されます。", "검색을 시작하면 사용자가 자동으로 표시됩니다.", "开始搜索时，用户会自动显示。", "Pengguna akan muncul otomatis saat Anda mulai mencari.", "De gebruiker verschijnt automatisch wanneer je begint te zoeken.", "Użytkownik pojawi się automatycznie po rozpoczęciu wyszukiwania.", "Користувач автоматично з’явиться після початку пошуку.", "Người dùng sẽ tự động xuất hiện khi bạn bắt đầu tìm kiếm."
        ),
        "Hazırkı balans: %d Coin" to all(
            "Current balance: %d Coin", "Hazırkı balans: %d Coin", "Mevcut bakiye: %d Coin", "Текущий баланс: %d Coin", "Saldo actual: %d Coin", "Solde actuel : %d Coin", "Aktueller Kontostand: %d Coin", "Saldo attuale: %d Coin", "Saldo atual: %d Coin", "الرصيد الحالي: %d Coin", "موجودی فعلی: %d Coin", "वर्तमान बैलेंस: %d कॉइन", "現在の残高: %d コイン", "현재 잔액: %d 코인", "当前余额：%d 金币", "Saldo saat ini: %d Coin", "Huidig saldo: %d Coin", "Bieżące saldo: %d coinów", "Поточний баланс: %d Coin", "Số dư hiện tại: %d Coin"
        ),
        "Yeni rəqəm birbaşa balans kimi yazılacaq." to all(
            "The new number will be written directly as the balance.", "Yeni rəqəm birbaşa balans kimi yazılacaq.", "Yeni sayı doğrudan bakiye olarak yazılacak.", "Новое число будет напрямую записано как баланс.", "El nuevo número se escribirá directamente como saldo.", "Le nouveau nombre sera directement enregistré comme solde.", "Die neue Zahl wird direkt als Kontostand gespeichert.", "Il nuovo numero verrà scritto direttamente come saldo.", "O novo número será gravado diretamente como saldo.", "سيتم تسجيل الرقم الجديد مباشرةً كرصيد.", "عدد جدید مستقیماً به‌عنوان موجودی ثبت می‌شود.", "नई संख्या सीधे बैलेंस के रूप में लिखी जाएगी।", "新しい数値が残高として直接設定されます。", "새 숫자가 잔액으로 직접 설정됩니다.", "新数字将直接作为余额写入。", "Angka baru akan langsung ditulis sebagai saldo.", "Het nieuwe getal wordt direct als saldo ingesteld.", "Nowa liczba zostanie bezpośrednio ustawiona jako saldo.", "Нове число буде безпосередньо записано як баланс.", "Số mới sẽ được ghi trực tiếp vào số dư."
        ),
        "Coin Yolla • %s" to all(
            "Send Coins • %s", "Coin Yolla • %s", "Coin Gönder • %s", "Отправить монеты • %s", "Enviar monedas • %s", "Envoyer des pièces • %s", "Coins senden • %s", "Invia monete • %s", "Enviar moedas • %s", "إرسال العملات • %s", "ارسال کوین • %s", "कॉइन भेजें • %s", "コインを送信 • %s", "코인 보내기 • %s", "发送金币 • %s", "Kirim koin • %s", "Munten sturen • %s", "Wyślij coiny • %s", "Надіслати Coin • %s", "Gửi Coin • %s"
        ),
        "+ Klik" to all(
            "+ Click", "+ Klik", "+ Tıkla", "+ Нажать", "+ Clic", "+ Cliquer", "+ Klicken", "+ Clicca", "+ Clicar", "+ انقر", "+ کلیک", "+ क्लिक", "+ クリック", "+ 클릭", "+ 点击", "+ Klik", "+ Klik", "+ Kliknij", "+ Натиснути", "+ Nhấn"
        ),
        "%s — people they have chatted with" to all(
            "%s — people they have chatted with", "%s — yazışdığı insanlar", "%s — sohbet ettiği kişiler", "%s — собеседники", "%s — personas con las que ha hablado", "%s — personnes avec qui il a discuté", "%s — Chatpartner", "%s — persone con cui ha chattato", "%s — pessoas com quem conversou", "%s — الأشخاص الذين تحدث معهم", "%s — افرادی که با آن‌ها گفتگو کرده", "%s — जिन लोगों से चैट की", "%s — チャットした相手", "%s — 대화한 사람", "%s — 聊过天的人", "%s — orang yang pernah diajak chat", "%s — mensen met wie is gechat", "%s — osoby, z którymi rozmawiał", "%s — співрозмовники", "%s — những người đã trò chuyện"
        ),
        "%s ↔ %s" to all(
            "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s", "%s ↔ %s"
        ),
        "%s\n\nThis operation may modify or overwrite existing data. Do you want to continue?" to all(
            "%s\n\nThis operation may modify or overwrite existing data. Do you want to continue?", "%s\n\nBu əməliyyat mövcud məlumatları dəyişə və ya üzərinə yaza bilər. Davam etmək istəyirsiniz?", "%s\n\nBu işlem mevcut verileri değiştirebilir veya üzerine yazabilir. Devam etmek istiyor musunuz?", "%s\n\nЭта операция может изменить или перезаписать существующие данные. Продолжить?", "%s\n\nEsta operación puede modificar o sobrescribir los datos existentes. ¿Quieres continuar?", "%s\n\nCette opération peut modifier ou écraser les données existantes. Voulez-vous continuer ?", "%s\n\nDieser Vorgang kann vorhandene Daten ändern oder überschreiben. Möchtest du fortfahren?", "%s\n\nQuesta operazione può modificare o sovrascrivere i dati esistenti. Vuoi continuare?", "%s\n\nEsta operação pode modificar ou substituir os dados existentes. Continuar?", "%s\n\nقد تؤدي هذه العملية إلى تعديل البيانات الموجودة أو الكتابة فوقها. هل تريد المتابعة؟", "%s\n\nاین عملیات ممکن است داده‌های موجود را تغییر دهد یا بازنویسی کند. ادامه می‌دهید؟", "%s\n\nयह ऑपरेशन मौजूदा डेटा को बदल या ओवरराइट कर सकता है। क्या आप जारी रखना चाहते हैं?", "%s\n\nこの操作は既存のデータを変更または上書きする可能性があります。続行しますか？", "%s\n\n이 작업은 기존 데이터를 변경하거나 덮어쓸 수 있습니다. 계속하시겠습니까?", "%s\n\n此操作可能修改或覆盖现有数据。是否继续？", "%s\n\nOperasi ini dapat mengubah atau menimpa data yang ada. Lanjutkan?", "%s\n\nDeze bewerking kan bestaande gegevens wijzigen of overschrijven. Wil je doorgaan?", "%s\n\nTa operacja może zmienić lub nadpisać istniejące dane. Czy chcesz kontynuować?", "%s\n\nЦя операція може змінити або перезаписати наявні дані. Продовжити?", "%s\n\nThao tác này có thể sửa đổi hoặc ghi đè dữ liệu hiện có. Bạn có muốn tiếp tục không?"
        ),
        " / %d XP" to all(
            " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP", " / %d XP"
        ),
        "+%d COIN" to all(
            "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d COIN", "+%d コイン", "+%d 코인", "+%d 金币", "+%d Koin", "+%d coins", "+%d coinów", "+%d Coin", "+%d Coin"
        ),
        "UID: %s" to all(
            "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s"
        ),
        "LEVEL %d" to all(
            "LEVEL %d", "SƏVİYYƏ %d", "SEVİYE %d", "УРОВЕНЬ %d", "NIVEL %d", "NIVEAU %d", "LEVEL %d", "LIVELLO %d", "NÍVEL %d", "المستوى %d", "سطح %d", "लेवल %d", "レベル %d", "레벨 %d", "等级 %d", "LEVEL %d", "LEVEL %d", "POZIOM %d", "РІВЕНЬ %d", "CẤP %d"
        ),
        "UID: %s" to all(
            "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s", "UID: %s"
        )
    )

    private fun all(vararg values: String): Map<String, String> {
        val langs = AppLocale.supported
        require(values.size == langs.size)
        return langs.zip(values).toMap()
    }
}
