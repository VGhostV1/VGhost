package com.vghost.app.ui.screens

import com.vghost.app.ui.components.premiumBackdrop
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedBannerBg
import com.vghost.app.ui.theme.GhostRedBannerBorder
import com.vghost.app.ui.theme.GhostRedGlow
import com.vghost.app.ui.theme.GhostRedHover
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextRed
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr

@Composable
fun PanicScreen(
    onTabSelected: (NavTab) -> Unit,
    onPanicActivated: () -> Unit,
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val scope = rememberCoroutineScope()
    val isPanicActivated by repository.isPanicActivated.collectAsState()
    val guestMode by repository.guestMode.collectAsState()
    var showPasswordDialog by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var isDeleting by remember { mutableStateOf(false) }
    fun activatePanic() {
        scope.launch {
            isDeleting = true
            passwordError = null
            val error = repository.activatePanicWipe(password)
            isDeleting = false
            if (error == null) {
                showPasswordDialog = false
                password = ""
                onPanicActivated()
            } else {
                passwordError = error
            }
        }
    }

    if (showPasswordDialog) {
        AlertDialog(
            onDismissRequest = { if (!isDeleting) { showPasswordDialog = false; password = ""; passwordError = null } },
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = GhostRedPrimary) },
            title = { Text(tr("Panik əməliyyatını təsdiqlə"), color = GhostTextWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(tr("Bu əməliyyat hesabınızı və məlumatlarınızı geri dönməz şəkildə siləcək. Davam etmək üçün hesab giriş şifrənizi daxil edin."), color = GhostTextSecondary)
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; passwordError = null },
                        label = { Text(tr("Hesab şifrəsi")) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        isError = passwordError != null,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isDeleting
                    )
                    passwordError?.let { Text(it, color = GhostTextRed, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                Button(onClick = { activatePanic() }, enabled = password.isNotBlank() && !isDeleting) {
                    Text(if (isDeleting) tr("Yoxlanılır...") else tr("TƏSDİQLƏ VƏ SİL"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasswordDialog = false; password = ""; passwordError = null }, enabled = !isDeleting) { Text(tr("Cancel")) }
            },
            containerColor = GhostSurface
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = {
            VGhostBottomNavBar(
                currentTab = NavTab.PANIC,
                onTabSelected = onTabSelected
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // Top Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = tr("Panic"),
                    color = GhostTextWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                // Glowing Shield with Exclamation Mark
                GlowingShieldIcon()

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = tr("Panik rejimi"),
                    color = GhostTextWhite,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = tr("Bu əməliyyat hesabınızı və ona bağlı bütün məlumatları cihazdan və serverdən həmişəlik siləcək."),
                    color = GhostTextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Action Checklist Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(GhostSurface)
                        .border(1.dp, GhostBorder, RoundedCornerShape(16.dp))
                        .padding(vertical = 14.dp, horizontal = 16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PanicActionItem(title = tr("Hesabı tamamilə sil"))
                        PanicActionItem(title = tr("Çat və mesajları sil"))
                        PanicActionItem(title = tr("Profil və cihaz məlumatlarını sil"))
                        PanicActionItem(title = tr("Wallet və oyun məlumatlarını sil"))
                        PanicActionItem(title = tr("Serverdəki əlaqəli məlumatları sil"))
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (isPanicActivated) {
                    // Panic feedback banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(GhostRedBannerBg)
                            .border(1.dp, GhostRedBannerBorder, RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tr("⚠ Panik aktiv edildi: hesab və əlaqəli məlumatlar həmişəlik silindi."),
                            color = GhostTextRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                } else {
                    // Activate Panic Primary Button
                    Button(
                        onClick = {
                            if (guestMode) activatePanic() else showPasswordDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GhostRedPrimary,
                            contentColor = GhostTextWhite
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("activate_panic_button")
                    ) {
                        Text(
                            text = tr("PANİKİ AKTİVLƏŞDİR"),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = tr("Bu əməliyyat geri qaytarıla bilməz."),
                    color = GhostTextMuted,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun GlowingShieldIcon() {
    Box(
        modifier = Modifier.size(130.dp),
        contentAlignment = Alignment.Center
    ) {
        // Red glowing outer aura
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            GhostRedGlow.copy(alpha = 0.35f),
                            GhostRedPrimary.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Red Shield Outline Box
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(GhostRedBannerBg)
                .border(2.dp, GhostRedPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.PriorityHigh,
                contentDescription = tr("Panic Exclamation"),
                tint = GhostRedPrimary,
                modifier = Modifier.size(44.dp)
            )
        }
    }
}

@Composable
private fun PanicActionItem(title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(GhostRedBannerBg)
                .border(1.dp, GhostRedPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = GhostRedPrimary,
                modifier = Modifier.size(14.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = title,
            color = GhostTextWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
