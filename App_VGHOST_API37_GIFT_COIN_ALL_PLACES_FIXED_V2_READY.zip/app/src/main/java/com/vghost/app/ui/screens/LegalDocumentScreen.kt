package com.vghost.app.ui.screens

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.*

enum class LegalDocument { PRIVACY_POLICY, TERMS }

@Composable
fun LegalDocumentScreen(document: LegalDocument, onBack: () -> Unit) {
    BackHandler { onBack() }
    val localPrivacy = if (document == LegalDocument.PRIVACY_POLICY) VGhostLocalPrivacyPolicy.get() else null
    val title = localPrivacy?.title ?: tr("Terms & Conditions")
    val sections = localPrivacy?.let { listOf(it.intro.let { intro -> tr("Privacy Policy") to intro }) + it.sections.map { section -> section.title to section.body } } ?: termsSections()

    Scaffold(modifier = Modifier.fillMaxSize().premiumBackdrop(), containerColor = Color.Transparent) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(GhostSurface.copy(alpha = .78f))
                        .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.ArrowBack, tr("Geri"), tint = GhostTextWhite) }
                Spacer(Modifier.width(12.dp))
                Text(title, color = GhostTextWhite, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 20.dp)
            ) {
                sections.forEach { (heading, body) ->
                    Text(heading, color = GhostTextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(body, color = GhostTextSecondary, fontSize = 13.sp, lineHeight = 19.sp)
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

private fun termsSections() = listOf(
    tr("Qəbul") to tr("Qeydiyyatı tamamlayaraq bu Terms & Conditions qaydalarını oxuduğunuzu və qəbul etdiyinizi təsdiqləyirsiniz."),
    tr("Hesab") to tr("İstifadəçi qeydiyyat zamanı düzgün məlumat təqdim etməli və hesabının giriş məlumatlarını qorumağa cavabdehdir."),
    tr("Ghost Coins") to tr("Ghost Coins tətbiq daxilində istifadə olunan virtual vahidlərdir və real pul kimi qəbul edilmir."),
    tr("Qadağan edilən istifadə") to tr("Xidmətdən qanunsuz fəaliyyət, spam, fırıldaqçılıq, digər istifadəçilərə zərər vermək və ya sistemin işini pozmaq üçün istifadə etmək qadağandır."),
    tr("Qaydaların dəyişdirilməsi") to tr("Tətbiqin funksiyaları və bu şərtlər gələcəkdə yenilənə bilər. Yenilənmiş qaydalar tətbiq daxilində yerli şəkildə təqdim edilə bilər.")
)
