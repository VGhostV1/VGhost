package com.vghost.app.ui.screens

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trf
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.network.VGhostApi
import com.vghost.app.data.state.VGhostRepository
import org.json.JSONArray

private data class AdminUser(val uid: String, val nickname: String, val banned: Boolean, val coinBalance: Long = 0L)
private data class AdminMessage(
    val id: String, val sender: String,
    val recipient: String, val text: String, val time: String
)
private data class AdminChatUser(val uid: String, val nickname: String)

private fun adminError(t: Throwable, fallback: String): String {
    val raw = t.message.orEmpty()
    return if (raw.isBlank()) fallback else com.vghost.app.i18n.BackendErrorTranslations.localize(raw, com.vghost.app.i18n.AppLocale.language.value)
}

@Composable
fun AdminScreen(onBack: () -> Unit, onAdminRejected: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { VGhostApi.init(context) }
    var authorized by remember { mutableStateOf<Boolean?>(null) }
    var users by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var messages by remember { mutableStateOf<List<AdminMessage>>(emptyList()) }
    var messageUsers by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var selectedMessageUser by remember { mutableStateOf<AdminUser?>(null) }
    var chatPartners by remember { mutableStateOf<List<AdminChatUser>>(emptyList()) }
    var selectedChatPartner by remember { mutableStateOf<AdminChatUser?>(null) }
    var messageSearch by remember { mutableStateOf("") }
    var usersCount by remember { mutableStateOf(0) }
    var messageCount by remember { mutableStateOf(0) }
    var adminRecoveryLogin by remember { mutableStateOf("") }
    var onlineCount by remember { mutableStateOf(0) }
    var selectedUserForCoins by remember { mutableStateOf<AdminUser?>(null) }
    var sendCoinsToAll by remember { mutableStateOf(false) }
    var coinGiftMessage by remember { mutableStateOf("") }
    var coinSearch by remember { mutableStateOf("") }
    var coinSearchResults by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var coinAmount by remember { mutableStateOf("100") }
    var totalCoins by remember { mutableStateOf(0L) }
    var coinOverviewUsers by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var coinOverviewSearch by remember { mutableStateOf("") }
    var coinOverviewSearchResults by remember { mutableStateOf<List<AdminUser>>(emptyList()) }
    var selectedUserForCoinEdit by remember { mutableStateOf<AdminUser?>(null) }
    var editCoinBalance by remember { mutableStateOf("") }
    var coinConfirmCode by remember { mutableStateOf("") }
    var adminSecurityCode by remember { mutableStateOf("") }
    var broadcastLink by remember { mutableStateOf("") }
    var securityDialog by remember { mutableStateOf(false) }
    var securityBusy by remember { mutableStateOf(false) }
    var pendingSecurityAction by remember { mutableStateOf<((String) -> Unit)?>(null) }
    var showLogs by remember { mutableStateOf(false) }
    var showDataTools by remember { mutableStateOf(false) }
    var searchUsers by remember { mutableStateOf("") }
    var adminLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var title by remember { mutableStateOf("VGhost") }
    var body by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var pendingExport by remember { mutableStateOf<Pair<String, ByteArray>?>(null) }
    var pendingImportToken by remember { mutableStateOf<String?>(null) }
    var pendingImportSummary by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun requestAdminSecurity(action: (String) -> Unit) {
        pendingSecurityAction = action
        securityDialog = true
    }

    fun rejectAdminSecurity() {
        securityDialog = false
        pendingSecurityAction = null
        adminSecurityCode = ""
        android.widget.Toast.makeText(context, "Siz Admin deyilsiz", android.widget.Toast.LENGTH_LONG).show()
        VGhostRepository.instance.logout()
        onAdminRejected()
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/gzip")) { uri ->
        val pending = pendingExport
        if (uri != null && pending != null) {
            scope.launch {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(pending.second) }
                        ?: throw IllegalStateException(tr("Backup faylı yazıla bilmədi."))
                    status = "Backup saxlanıldı: ${pending.first}"
                } catch (e: Throwable) { status = adminError(e, tr("Backup saxlanmadı.")) }
                finally { pendingExport = null }
            }
        } else { pendingExport = null }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalStateException(tr("Backup faylı oxunmadı."))
                    if (bytes.size > 512 * 1024 * 1024) throw IllegalStateException(tr("Backup 512 MB limitini keçir."))
                    status = tr("Backup yoxlanılır...")
                    val name = "vghost-import.sql.gz"
                    val result = VGhostApi.adminBackupValidate(name, bytes, adminSecurityCode)
                    if (!result.optBoolean("valid")) throw IllegalStateException(tr("Backup etibarlı deyil."))
                    pendingImportToken = result.optString("confirmToken")
                    pendingImportSummary = "${result.optInt("statements")} SQL əməliyyatı • ${result.optInt("tables")} cədvəl"
                    status = tr("Backup yoxlandı. İdxal təsdiqi gözlənilir.")
                } catch (e: Throwable) { status = adminError(e, tr("Backup yoxlanmadı.")) }
            }
        }
    }

    suspend fun loadData() {
        loading = true
        try {
            val dash = VGhostApi.adminDashboard()
            authorized = true
            usersCount = dash.optInt("users",0)
            onlineCount = dash.optInt("online",0)
            messageCount = dash.optInt("active_messages",0)
            totalCoins = dash.optLong("total_coins",0L)
            adminRecoveryLogin = dash.optString("email", "")
            val ua = VGhostApi.adminUsers(searchUsers).optJSONArray("users") ?: JSONArray()
            users = (0 until ua.length()).map { val o=ua.getJSONObject(it); AdminUser(o.optString("uid"),o.optString("nickname"),o.optBoolean("isBanned"),o.optLong("coinBalance",0L)) }
            try {
                val cj = VGhostApi.adminCoinsOverview()
                totalCoins = cj.optLong("totalCoins",0L)
                val ca = cj.optJSONArray("users") ?: JSONArray()
                coinOverviewUsers = (0 until ca.length()).map { i -> val o=ca.getJSONObject(i); AdminUser(o.optString("uid"),o.optString("nickname"),false,o.optLong("balance",0L)) }
            } catch (_: Throwable) {}
            val ma = VGhostApi.adminMessages().optJSONArray("messages") ?: JSONArray()
            messages = (0 until ma.length()).map { val o=ma.getJSONObject(it); AdminMessage(o.optString("id"),o.optString("senderNickname"),o.optString("receiverNickname"),o.optString("message"),o.optString("created_at")) }
            val byNickname = users.associateBy { it.nickname.lowercase() }
            val ids = linkedMapOf<String, AdminUser>()
            messages.forEach { m ->
                byNickname[m.sender.lowercase()]?.let { ids[it.uid] = it }
                byNickname[m.recipient.lowercase()]?.let { ids[it.uid] = it }
            }
            messageUsers = ids.values.toList()
            status = ""
        } catch (e: Throwable) { authorized=false; status=adminError(e, tr("Unable to load admin data.")) } finally { loading=false }
    }

    LaunchedEffect(Unit) {
        try {
            val dash = VGhostApi.adminDashboard()
            authorized = true
            usersCount = dash.optInt("users",0)
            onlineCount = dash.optInt("online",0)
            messageCount = dash.optInt("active_messages",0)
            totalCoins = dash.optLong("total_coins",0L)
            adminRecoveryLogin = dash.optString("email", "")
            loading = false
        } catch (e: Exception) {
            authorized = false
            status = adminError(e, tr("Unable to load admin data."))
            loading = false
        }
    }

    LaunchedEffect(coinSearch) {
        val q = coinSearch.trim()
        if (q.isBlank()) {
            coinSearchResults = emptyList()
        } else {
            // Search the server while typing so users outside the initial 200-user
            // admin list are also found immediately.
            delay(220)
            try {
                val j = VGhostApi.adminUsers(q)
                val a = j.optJSONArray("users") ?: JSONArray()
                coinSearchResults = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    AdminUser(
                        o.optString("uid"),
                        o.optString("nickname"),
                        o.optBoolean("isBanned"),
                        o.optLong("coinBalance", 0L)
                    )
                }.take(20)
            } catch (_: Throwable) {
                // Keep local results as a fallback if the live search is offline.
                val lower = q.lowercase()
                coinSearchResults = users.filter {
                    it.nickname.lowercase().contains(lower) || it.uid.lowercase().contains(lower)
                }.take(20)
            }
        }
    }

    LaunchedEffect(coinOverviewSearch) {
        val q = coinOverviewSearch.trim()
        if (q.isBlank()) {
            coinOverviewSearchResults = emptyList()
        } else {
            delay(220)
            try {
                val j = VGhostApi.adminUsers(q)
                val a = j.optJSONArray("users") ?: JSONArray()
                coinOverviewSearchResults = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    AdminUser(
                        o.optString("uid"),
                        o.optString("nickname"),
                        o.optBoolean("isBanned"),
                        o.optLong("coinBalance", o.optLong("balance", 0L))
                    )
                }.take(20)
            } catch (_: Throwable) {
                val lower = q.lowercase()
                coinOverviewSearchResults = coinOverviewUsers.filter {
                    it.nickname.lowercase().contains(lower) || it.uid.lowercase().contains(lower)
                }.take(20)
            }
        }
    }

    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).premiumBackdrop()) {
        if (loading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        } else if (authorized != true) {
            Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(tr("ACCESS DENIED"), color = Color(0xFFFF2438), fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(8.dp))
                Text(tr("Super Admin authorization required."), color = Color.LightGray)
                Spacer(Modifier.height(18.dp))
                OutlinedButton(onClick = onBack) { Text(tr("BACK")) }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, tr("Back"), tint = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(tr("V GHOST"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text(tr("RED • WHITE CONTROL ROOM"), color = Color(0xFFFF2438), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            scope.launch {
                                try {
                                    loadData()
                                    status = tr("Admin məlumatları yeniləndi.")
                                } catch (e: Throwable) { status = adminError(e, tr("Unable to load admin data.")) }
                            }
                        }) {
                            Icon(Icons.Filled.Refresh, "Refresh", tint = Color.White)
                        }
                        Icon(Icons.Filled.Visibility, "Admin", tint = Color(0xFFFF4B5C))
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("USERS", usersCount.toString(), Modifier.weight(1f))
                    StatCard("ONLINE", onlineCount.toString(), Modifier.weight(1f))
                    StatCard("MESSAGES", messageCount.toString(), Modifier.weight(1f))
                }
                if (status.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        status,
                        color = if (status.contains("failed", ignoreCase = true) || status.contains("error", ignoreCase = true)) Color(0xFFFF6675) else Color(0xFFD8D8DE),
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        NeonCard {
                            Text(tr("📢 BROADCAST TO EVERYONE"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                title, { title = it }, Modifier.fillMaxWidth(),
                                label = { Text(tr("Title")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                body, { body = it }, Modifier.fillMaxWidth().heightIn(min = 110.dp),
                                label = { Text(tr("Announcement")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                broadcastLink, { broadcastLink = it }, Modifier.fillMaxWidth(),
                                label = { Text(tr("Link (optional)")) },
                                placeholder = { Text("https://...") },
                                singleLine = true
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    val message = body.trim()
                                    if (message.isNotEmpty()) {
                                        requestAdminSecurity { code ->
                                            scope.launch {
                                                try {
                                                    val result = VGhostApi.adminBroadcast(title.trim().ifBlank { "VGhost" }, message, broadcastLink.trim(), code)
                                                    body = ""
                                                    broadcastLink = ""
                                                    val sent = result.optInt("pushSent", 0)
                                                    val total = result.optInt("totalDevices", 0)
                                                    val failed = result.optInt("failed", 0)
                                                    val delivery = result.optString("delivery")
                                                    val reason = result.optString("reason")
                                                    status = if (delivery == "fcm") "Broadcast göndərildi: $sent / $total cihaz${if (failed > 0) " • $failed uğursuz" else ""}" else "Broadcast push göndərilmədi: ${reason.ifBlank { delivery }}"
                                                } catch (e: Exception) {
                                                    status = adminError(e, tr("Broadcast failed."))
                                                } finally { adminSecurityCode = "" }
                                            }
                                        }
                                    }
                                },
                                enabled = body.isNotBlank()
                            ) { Icon(Icons.Filled.Send, null); Spacer(Modifier.width(6.dp)); Text(tr("SEND TO ALL")) }
                            Text(
                                if (status.isBlank()) "Registered devices receive this announcement through Firebase Cloud Messaging."
                                else status,
                                color = Color(0xFFD8D8DE), fontSize = 11.sp
                            )
                        }
                    }
                    item {
                        NeonCard {
                            Text(tr("👑 ADMIN CONTROLS"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    if (showLogs) showLogs = false
                                    else {
                                        showLogs = true
                                        scope.launch {
                                            try {
                                                val logs = VGhostApi.adminLogs().optJSONArray("logs") ?: JSONArray()
                                                adminLogs = (0 until logs.length()).map { i -> val m=logs.getJSONObject(i); "${m.optString("action")} • target=${m.optString("targetNickname")} • actor=${m.optString("adminNickname")}" }
                                            } catch (e: Throwable) { status = adminError(e, tr("Unable to load admin logs.")) }
                                        }
                                    }
                                }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.List, null); Spacer(Modifier.width(5.dp)); Text(tr("LOGS"))
                                }
                                OutlinedButton(onClick = { showDataTools = !showDataTools }, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.CloudUpload, null); Spacer(Modifier.width(5.dp)); Text(tr("BACKUP"))
                                }
                            }
                            if (showLogs) {
                                Spacer(Modifier.height(8.dp))
                                adminLogs.take(20).forEach { log ->
                                    Text(log, color = Color(0xFFD8D8DE), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                                }
                            }
                            if (showDataTools) {
                                Spacer(Modifier.height(8.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = {
                                        requestAdminSecurity { code ->
                                            adminSecurityCode = code
                                            scope.launch {
                                                try {
                                                    status = tr("Backup hazırlanır...")
                                                    pendingExport = VGhostApi.adminBackupExport(code)
                                                    exportLauncher.launch(pendingExport?.first ?: "vghost-backup.sql.gz")
                                                } catch (e: Throwable) { status = adminError(e, tr("Backup export alınmadı.")); adminSecurityCode = "" }
                                            }
                                        }
                                    }, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Filled.CloudUpload, null); Spacer(Modifier.width(4.dp)); Text(tr("EXPORT"))
                                    }
                                    OutlinedButton(onClick = {
                                        requestAdminSecurity { code ->
                                            adminSecurityCode = code
                                            importLauncher.launch(arrayOf("application/gzip", "application/octet-stream"))
                                        }
                                    }, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Filled.CloudDownload, null); Spacer(Modifier.width(4.dp)); Text(tr("IMPORT"))
                                    }
                                }
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Text(tr("👥 USERS"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = searchUsers,
                                onValueChange = { searchUsers = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(tr("Search nickname / UID")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    try {
                                        val ua = VGhostApi.adminUsers(searchUsers).optJSONArray("users") ?: JSONArray()
                                        users = (0 until ua.length()).map { val o=ua.getJSONObject(it); AdminUser(o.optString("uid"),o.optString("nickname"),o.optBoolean("isBanned"),o.optLong("coinBalance",0L)) }
                                        status = tr("İstifadəçi siyahısı yeniləndi.")
                                    } catch (e: Throwable) { status = adminError(e, tr("İstifadəçilər yüklənmədi.")) }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text(tr("İSTİFADƏÇİLƏRİ YÜKLƏ")) }
                            Spacer(Modifier.height(8.dp))
                            users.filter {
                                val q = searchUsers.trim().lowercase()
                                q.isBlank() || it.nickname.lowercase().contains(q) || it.uid.lowercase().contains(q)
                            }.take(100).forEach { u ->
                                UserRow(
                                    u,
                                    onError = { status = it },
                                    onBanStateChanged = { uid, banned ->
                                        users = users.map { if (it.uid == uid) it.copy(banned = banned) else it }
                                    },
                                    onDeleted = { uid ->
                                        users = users.filterNot { it.uid == uid }
                                        coinOverviewUsers = coinOverviewUsers.filterNot { it.uid == uid }
                                        // Re-read the dashboard count because the visible
                                        // list may currently be filtered by nickname/UID.
                                        scope.launch {
                                            try {
                                                val dash = VGhostApi.adminDashboard()
                                                usersCount = dash.optInt("users", usersCount)
                                                onlineCount = dash.optInt("online", onlineCount)
                                                totalCoins = dash.optLong("total_coins", totalCoins)
                                            } catch (_: Throwable) {}
                                        }
                                    },
                                    onCoins = { selectedUserForCoins = it },
                                    requestSecurity = ::requestAdminSecurity,
                                    securityCode = adminSecurityCode
                                )
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(tr("🪙 COIN CIRCULATION"), color = Color(0xFFFFD54A), fontWeight = FontWeight.Bold)
                                    Text(tr("Dövriyyədə olan bütün Coin"), color = Color(0xFF8F8D9B), fontSize = 10.sp)
                                }
                                Text("$totalCoins 🪙", color = Color(0xFFFFD54A), fontSize = 21.sp, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = coinOverviewSearch,
                                onValueChange = { coinOverviewSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(tr("İstifadəçi axtar • Coin sayı")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    try {
                                        val j = VGhostApi.adminCoinsOverview()
                                        totalCoins = j.optLong("totalCoins",0L)
                                        val a = j.optJSONArray("users") ?: JSONArray()
                                        coinOverviewUsers = (0 until a.length()).map { i ->
                                            val o=a.getJSONObject(i)
                                            AdminUser(o.optString("uid"),o.optString("nickname"),false,o.optLong("balance",0L))
                                        }
                                        status = "Coin dövriyyəsi yeniləndi."
                                    } catch(e:Throwable) { status=adminError(e, "Coin məlumatları yüklənmədi.") }
                                }
                            }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(6.dp)); Text(tr("COINLƏRİ YENİLƏ"))
                            }
                            Spacer(Modifier.height(8.dp))
                            val q = coinOverviewSearch.trim()
                            if (q.isNotBlank()) {
                                if (coinOverviewSearchResults.isEmpty()) {
                                    Text(tr("İstifadəçi tapılmadı."), color = Color(0xFF888894), fontSize = 12.sp)
                                }
                                coinOverviewSearchResults.take(20).forEach { u ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                            .background(Color(0x4416161C), RoundedCornerShape(12.dp))
                                            .clickable {
                                                coinOverviewSearch = u.nickname
                                                selectedUserForCoinEdit = u
                                                editCoinBalance = u.coinBalance.toString()
                                                coinConfirmCode = ""
                                            }
                                            .padding(horizontal = 12.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.Star, null, tint = Color(0xFFFFD54A))
                                        Spacer(Modifier.width(9.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text(trf("UID: %s", u.uid), color = Color(0xFF77758A), fontSize = 9.sp)
                                        }
                                        Text("${u.coinBalance} 🪙", color = Color(0xFFFFD54A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else if (coinOverviewUsers.isNotEmpty()) {
                                coinOverviewUsers.take(100).forEach { u ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical=4.dp).background(Color(0x4416161C), RoundedCornerShape(12.dp)).padding(horizontal=12.dp,vertical=9.dp),
                                        verticalAlignment=Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.Star,null,tint=Color(0xFFFFD54A))
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(u.nickname,color=Color.White,fontWeight=FontWeight.SemiBold)
                                            Text(trf("UID: %s", u.uid),color=Color(0xFF77758A),fontSize=9.sp)
                                        }
                                        Text("${u.coinBalance} 🪙",color=Color(0xFFFFD54A),fontWeight=FontWeight.Bold,fontSize=12.sp)
                                        Spacer(Modifier.width(6.dp))
                                        TextButton(onClick={ selectedUserForCoinEdit=u; editCoinBalance=u.coinBalance.toString(); coinConfirmCode="" }) { Text(tr("EDIT")) }
                                    }
                                }
                            } else {
                                Text(tr("İstifadəçi axtarışa başlayanda avtomatik görünəcək."), color = Color(0xFF77758A), fontSize = 11.sp)
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Text(tr("💬 MESSAGE LIST"), color = Color(0xFFFF4B5C), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = messageSearch,
                                onValueChange = { messageSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(tr("Search Users")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                scope.launch {
                                    try {
                                        val j = VGhostApi.adminMessages()
                                        messages = (0 until (j.optJSONArray("messages") ?: JSONArray()).length()).map { i -> val o=j.getJSONArray("messages").getJSONObject(i); AdminMessage(o.optString("id"),o.optString("senderNickname"),o.optString("receiverNickname"),o.optString("message"),o.optString("created_at")) }
                                        val byNickname = users.associateBy { it.nickname.lowercase() }
                                        val ids = linkedMapOf<String, AdminUser>()
                                        messages.forEach { m -> byNickname[m.sender.lowercase()]?.let { ids[it.uid] = it }; byNickname[m.recipient.lowercase()]?.let { ids[it.uid] = it } }
                                        messageUsers = ids.values.toList()
                                        status = tr("Mesajlar yükləndi.")
                                    } catch (e: Throwable) { status = adminError(e, tr("Mesajlar yüklənmədi.")) }
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text(tr("MESAJLARI YÜKLƏ")) }
                            Spacer(Modifier.height(8.dp))
                            if (selectedMessageUser == null) {
                                messageUsers.filter { messageSearch.isBlank() || it.nickname.contains(messageSearch.trim(), true) || it.uid.contains(messageSearch.trim(), true) }.forEach { u ->
                                    MessageUserRow(u) {
                                        selectedMessageUser = u
                                        selectedChatPartner = null
                                        scope.launch {
                                            try {
                                                val j = VGhostApi.adminMessages(u.uid)
                                                val ca = j.optJSONArray("contacts") ?: JSONArray()
                                                chatPartners = (0 until ca.length()).map { i -> val o=ca.getJSONObject(i); AdminChatUser(o.optString("uid"),o.optString("nickname")) }
                                            } catch (e: Throwable) { status = adminError(e, "Unable to load conversations.") }
                                        }
                                    }
                                }
                            } else if (selectedChatPartner == null) {
                                Text(trf("%s — people they have chatted with", selectedMessageUser!!.nickname), color = Color.LightGray, fontSize = 12.sp)
                                Spacer(Modifier.height(5.dp))
                                TextButton(onClick = { selectedMessageUser = null; chatPartners = emptyList() }) { Text(tr("← MESSAGE LIST")) }
                                chatPartners.forEach { partner ->
                                    MessageUserRow(AdminUser(partner.uid, partner.nickname, false)) {
                                        selectedChatPartner = partner
                                        scope.launch {
                                            try {
                                                val j = VGhostApi.adminMessages(selectedMessageUser!!.uid, partner.uid)
                                                val pa = j.optJSONArray("messages") ?: JSONArray()
                                                messages = (0 until pa.length()).map { i -> val o=pa.getJSONObject(i); AdminMessage(o.optString("id"),o.optString("senderNickname"),o.optString("receiverNickname"),o.optString("message"),o.optString("created_at")) }
                                            } catch (e: Throwable) { status = adminError(e, "Unable to load chat.") }
                                        }
                                    }
                                }
                            } else {
                                Text(trf("%s ↔ %s", selectedMessageUser!!.nickname, selectedChatPartner!!.nickname), color = Color.White, fontWeight = FontWeight.Bold)
                                TextButton(onClick = { selectedChatPartner = null }) { Text(tr("← Yazışdığı adamlar")) }
                                messages.forEach { m ->
                                    MessageRow(
                                        m = m,
                                        onError = { status = it },
                                        refresh = {
                                            scope.launch {
                                                try {
                                                    val j = VGhostApi.adminMessages(
                                                        selectedMessageUser!!.uid,
                                                        selectedChatPartner!!.uid
                                                    )
                                                    val pa = j.optJSONArray("messages") ?: JSONArray()
                                                    messages = (0 until pa.length()).map { i ->
                                                        val o = pa.getJSONObject(i)
                                                        AdminMessage(
                                                            o.optString("id"),
                                                            o.optString("senderNickname"),
                                                            o.optString("receiverNickname"),
                                                            o.optString("message"),
                                                            o.optString("created_at")
                                                        )
                                                    }
                                                } catch (e: Throwable) {
                                                    status = adminError(e, "Unable to refresh chat.")
                                                }
                                            }
                                        },
                                        securityCode = adminSecurityCode,
                                        requestSecurity = ::requestAdminSecurity
                                    )
                                }
                            }
                        }
                    }
                    item {
                        NeonCard {
                            Text(tr("🪙 COIN TRANSFER"), color = Color(0xFFFF2438), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    selectedUserForCoins = null
                                    sendCoinsToAll = true
                                    coinAmount = "100"
                                    coinGiftMessage = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.People, null); Spacer(Modifier.width(6.dp)); Text(tr("BÜTÜN İSTİFADƏÇİLƏRƏ COIN GÖNDƏR"))
                            }
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = coinSearch,
                                onValueChange = { coinSearch = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text(tr("Ləqəb / UID axtar")) }
                            )
                            Spacer(Modifier.height(8.dp))
                            if (coinSearch.trim().isNotBlank() && coinSearchResults.isEmpty()) {
                                Text(tr("İstifadəçi tapılmadı."), color = Color(0xFF888894), fontSize = 12.sp)
                            }
                            coinSearchResults.take(20).forEach { u ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                        .background(Color(0x5516161C), RoundedCornerShape(12.dp))
                                        .clickable {
                                            selectedUserForCoins = u
                                            coinConfirmCode = ""
                                        }.padding(horizontal = 12.dp, vertical = 11.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Star, null, tint = Color(0xFFFFD54A))
                                    Spacer(Modifier.width(9.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text(trf("UID: %s", u.uid), color = Color(0xFF77758A), fontSize = 9.sp)
                                    }
                                    Text(tr("+ Klik"), color = Color(0xFFFF4B5C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    }
                }
            }
        }

        if (selectedUserForCoinEdit != null) {
            val user = selectedUserForCoinEdit!!
            AlertDialog(
                onDismissRequest = { selectedUserForCoinEdit = null },
                title = { Text(tr("🪙 Coin balansını redaktə et")) },
                text = {
                    Column {
                        Text(user.nickname, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(trf("Hazırkı balans: %d Coin", user.coinBalance), color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = editCoinBalance,
                            onValueChange = { editCoinBalance = it.filter(Char::isDigit).take(12) },
                            label = { Text(tr("Yeni Coin sayı")) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(tr("Yeni rəqəm birbaşa balans kimi yazılacaq."), color = Color(0xFF888894), fontSize = 10.sp)
                    }
                },
                confirmButton = {
                    Button(enabled=editCoinBalance.toLongOrNull()!=null, onClick={
                        requestAdminSecurity { code ->
                            scope.launch {
                                try {
                                    val balance=editCoinBalance.toLongOrNull() ?: 0L
                                    val r=VGhostApi.adminSetCoins(user.uid,balance,code)
                                    val newBal=r.optLong("balance",balance)
                                    // Re-read the authoritative server state so both the edited
                                    // wallet and total circulation are guaranteed to match DB.
                                    try {
                                        val fresh=VGhostApi.adminCoinsOverview()
                                        totalCoins=fresh.optLong("totalCoins",totalCoins)
                                        val fa=fresh.optJSONArray("users")
                                        if(fa!=null) coinOverviewUsers=(0 until fa.length()).map { i ->
                                            val o=fa.getJSONObject(i)
                                            AdminUser(o.optString("uid"),o.optString("nickname"),false,o.optLong("balance",0L))
                                        }
                                    } catch(_:Throwable) {
                                        coinOverviewUsers=coinOverviewUsers.map { if(it.uid==user.uid) it.copy(coinBalance=newBal) else it }
                                        totalCoins=coinOverviewUsers.sumOf { it.coinBalance }
                                    }
                                    users=users.map { if(it.uid==user.uid) it.copy(coinBalance=newBal) else it }
                                    status="${user.nickname} balansı $newBal Coin olaraq yeniləndi."
                                    selectedUserForCoinEdit=null
                                } catch(e:Throwable) { status=adminError(e, "Coin balansı dəyişdirilmədi.") }
                            }
                        }
                    }) { Text(tr("YADDA SAXLA")) }
                },
                dismissButton = { TextButton(onClick={ selectedUserForCoinEdit=null }) { Text(tr("LƏĞV ET")) } }
            )
        }

        if (securityDialog) {
            var enteredCode by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { },
                title = { Text(tr("Admin təhlükəsizlik")) },
                text = {
                    Column {
                        Text(tr("Bu əməliyyat üçün admin təsdiq kodunu daxil et."), color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = enteredCode,
                            onValueChange = { enteredCode = it },
                            label = { Text(tr("Admin kodu")) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        enabled = enteredCode.isNotBlank() && !securityBusy,
                        onClick = {
                            securityBusy = true
                            scope.launch {
                                try {
                                    VGhostApi.adminSecurityVerify(enteredCode.trim())
                                    val action = pendingSecurityAction
                                    pendingSecurityAction = null
                                    securityDialog = false
                                    val verifiedCode = enteredCode.trim()
                                    enteredCode = ""
                                    adminSecurityCode = verifiedCode
                                    action?.invoke(verifiedCode)
                                } catch (e: Throwable) {
                                    val msg = adminError(e, tr("Admin kodu yanlışdır."))
                                    status = if (msg.contains("INVALID_SECURITY_CODE", true)) {
                                        "Admin təsdiq kodu yanlışdır. Yenidən yoxla."
                                    } else msg
                                    // Keep the dialog open on verification failure, but make
                                    // the server error immediately visible instead of leaving
                                    // it hidden behind the modal.
                                    android.widget.Toast.makeText(context, status, android.widget.Toast.LENGTH_LONG).show()
                                    if (msg.contains("SUPER_ADMIN_REQUIRED", true)) {
                                        securityDialog = false
                                        pendingSecurityAction = null
                                    }
                                } finally {
                                    securityBusy = false
                                }
                            }
                        }
                    ) { Text(tr("TƏSDİQLƏ")) }
                },
                dismissButton = {
                    TextButton(onClick = { securityDialog = false; pendingSecurityAction = null }) { Text(tr("LƏĞV ET")) }
                }
            )
        }
        if (sendCoinsToAll) {
            AlertDialog(
                onDismissRequest = { sendCoinsToAll = false },
                title = { Text(tr("🪙 Bütün istifadəçilərə Coin")) },
                text = {
                    Column {
                        Text(tr("Bütün aktiv istifadəçilərin hesabına coin əlavə ediləcək."), color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = coinAmount,
                            onValueChange = { coinAmount = it.filter { c -> c.isDigit() } },
                            label = { Text(tr("Coin miqdarı")) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = coinGiftMessage,
                            onValueChange = { coinGiftMessage = it },
                            label = { Text(tr("Yazı / Hədiyyə mesajı")) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp)
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(tr("Məsələn: Yeni iliniz mübarək! 🎁 Bu coinlər sizə hədiyyədir."), color = Color(0xFFD8D8DE), fontSize = 10.sp)
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val amount = coinAmount.toLongOrNull()
                        val message = coinGiftMessage.trim()
                        if (amount == null || amount <= 0L) {
                            status = tr("Coin miqdarı tələb olunur.")
                        } else if (message.isBlank()) {
                            status = tr("Yazı əlavə et.")
                        } else {
                            requestAdminSecurity { code ->
                                scope.launch {
                                    try {
                                        val result = VGhostApi.adminCoinsAll(amount, message, code)
                                        val count = result.optInt("usersCredited", 0)
                                        val notified = result.optInt("notificationsCreated", 0)
                                        status = "${amount} Coin $count istifadəçiyə göndərildi. $notified bildiriş yaradıldı."
                                        sendCoinsToAll = false
                                        coinGiftMessage = ""
                                        coinConfirmCode = ""
                                    } catch (e: Throwable) {
                                        status = adminError(e, tr("Coin göndərilmədi."))
                                    }
                                }
                            }
                        }
                    }) { Text(tr("HAMISINA GÖNDƏR")) }
                },
                dismissButton = { TextButton(onClick = { sendCoinsToAll = false }) { Text(tr("CANCEL")) } }
            )
        }
        selectedUserForCoins?.let { user ->
            AlertDialog(
                onDismissRequest = { selectedUserForCoins = null },
                title = { Text(trf("Coin Yolla • %s", user.nickname)) },
                text = {
                    Column {
                        Text(tr("Məbləği və admin təsdiq kodunu daxil et."), color = Color.LightGray)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = coinAmount,
                            onValueChange = { coinAmount = it.filter { c -> c.isDigit() || c == '-' } },
                            label = { Text(tr("Coin miqdarı")) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            tr("YOLA GÖNDƏR düyməsinə basanda admin təsdiq kodu ayrıca soruşulacaq."),
                            color = Color(0xFFD8D8DE), fontSize = 10.sp
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val amount = coinAmount.toLongOrNull()
                        if (amount == null || amount == 0L) {
                            status = tr("Coin miqdarı tələb olunur.")
                        } else {
                            requestAdminSecurity { code ->
                                scope.launch {
                                    try {
                                        val result = VGhostApi.adminCoins(user.uid, amount, code)
                                        val newBalance = result.optLong("balance", -1L)
                                        status = if (newBalance >= 0L) {
                                            "${user.nickname} hesabına $amount coin göndərildi. Yeni balans: $newBalance"
                                        } else {
                                            "${user.nickname} hesabına $amount coin göndərildi."
                                        }
                                        // Reload the admin user data after the server confirms the wallet update.
                                        try {
                                            val refreshed = VGhostApi.adminUsers("", adminSecurityCode)
                                            val ua2 = refreshed.optJSONArray("users")
                                            if (ua2 != null) users = (0 until ua2.length()).map { val o=ua2.getJSONObject(it); AdminUser(o.optString("uid"),o.optString("nickname"),o.optBoolean("isBanned"),o.optLong("coinBalance",0L)) }
                                        } catch (_: Throwable) { }
                                        selectedUserForCoins = null
                                        coinConfirmCode = ""
                                    } catch (e: Throwable) {
                                        status = adminError(e, tr("Coin göndərilmədi."))
                                    }
                                }
                            }
                        }
                    }) { Text(tr("YOLA GÖNDƏR")) }
                },
                dismissButton = { TextButton(onClick = { selectedUserForCoins = null }) { Text(tr("CANCEL")) } }
            )
        }
        pendingImportToken?.let { token ->
            AlertDialog(
                onDismissRequest = { pendingImportToken = null },
                title = { Text(tr("FULL IMPORT TƏSDİQİ")) },
                text = { Text(trf("%s\n\nThis operation may modify or overwrite existing data. Do you want to continue?", pendingImportSummary)) },
                confirmButton = {
                    Button(onClick = {
                        scope.launch {
                            try {
                                status = tr("Backup idxal olunur...")
                                val result = VGhostApi.adminBackupImport(token, adminSecurityCode)
                                pendingImportToken = null
                                status = "Import tamamlandı: ${result.optInt("statements")} SQL əməliyyatı."
                                loadData()
                            } catch (e: Throwable) { status = adminError(e, tr("Import alınmadı.")); pendingImportToken = null }
                            finally { adminSecurityCode = "" }
                        }
                    }) { Text(tr("TƏSDİQLƏ VƏ İDXAL ET")) }
                },
                dismissButton = { OutlinedButton(onClick = { pendingImportToken = null }) { Text(tr("LƏĞV ET")) } }
            )
        }
    }

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.shadow(16.dp, RoundedCornerShape(18.dp))
            .background(Color(0xF20D0D12), RoundedCornerShape(18.dp))
            .border(1.dp, Color(0x99FF2438), RoundedCornerShape(18.dp))
            .padding(16.dp)
            .then(modifier)
    ) {
        Text(label, color = Color(0xFFD8D8DE), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(20.dp))
            .background(Color(0xF20D0D12), RoundedCornerShape(20.dp))
            .border(1.dp, Color(0x99FF2438), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun UserRow(
    u: AdminUser,
    
    onError: (String) -> Unit,
    onBanStateChanged: (String, Boolean) -> Unit,
    onDeleted: (String) -> Unit,
    onCoins: (AdminUser) -> Unit,
    requestSecurity: (((String) -> Unit) -> Unit),
    securityCode: String
) {
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Row(
        Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.People, null, tint = if (u.banned) Color(0xFFFF2438) else Color(0xFFFF2438))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(u.uid, color = Color(0xFF77758A), fontSize = 9.sp)
        }
        TextButton(
            enabled = !busy,
            onClick = {
                requestSecurity { code ->
                    busy = true
                    scope.launch {
                        try {
                            VGhostApi.adminUserAction(u.uid, if (u.banned) "unban" else "ban", code)
                            val updated = !u.banned
                            onBanStateChanged(u.uid, updated)
                        } catch (e: Throwable) {
                            onError(adminError(e, if (u.banned) tr("UNBAN failed.") else tr("BAN failed.")))
                        } finally {
                            busy = false
                        }
                    }
                }
            }
        ) { Text(if (u.banned) tr("UNBAN") else tr("BAN")) }
        IconButton(enabled = !busy, onClick = { onCoins(u) }) {
            Icon(Icons.Filled.Star, "Ghost Coins", tint = Color(0xFFFFD54A))
        }
        TextButton(
            enabled = !busy,
            onClick = {
                requestSecurity { code ->
                    busy = true
                    scope.launch {
                        try {
                            VGhostApi.adminUserAction(u.uid, "delete", code)
                            onDeleted(u.uid)
                        } catch (e: Throwable) {
                            onError(adminError(e, "DELETE failed."))
                        } finally {
                            busy = false
                        }
                    }
                }
            }
        ) { Text(tr("DELETE"), color = Color(0xFFFF2438)) }
    }
}

@Composable
private fun MessageUserRow(u: AdminUser, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Color(0x5516161C), RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.People, null, tint = Color(0xFFFF2438))
        Spacer(Modifier.width(9.dp))
        Text(u.nickname, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(tr("+ Klik"), color = Color(0xFFFF4B5C), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MessageRow(
    m: AdminMessage,
    onError: (String) -> Unit,
    refresh: suspend () -> Unit,
    securityCode: String,
    requestSecurity: (((String) -> Unit) -> Unit)
) {
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxWidth().padding(vertical = 7.dp)
            .background(Color(0x6616161C), RoundedCornerShape(12.dp))
            .padding(11.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(trf("%s → %s", m.sender, m.recipient), color = Color(0xFFFF2438), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(
                enabled = !busy,
                onClick = {
                    requestSecurity { code ->
                        busy = true
                        scope.launch {
                            try {
                                VGhostApi.adminDeleteMessage(m.id, code)
                                refresh()
                            } catch (e: Throwable) {
                                onError(adminError(e, tr("Message delete failed.")))
                            } finally {
                                busy = false
                            }
                        }
                    }
                }
            ) { Icon(Icons.Filled.Delete, "Delete message", tint = Color(0xFFFF2438)) }
        }
        Text(m.text, color = Color.White, fontSize = 13.sp)
        Text(m.time, color = Color(0xFF77758A), fontSize = 9.sp)
    }
}
