package com.vghost.app.ui.screens

import com.vghost.app.ui.components.premiumBackdrop
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.model.ChatSummary
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.data.state.SessionState
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.components.VGhostBottomNavBar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onChatClicked: (String) -> Unit,
    onTabSelected: (NavTab) -> Unit,
    onNotificationTarget: (VGhostRepository.AppNotification) -> Unit = {},
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    val chats by repository.chats.collectAsState()
    val sessionState by repository.sessionState.collectAsState()
    // The visible Guest label is derived from the authoritative session state,
    // not from a cached flag that can become stale after login.
    val guestMode = sessionState is SessionState.LoggedInGhost
    val allNotifications by repository.notifications.collectAsState()
    // Chat messages have their own Messages/Chat screen and must not pollute the
    // general notification center. Keep other notification types here.
    val notifications = remember(allNotifications) {
        allNotifications.filterNot { it.type.equals("message", ignoreCase = true) }
    }
    val unreadNotifications = notifications.filter { !it.isRead }.sumOf { it.count.coerceAtLeast(1) }
    var showNotifications by remember { mutableStateOf(false) }
    var selectedFriendRequest by remember { mutableStateOf<VGhostRepository.AppNotification?>(null) }
    var friendActionLoading by remember { mutableStateOf(false) }
    var friendActionError by remember { mutableStateOf<String?>(null) }
    val screenScope = rememberCoroutineScope()

    LaunchedEffect(sessionState) {
        if (sessionState is SessionState.LoggedInNormalUser) {
            repository.startChatListSync()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop(),
        containerColor = Color.Transparent,
        bottomBar = {
            VGhostBottomNavBar(
                currentTab = NavTab.CHATS,
                onTabSelected = onTabSelected
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // Messages page header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = tr("MESAJLAR"),
                        color = GhostTextWhite,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    if (guestMode) {
                        Text(
                            text = tr("Qonaq rejimi"),
                            color = GhostRedPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box {
                        IconButton(
                            onClick = { showNotifications = true },
                            modifier = Modifier.testTag("notifications_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsNone,
                                contentDescription = tr("Bildirişlər"),
                                tint = GhostTextWhite,
                                modifier = Modifier.size(25.dp)
                            )
                        }
                        if (unreadNotifications > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 7.dp, end = 7.dp)
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(GhostRedPrimary)
                                    .border(1.dp, GhostBlack, CircleShape)
                            )
                        }
                    }
                }
            }

            if (showNotifications) {
                AlertDialog(
                    onDismissRequest = { showNotifications = false },
                    containerColor = GhostSurface,
                    titleContentColor = GhostTextWhite,
                    textContentColor = GhostTextSecondary,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.NotificationsNone,
                                contentDescription = null,
                                tint = GhostRedPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(tr("BİLDİRİŞLƏR"), fontWeight = FontWeight.Black)
                        }
                    },
                    text = {
                        if (notifications.isEmpty()) {
                            Text(tr("Hələ heç bir bildiriş yoxdur."))
                        } else {
                            // AlertDialog's text slot is bounded; a normal Column cannot
                            // scroll here. LazyColumn makes the complete notification
                            // history accessible by swiping upward/downward.
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 500.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(notifications) { notification ->
                                    val icon = when (notification.type) {
                                        "gift" -> Icons.Outlined.CardGiftcard
                                        "coin_transfer", "coin_gift", "coin_received" -> Icons.Outlined.AccountBalanceWallet
                                        "welcome_bonus", "daily_bonus" -> Icons.Outlined.AccountBalanceWallet
                                        "admin", "broadcast" -> Icons.Outlined.Campaign
                                        "friend_request", "friend_accepted" -> Icons.Outlined.PersonAdd
                                        else -> Icons.Outlined.Person
                                    }
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (notification.isRead) Color.Transparent else GhostBlack.copy(alpha = 0.35f))
                                            .clickable {
                                                if (!notification.isRead) repository.markNotificationRead(notification.id)
                                                if (notification.type == "friend_request") {
                                                    selectedFriendRequest = notification
                                                    friendActionError = null
                                                } else if (notification.type.equals("gift", true)) {
                                                    showNotifications = false
                                                    repository.openGiftNotification(notification)
                                                } else {
                                                    showNotifications = false
                                                    onNotificationTarget(notification)
                                                }
                                            }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Icon(icon, null, tint = if (notification.isRead) GhostTextMuted else GhostRedPrimary, modifier = Modifier.size(22.dp))
                                        Spacer(modifier = Modifier.width(9.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text(notification.title, color = if (notification.isRead) GhostTextSecondary else GhostTextWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (notification.count > 1) {
                                                        Text("×${notification.count}", color = GhostRedPrimary, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(end = 6.dp))
                                                    }
                                                    Text(if (notification.isRead) tr("OXUNUB") else tr("YENİ"), color = if (notification.isRead) GhostTextMuted else GhostRedPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text(notification.body, color = GhostTextSecondary, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                            if (notification.createdAt.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(notification.createdAt.replace("T", " ").take(19), color = GhostTextMuted, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        if (notifications.isNotEmpty()) {
                            Row {
                                if (unreadNotifications > 0) {
                                    TextButton(onClick = { repository.markAllNotificationsRead() }) {
                                        Text(tr("HAMISINI OXU"), color = GhostTextWhite, fontWeight = FontWeight.Bold)
                                    }
                                }
                                TextButton(onClick = { repository.clearInAppNotifications(); showNotifications = false }) {
                                    Text(tr("TƏMİZLƏ"), color = GhostRedPrimary, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            TextButton(onClick = { showNotifications = false }) {
                                Text(tr("BAĞLA"), color = GhostRedPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                )
            }

            selectedFriendRequest?.let { request ->
                AlertDialog(
                    onDismissRequest = { if (!friendActionLoading) selectedFriendRequest = null },
                    containerColor = GhostSurface,
                    title = { Text(tr("DOSTLUQ SORĞUSU"), color = GhostTextWhite, fontWeight = FontWeight.Black) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(request.body.ifBlank { tr("Sənə dostluq sorğusu göndərilib.") }, color = GhostTextSecondary)
                            if (friendActionError != null) Text(friendActionError!!, color = GhostRedPrimary, fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(enabled = !friendActionLoading, onClick = {
                            val uid = request.targetValue.trim()
                            screenScope.launch {
                                friendActionLoading = true
                                val user = repository.findUserByNickname(uid)
                                val err = if (user == null) tr("İstifadəçi tapılmadı.") else repository.acceptFriend(user.uid)
                                friendActionLoading = false
                                if (err == null) { repository.removeInAppNotification(request.id); selectedFriendRequest = null; showNotifications = false } else friendActionError = err
                            }
                        }) { Text(if (friendActionLoading) tr("GÖZLƏ...") else tr("QƏBUL ET"), color = GhostTextWhite, fontWeight = FontWeight.Bold) }
                    },
                    dismissButton = {
                        TextButton(enabled = !friendActionLoading, onClick = {
                            val nick = request.targetValue.trim()
                            screenScope.launch {
                                friendActionLoading = true
                                val user = repository.findUserByNickname(nick)
                                val err = if (user == null) tr("İstifadəçi tapılmadı.") else repository.rejectFriend(user.uid)
                                friendActionLoading = false
                                if (err == null) { repository.removeInAppNotification(request.id); selectedFriendRequest = null; showNotifications = false } else friendActionError = err
                            }
                        }) { Text(tr("RƏDD ET"), color = GhostRedPrimary, fontWeight = FontWeight.Bold) }
                    }
                )
            }

            if (chats.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ChatBubbleOutline,
                            contentDescription = null,
                            tint = GhostTextMuted,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = tr("Hələ heç bir mesaj yoxdur"),
                            color = GhostTextWhite,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = tr("İstifadəçilər bölməsindən birini seç və söhbətə başla."),
                            color = GhostTextSecondary,
                            fontSize = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        TextButton(
                            onClick = { onTabSelected(NavTab.FIND) },
                            modifier = Modifier.testTag("messages_find_users_button")
                        ) {
                            Text(
                                text = tr("İstifadəçiləri tap"),
                                color = GhostRedPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(chats, key = { it.id }) { chat ->
                        ChatItemRow(
                            chat = chat,
                            onClick = { onChatClicked(chat.nickname) }
                        )
                        HorizontalDivider(
                            thickness = 0.5.dp,
                            color = GhostBorder.copy(alpha = 0.5f),
                            modifier = Modifier.padding(start = 76.dp, end = 16.dp)
                        )
                    }
                }
            }
            }
        }
    }

@Composable
private fun ChatItemRow(
    chat: ChatSummary,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("chat_item_${chat.nickname}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Ghost Avatar
        GhostAvatar(
            size = 48.dp,
            showBorder = true,
            avatarId = chat.avatarId
        )

        Spacer(modifier = Modifier.width(14.dp))

        // Nickname + Last Message
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = chat.nickname,
                color = GhostTextWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(3.dp))
            val previewText = (chat.messageTypePrefix ?: "") + chat.lastMessage
            Text(
                text = previewText,
                color = GhostTextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Time and Unread Badge
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = chat.time,
                color = GhostTextMuted,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (chat.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(GhostRedPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = chat.unreadCount.toString(),
                        color = GhostTextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
