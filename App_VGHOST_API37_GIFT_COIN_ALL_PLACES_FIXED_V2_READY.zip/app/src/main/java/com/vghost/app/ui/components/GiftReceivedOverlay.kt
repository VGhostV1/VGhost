package com.vghost.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.vghost.app.i18n.tr
import com.vghost.app.i18n.VGhostLanguage

private fun trfGift(source:String, value:String): String = String.format(java.util.Locale.getDefault(), VGhostLanguage.tr(source), value)

@Composable
fun GiftReceivedOverlay(icon:String,name:String,sender:String,eventToken:Long,onDismiss:()->Unit){
    LaunchedEffect(eventToken){ delay(10000); onDismiss() }
    val transition=rememberInfiniteTransition(label="giftPulse")
    val pulse by transition.animateFloat(
        initialValue=0.96f,targetValue=1.08f,
        animationSpec=infiniteRepeatable(tween(700),RepeatMode.Reverse),label="giftScale"
    )
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha=.78f)).clickable{onDismiss()},
        contentAlignment=Alignment.Center
    ){
        Column(
            horizontalAlignment=Alignment.CenterHorizontally,
            modifier=Modifier.padding(28.dp)
        ){
            Text(icon,fontSize=82.sp,modifier=Modifier.scale(pulse))
            Spacer(Modifier.height(16.dp))
            Text(tr("🎁 SƏNƏ HƏDİYYƏ GƏLDİ!"),color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text(name,color=Color(0xFFFFD166),fontSize=21.sp,fontWeight=FontWeight.Bold)
            if(sender.isNotBlank()){
                Spacer(Modifier.height(8.dp))
                Text(trfGift("Göndərən: %s", sender),color=Color.LightGray,fontSize=15.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text(tr("Bağlamaq üçün toxun"),color=Color.Gray,fontSize=12.sp)
        }
    }
}
