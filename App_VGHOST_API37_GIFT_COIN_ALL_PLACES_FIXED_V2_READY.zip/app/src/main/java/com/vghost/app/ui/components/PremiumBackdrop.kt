package com.vghost.app.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostRedGlow

/** Shared visual backdrop used to reproduce the approved V Ghost premium preview.
 * It only paints behind content and never changes navigation or business logic. */
fun Modifier.premiumBackdrop(): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height
    drawRect(GhostBlack)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GhostRedGlow.copy(alpha = 0.10f),
                GhostRedGlow.copy(alpha = 0.028f),
                Color.Transparent
            ),
            center = Offset(w * 0.5f, h * 0.22f),
            radius = w * 0.82f
        ),
        center = Offset(w * 0.5f, h * 0.22f),
        radius = w * 0.82f
    )
    // Deterministic ember particles: premium texture, no animation overhead.
    val particles = listOf(
        0.08f to 0.13f, 0.16f to 0.21f, 0.83f to 0.17f, 0.91f to 0.28f,
        0.27f to 0.08f, 0.73f to 0.10f, 0.12f to 0.54f, 0.88f to 0.62f,
        0.22f to 0.76f, 0.78f to 0.81f, 0.48f to 0.07f, 0.54f to 0.92f
    )
    particles.forEachIndexed { i, (x, y) ->
        drawCircle(
            color = GhostRedGlow.copy(alpha = if (i % 3 == 0) 0.32f else 0.16f),
            radius = if (i % 4 == 0) 2.0f else 1.1f,
            center = Offset(w * x, h * y)
        )
    }
}
