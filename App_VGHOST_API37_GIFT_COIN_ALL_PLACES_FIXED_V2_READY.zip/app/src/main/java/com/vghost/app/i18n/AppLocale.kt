package com.vghost.app.i18n

import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow

object AppLocale {
    private const val PREFS = "vghost_preferences"
    private const val KEY_LANGUAGE = "app_language"
    const val SYSTEM = "system"

    // Compose-observable app language. Updating this forces every screen to
    // rebuild from the translation table immediately, without relying only on
    // Activity recreation.
    val language = MutableStateFlow("en")

    val supported = listOf("az", "tr", "en", "ru", "es", "fr", "de", "it", "pt", "ar", "fa", "hi", "ja", "ko", "zh", "id", "nl", "pl", "uk", "vi")

    fun current(context: Context): String {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, null)
        return saved ?: Locale.getDefault().language.lowercase(Locale.ROOT).takeIf { it in supported } ?: "en"
    }

    fun set(context: Context, language: String) {
        require(language in supported)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, language).apply()
        val locale = Locale(language)
        Locale.setDefault(locale)
        this.language.value = language
        if (Build.VERSION.SDK_INT >= 33) {
            context.getSystemService(android.app.LocaleManager::class.java).applicationLocales = android.os.LocaleList.forLanguageTags(language)
        }
    }

    fun wrap(context: Context): ContextWrapper {
        val language = current(context)
        val locale = Locale(language)
        Locale.setDefault(locale)
        this.language.value = language
        val config = android.content.res.Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLocales(android.os.LocaleList(locale))
        return ContextWrapper(context.createConfigurationContext(config))
    }
}
