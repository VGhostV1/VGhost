package com.vghost.app.ui.screens

import java.util.Locale

data class LocalPrivacySection(val title: String, val body: String)
data class LocalPrivacyDocument(val title: String, val intro: String, val sections: List<LocalPrivacySection>)

object VGhostLocalPrivacyPolicy {
    private val docs = mapOf(
        "en" to LocalPrivacyDocument("V GHOST — Privacy Policy", "This policy explains how V GHOST handles information when you use the app and related services.", listOf(
            LocalPrivacySection("Account information", "V GHOST processes your nickname, email and password information to manage your account. Passwords are stored as hashes, not plain text."),
            LocalPrivacySection("Profile and social features", "Profile details such as name, bio and avatar, plus friendship, blocking, profile-view and online-status data may be processed for social features."),
            LocalPrivacySection("Messages and voice messages", "Messages, metadata and voice-message files may be processed to provide chat, according to the service’s expiration and deletion rules."),
            LocalPrivacySection("Notifications and device data", "When push notifications are enabled, a device identifier and Firebase Cloud Messaging token may be stored to deliver notifications."),
            LocalPrivacySection("Coins, gifts and games", "Coin balances, transactions, gifts and game-round information may be stored when you use those features."),
            LocalPrivacySection("Use and sharing", "Information is used for accounts, messaging, social features, notifications, security and service operation. Necessary service providers may process information. V GHOST does not state that it sells personal information."),
            LocalPrivacySection("Security, retention and deletion", "Reasonable security measures are used, but no internet service is completely secure. Data is retained as needed. You can delete your account in the app or through the public deletion page."),
            LocalPrivacySection("Choices, children and updates", "You can manage privacy and notification settings. V GHOST is not intended for children below the minimum age required by applicable law. This policy may be updated.")
        )),
        "az" to LocalPrivacyDocument("V GHOST — Məxfilik Siyasəti", "Bu siyasət tətbiqdən və əlaqəli xidmətlərdən istifadə edərkən V GHOST-un məlumatları necə idarə etdiyini izah edir.", listOf(
            LocalPrivacySection("Hesab məlumatları", "V GHOST hesabınızı idarə etmək üçün nik, e-poçt və şifrə məlumatlarınızı emal edir. Şifrələr açıq mətn kimi deyil, heşlənmiş formada saxlanılır."),
            LocalPrivacySection("Profil və sosial funksiyalar", "Ad, bio və profil şəkli kimi məlumatlar, həmçinin dostluq, bloklama, profil baxışları və onlayn status məlumatları sosial funksiyalar üçün emal oluna bilər."),
            LocalPrivacySection("Mesajlar və səs mesajları", "Çat xidmətini təmin etmək üçün mesajlar, metadatа və səs mesajı faylları xidmətin saxlanma və silinmə qaydalarına uyğun emal oluna bilər."),
            LocalPrivacySection("Bildirişlər və cihaz məlumatları", "Push bildirişləri aktiv olduqda bildirişləri çatdırmaq üçün cihaz identifikatoru və Firebase Cloud Messaging tokeni saxlanıla bilər."),
            LocalPrivacySection("Coin, hədiyyə və oyunlar", "Bu funksiyalardan istifadə etdikdə Coin balansları, əməliyyatlar, hədiyyələr və oyun raundları barədə məlumatlar saxlanıla bilər."),
            LocalPrivacySection("İstifadə və paylaşma", "Məlumatlar hesab, mesajlaşma, sosial funksiyalar, bildirişlər, təhlükəsizlik və xidmətin işləməsi üçün istifadə olunur. Zəruri xidmət təminatçıları məlumatları emal edə bilər. V GHOST şəxsi məlumatları satdığını bildirmir."),
            LocalPrivacySection("Təhlükəsizlik, saxlanma və silinmə", "Münasib təhlükəsizlik tədbirləri tətbiq edilir, lakin internetdə heç bir xidmət tam təhlükəsiz deyil. Məlumatlar lazım olduğu müddətdə saxlanılır. Hesabınızı tətbiqdən və ya ictimai silinmə səhifəsindən silə bilərsiniz."),
            LocalPrivacySection("Seçimlər, uşaqlar və yeniləmələr", "Məxfilik və bildiriş parametrlərini idarə edə bilərsiniz. V GHOST tətbiq olunan qanunların tələb etdiyi minimum yaşdan aşağı uşaqlar üçün nəzərdə tutulmayıb. Bu siyasət yenilənə bilər.")
        )),
        "tr" to LocalPrivacyDocument("V GHOST — Gizlilik Politikası", "Bu politika, uygulamayı ve ilgili hizmetleri kullanırken V GHOST’un bilgileri nasıl işlediğini açıklar.", listOf(
            LocalPrivacySection("Hesap bilgileri", "V GHOST hesabınızı yönetmek için kullanıcı adı, e-posta ve şifre bilgilerinizi işler. Şifreler düz metin olarak değil, hash olarak saklanır."),
            LocalPrivacySection("Profil ve sosyal özellikler", "Ad, biyografi ve profil resmi gibi bilgiler ile arkadaşlık, engelleme, profil görüntüleme ve çevrimiçi durum verileri sosyal özellikler için işlenebilir."),
            LocalPrivacySection("Mesajlar ve sesli mesajlar", "Sohbeti sağlamak için mesajlar, meta veriler ve sesli mesaj dosyaları hizmetin saklama ve silme kurallarına göre işlenebilir."),
            LocalPrivacySection("Bildirimler ve cihaz verileri", "Anlık bildirimler etkinleştirildiğinde bildirim göndermek için cihaz kimliği ve Firebase Cloud Messaging tokenı saklanabilir."),
            LocalPrivacySection("Coin, hediyeler ve oyunlar", "Bu özellikleri kullandığınızda Coin bakiyeleri, işlemler, hediyeler ve oyun turu bilgileri saklanabilir."),
            LocalPrivacySection("Kullanım ve paylaşım", "Bilgiler hesap, mesajlaşma, sosyal özellikler, bildirimler, güvenlik ve hizmetin çalışması için kullanılır. Gerekli hizmet sağlayıcılar bilgileri işleyebilir. V GHOST kişisel bilgileri sattığını belirtmez."),
            LocalPrivacySection("Güvenlik, saklama ve silme", "Makul güvenlik önlemleri kullanılır, ancak hiçbir internet hizmeti tamamen güvenli değildir. Veriler gerektiği kadar saklanır. Hesabınızı uygulamadan veya herkese açık silme sayfasından silebilirsiniz."),
            LocalPrivacySection("Seçimler, çocuklar ve güncellemeler", "Gizlilik ve bildirim ayarlarını yönetebilirsiniz. V GHOST, yürürlükteki yasaların gerektirdiği asgari yaşın altındaki çocuklara yönelik değildir. Bu politika güncellenebilir.")
        )),
        "ru" to LocalPrivacyDocument("V GHOST — Политика конфиденциальности", "В этой политике объясняется, как V GHOST обрабатывает информацию при использовании приложения и связанных сервисов.", listOf(
            LocalPrivacySection("Данные аккаунта", "V GHOST обрабатывает никнейм, электронную почту и данные пароля для управления аккаунтом. Пароли хранятся в виде хеша, а не в открытом виде."),
            LocalPrivacySection("Профиль и социальные функции", "Имя, биография и аватар, а также данные о дружбе, блокировках, просмотрах профиля и онлайн-статусе могут обрабатываться для социальных функций."),
            LocalPrivacySection("Сообщения и голосовые сообщения", "Сообщения, метаданные и файлы голосовых сообщений могут обрабатываться для работы чата согласно правилам хранения и удаления сервиса."),
            LocalPrivacySection("Уведомления и данные устройства", "При включённых push-уведомлениях для их доставки могут храниться идентификатор устройства и токен Firebase Cloud Messaging."),
            LocalPrivacySection("Монеты, подарки и игры", "При использовании этих функций могут храниться балансы монет, операции, подарки и сведения об игровых раундах."),
            LocalPrivacySection("Использование и передача", "Информация используется для аккаунтов, сообщений, социальных функций, уведомлений, безопасности и работы сервиса. Необходимые поставщики услуг могут обрабатывать информацию. V GHOST не заявляет о продаже персональной информации."),
            LocalPrivacySection("Безопасность, хранение и удаление", "Используются разумные меры безопасности, но ни один интернет-сервис не является полностью безопасным. Данные хранятся столько, сколько необходимо. Аккаунт можно удалить в приложении или на публичной странице удаления."),
            LocalPrivacySection("Выбор, дети и обновления", "Вы можете управлять настройками конфиденциальности и уведомлений. V GHOST не предназначен для детей младше минимального возраста, установленного законом. Политика может обновляться.")
        )),
        "es" to LocalPrivacyDocument("V GHOST — Política de privacidad", "Esta política explica cómo V GHOST gestiona la información cuando utilizas la aplicación y los servicios relacionados.", listOf(
            LocalPrivacySection("Información de la cuenta", "V GHOST procesa tu apodo, correo electrónico y contraseña para gestionar tu cuenta. Las contraseñas se almacenan como hashes, no en texto plano."),
            LocalPrivacySection("Perfil y funciones sociales", "Los datos del perfil, como nombre, biografía y avatar, además de amistad, bloqueo, visitas al perfil y estado en línea, pueden procesarse para funciones sociales."),
            LocalPrivacySection("Mensajes y mensajes de voz", "Los mensajes, metadatos y archivos de voz pueden procesarse para ofrecer el chat, según las reglas de conservación y eliminación del servicio."),
            LocalPrivacySection("Notificaciones y datos del dispositivo", "Cuando las notificaciones push están activadas, pueden almacenarse un identificador del dispositivo y un token de Firebase Cloud Messaging para enviarlas."),
            LocalPrivacySection("Monedas, regalos y juegos", "Al usar estas funciones pueden almacenarse saldos de monedas, transacciones, regalos e información de las rondas de juego."),
            LocalPrivacySection("Uso y compartición", "La información se usa para cuentas, mensajes, funciones sociales, notificaciones, seguridad y funcionamiento del servicio. Los proveedores necesarios pueden procesarla. V GHOST no afirma vender información personal."),
            LocalPrivacySection("Seguridad, conservación y eliminación", "Se aplican medidas de seguridad razonables, pero ningún servicio de Internet es completamente seguro. Los datos se conservan cuando es necesario. Puedes eliminar tu cuenta en la aplicación o en la página pública de eliminación."),
            LocalPrivacySection("Opciones, niños y actualizaciones", "Puedes gestionar la privacidad y las notificaciones. V GHOST no está destinado a menores de la edad mínima exigida por la ley. Esta política puede actualizarse.")
        )),
        "fr" to LocalPrivacyDocument("V GHOST — Politique de confidentialité", "Cette politique explique comment V GHOST traite les informations lorsque vous utilisez l’application et les services associés.", listOf(
            LocalPrivacySection("Informations du compte", "V GHOST traite votre pseudonyme, votre e-mail et votre mot de passe pour gérer votre compte. Les mots de passe sont stockés sous forme de hachage."),
            LocalPrivacySection("Profil et fonctions sociales", "Les informations de profil et les données sociales peuvent être traitées pour fournir les fonctions sociales."),
            LocalPrivacySection("Messages et messages vocaux", "Les messages, métadonnées et fichiers vocaux peuvent être traités selon les règles de conservation et de suppression du service."),
            LocalPrivacySection("Notifications et données de l’appareil", "Un identifiant d’appareil et un jeton Firebase Cloud Messaging peuvent être conservés pour envoyer les notifications."),
            LocalPrivacySection("Coins, cadeaux et jeux", "Les soldes, transactions, cadeaux et informations de parties peuvent être conservés lorsque vous utilisez ces fonctions."),
            LocalPrivacySection("Utilisation et partage", "Les informations servent au compte, aux messages, aux fonctions sociales, aux notifications, à la sécurité et au fonctionnement du service."),
            LocalPrivacySection("Sécurité, conservation et suppression", "Des mesures de sécurité raisonnables sont utilisées. Les données sont conservées aussi longtemps que nécessaire et le compte peut être supprimé."),
            LocalPrivacySection("Choix, enfants et mises à jour", "Vous pouvez gérer les paramètres de confidentialité et de notifications. Le service n’est pas destiné aux enfants sous l’âge légal minimum et cette politique peut être mise à jour.")
        )),
        "de" to LocalPrivacyDocument("V GHOST — Datenschutzerklärung", "Diese Richtlinie erklärt, wie V GHOST Informationen verarbeitet, wenn Sie die App und verbundene Dienste nutzen.", listOf(
            LocalPrivacySection("Kontoinformationen", "V GHOST verarbeitet Spitzname, E-Mail und Passwort zur Verwaltung Ihres Kontos. Passwörter werden als Hashes und nicht im Klartext gespeichert."),
            LocalPrivacySection("Profil und soziale Funktionen", "Profildaten und soziale Daten können für soziale Funktionen verarbeitet werden."),
            LocalPrivacySection("Nachrichten und Sprachnachrichten", "Nachrichten, Metadaten und Sprachdateien können nach den Speicher- und Löschregeln des Dienstes verarbeitet werden."),
            LocalPrivacySection("Benachrichtigungen und Gerätedaten", "Eine Gerätekennung und ein Firebase-Cloud-Messaging-Token können für Benachrichtigungen gespeichert werden."),
            LocalPrivacySection("Coins, Geschenke und Spiele", "Münzguthaben, Transaktionen, Geschenke und Spieldaten können bei Nutzung dieser Funktionen gespeichert werden."),
            LocalPrivacySection("Nutzung und Weitergabe", "Informationen dienen Konto, Nachrichten, sozialen Funktionen, Benachrichtigungen, Sicherheit und Betrieb. Erforderliche Dienstleister können Daten verarbeiten."),
            LocalPrivacySection("Sicherheit, Speicherung und Löschung", "Es werden angemessene Sicherheitsmaßnahmen eingesetzt. Daten werden so lange wie nötig gespeichert und das Konto kann gelöscht werden."),
            LocalPrivacySection("Wahlmöglichkeiten, Kinder und Updates", "Sie können Datenschutz- und Benachrichtigungseinstellungen verwalten. Der Dienst richtet sich nicht an Kinder unter dem gesetzlichen Mindestalter und diese Richtlinie kann aktualisiert werden.")
        )),
        "it" to LocalPrivacyDocument("V GHOST — Informativa sulla privacy", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Informazioni dell’account", "V GHOST tratta nickname, e-mail e password per gestire l’account. Le password sono conservate come hash."),
            LocalPrivacySection("Profilo e funzioni social", "I dati del profilo e quelli social possono essere trattati per le funzioni social."),
            LocalPrivacySection("Messaggi e messaggi vocali", "Messaggi, metadati e file vocali possono essere trattati secondo le regole di conservazione e cancellazione."),
            LocalPrivacySection("Notifiche e dati del dispositivo", "Un identificatore del dispositivo e un token Firebase possono essere conservati per le notifiche."),
            LocalPrivacySection("Coin, regali e giochi", "Saldi, transazioni, regali e dati delle partite possono essere conservati quando usi queste funzioni."),
            LocalPrivacySection("Uso e condivisione", "Le informazioni servono per account, messaggi, funzioni social, notifiche, sicurezza e servizio."),
            LocalPrivacySection("Sicurezza, conservazione ed eliminazione", "Sono adottate misure di sicurezza ragionevoli; i dati sono conservati quanto necessario e l’account può essere eliminato."),
            LocalPrivacySection("Scelte, minori e aggiornamenti", "Puoi gestire privacy e notifiche. Il servizio non è destinato ai minori sotto l’età minima prevista dalla legge e la policy può essere aggiornata.")
        )),
        "pt" to LocalPrivacyDocument("V GHOST — Política de Privacidade", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Informações da conta", "A V GHOST processa apelido, e-mail e senha para gerir a conta. As senhas são armazenadas como hash."),
            LocalPrivacySection("Perfil e recursos sociais", "Dados do perfil e dados sociais podem ser processados para recursos sociais."),
            LocalPrivacySection("Mensagens e mensagens de voz", "Mensagens, metadados e arquivos de voz podem ser processados conforme as regras de retenção e exclusão."),
            LocalPrivacySection("Notificações e dados do dispositivo", "Um identificador do dispositivo e um token do Firebase podem ser armazenados para enviar notificações."),
            LocalPrivacySection("Moedas, presentes e jogos", "Saldos, transações, presentes e dados das partidas podem ser armazenados ao usar esses recursos."),
            LocalPrivacySection("Uso e compartilhamento", "As informações são usadas para conta, mensagens, recursos sociais, notificações, segurança e operação."),
            LocalPrivacySection("Segurança, retenção e exclusão", "São usadas medidas razoáveis de segurança; os dados são mantidos quando necessário e a conta pode ser excluída."),
            LocalPrivacySection("Escolhas, crianças e atualizações", "Você pode gerenciar privacidade e notificações. O serviço não se destina a menores abaixo da idade legal mínima e esta política pode ser atualizada.")
        )),
        "ar" to LocalPrivacyDocument("V GHOST — سياسة الخصوصية", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("معلومات الحساب", "تعالج V GHOST اسم المستخدم والبريد الإلكتروني وكلمة المرور لإدارة الحساب، وتُخزن كلمات المرور على شكل تجزئة."),
            LocalPrivacySection("الملف الشخصي والميزات الاجتماعية", "قد تُعالج بيانات الملف الشخصي والبيانات الاجتماعية لتوفير الميزات الاجتماعية."),
            LocalPrivacySection("الرسائل والرسائل الصوتية", "قد تُعالج الرسائل والبيانات الوصفية وملفات الصوت وفق قواعد الاحتفاظ والحذف في الخدمة."),
            LocalPrivacySection("الإشعارات وبيانات الجهاز", "قد يتم حفظ معرّف الجهاز ورمز Firebase Cloud Messaging لإرسال الإشعارات."),
            LocalPrivacySection("العملات والهدايا والألعاب", "قد تُحفظ أرصدة العملات والمعاملات والهدايا ومعلومات جولات اللعب عند استخدام هذه الميزات."),
            LocalPrivacySection("الاستخدام والمشاركة", "تُستخدم المعلومات للحساب والرسائل والميزات الاجتماعية والإشعارات والأمان وتشغيل الخدمة."),
            LocalPrivacySection("الأمان والاحتفاظ والحذف", "تُستخدم إجراءات أمنية معقولة، وتُحفظ البيانات عند الحاجة ويمكن حذف الحساب."),
            LocalPrivacySection("الخيارات والأطفال والتحديثات", "يمكنك إدارة إعدادات الخصوصية والإشعارات. الخدمة ليست مخصصة للأطفال دون الحد الأدنى القانوني للعمر وقد تُحدّث السياسة.")
        )),
        "fa" to LocalPrivacyDocument("V GHOST — سیاست حریم خصوصی", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("اطلاعات حساب", "V GHOST نام کاربری، ایمیل و رمز عبور را برای مدیریت حساب پردازش می‌کند و رمزها به‌صورت هش ذخیره می‌شوند."),
            LocalPrivacySection("پروفایل و قابلیت‌های اجتماعی", "اطلاعات پروفایل و داده‌های اجتماعی ممکن است برای ارائه قابلیت‌های اجتماعی پردازش شوند."),
            LocalPrivacySection("پیام‌ها و پیام‌های صوتی", "پیام‌ها، فراداده‌ها و فایل‌های صوتی طبق قوانین نگهداری و حذف سرویس پردازش می‌شوند."),
            LocalPrivacySection("اعلان‌ها و داده‌های دستگاه", "برای ارسال اعلان‌ها ممکن است شناسه دستگاه و توکن Firebase Cloud Messaging ذخیره شود."),
            LocalPrivacySection("سکه، هدیه و بازی‌ها", "موجودی، تراکنش‌ها، هدایا و اطلاعات دورهای بازی هنگام استفاده از این قابلیت‌ها ممکن است ذخیره شوند."),
            LocalPrivacySection("استفاده و اشتراک‌گذاری", "اطلاعات برای حساب، پیام‌ها، قابلیت‌های اجتماعی، اعلان‌ها، امنیت و عملکرد سرویس استفاده می‌شود."),
            LocalPrivacySection("امنیت، نگهداری و حذف", "اقدامات امنیتی منطقی استفاده می‌شود؛ داده‌ها در صورت نیاز نگهداری و حساب قابل حذف است."),
            LocalPrivacySection("انتخاب‌ها، کودکان و به‌روزرسانی‌ها", "می‌توانید تنظیمات حریم خصوصی و اعلان‌ها را مدیریت کنید. سرویس برای کودکان زیر حداقل سن قانونی نیست و این سیاست ممکن است به‌روزرسانی شود.")
        )),
        "hi" to LocalPrivacyDocument("V GHOST — गोपनीयता नीति", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("खाता जानकारी", "V GHOST खाते के प्रबंधन के लिए उपनाम, ईमेल और पासवर्ड संसाधित करता है। पासवर्ड हैश के रूप में रखे जाते हैं।"),
            LocalPrivacySection("प्रोफ़ाइल और सामाजिक सुविधाएँ", "प्रोफ़ाइल और सामाजिक डेटा सामाजिक सुविधाएँ देने के लिए संसाधित किया जा सकता है।"),
            LocalPrivacySection("संदेश और वॉइस संदेश", "संदेश, मेटाडेटा और वॉइस फ़ाइलें सेवा के संग्रहण और हटाने के नियमों के अनुसार संसाधित की जा सकती हैं।"),
            LocalPrivacySection("सूचनाएँ और डिवाइस डेटा", "सूचनाएँ भेजने के लिए डिवाइस पहचानकर्ता और Firebase Cloud Messaging टोकन रखा जा सकता है।"),
            LocalPrivacySection("कॉइन, उपहार और गेम", "इन सुविधाओं का उपयोग करने पर कॉइन बैलेंस, लेनदेन, उपहार और गेम राउंड की जानकारी रखी जा सकती है।"),
            LocalPrivacySection("उपयोग और साझा करना", "जानकारी का उपयोग खाते, संदेश, सामाजिक सुविधाओं, सूचनाओं, सुरक्षा और सेवा संचालन के लिए होता है।"),
            LocalPrivacySection("सुरक्षा, रखरखाव और हटाना", "उचित सुरक्षा उपाय अपनाए जाते हैं; डेटा आवश्यकता अनुसार रखा जाता है और खाता हटाया जा सकता है।"),
            LocalPrivacySection("विकल्प, बच्चे और अपडेट", "आप गोपनीयता और सूचना सेटिंग नियंत्रित कर सकते हैं। सेवा कानूनी न्यूनतम आयु से कम बच्चों के लिए नहीं है और नीति अपडेट हो सकती है।")
        )),
        "ja" to LocalPrivacyDocument("V GHOST — プライバシーポリシー", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("アカウント情報", "V GHOSTはアカウント管理のためニックネーム、メールアドレス、パスワードを処理します。パスワードはハッシュとして保存されます。"),
            LocalPrivacySection("プロフィールとソーシャル機能", "プロフィール情報やソーシャルデータは、ソーシャル機能の提供のために処理される場合があります。"),
            LocalPrivacySection("メッセージと音声メッセージ", "メッセージ、メタデータ、音声ファイルは、サービスの保存・削除ルールに従って処理される場合があります。"),
            LocalPrivacySection("通知と端末データ", "通知を配信するため、端末識別子とFirebase Cloud Messagingトークンが保存される場合があります。"),
            LocalPrivacySection("コイン、ギフト、ゲーム", "これらの機能を利用すると、コイン残高、取引、ギフト、ゲームラウンド情報が保存される場合があります。"),
            LocalPrivacySection("利用と共有", "情報はアカウント、メッセージ、ソーシャル機能、通知、安全性、サービス運用に使用されます。"),
            LocalPrivacySection("セキュリティ、保存、削除", "合理的な安全対策を行います。データは必要な期間保存され、アカウントは削除できます。"),
            LocalPrivacySection("選択、子ども、更新", "プライバシーと通知設定を管理できます。法定最低年齢未満の子どもを対象としておらず、ポリシーは更新される場合があります。")
        )),
        "ko" to LocalPrivacyDocument("V GHOST — 개인정보 처리방침", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("계정 정보", "V GHOST는 계정 관리를 위해 닉네임, 이메일 및 비밀번호를 처리합니다. 비밀번호는 해시 형태로 저장됩니다."),
            LocalPrivacySection("프로필 및 소셜 기능", "프로필 정보와 소셜 데이터는 소셜 기능 제공을 위해 처리될 수 있습니다."),
            LocalPrivacySection("메시지 및 음성 메시지", "메시지, 메타데이터 및 음성 파일은 서비스의 보관 및 삭제 규칙에 따라 처리될 수 있습니다."),
            LocalPrivacySection("알림 및 기기 데이터", "알림 전송을 위해 기기 식별자와 Firebase Cloud Messaging 토큰이 저장될 수 있습니다."),
            LocalPrivacySection("코인, 선물 및 게임", "이 기능을 사용하면 코인 잔액, 거래, 선물 및 게임 라운드 정보가 저장될 수 있습니다."),
            LocalPrivacySection("이용 및 공유", "정보는 계정, 메시지, 소셜 기능, 알림, 보안 및 서비스 운영에 사용됩니다."),
            LocalPrivacySection("보안, 보관 및 삭제", "합리적인 보안 조치를 사용하며 필요한 기간 동안 데이터를 보관하고 계정을 삭제할 수 있습니다."),
            LocalPrivacySection("선택, 아동 및 업데이트", "개인정보 및 알림 설정을 관리할 수 있습니다. 법정 최소 연령 미만의 아동을 대상으로 하지 않으며 정책은 변경될 수 있습니다.")
        )),
        "zh" to LocalPrivacyDocument("V GHOST — 隐私政策", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("账户信息", "V GHOST会处理昵称、电子邮件和密码信息以管理账户。密码以哈希形式保存，而不是明文保存。"),
            LocalPrivacySection("个人资料和社交功能", "个人资料信息和社交数据可能会被处理，以提供社交功能。"),
            LocalPrivacySection("消息和语音消息", "消息、元数据和语音文件可能根据服务的保存和删除规则进行处理。"),
            LocalPrivacySection("通知和设备数据", "启用推送通知后，可能保存设备标识符和Firebase Cloud Messaging令牌以发送通知。"),
            LocalPrivacySection("金币、礼物和游戏", "使用这些功能时，金币余额、交易、礼物和游戏回合信息可能会被保存。"),
            LocalPrivacySection("使用和共享", "信息用于账户、消息、社交功能、通知、安全和服务运行。必要的服务提供商可能处理信息。"),
            LocalPrivacySection("安全、保留与删除", "我们采用合理的安全措施；数据会在必要期限内保存，账户可以删除。"),
            LocalPrivacySection("选择、儿童和更新", "你可以管理隐私和通知设置。V GHOST不面向低于适用法律最低年龄的儿童，本政策可能更新。")
        )),
        "id" to LocalPrivacyDocument("V GHOST — Kebijakan Privasi", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Informasi akun", "V GHOST memproses nama pengguna, email, dan kata sandi untuk mengelola akun. Kata sandi disimpan sebagai hash."),
            LocalPrivacySection("Profil dan fitur sosial", "Data profil dan sosial dapat diproses untuk menyediakan fitur sosial."),
            LocalPrivacySection("Pesan dan pesan suara", "Pesan, metadata, dan file suara dapat diproses sesuai aturan penyimpanan dan penghapusan layanan."),
            LocalPrivacySection("Notifikasi dan data perangkat", "ID perangkat dan token Firebase Cloud Messaging dapat disimpan untuk mengirim notifikasi."),
            LocalPrivacySection("Koin, hadiah, dan permainan", "Saldo koin, transaksi, hadiah, dan informasi ronde permainan dapat disimpan saat fitur digunakan."),
            LocalPrivacySection("Penggunaan dan berbagi", "Informasi digunakan untuk akun, pesan, fitur sosial, notifikasi, keamanan, dan pengoperasian layanan."),
            LocalPrivacySection("Keamanan, penyimpanan, dan penghapusan", "Langkah keamanan yang wajar digunakan; data disimpan sesuai kebutuhan dan akun dapat dihapus."),
            LocalPrivacySection("Pilihan, anak-anak, dan pembaruan", "Anda dapat mengatur privasi dan notifikasi. Layanan tidak ditujukan bagi anak di bawah usia minimum menurut hukum dan kebijakan dapat diperbarui.")
        )),
        "nl" to LocalPrivacyDocument("V GHOST — Privacybeleid", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Accountgegevens", "V GHOST verwerkt bijnaam, e-mail en wachtwoord om je account te beheren. Wachtwoorden worden als hash opgeslagen."),
            LocalPrivacySection("Profiel en sociale functies", "Profielgegevens en sociale gegevens kunnen worden verwerkt voor sociale functies."),
            LocalPrivacySection("Berichten en spraakberichten", "Berichten, metadata en spraakbestanden kunnen worden verwerkt volgens de bewaar- en verwijderregels van de dienst."),
            LocalPrivacySection("Meldingen en apparaatgegevens", "Een apparaat-ID en Firebase Cloud Messaging-token kunnen worden opgeslagen om meldingen te verzenden."),
            LocalPrivacySection("Coins, cadeaus en games", "Coin-saldi, transacties, cadeaus en spelrondegegevens kunnen worden opgeslagen wanneer je deze functies gebruikt."),
            LocalPrivacySection("Gebruik en delen", "Informatie wordt gebruikt voor accounts, berichten, sociale functies, meldingen, beveiliging en werking."),
            LocalPrivacySection("Beveiliging, bewaring en verwijdering", "Er worden redelijke beveiligingsmaatregelen gebruikt; gegevens worden zo lang als nodig bewaard en het account kan worden verwijderd."),
            LocalPrivacySection("Keuzes, kinderen en updates", "Je kunt privacy- en meldingsinstellingen beheren. De dienst is niet bedoeld voor kinderen onder de wettelijke minimumleeftijd en dit beleid kan worden bijgewerkt.")
        )),
        "pl" to LocalPrivacyDocument("V GHOST — Polityka prywatności", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Informacje o koncie", "V GHOST przetwarza pseudonim, e-mail i hasło w celu zarządzania kontem. Hasła są przechowywane jako skróty."),
            LocalPrivacySection("Profil i funkcje społecznościowe", "Dane profilu i dane społecznościowe mogą być przetwarzane w celu zapewnienia funkcji społecznościowych."),
            LocalPrivacySection("Wiadomości i wiadomości głosowe", "Wiadomości, metadane i pliki głosowe mogą być przetwarzane zgodnie z zasadami przechowywania i usuwania."),
            LocalPrivacySection("Powiadomienia i dane urządzenia", "Identyfikator urządzenia i token Firebase Cloud Messaging mogą być przechowywane do wysyłania powiadomień."),
            LocalPrivacySection("Monety, prezenty i gry", "Saldo monet, transakcje, prezenty i informacje o rundach gry mogą być przechowywane podczas korzystania z tych funkcji."),
            LocalPrivacySection("Wykorzystanie i udostępnianie", "Informacje służą kontu, wiadomościom, funkcjom społecznym, powiadomieniom, bezpieczeństwu i działaniu usługi."),
            LocalPrivacySection("Bezpieczeństwo, przechowywanie i usuwanie", "Stosowane są rozsądne środki bezpieczeństwa; dane są przechowywane tak długo, jak to konieczne, a konto można usunąć."),
            LocalPrivacySection("Wybory, dzieci i aktualizacje", "Możesz zarządzać prywatnością i powiadomieniami. Usługa nie jest przeznaczona dla dzieci poniżej ustawowego wieku minimalnego, a polityka może być aktualizowana.")
        )),
        "uk" to LocalPrivacyDocument("V GHOST — Політика конфіденційності", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Інформація про обліковий запис", "V GHOST обробляє нікнейм, електронну пошту та пароль для керування обліковим записом. Паролі зберігаються у вигляді хешів."),
            LocalPrivacySection("Профіль і соціальні функції", "Дані профілю та соціальні дані можуть оброблятися для надання соціальних функцій."),
            LocalPrivacySection("Повідомлення та голосові повідомлення", "Повідомлення, метадані та голосові файли можуть оброблятися відповідно до правил зберігання й видалення сервісу."),
            LocalPrivacySection("Сповіщення та дані пристрою", "Для надсилання сповіщень можуть зберігатися ідентифікатор пристрою та токен Firebase Cloud Messaging."),
            LocalPrivacySection("Монети, подарунки та ігри", "Баланс монет, транзакції, подарунки та інформація про ігрові раунди можуть зберігатися під час використання цих функцій."),
            LocalPrivacySection("Використання та передача", "Інформація використовується для облікового запису, повідомлень, соціальних функцій, сповіщень, безпеки та роботи сервісу."),
            LocalPrivacySection("Безпека, зберігання та видалення", "Застосовуються розумні заходи безпеки; дані зберігаються за потреби, а обліковий запис можна видалити."),
            LocalPrivacySection("Вибір, діти та оновлення", "Ви можете керувати налаштуваннями приватності та сповіщень. Сервіс не призначений для дітей молодших за встановлений законом мінімальний вік, а політика може оновлюватися.")
        )),
        "vi" to LocalPrivacyDocument("V GHOST — Chính sách quyền riêng tư", "Cette politique décrit la manière dont V GHOST traite les informations lors de l’utilisation de l’application et des services associés.", listOf(
            LocalPrivacySection("Thông tin tài khoản", "V GHOST xử lý biệt danh, email và mật khẩu để quản lý tài khoản. Mật khẩu được lưu dưới dạng mã băm."),
            LocalPrivacySection("Hồ sơ và tính năng xã hội", "Thông tin hồ sơ và dữ liệu xã hội có thể được xử lý để cung cấp các tính năng xã hội."),
            LocalPrivacySection("Tin nhắn và tin nhắn thoại", "Tin nhắn, siêu dữ liệu và tệp thoại có thể được xử lý theo quy tắc lưu trữ và xóa của dịch vụ."),
            LocalPrivacySection("Thông báo và dữ liệu thiết bị", "Mã nhận dạng thiết bị và mã thông báo Firebase Cloud Messaging có thể được lưu để gửi thông báo."),
            LocalPrivacySection("Coin, quà tặng và trò chơi", "Số dư Coin, giao dịch, quà tặng và thông tin vòng chơi có thể được lưu khi bạn sử dụng các tính năng này."),
            LocalPrivacySection("Sử dụng và chia sẻ", "Thông tin được dùng cho tài khoản, tin nhắn, tính năng xã hội, thông báo, bảo mật và vận hành dịch vụ."),
            LocalPrivacySection("Bảo mật, lưu trữ và xóa", "Các biện pháp bảo mật hợp lý được áp dụng; dữ liệu được lưu khi cần và tài khoản có thể được xóa."),
            LocalPrivacySection("Lựa chọn, trẻ em và cập nhật", "Bạn có thể quản lý cài đặt quyền riêng tư và thông báo. Dịch vụ không dành cho trẻ dưới độ tuổi tối thiểu theo luật và chính sách có thể được cập nhật.")
        ))
    )
    fun get(): LocalPrivacyDocument {
        val lang = Locale.getDefault().language.lowercase(Locale.ROOT)
        return docs[lang] ?: docs.getValue("en")
    }
}
