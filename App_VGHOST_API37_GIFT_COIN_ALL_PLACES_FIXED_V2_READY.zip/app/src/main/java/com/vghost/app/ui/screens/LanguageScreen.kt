package com.vghost.app.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.i18n.AppLocale
import com.vghost.app.i18n.tr
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.ui.theme.GhostRedPrimary

@Composable
fun LanguageScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var selected by remember { mutableStateOf(AppLocale.current(context)) }

    val languages = listOf(
        "az" to "🇦🇿", "tr" to "🇹🇷", "en" to "🇬🇧", "ru" to "🇷🇺",
        "es" to "🇪🇸", "fr" to "🇫🇷", "de" to "🇩🇪", "it" to "🇮🇹",
        "pt" to "🇵🇹", "ar" to "🇸🇦", "fa" to "🇮🇷", "hi" to "🇮🇳", "ja" to "🇯🇵", "ko" to "🇰🇷", "zh" to "🇨🇳", "id" to "🇮🇩", "nl" to "🇳🇱", "pl" to "🇵🇱", "uk" to "🇺🇦", "vi" to "🇻🇳"
    )

    Scaffold(
        modifier = Modifier.fillMaxSize().premiumBackdrop(),
        containerColor = Color.Transparent
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().height(64.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(GhostSurface.copy(alpha = .82f))
                        .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.ArrowBack, tr("Geri"), tint = GhostTextWhite)
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    tr("Dil"),
                    color = GhostTextWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(Modifier.height(8.dp))

            Column(
                Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                languages.chunked(4).forEach { rowLanguages ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowLanguages.forEach { (code, flag) ->
                            val active = code == selected
                            Box(
                                Modifier.weight(1f)
                                    .height(76.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (active) GhostRedPrimary.copy(alpha = .18f)
                                        else GhostSurface.copy(alpha = .84f)
                                    )
                                    .border(
                                        if (active) 2.dp else 1.dp,
                                        if (active) GhostRedPrimary else GhostBorder,
                                        RoundedCornerShape(16.dp)
                                    )
                                    .clickable {
                                        if (code != selected) {
                                            selected = code
                                            AppLocale.set(context.applicationContext, code)
                                            (context as? Activity)?.recreate()
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(flag, fontSize = 32.sp)
                            }
                        }
                        repeat(4 - rowLanguages.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                tr("Dil seçmək üçün bayrağa toxun"),
                color = GhostTextMuted,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}
