package com.vghost.app.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vghost.app.R
import com.vghost.app.i18n.tr
import com.vghost.app.ui.theme.GhostRedPrimary

/**
 * VGhost brand logo. The same supplied artwork is used throughout the app
 * so splash/login/register/chat/profile branding stays consistent.
 */
@Composable
fun GhostLogo(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    showHaloRing: Boolean = false,
    animateGlow: Boolean = true
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        if (showHaloRing) {
            Box(
                modifier = Modifier
                    .size(size * 0.94f)
                    .border(1.5.dp, GhostRedPrimary.copy(alpha = 0.70f), CircleShape)
            )
        }

        Image(
            painter = painterResource(id = R.drawable.vghost_logo_asset),
            contentDescription = "V Ghost",
            modifier = Modifier.size(size),
            contentScale = ContentScale.Fit,
            alpha = if (animateGlow) 1f else 0.98f
        )
    }
}

/**
 * Fixed VGhost profile/avatar mark. User-selectable avatars are intentionally disabled.
 */
@Composable
fun GhostAvatar(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    showBorder: Boolean = true,
    avatarId: String = "ghost",
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        // This is the user's fixed VGhost profile picture. The supplied artwork
        // has a transparent background, so no black square/circle is rendered.
        Image(
            painter = painterResource(id = avatarPainter(avatarId)),
            contentDescription = tr(if (avatarId.equals("male", true)) "Kişi avatarı" else if (avatarId.equals("female", true)) "Qadın avatarı" else "V Ghost profile picture"),
            modifier = Modifier.size(size),
            contentScale = ContentScale.Fit
        )
    }
}


fun avatarPainterId(avatarId: String): Int = when (avatarId.lowercase()) {
    "male", "male_red", "man" -> R.drawable.avatar_male_red
    "female", "female_white", "woman" -> R.drawable.avatar_female_white
    else -> R.drawable.profile_ghost_overlay
}

private fun avatarPainter(avatarId: String): Int = avatarPainterId(avatarId)


/**
 * Large profile Ghost with a gentle floating flight animation.
 * It stays inside the profile area and does not intercept touches.
 */
@Composable
fun FlyingGhost(
    modifier: Modifier = Modifier,
    size: Dp = 152.dp,
    avatarId: String = "ghost",
) {
    val transition = rememberInfiniteTransition(label = "profile_ghost_flight")
    val x = transition.animateFloat(
        initialValue = -7f,
        targetValue = 7f,
        animationSpec = infiniteRepeatable(
            animation = tween(4200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "profile_ghost_x"
    )
    val y = transition.animateFloat(
        initialValue = 0f,
        targetValue = -10f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "profile_ghost_y"
    )
    val tilt = transition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "profile_ghost_tilt"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = avatarPainter(avatarId)),
            contentDescription = tr(if (avatarId.equals("male", true)) "Kişi avatarı" else if (avatarId.equals("female", true)) "Qadın avatarı" else "V Ghost profile picture"),
            modifier = Modifier
                .size(size)
                .offset(x = x.value.dp, y = y.value.dp)
                .rotate(tilt.value),
            contentScale = ContentScale.Fit
        )
    }
}
