package com.vghost.app

import android.content.Context
import java.io.File

/** Keeps media cache bounded so repeated Reels/Story playback cannot consume device storage indefinitely. */
object StoryMediaCache {
    private const val MAX_STORY_CACHE_BYTES = 50L * 1024L * 1024L
    private const val TRIM_TO_BYTES = 40L * 1024L * 1024L

    fun directory(context: Context): File = File(context.cacheDir, "story_videos").apply { mkdirs() }

    fun fileFor(context: Context, key: String): File = File(directory(context), "story_video_$key.mp4")

    @Synchronized
    fun trim(context: Context, keep: File? = null) {
        val dir = directory(context)
        val files = dir.listFiles()?.filter { it.isFile }?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        if (total <= MAX_STORY_CACHE_BYTES) return
        for (file in files) {
            if (file == keep) continue
            if (total <= TRIM_TO_BYTES) break
            val len = file.length()
            if (file.delete()) total -= len
        }
    }

    /** Removes the legacy story files that were previously written directly to cacheDir. */
    fun removeLegacyFiles(context: Context) {
        context.cacheDir.listFiles()?.forEach { file ->
            if (file.isFile && file.name.startsWith("story_video_")) {
                runCatching { file.delete() }
            }
        }
        trim(context)
    }
}
