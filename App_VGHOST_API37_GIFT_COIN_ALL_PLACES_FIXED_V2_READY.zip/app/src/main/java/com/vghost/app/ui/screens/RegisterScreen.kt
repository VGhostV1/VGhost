package com.vghost.app.ui.screens

import kotlinx.coroutines.launch
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Pin
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.components.GhostAvatar
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostBorder
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostSurface
import com.vghost.app.ui.theme.GhostTextMuted
import com.vghost.app.ui.theme.GhostTextSecondary
import com.vghost.app.ui.theme.GhostTextWhite
import com.vghost.app.i18n.tr

@Composable
fun RegisterScreen(
    onRegisterSuccess: (String) -> Unit,
    onNavigateToLogin: () -> Unit = {},
    onEnterGhostMode: () -> Unit = {},
    onOpenPrivacyPolicy: () -> Unit = {},
    onOpenTerms: () -> Unit = {},
    modifier: Modifier = Modifier,
    repository: VGhostRepository = VGhostRepository.instance
) {
    var nickname by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var appPin by remember { mutableStateOf("") }
    var confirmAppPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    var isSubmitting by remember { mutableStateOf(false) }
    var legalAccepted by remember { mutableStateOf(false) }
    var gender by remember { mutableStateOf("male") }
    // Keep both the system back gesture/button and the visible arrow on the
    // same reliable navigation callback.
    BackHandler { onNavigateToLogin() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .premiumBackdrop()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .imePadding()
    ) {
        // Top Back Button
        IconButton(
            onClick = { onNavigateToLogin() },
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 12.dp, top = 8.dp)
                .testTag("register_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = tr("Back to Login"),
                tint = GhostTextWhite
            )
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            val compact = maxHeight < 700.dp
            val veryCompact = maxHeight < 620.dp
            val fieldHeight = if (veryCompact) 52.dp else if (compact) 54.dp else 56.dp
            val fieldGap = if (veryCompact) 7.dp else if (compact) 9.dp else 11.dp
            val sectionGap = if (veryCompact) 8.dp else if (compact) 12.dp else 18.dp
            val titleGap = if (veryCompact) 2.dp else 5.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = if (veryCompact) 4.dp else 8.dp, bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                Spacer(modifier = Modifier.height(if (veryCompact) 2.dp else 6.dp))

            Text(
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(color = GhostRedPrimary, fontWeight = FontWeight.Black)) {
                        append("V ")
                    }
                    withStyle(style = SpanStyle(color = GhostTextWhite, fontWeight = FontWeight.Bold)) {
                        append("GHOST")
                    }
                },
                fontSize = if (veryCompact) 21.sp else 23.sp,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(titleGap))

            Text(
                text = tr("Create your account"),
                color = GhostTextWhite,
                fontSize = if (veryCompact) 16.sp else 18.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(1.dp))

            Text(
                text = tr("Quick and simple."),
                color = GhostTextSecondary,
                fontSize = if (veryCompact) 12.sp else 13.sp
            )

            Spacer(modifier = Modifier.height(sectionGap))

            // 1. Nickname
            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it; errorMessage = null },
                placeholder = { Text(tr("Nickname"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_nickname_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            // 2. Recovery / login email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it; errorMessage = null },
                placeholder = { Text(tr("Email"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_email_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            // 3. Gender / avatar choice
            Text(
                text = tr("Sən kişisən, yoxsa qadın?"),
                color = GhostTextSecondary,
                fontSize = if (veryCompact) 11.sp else 12.sp,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("male" to tr("Kişi"), "female" to tr("Qadın")).forEach { (id, label) ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (gender == id) GhostRedPrimary.copy(alpha = .14f) else GhostSurface)
                            .border(1.dp, if (gender == id) GhostRedPrimary else GhostBorder, RoundedCornerShape(12.dp))
                            .clickable { gender = id; errorMessage = null }
                            .padding(vertical = if (veryCompact) 3.dp else 5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GhostAvatar(size = if (veryCompact) 38.dp else 46.dp, showBorder = false, avatarId = id)
                        Text(label, color = GhostTextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(fieldGap))

            // 4. Password
            OutlinedTextField(
                value = password,
                onValueChange = { password = it; errorMessage = null },
                placeholder = { Text(tr("Password"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Lock,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    IconButton(
                        onClick = { isPasswordVisible = !isPasswordVisible },
                        modifier = Modifier.testTag("toggle_register_password_visibility")
                    ) {
                        Icon(
                            imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = null,
                            tint = GhostTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next
                ),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_password_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            // 4. App PIN
            OutlinedTextField(
                value = appPin,
                onValueChange = { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) appPin = it; errorMessage = null },
                placeholder = { Text(tr("App PIN"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Pin,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Next
                ),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_pin_input")
            )

            Spacer(modifier = Modifier.height(fieldGap))

            // 4. Confirm App PIN
            OutlinedTextField(
                value = confirmAppPin,
                onValueChange = { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) confirmAppPin = it; errorMessage = null },
                placeholder = { Text(tr("Confirm App PIN"), color = GhostTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Pin,
                        contentDescription = null,
                        tint = GhostTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                colors = outlinedTextFieldColors(),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(fieldHeight).testTag("register_confirm_pin_input")
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = errorMessage ?: "",
                    color = GhostRedPrimary,
                    fontSize = if (veryCompact) 11.sp else 12.sp,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 7.dp else 12.dp))

            // PIN Security notice
            Text(
                text = tr("PIN protects your app.\nYou can change it later from Security settings."),
                color = GhostTextSecondary,
                fontSize = if (veryCompact) 10.sp else 11.sp,
                textAlign = TextAlign.Center,
                lineHeight = if (veryCompact) 13.sp else 15.sp
            )

            Spacer(modifier = Modifier.height(if (veryCompact) 8.dp else 14.dp))

            // Local legal acceptance is required before account creation.
            Row(
                modifier = Modifier.fillMaxWidth().clickable { legalAccepted = !legalAccepted },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = legalAccepted,
                    onCheckedChange = { legalAccepted = it }
                )
                Text(
                    text = tr("Privacy Policy və Terms & Conditions-i oxudum və qəbul edirəm."),
                    color = GhostTextSecondary,
                    fontSize = if (veryCompact) 10.sp else 11.sp,
                    lineHeight = 14.sp,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("Privacy Policy"),
                    color = GhostRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onOpenPrivacyPolicy)
                )
                Text("  •  ", color = GhostTextMuted, fontSize = 11.sp)
                Text(
                    text = tr("Terms & Conditions"),
                    color = GhostRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onOpenTerms)
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 7.dp else 10.dp))

            // Create Account Button
            Button(
                onClick = {
                    if (isSubmitting) return@Button
                    focusManager.clearFocus()
                    if (!legalAccepted) {
                        errorMessage = tr("Qeydiyyat üçün Privacy Policy və Terms & Conditions-i qəbul etməlisən.")
                    } else if (appPin != confirmAppPin) {
                        errorMessage = tr("PINs do not match")
                    } else {
                        isSubmitting = true
                        scope.launch {
                            errorMessage = repository.registerOnline(nickname.trim(), email.trim(), password, appPin, gender)
                            isSubmitting = false
                            if (errorMessage == null) onRegisterSuccess(nickname.trim())
                        }
                    }
                },
                enabled = !isSubmitting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GhostRedPrimary,
                    contentColor = GhostTextWhite
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (veryCompact) 46.dp else 50.dp)
                    .testTag("create_account_button")
            ) {
                Text(
                    text = tr("CREATE ACCOUNT"),
                    fontSize = if (veryCompact) 14.sp else 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 7.dp else 12.dp))

            // Already have an account? Login
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("Already have an account?"),
                    color = GhostTextSecondary,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = tr("Login"),
                    color = GhostRedPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToLogin() }
                        .testTag("register_login_link")
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 9.dp else 14.dp))

            // Secondary Action: CONTINUE AS GHOST
            OutlinedButton(
                onClick = {
                    focusManager.clearFocus()
                    onEnterGhostMode()
                },
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = GhostSurface.copy(alpha = 0.6f),
                    contentColor = GhostRedPrimary
                ),
                border = BorderStroke(1.dp, GhostRedPrimary.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (veryCompact) 44.dp else 48.dp)
                    .testTag("continue_as_ghost_button_register")
            ) {
                Text(
                    text = "👣 " + tr("Qonaq rejimi"),
                    color = GhostRedPrimary,
                    fontSize = if (veryCompact) 12.sp else 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(if (veryCompact) 3.dp else 8.dp))
            }
        }
    }
}

@Composable
private fun outlinedTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = GhostSurface,
    unfocusedContainerColor = GhostSurface,
    focusedBorderColor = GhostRedPrimary,
    unfocusedBorderColor = GhostBorder,
    focusedTextColor = GhostTextWhite,
    unfocusedTextColor = GhostTextWhite,
    cursorColor = GhostRedPrimary
)
