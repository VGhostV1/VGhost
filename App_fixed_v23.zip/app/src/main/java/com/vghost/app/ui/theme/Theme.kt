package com.vghost.app.ui.theme

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = GhostRedPrimary,
    onPrimary = GhostTextWhite,
    primaryContainer = GhostRedDark,
    onPrimaryContainer = GhostTextWhite,
    secondary = GhostCyan,
    onSecondary = GhostBlack,
    tertiary = GhostViolet,
    onTertiary = GhostTextWhite,
    tertiaryContainer = Color(0xFF30245A),
    onTertiaryContainer = GhostTextWhite,
    background = GhostBlack,
    onBackground = GhostTextWhite,
    surface = GhostSurface,
    onSurface = GhostTextWhite,
    surfaceVariant = GhostSurfaceElevated,
    onSurfaceVariant = GhostTextSecondary,
    outline = GhostBorder,
    outlineVariant = GhostBorderLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

/**
 * App-wide cinematic atmosphere. The movement is intentionally very slow and
 * subtle: it gives the app a living, premium feel without looking like a
 * neon-game UI.
 */
@Composable
fun NeonBackdrop(content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "vghost_atmosphere")
    val drift by transition.animateFloat(
        initialValue = -0.08f,
        targetValue = 0.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(9000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF18202B),
                        Color(0xFF0A0E14),
                        GhostBlack
                    ),
                    radius = 1250f
                )
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = (drift * 28f).dp)
                .alpha(0.75f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            GhostCyan.copy(alpha = 0.075f),
                            Color.Transparent
                        ),
                        radius = 850f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .offset(x = (-drift * 22f).dp)
                .alpha(0.75f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            GhostRedPrimary.copy(alpha = 0.075f),
                            Color.Transparent
                        ),
                        radius = 920f
                    )
                )
        )
        content()
    }
}
