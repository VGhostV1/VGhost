package com.vghost.app.ui.screens

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trKey
import com.vghost.app.i18n.localizedFilmCategory
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import android.content.pm.ActivityInfo
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.LocalMovies
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.vghost.app.data.model.Film
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.network.VGhostApi
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostCyan
import com.vghost.app.ui.theme.GhostViolet
import com.vghost.app.ui.theme.GhostRedGlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.delay
import kotlin.math.roundToLong

private val VideoRed = GhostRedPrimary

@Composable
fun FilmDetailScreen(filmId: Long, onBack: () -> Unit, onFilmSelected: (Long) -> Unit = {}, onAuthRequired: () -> Unit = {}) {
    var film by remember { mutableStateOf<Film?>(null) }
    var nextFilms by remember { mutableStateOf<List<Film>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    var fullscreen by remember { mutableStateOf(false) }
    var ratingBusy by remember { mutableStateOf(false) }
    var ratingMessage by remember { mutableStateOf("") }
    var pendingRating by remember { mutableStateOf<Int?>(null) }
    var selectedRating by remember { mutableStateOf(0) }
    var likeBusy by remember { mutableStateOf(false) }
    val likeScope = rememberCoroutineScope()
    LaunchedEffect(pendingRating) {
        val value = pendingRating ?: return@LaunchedEffect
        ratingBusy = true
        runCatching { if (VGhostApi.token().isNullOrBlank()) throw IllegalStateException("AUTH_REQUIRED") else VGhostApi.rateFilm(filmId, value) }.onSuccess { result ->
            val avg = result.optDouble("rating_average", film?.ratingAverage ?: 0.0)
            val count = result.optInt("rating_count", film?.ratingCount ?: 0)
            val mine = result.optInt("my_rating", value)
            selectedRating = mine
            film = film?.copy(ratingAverage = avg, ratingCount = count, myRating = mine)
            ratingMessage = tr("Qiymətləndirmən yadda saxlanıldı")
        }.onFailure { ratingMessage = tr("Qiymətləndirmə alınmadı") }
        ratingBusy = false
        pendingRating = null
    }

    LaunchedEffect(filmId) {
        try {
            val loaded = VGhostApi.film(filmId).optJSONObject("film")?.toFilm()
            film = loaded
            selectedRating = loaded?.myRating ?: 0
            if (loaded != null) {
                if (!VGhostApi.token().isNullOrBlank()) runCatching { VGhostApi.trackFilm(loaded.id, "view") }
                val result = VGhostApi.films(category = loaded.category)
                val a = result.optJSONArray("films")
                nextFilms = if (a != null) {
                    (0 until a.length()).mapNotNull { i ->
                        runCatching { a.getJSONObject(i).toFilm() }.getOrNull()
                    }.filter { it.id != loaded.id }.take(10)
                } else emptyList()
            }
        } catch (e: Throwable) {
            error = e.message.orEmpty()
        }
    }

    val activity = LocalContext.current as? Activity
    val downloadContext = LocalContext.current

    DisposableEffect(fullscreen) {
        activity?.let { a ->
            // Use a hard landscape/portrait lock and a jump-cut rotation so Android
            // does not leave the Activity in the partially-rotated/tilted state
            // seen on some devices when immersive fullscreen is entered.
            a.window.attributes = a.window.attributes.apply {
                rotationAnimation = WindowManager.LayoutParams.ROTATION_ANIMATION_JUMPCUT
            }
            a.requestedOrientation = if (fullscreen) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }

            val controller = WindowCompat.getInsetsController(a.window, a.window.decorView)
            if (fullscreen) {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose { }
    }

    BackHandler(enabled = fullscreen) { fullscreen = false }

    Box(Modifier.fillMaxSize().premiumBackdrop()) {
        if (film == null) {
            if (error.isNotBlank()) {
                Text(error, color = Color.White, modifier = Modifier.align(Alignment.Center).padding(24.dp))
            } else {
                CircularProgressIndicator(color = VideoRed, modifier = Modifier.align(Alignment.Center))
            }
        } else {
            val f = film!!
            // Keep a single FilmPlayer composable instance across normal/fullscreen
            // layout changes. Previously the player lived in two different branches,
            // so entering fullscreen disposed the old ExoPlayer and created a new one.
            // That made fullscreen appear briefly and then snap back/restart.
            val detailScrollState = rememberScrollState()
            Column(
                Modifier
                    .fillMaxSize()
                    .then(if (fullscreen) Modifier else Modifier.verticalScroll(detailScrollState))
            ) {
                if (!fullscreen) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 12.dp, start = 8.dp, end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White)
                        }
                        Text(f.title, color = Color.White, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                    }
                }

                FilmPlayer(
                    f.id,
                    f.videoUrl,
                    modifier = if (fullscreen) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                    isVip = f.isVip,
                    fullscreen = fullscreen,
                    onFullscreenChange = { fullscreen = it }
                )

                if (!fullscreen) {
                    FilmInfoBlock(f, selectedRating = selectedRating, ratingBusy = ratingBusy, likeBusy = likeBusy, onDownload = { enqueueFilmDownload(downloadContext, f) }, onRate = { value -> if (VGhostApi.token().isNullOrBlank()) onAuthRequired() else { selectedRating = value; pendingRating = value; ratingMessage = "" } }, onLike = {
                        if (VGhostApi.token().isNullOrBlank()) { onAuthRequired() } else if (!likeBusy) {
                            likeBusy = true
                            val previous = f
                            // Optimistic UI: the heart/count reacts immediately, then
                            // the server response becomes the source of truth.
                            film = previous.copy(
                                likedByMe = !previous.likedByMe,
                                likeCount = (previous.likeCount + if (previous.likedByMe) -1 else 1).coerceAtLeast(0)
                            )
                            likeScope.launch {
                                runCatching { VGhostApi.likeFilm(previous.id) }
                                    .onSuccess { r ->
                                        film = film?.copy(
                                            likeCount = r.optInt("like_count", film?.likeCount ?: 0),
                                            likedByMe = r.optBoolean("liked_by_me", film?.likedByMe ?: false)
                                        )
                                    }
                                    .onFailure {
                                        film = previous
                                        ratingMessage = tr("Bəyənmə alınmadı")
                                    }
                                likeBusy = false
                            }
                        }
                    })

                    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
                        if (nextFilms.isNotEmpty()) {
                            Spacer(Modifier.height(28.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.LocalMovies, null, tint = VideoRed, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(tr("Sıradakı Filmlər"), color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
                            }
                            Spacer(Modifier.height(12.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(nextFilms, key = { it.id }) { next ->
                                    FilmNextCard(next) {
                                        if (next.id != f.id) onFilmSelected(next.id)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilmPlayer(
    filmId: Long,
    url: String,
    modifier: Modifier = Modifier,
    isVip: Boolean = false,
    fullscreen: Boolean,
    onFullscreenChange: (Boolean) -> Unit
) {
    val context = LocalContext.current
    var playbackError by remember(url) { mutableStateOf<String?>(null) }
    var controlsVisible by remember(url) { mutableStateOf(true) }
    var position by remember(url) { mutableLongStateOf(0L) }
    var duration by remember(url) { mutableLongStateOf(0L) }
    var playTracked by remember(url) { mutableStateOf(false) }
    var muted by remember(url) { mutableStateOf(false) }
    var locked by remember(url) { mutableStateOf(false) }
    var tapHint by remember(url) { mutableStateOf("") }
    var vipWarningVisible by remember(url) { mutableStateOf(false) }
    var vipChecking by remember(url) { mutableStateOf(false) }
    val vipScope = rememberCoroutineScope()
    var videoAspectRatio by remember(url) { mutableFloatStateOf(16f / 9f) }

    val player = remember(url) {
        val http = DefaultHttpDataSource.Factory()
        if (VGhostApi.isSameApiOrigin(VGhostApi.absoluteUrl(url))) {
            VGhostApi.token()?.takeIf { it.isNotBlank() }?.let {
                http.setDefaultRequestProperties(mapOf("Authorization" to "Bearer $it"))
            }
        }
        val dataSource = DefaultDataSource.Factory(context, http)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSource))
            .build()
            .apply {
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        playbackError = when {
                            error.cause is HttpDataSource.InvalidResponseCodeException &&
                                (error.cause as HttpDataSource.InvalidResponseCodeException).responseCode == 403 && isVip ->
                                "VIP_FILM_REQUIRED"
                            else -> "VIDEO_PLAYBACK_FAILED"
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        duration = this@apply.duration.coerceAtLeast(0L)
                    }

                    override fun onVideoSizeChanged(videoSize: VideoSize) {
                        val ratio = if (videoSize.height > 0) {
                            (videoSize.width.toFloat() * videoSize.pixelWidthHeightRatio) / videoSize.height.toFloat()
                        } else 0f
                        if (ratio.isFinite() && ratio > 0f) {
                            videoAspectRatio = ratio.coerceIn(0.45f, 3.0f)
                        }
                    }
                })
                setMediaItem(MediaItem.fromUri(VGhostApi.absoluteUrl(url)))
                prepare()
                playWhenReady = false
            }
    }

    LaunchedEffect(player, filmId) {
        var lastWatchAt = System.currentTimeMillis()
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.takeIf { it > 0 } ?: 0L
            if (player.isPlaying && !playTracked) {
                playTracked = true
                if (!VGhostApi.token().isNullOrBlank()) runCatching { VGhostApi.trackFilm(filmId, "play") }
            }
            val now = System.currentTimeMillis()
            if (player.isPlaying && now - lastWatchAt >= 10_000L) {
                val seconds = ((now - lastWatchAt) / 1000L).toInt().coerceIn(1, 30)
                lastWatchAt = now
                if (!VGhostApi.token().isNullOrBlank()) runCatching { VGhostApi.trackFilm(filmId, "watch", seconds) }
            } else if (!player.isPlaying) {
                lastWatchAt = now
            }
            delay(250)
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    // FILM DETAIL PLAYER ONLY: keep the film page separate from the Trailer/Reels player.
    // Normal film playback uses a YouTube-like 16:9 stage; the real video is FIT inside it
    // so portrait videos are never stretched into a huge cropped block. Fullscreen keeps the
    // existing immersive behavior.
    val playerLayoutModifier = if (fullscreen) {
        modifier.fillMaxSize()
    } else {
        Modifier.fillMaxWidth().aspectRatio(16f / 9f)
    }

    Box(
        playerLayoutModifier.background(Color.Black).pointerInput(player, locked) {
            detectTapGestures { offset ->
                if (locked) return@detectTapGestures
                val half = size.width / 2f
                if (offset.x < half) {
                    player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                    tapHint = "↶ 10"
                } else {
                    val d = player.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
                    player.seekTo((player.currentPosition + 10_000L).coerceAtMost(d))
                    tapHint = "10 ↷"
                }
            }
        }
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    resizeMode = if (fullscreen) {
                        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    } else {
                        androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                    layoutParams = ViewGroup.LayoutParams(-1, -1)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (controlsVisible && playbackError == null) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, Color(0xD9000000))
                    )
                )
            )

            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    if (player.isPlaying) {
                        player.pause()
                    } else if (isVip) {
                        // VIP films must never start silently. Verify the current VIP
                        // entitlement first; only an active server-side VIP session
                        // is allowed to start playback.
                        vipChecking = true
                        vipScope.launch {
                            val activeVip = if (!VGhostApi.token().isNullOrBlank()) {
                                VGhostRepository.instance.refreshVipStatus()
                            } else {
                                false
                            }
                            vipChecking = false
                            if (activeVip) {
                                playbackError = null
                                player.play()
                            } else {
                                vipWarningVisible = true
                            }
                        }
                    } else {
                        player.play()
                    }
                }) {
                    Icon(
                        if (player.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (player.isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }

                Text(formatVideoTime(position), color = Color.White, style = MaterialTheme.typography.labelSmall, fontSize = 13.sp)

                NeonSeekBar(
                    position = position,
                    duration = duration,
                    modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
                    onSeek = { target ->
                        if (duration > 0) {
                            position = target.coerceIn(0L, duration)
                            player.seekTo(position)
                        }
                    }
                )

                Text(formatVideoTime(duration), color = Color.White, style = MaterialTheme.typography.labelSmall, fontSize = 13.sp)

                IconButton(onClick = { onFullscreenChange(!fullscreen) }) {
                    Icon(
                        if (fullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                        contentDescription = if (fullscreen) "Exit fullscreen" else "Fullscreen",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                IconButton(onClick = { muted = !muted; player.volume = if (muted) 0f else 1f }) {
                    Icon(if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, if (muted) tr("Səsi aç") else tr("Səsi kəs"), tint = Color.White, modifier = Modifier.size(27.dp))
                }

                IconButton(onClick = { locked = !locked; controlsVisible = !locked }) {
                    Icon(if (locked) Icons.Filled.Lock else Icons.Filled.LockOpen, if (locked) tr("Kilidi aç") else tr("Ekranı kilidlə"), tint = Color.White, modifier = Modifier.size(27.dp))
                }
            }
        }

        if (tapHint.isNotBlank()) {
            LaunchedEffect(tapHint) { delay(500); tapHint = "" }
            Box(Modifier.fillMaxSize(), contentAlignment = if (tapHint.startsWith("↶")) Alignment.CenterStart else Alignment.CenterEnd) {
                Text(tapHint, color = Color.White, fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.padding(28.dp).background(Color.Black.copy(.45f), RoundedCornerShape(14.dp)).padding(12.dp))
            }
        }

        if (locked) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopEnd) {
                IconButton(onClick = { locked = false; controlsVisible = true }) {
                    Icon(Icons.Filled.Lock, tr("Kilidi aç"), tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
        }

        if (vipWarningVisible) {
            AlertDialog(
                onDismissRequest = { if (!vipChecking) vipWarningVisible = false },
                title = {
                    Text(tr("👑 VIP video"))
                },
                text = {
                    Text(
                        tr("Bu film VIP-dir. Videonu izləmək üçün aktiv VIP üzvlüyü lazımdır."),
                        color = Color.White.copy(.82f)
                    )
                },
                confirmButton = {
                    TextButton(
                        enabled = !vipChecking,
                        onClick = {
                            vipWarningVisible = false
                            vipChecking = true
                            vipScope.launch {
                                val activeVip = if (!VGhostApi.token().isNullOrBlank()) {
                                    VGhostRepository.instance.refreshVipStatus()
                                } else false
                                vipChecking = false
                                if (activeVip) {
                                    playbackError = null
                                    player.play()
                                } else {
                                    // Keep the warning visible so a guest/user without
                                    // VIP cannot accidentally start a protected stream.
                                    vipWarningVisible = true
                                }
                            }
                        }
                    ) {
                        Text(if (vipChecking) tr("Yoxlanılır...") else tr("VIP-i aktiv et"))
                    }
                },
                dismissButton = {
                    TextButton(
                        enabled = !vipChecking,
                        onClick = { vipWarningVisible = false }
                    ) {
                        Text(tr("← Geri"))
                    }
                },
                containerColor = Color(0xFF130B14),
                titleContentColor = Color(0xFFFFD75A),
                textContentColor = Color.White
            )
        }

        playbackError?.let { code ->
            Box(
                Modifier.fillMaxSize().background(Color(0xCC09070B)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Text(
                        if (code == "VIP_FILM_REQUIRED") tr("Bu film VIP-dir") else tr("Video oynadıla bilmədi"),
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (code == "VIP_FILM_REQUIRED") tr("Videoya baxmaq üçün aktiv VIP üzvlük lazımdır.") else tr("Video serverdən yüklənə bilmədi. Bir az sonra yenidən cəhd et."),
                        color = Color.White.copy(.75f),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}



@Composable
private fun FilmInfoBlock(film: Film, selectedRating: Int = film.myRating, ratingBusy: Boolean = false, likeBusy: Boolean = false, onDownload: () -> Unit = {}, onRate: (Int) -> Unit = {}, onLike: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.size(width = 94.dp, height = 132.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, VideoRed.copy(.35f), RoundedCornerShape(12.dp))
        ) {
            NextFilmPoster(VGhostApi.absoluteUrl(film.posterUrl))
        }
        Column(Modifier.weight(1f)) {
            Text(film.title.ifBlank { "VGhost Film" }, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                if (film.category.isNotBlank()) FilmMetaChip(localizedFilmCategory(film.category))
                film.releaseYear?.let { FilmMetaChip(it.toString()) }
                film.durationMinutes?.let { FilmMetaChip("${it} dəq") }
                if (film.isVip) FilmMetaChip("VIP", accent = Color(0xFFFFC83D))
            }
            Spacer(Modifier.height(10.dp))
            Text(
                film.description.ifBlank { tr("Film haqqında məlumat burada görünəcək.") },
                color = Color.White.copy(.82f),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("👁 ${film.viewCount}", color = Color.White.copy(.65f), style = MaterialTheme.typography.labelMedium, fontSize = 14.sp)
                Text("★ ${if (film.ratingCount > 0) String.format("%.1f", film.ratingAverage) else "—"}", color = Color(0xFFFFC83D), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 14.sp)
                Text("(${film.ratingCount})", color = Color.White.copy(.45f), style = MaterialTheme.typography.labelSmall, fontSize = 13.sp)
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                (1..5).forEach { value ->
                    Text(
                        text = if (value <= selectedRating) "★" else "☆",
                        color = if (value <= selectedRating) Color(0xFFFFC83D) else Color.White.copy(.45f),
                        fontSize = 30.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        modifier = Modifier
                            .size(42.dp)
                            .clickable(enabled = !ratingBusy) { onRate(value) }
                            .padding(2.dp)
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .padding(top = 10.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(enabled = !likeBusy) { onLike() }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = if (film.likedByMe) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = if (film.likedByMe) tr("Bəyənməni geri götür") else tr("Bəyən"),
                    tint = if (film.likedByMe) VideoRed else Color.White,
                    modifier = Modifier.size(36.dp)
                )
                Text(
                    text = film.likeCount.toString(),
                    color = if (film.likedByMe) VideoRed else Color.White,
                    fontSize = 30.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
            }
            Spacer(Modifier.height(14.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(VideoRed.copy(.24f), Color(0xFF8B5CF6).copy(.20f), VideoRed.copy(.24f))))
                    .border(1.5.dp, VideoRed.copy(.85f), RoundedCornerShape(16.dp))
                    .clickable { onDownload() }
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text(trKey("download"), color = Color.White, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
                }
            }
        }
    }
}

private fun enqueueFilmDownload(context: Context, film: Film) {
    val url = VGhostApi.absoluteUrl(film.videoUrl)
    if (url.isBlank()) {
        Toast.makeText(context, trKey("film_download_failed"), Toast.LENGTH_SHORT).show()
        return
    }
    runCatching {
        val cleanTitle = film.title.ifBlank { "VGhost_Film" }.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').take(90)
        val ext = when {
            url.substringBefore('?').lowercase().endsWith(".mkv") -> "mkv"
            url.substringBefore('?').lowercase().endsWith(".webm") -> "webm"
            else -> "mp4"
        }
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(film.title.ifBlank { "VGhost Film" })
            .setDescription(trKey("downloading_ellipsis"))
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
            .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "$cleanTitle.$ext")
        VGhostApi.token()?.takeIf { it.isNotBlank() }?.let { request.addRequestHeader("Authorization", "Bearer $it") }
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(context, trKey("downloading_ellipsis"), Toast.LENGTH_SHORT).show()
    }.onFailure {
        Toast.makeText(context, trKey("film_download_failed"), Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun NeonSeekBar(
    position: Long,
    duration: Long,
    modifier: Modifier = Modifier,
    onSeek: (Long) -> Unit
) {
    val safeDuration = duration.coerceAtLeast(1L)
    BoxWithConstraints(
        modifier = modifier
            .height(24.dp)
            .pointerInput(safeDuration) {
                detectTapGestures { offset ->
                    val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                    onSeek((safeDuration * fraction).roundToLong())
                }
            }
            .pointerInput(safeDuration) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                        onSeek((safeDuration * fraction).roundToLong())
                    },
                    onDragEnd = {},
                    onDragCancel = {}
                ) { change, _ ->
                    val fraction = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                    onSeek((safeDuration * fraction).roundToLong())
                }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        val fraction = (position.coerceIn(0L, safeDuration).toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val y = size.height / 2f
            val left = 2f
            val right = size.width - 2f
            val trackWidth = right - left
            drawLine(
                brush = Brush.linearGradient(listOf(Color(0xFF24152F), Color(0xFF3540A8), Color(0xFF6A4CFF))),
                start = androidx.compose.ui.geometry.Offset(left, y),
                end = androidx.compose.ui.geometry.Offset(right, y),
                strokeWidth = 7f,
                cap = StrokeCap.Round
            )
            drawLine(
                brush = Brush.linearGradient(listOf(GhostRedPrimary, GhostCyan, GhostViolet)),
                start = androidx.compose.ui.geometry.Offset(left, y),
                end = androidx.compose.ui.geometry.Offset(left + trackWidth * fraction, y),
                strokeWidth = 7f,
                cap = StrokeCap.Round
            )
            val thumbX = left + trackWidth * fraction
            drawCircle(Color(0x55FF1493), 11f, androidx.compose.ui.geometry.Offset(thumbX, y))
            drawCircle(GhostRedGlow, 7f, androidx.compose.ui.geometry.Offset(thumbX, y))
            drawCircle(Color.White, 3f, androidx.compose.ui.geometry.Offset(thumbX, y))
        }
    }
}

@Composable
private fun FilmMetaChip(text: String, accent: Color = Color.White.copy(.72f)) {
    Box(Modifier.clip(RoundedCornerShape(9.dp)).background(Color.White.copy(.055f)).border(1.dp, accent.copy(.35f), RoundedCornerShape(9.dp)).padding(horizontal = 9.dp, vertical = 5.dp)) {
        Text(text, color = accent, style = MaterialTheme.typography.labelSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }
}

@Composable
private fun FilmNextCard(film: Film, onClick: () -> Unit) {
    Column(Modifier.width(118.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(166.dp).clip(RoundedCornerShape(13.dp)).border(1.dp, VideoRed.copy(.24f), RoundedCornerShape(13.dp))) {
            NextFilmPoster(VGhostApi.absoluteUrl(film.posterUrl))
            if (film.isVip) {
                Text("VIP", color = Color(0xFFFFC83D), style = MaterialTheme.typography.labelSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Black, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).clip(RoundedCornerShape(7.dp)).background(Color.Black.copy(.75f)).padding(horizontal = 6.dp, vertical = 3.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(film.title, color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 1)
        Text(localizedFilmCategory(film.category), color = Color.White.copy(.55f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun NextFilmPoster(url: String) {
    var bitmap by remember(url) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(url) {
        if (url.isNotBlank()) bitmap = withContext(Dispatchers.IO) {
            runCatching {
                (URL(url).openConnection() as HttpURLConnection).run {
                    connectTimeout = 7000
                    readTimeout = 10000
                    inputStream.use { BitmapFactory.decodeStream(it) }
                }
            }.getOrNull()
        }
    }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    else Box(Modifier.fillMaxSize().background(Color(0xFF180A18)), contentAlignment = Alignment.Center) {
        Icon(Icons.Outlined.LocalMovies, null, tint = VideoRed.copy(.45f), modifier = Modifier.size(42.dp))
    }
}

private fun formatVideoTime(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds)
    else "%d:%02d".format(minutes, seconds)
}

private fun org.json.JSONObject.toFilm() = Film(
    optLong("id"),
    optString("title"),
    optString("description"),
    optString("poster_url"),
    optString("video_url"),
    optString("category"),
    if (has("release_year") && !isNull("release_year")) optInt("release_year") else null,
    if (has("duration_minutes") && !isNull("duration_minutes")) optInt("duration_minutes") else null,
    optInt("is_vip") == 1 || optBoolean("is_vip"),
    optInt("is_featured") == 1 || optBoolean("is_featured"),
    optInt("view_count"), optInt("play_count"), optDouble("rating_average", 0.0), optInt("rating_count"), optInt("my_rating"), optInt("like_count"), optBoolean("liked_by_me")
)
