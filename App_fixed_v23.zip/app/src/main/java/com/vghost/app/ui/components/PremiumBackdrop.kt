package com.vghost.app.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.vghost.app.ui.theme.GhostBlack
import com.vghost.app.ui.theme.GhostCyan
import com.vghost.app.ui.theme.GhostGold
import com.vghost.app.ui.theme.GhostRedPrimary
import com.vghost.app.ui.theme.GhostViolet

/** Shared cinematic premium backdrop used behind screens. */
fun Modifier.premiumBackdrop(): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF070A0F),
                GhostBlack,
                Color(0xFF040508)
            )
        )
    )

    // Large, soft atmospheric lights. These are deliberately low-alpha.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GhostCyan.copy(alpha = 0.085f),
                Color.Transparent
            ),
            center = Offset(w * 0.12f, h * 0.10f),
            radius = w * 0.72f
        ),
        center = Offset(w * 0.12f, h * 0.10f),
        radius = w * 0.72f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GhostRedPrimary.copy(alpha = 0.085f),
                Color.Transparent
            ),
            center = Offset(w * 0.92f, h * 0.28f),
            radius = w * 0.82f
        ),
        center = Offset(w * 0.92f, h * 0.28f),
        radius = w * 0.82f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                GhostViolet.copy(alpha = 0.055f),
                Color.Transparent
            ),
            center = Offset(w * 0.52f, h * 0.78f),
            radius = w * 0.80f
        ),
        center = Offset(w * 0.52f, h * 0.78f),
        radius = w * 0.80f
    )

    // Fine diagonal light cuts add depth without dominating the UI.
    val streaks = listOf(
        Triple(Offset(-w * 0.10f, h * 0.18f), Offset(w * 0.35f, -h * 0.02f), GhostCyan),
        Triple(Offset(w * 0.70f, -h * 0.02f), Offset(w * 1.10f, h * 0.18f), GhostRedPrimary),
        Triple(Offset(-w * 0.06f, h * 0.88f), Offset(w * 0.28f, h * 1.04f), GhostViolet),
        Triple(Offset(w * 0.78f, h * 1.03f), Offset(w * 1.08f, h * 0.86f), GhostCyan)
    )
    streaks.forEach { (start, end, tint) ->
        drawLine(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, tint.copy(alpha = 0.12f), Color.Transparent),
                start = start,
                end = end
            ),
            start = start,
            end = end,
            strokeWidth = 1.4f
        )
    }

    // One restrained champagne-gold arc: premium rather than "neon".
    drawArc(
        brush = Brush.sweepGradient(
            listOf(Color.Transparent, GhostGold.copy(alpha = 0.10f), Color.Transparent)
        ),
        startAngle = 198f,
        sweepAngle = 74f,
        useCenter = false,
        topLeft = Offset(-w * 0.10f, h * 0.58f),
        size = Size(w * 1.20f, w * 1.20f),
        style = Stroke(width = 1.6f)
    )

    // Tiny particles are sparse and low-contrast.
    val particles = listOf(
        0.08f to 0.13f, 0.16f to 0.21f, 0.83f to 0.17f, 0.91f to 0.28f,
        0.27f to 0.08f, 0.73f to 0.10f, 0.12f to 0.54f, 0.88f to 0.62f,
        0.22f to 0.76f, 0.78f to 0.81f, 0.48f to 0.07f, 0.54f to 0.92f
    )
    particles.forEachIndexed { i, (x, y) ->
        val tint = when (i % 3) {
            0 -> GhostCyan
            1 -> GhostRedPrimary
            else -> GhostGold
        }
        drawCircle(
            color = tint.copy(alpha = if (i % 4 == 0) 0.22f else 0.08f),
            radius = if (i % 4 == 0) 1.6f else 0.8f,
            center = Offset(w * x, h * y)
        )
    }
}
