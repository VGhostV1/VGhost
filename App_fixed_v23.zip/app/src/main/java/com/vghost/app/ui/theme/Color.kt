package com.vghost.app.ui.theme

import androidx.compose.ui.graphics.Color

// VGhost premium palette: cinematic, deep, elegant and high-contrast.
// Neon is used only as a restrained accent; the app should feel luxurious,
// not like every surface is glowing.
val GhostBlack = Color(0xFF05070B)
val GhostDarkBackground = Color(0xFF080B11)
val GhostSurface = Color(0xFF0E1219)
val GhostSurfaceElevated = Color(0xFF141A23)
val GhostSurfaceHighlight = Color(0xFF1C2430)
val GhostBorder = Color(0xFF27313D)
val GhostBorderLight = Color(0xFF394655)

// Primary accent: cinematic crimson / coral rather than hot pink.
val GhostRedPrimary = Color(0xFFFF4F6D)
val GhostRedHover = Color(0xFFFF6B7F)
val GhostRedDark = Color(0xFF7F2338)
val GhostRedGlow = Color(0xFFFF8A9A)
val GhostRedBannerBg = Color(0xFF1A0D14)
val GhostRedBannerBorder = Color(0xFF7A3144)

// Premium accent colors.
val GhostCyan = Color(0xFF5DE7FF)
val GhostBlue = Color(0xFF6C8CFF)
val GhostViolet = Color(0xFFA78BFA)
val GhostGold = Color(0xFFFFD166)
val GhostGoldSoft = Color(0xFFFFE3A1)

// Extra visual-depth colors.
val GhostSurfaceGlass = Color(0xCC101720)
val GhostSurfaceGlassStrong = Color(0xEE141B24)
val GhostNeonSoft = GhostCyan
val GhostNeonDim = Color(0xFF24495A)
val GhostShadowRed = Color(0x99030006)
val GhostWhiteSoft = Color(0xFFF7F9FC)

// Typography & content colors.
val GhostTextWhite = Color(0xFFF7F9FC)
val GhostTextSecondary = Color(0xFFB7C0CC)
val GhostTextMuted = Color(0xFF727D8A)
val GhostTextRed = Color(0xFFFF8A9A)

// Status & encrypted badges.
val GhostStatusOnline = Color(0xFF35E58B)
val GhostStatusOffline = Color(0xFFFFFFFF)
val GhostGoldBg = Color(0xFF1D180D)
val GhostGoldBorder = Color(0xFF4B3A18)
val GhostGoldText = GhostGold
