package com.vghost.app.i18n

import android.content.Context
import java.security.MessageDigest

/** Resource-backed translation lookup without runtime resource-name reflection. */
internal object TranslationResources {
    fun textKey(context: Context, key: String): String? {
        val id = TranslationKeyIds.id(key)
        if (id == 0) return null
        return runCatching { AppLocale.wrap(context).getString(id) }.getOrNull()
    }

    fun text(context: Context, source: String): String? {
        val name = "t_" + MessageDigest.getInstance("SHA-1")
            .digest(source.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }.take(12)
        return textKey(context, name)
    }
}
