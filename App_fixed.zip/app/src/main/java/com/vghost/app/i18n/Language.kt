package com.vghost.app.i18n

import android.content.Context
import java.util.Locale

/** Resource-backed UI translation facade. */
object VGhostLanguage {
    @Volatile private var appContext: Context? = null

    internal fun init(context: Context) { appContext = context.applicationContext }
    internal fun context(): Context? = appContext

    fun trKey(key: String): String {
        val context = appContext ?: return "—"
        val id = TranslationKeyIds.id(key)
        if (id == 0) return "—"
        val localized = AppLocale.wrap(context)
        return runCatching { localized.getString(id) }.getOrElse { "—" }
    }

    fun tr(source: String): String {
        val context = appContext ?: return source
        return TranslationResources.text(AppLocale.wrap(context), source) ?: source
    }

    fun trf(source: String, vararg args: Any): String =
        runCatching { String.format(Locale.getDefault(), tr(source), *args) }.getOrDefault(tr(source))

    fun trfKey(key: String, vararg args: Any): String =
        runCatching { String.format(Locale.getDefault(), trKey(key), *args) }.getOrDefault(trKey(key))
}

fun tr(source: String): String = VGhostLanguage.tr(source)
fun trf(source: String, vararg args: Any): String = VGhostLanguage.trf(source, *args)
fun trfKey(key: String, vararg args: Any): String = VGhostLanguage.trfKey(key, *args)
fun trKey(key: String): String = VGhostLanguage.trKey(key)
