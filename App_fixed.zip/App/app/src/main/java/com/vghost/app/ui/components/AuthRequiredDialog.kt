package com.vghost.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Small non-navigating gate used when a guest taps an authenticated feature. */
@Composable
fun AuthRequiredDialog(
    onDismiss: () -> Unit,
    onLogin: () -> Unit,
    onRegister: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF120A12),
        titleContentColor = Color.White,
        textContentColor = Color(0xFFB9B4C4),
        title = {
            Text("🔐 Hesab tələb olunur", fontWeight = FontWeight.Black, fontSize = 20.sp)
        },
        text = {
            Text("Bu funksiyadan istifadə etmək üçün qeydiyyatdan keçin və ya hesabınıza daxil olun.")
        },
        confirmButton = {
            Column(Modifier.fillMaxWidth()) {
                Button(
                    onClick = onRegister,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744))
                ) { Text("Qeydiyyatdan keç", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = onLogin, modifier = Modifier.fillMaxWidth()) {
                    Text("Daxil ol", color = Color(0xFFB96CFF), fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("← Geri", color = Color(0xFF9EA0AA))
                }
            }
        }
    )
}
