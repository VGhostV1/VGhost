package com.vghost.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import com.vghost.app.data.model.GiftCatalog
import com.vghost.app.ui.components.GiftReceivedOverlay
import com.vghost.app.ui.components.LevelUpOverlay
import com.vghost.app.ui.components.AuthRequiredDialog
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.vghost.app.data.state.VGhostRepository
import com.vghost.app.i18n.AppLocale
import com.vghost.app.ui.components.NavTab
import com.vghost.app.ui.screens.ChatScreen
import com.vghost.app.ui.screens.AdminScreen
import com.vghost.app.ui.screens.FindByNicknameScreen
import com.vghost.app.ui.screens.VipScreen
import com.vghost.app.ui.screens.HomeScreen
import com.vghost.app.ui.screens.FilmHomeScreen
import com.vghost.app.ui.screens.FilmDetailScreen
import com.vghost.app.ui.screens.AdminFilmsScreen
import com.vghost.app.ui.screens.LoginScreen
import com.vghost.app.ui.screens.PanicScreen
import com.vghost.app.ui.screens.StoryScreen
import com.vghost.app.ui.screens.PinLockScreen
import com.vghost.app.ui.screens.ProfileScreen
import com.vghost.app.ui.screens.OtherProfileScreen
import com.vghost.app.ui.screens.RegisterScreen
import com.vghost.app.ui.screens.SettingsScreen
import com.vghost.app.ui.screens.LanguageScreen
import com.vghost.app.ui.screens.PrivacyScreen
import com.vghost.app.ui.screens.LegalDocument
import com.vghost.app.ui.screens.LegalDocumentScreen
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object AppRoutes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val FILMS = "films"
    const val FILM_DETAIL = "film_detail/{filmId}"
    const val FIND = "find"
    const val VIP = "vip"
    const val PANIC = "panic"
    const val STORY = "story"
    const val STORY_WITH_ID = "story?storyId={storyId}"
    const val CHAT = "chat/{nickname}"
    const val PIN_LOCK = "pin_lock"
    const val ADMIN = "admin"
    const val ADMIN_FILMS = "admin_films"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val LANGUAGE = "language"
    const val PRIVACY = "privacy"
    const val PRIVACY_POLICY = "privacy_policy"
    const val TERMS = "terms"
    const val OTHER_PROFILE = "other_profile/{nickname}?uid={uid}&online={online}&vip={vip}"

    fun filmDetailRoute(id: Long): String = "film_detail/$id"

    fun chatRoute(nickname: String): String {
        val encoded = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "chat/$encoded"
    }

    fun otherProfileRoute(nickname: String): String {
        val encoded = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "other_profile/$encoded?online=false&vip=false"
    }

    fun otherProfileRouteWithUid(uid: String, nickname: String, online: Boolean, vip: Boolean = false): String {
        val encodedUid = URLEncoder.encode(uid, StandardCharsets.UTF_8.toString())
        val encodedNickname = URLEncoder.encode(nickname, StandardCharsets.UTF_8.toString())
        return "other_profile/$encodedNickname?uid=$encodedUid&online=$online&vip=$vip"
    }
}

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    initialChatNickname: String? = null,
    initialNotificationTarget: String? = null,
    initialNotificationTargetValue: String? = null,
    navController: NavHostController = rememberNavController()
) {
    val giftEvent by VGhostRepository.instance.giftReceivedEvent.collectAsState()
    val levelUpEvent by VGhostRepository.instance.levelUpEvent.collectAsState()
    val sessionState by VGhostRepository.instance.sessionState.collectAsState()
    val appLanguage by AppLocale.language.collectAsState()
    val context = LocalContext.current
    var authReturnRoute by remember { mutableStateOf<String?>(null) }
    var showAuthRequiredDialog by remember { mutableStateOf(false) }
    var hadAuthenticatedSession by remember { mutableStateOf(sessionState is com.vghost.app.data.state.SessionState.LoggedInNormalUser) }

    // A fresh install is allowed to browse the public movie area. We only
    // force Login after an already-authenticated session becomes logged out
    // (for example after an explicit logout or an invalidated session).
    LaunchedEffect(sessionState) {
        if (sessionState is com.vghost.app.data.state.SessionState.LoggedInNormalUser) {
            hadAuthenticatedSession = true
        } else if (hadAuthenticatedSession &&
            navController.currentDestination?.route != AppRoutes.LOGIN &&
            navController.currentDestination?.route != AppRoutes.REGISTER) {
            navController.navigate(AppRoutes.LOGIN) {
                popUpTo(0) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    fun requireAuth(returnRoute: String) {
        if (sessionState is com.vghost.app.data.state.SessionState.LoggedInNormalUser) {
            navController.navigate(returnRoute) { launchSingleTop = true }
        } else {
            authReturnRoute = returnRoute
            showAuthRequiredDialog = true
        }
    }

    fun openLoginForPendingDestination() {
        showAuthRequiredDialog = false
        navController.navigate(AppRoutes.LOGIN) { launchSingleTop = true }
    }

    fun openRegisterForPendingDestination() {
        showAuthRequiredDialog = false
        navController.navigate(AppRoutes.REGISTER) { launchSingleTop = true }
    }
    Box(modifier.fillMaxSize()) {
        // Changing language rebuilds the whole destination subtree, so every
        // screen immediately reads the new translations, not only Panic.
        key(appLanguage) {
    NavHost(
        navController = navController,
        // Keep an authenticated local session on process recreation. If the
        // repository has an account/session, MainActivity handles the PIN gate
        // first; after unlock navigation must open Home, not Login.
        startDestination = when {
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && !initialChatNickname.isNullOrBlank() -> AppRoutes.chatRoute(initialChatNickname)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("chat", true) && !initialNotificationTargetValue.isNullOrBlank() -> AppRoutes.chatRoute(initialNotificationTargetValue)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("profile", true) && !initialNotificationTargetValue.isNullOrBlank() -> AppRoutes.otherProfileRoute(initialNotificationTargetValue)
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("profile", true) -> AppRoutes.PROFILE
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("home", true) -> AppRoutes.HOME
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("find", true) -> AppRoutes.FIND
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser && initialNotificationTarget.equals("admin", true) -> AppRoutes.ADMIN
            VGhostRepository.instance.sessionState.value is com.vghost.app.data.state.SessionState.LoggedInNormalUser -> AppRoutes.FILMS
            else -> AppRoutes.FILMS
        },
        modifier = modifier,
        // Smooth app-wide transitions compatible with the Compose version used by this project.
        enterTransition = {
            fadeIn(animationSpec = tween(220)) +
                slideInHorizontally(animationSpec = tween(280)) { it / 8 }
        },
        exitTransition = {
            fadeOut(animationSpec = tween(160)) +
                slideOutHorizontally(animationSpec = tween(220)) { -it / 12 }
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(200)) +
                slideInHorizontally(animationSpec = tween(260)) { -it / 8 }
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(140)) +
                slideOutHorizontally(animationSpec = tween(200)) { it / 12 }
        }
    ) {
        // 1. Login Screen
        composable(AppRoutes.LOGIN) {
            LoginScreen(
                onLoginSuccess = { nickname ->
                    val destination = authReturnRoute ?: AppRoutes.FILMS
                    authReturnRoute = null
                    navController.navigate(destination) {
                        popUpTo(AppRoutes.LOGIN) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(AppRoutes.REGISTER) {
                        launchSingleTop = true
                    }
                },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
            )
        }

        // Language picker is available before login and from Profile.
        composable(AppRoutes.LANGUAGE) {
            LanguageScreen(onBack = { navController.popBackStack() })
        }

        // 2. Register Screen
        composable(AppRoutes.REGISTER) {
            RegisterScreen(
                onRegisterSuccess = { nickname ->
                    val destination = authReturnRoute ?: AppRoutes.FILMS
                    authReturnRoute = null
                    navController.navigate(destination) {
                        popUpTo(AppRoutes.REGISTER) { inclusive = true }
                        popUpTo(AppRoutes.LOGIN) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToLogin = {
                    // The Register screen's top-left arrow must ALWAYS return
                    // directly to Login. Do not use popBackStack here because
                    // the previous destination can vary after process restore
                    // or nested navigation. Remove Register from the stack and
                    // land on Login deterministically.
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.REGISTER) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onOpenPrivacyPolicy = { navController.navigate(AppRoutes.PRIVACY_POLICY) },
                onOpenTerms = { navController.navigate(AppRoutes.TERMS) }
            
            )
        }

        // 3. Home / Chats Screen
        composable(AppRoutes.HOME) {
            HomeScreen(
                onChatClicked = { nickname ->
                    navController.navigate(AppRoutes.chatRoute(nickname))
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.CHATS -> {} // Already on Home
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                },
                onNotificationTarget = { notification ->
                    when (notification.target.lowercase()) {
                        "chat" -> if (notification.targetValue.isNotBlank()) navController.navigate(AppRoutes.chatRoute(notification.targetValue)) { launchSingleTop = true }
                        "profile" -> if (notification.targetValue.isNotBlank()) navController.navigate(AppRoutes.otherProfileRoute(notification.targetValue)) { launchSingleTop = true } else navController.navigate(AppRoutes.PROFILE) { launchSingleTop = true }
                        "story" -> {
                            val sid = notification.targetValue.toLongOrNull() ?: 0L
                            navController.navigate(if (sid > 0L) "story?storyId=$sid" else AppRoutes.STORY) { launchSingleTop = true }
                        }
                        "films" -> navController.navigate(AppRoutes.FILMS) { launchSingleTop = true }
                        "find" -> navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                        "admin" -> navController.navigate(AppRoutes.ADMIN) { launchSingleTop = true }
                        "link" -> {
                            val value = notification.targetValue.trim()
                            try {
                                val uri = Uri.parse(value)
                                if ((uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) && uri.host != null) {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                } else {
                                    navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                                }
                            } catch (_: Throwable) {
                                navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                            }
                        }
                        else -> navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                    }
                }
            )
        }

        // Film catalog. The seven-tap logo shortcut remains the hidden Admin entry.
        composable(AppRoutes.FILMS) {
            FilmHomeScreen(
                onAdminSecret = { navController.navigate(AppRoutes.ADMIN) },
                onFilmSelected = { id -> navController.navigate(AppRoutes.filmDetailRoute(id)) },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> {}
                        NavTab.CHATS -> requireAuth(AppRoutes.HOME)
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> requireAuth(AppRoutes.PROFILE)
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        composable(
            AppRoutes.FILM_DETAIL,
            arguments = listOf(navArgument("filmId") { type = NavType.LongType })
        ) { entry ->
            FilmDetailScreen(
                filmId = entry.arguments?.getLong("filmId") ?: 0L,
                onBack = { navController.popBackStack() },
                onFilmSelected = { id -> navController.navigate(AppRoutes.filmDetailRoute(id)) { launchSingleTop = true } },
                onAuthRequired = { authReturnRoute = navController.currentDestination?.route ?: AppRoutes.FILMS; showAuthRequiredDialog = true }
            )
        }

        // 4. Super Admin Control Room (inside the Android app)
        composable(AppRoutes.ADMIN) {
            AdminScreen(
                onBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) { launchSingleTop = true }
                    }
                },
                onOpenFilms = { navController.navigate(AppRoutes.ADMIN_FILMS) },
                onAdminRejected = {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.ADMIN) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 5. VIP subscription / benefits screen
        // except for the crown shortcut in its top-right corner.
        composable(AppRoutes.VIP) {
            VipScreen(
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                    }
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        // 6. Find by Nickname Screen
        composable(AppRoutes.FIND) {
            FindByNicknameScreen(
                onOpenVip = { requireAuth(AppRoutes.VIP) },
                onOpenChat = { nickname -> requireAuth(AppRoutes.chatRoute(nickname)) },
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.FIND) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                },
                onUserSelected = { user ->
                    navController.navigate(AppRoutes.otherProfileRouteWithUid(user.uid, user.nickname, user.online, user.isVip))
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.CHATS -> requireAuth(AppRoutes.HOME)
                        NavTab.FIND -> {} // Already on Find
                        NavTab.PROFILE -> requireAuth(AppRoutes.PROFILE)
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        composable(AppRoutes.ADMIN_FILMS) {
            AdminFilmsScreen(onBack = { navController.popBackStack() })
        }

        // 5. Other User Profile
        composable(
            route = AppRoutes.OTHER_PROFILE,
            arguments = listOf(
                navArgument("nickname") { type = NavType.StringType },
                navArgument("uid") { type = NavType.StringType; nullable = true; defaultValue = null },
                navArgument("online") { type = NavType.BoolType; defaultValue = false },
                navArgument("vip") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val nickname = URLDecoder.decode(backStackEntry.arguments?.getString("nickname").orEmpty(), StandardCharsets.UTF_8.toString())
            val initialUid = backStackEntry.arguments?.getString("uid")?.let { URLDecoder.decode(it, StandardCharsets.UTF_8.toString()) }
            val initialOnline = backStackEntry.arguments?.getBoolean("online") ?: false
            val initialVip = backStackEntry.arguments?.getBoolean("vip") ?: false
            OtherProfileScreen(
                nickname = nickname,
                initialUid = initialUid,
                initialOnline = initialOnline,
                initialVip = initialVip,
                onNavigateBack = {
                    if (!navController.popBackStack()) navController.navigate(AppRoutes.FIND) { launchSingleTop = true }
                },
                onOpenChat = { target -> navController.navigate(AppRoutes.chatRoute(target)) },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                }
            )
        }

        // 6. Profile Screen
        composable(AppRoutes.PROFILE) {
            ProfileScreen(
                onOpenSettings = { navController.navigate(AppRoutes.SETTINGS) },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> {} // Already on My Profile; repeated taps must not re-enter/reload it.
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { launchSingleTop = true }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                    }
                },
                onOpenPanic = { navController.navigate(AppRoutes.PANIC) { launchSingleTop = true } },
                onLogout = {
                    // Explicit user logout: clear the local App PIN as well as the session.
                    // Network outages never call this path, so offline sessions remain intact.
                    VGhostRepository.instance.logoutAndClearLocalPin()
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.PROFILE) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 6. Chat Screen (Text Only)

        composable(AppRoutes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenLanguage = { navController.navigate(AppRoutes.LANGUAGE) },
                onOpenPrivacy = { navController.navigate(AppRoutes.PRIVACY) },
                onOpenPrivacyPolicy = { navController.navigate(AppRoutes.PRIVACY_POLICY) },
                onOpenTerms = { navController.navigate(AppRoutes.TERMS) },
                onAccountDeleted = {
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(AppRoutes.SETTINGS) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(AppRoutes.PRIVACY) {
            PrivacyScreen(onBack = { navController.popBackStack() })
        }

        composable(AppRoutes.PRIVACY_POLICY) {
            LegalDocumentScreen(LegalDocument.PRIVACY_POLICY, onBack = { navController.popBackStack() })
        }

        composable(AppRoutes.TERMS) {
            LegalDocumentScreen(LegalDocument.TERMS, onBack = { navController.popBackStack() })
        }

        composable(
            route = AppRoutes.CHAT,
            arguments = listOf(navArgument("nickname") { type = NavType.StringType })
        ) { backStackEntry ->
            val encodedNickname = backStackEntry.arguments?.getString("nickname") ?: "Shadow_7"
            val decodedNickname = URLDecoder.decode(encodedNickname, StandardCharsets.UTF_8.toString())
            ChatScreen(
                recipientNickname = decodedNickname,
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // 6. Story / Status screen
        composable(AppRoutes.STORY_WITH_ID, arguments = listOf(navArgument("storyId") { type = NavType.LongType; defaultValue = 0L })) { backStackEntry ->
            val initialStoryId = backStackEntry.arguments?.getLong("storyId") ?: 0L
            val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
            val storyVisible = currentRoute?.startsWith("story") == true
            StoryScreen(
                initialStoryId = initialStoryId,
                isVisible = storyVisible,
                onOpenRegister = { openRegisterForPendingDestination() },
                onAuthRequired = { authReturnRoute = AppRoutes.STORY; showAuthRequiredDialog = true },
                onBack = { if (!navController.popBackStack()) navController.navigate(AppRoutes.HOME) { launchSingleTop = true } },
                onOpenProfile = { uid, nickname ->
                    navController.navigate(AppRoutes.otherProfileRouteWithUid(uid.toString(), nickname, false)) { launchSingleTop = true }
                },
                onOpenFilm = { filmId ->
                    if (filmId > 0L) navController.navigate(AppRoutes.filmDetailRoute(filmId)) { launchSingleTop = true }
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.CHATS -> requireAuth(AppRoutes.HOME)
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.PROFILE -> requireAuth(AppRoutes.PROFILE)
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) { popUpTo(AppRoutes.HOME) { inclusive = false }; launchSingleTop = true }
                        NavTab.STORY -> {}
                    }
                }
            )
        }

        // 7. Panic Screen — opened from My Profile
        composable(AppRoutes.PANIC) {
            PanicScreen(
                onPanicActivated = {
                    // Panic permanently deletes the account on the backend.
                    // Immediately leave the authenticated navigation graph; there is
                    // no guest/anonymous fallback after account deletion.
                    navController.navigate(AppRoutes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onTabSelected = { tab ->
                    when (tab) {
                        NavTab.FILMS -> navController.navigate(AppRoutes.FILMS) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.CHATS -> navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.FIND -> navController.navigate(AppRoutes.FIND) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.PROFILE -> navController.navigate(AppRoutes.PROFILE) { launchSingleTop = true }
                        NavTab.PANIC -> navController.navigate(AppRoutes.PANIC) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                        NavTab.STORY -> navController.navigate(AppRoutes.STORY) {
                            popUpTo(AppRoutes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }

        // 7. App Lock / PIN Entry Screen
        composable(AppRoutes.PIN_LOCK) {
            PinLockScreen(
                onUnlockSuccess = {
                    navController.navigate(AppRoutes.HOME) {
                        popUpTo(AppRoutes.PIN_LOCK) { inclusive = true }
                    }
                },
                onNavigateBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(AppRoutes.HOME) {
                            popUpTo(AppRoutes.PIN_LOCK) { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                }
            )
        }
    }
        } // key(appLanguage)
    if (showAuthRequiredDialog) {
        AuthRequiredDialog(
            onDismiss = { showAuthRequiredDialog = false; authReturnRoute = null },
            onLogin = { openLoginForPendingDestination() },
            onRegister = { openRegisterForPendingDestination() }
        )
    }
    giftEvent?.let { event -> GiftCatalog.find(event.giftId)?.let { gift -> GiftReceivedOverlay(gift, event.sender, event.token) { VGhostRepository.instance.clearGiftReceived(event.token) } } }
    levelUpEvent?.let { event -> LevelUpOverlay(event.level, event.coins, event.token) { VGhostRepository.instance.clearLevelUpEvent(event.token) } }
    }
}
