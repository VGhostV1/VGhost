package com.vghost.app.ui.screens

import android.content.Context
import com.vghost.app.R

data class LocalPrivacySection(val title: String, val body: String)
data class LocalPrivacyDocument(val title: String, val intro: String, val sections: List<LocalPrivacySection>)

object VGhostLocalPrivacyPolicy {
    fun get(context: Context): LocalPrivacyDocument {
        fun s(id: Int): String = context.getString(id)

        // Never call getString(0): getIdentifier() returns 0 when a localized
        // resource is missing, which previously caused Privacy Policy to crash.
        fun optionalString(name: String): String? {
            val id = context.resources.getIdentifier(name, "string", context.packageName)
            if (id == 0) return null
            return runCatching { s(id) }.getOrNull()?.takeIf { it.isNotBlank() }
        }

        val sections = (1..8).mapNotNull { i ->
            val title = optionalString("privacy_s${i}_title")
            val body = optionalString("privacy_s${i}_body")
            if (title == null || body == null) null else LocalPrivacySection(title, body)
        }

        return LocalPrivacyDocument(
            s(R.string.privacy_title),
            s(R.string.privacy_intro),
            sections
        )
    }
}
