package com.vghost.app.ui.screens
import com.vghost.app.i18n.trKey

import com.vghost.app.i18n.tr
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.vghost.app.data.state.VGhostRepository
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vghost.app.ui.components.premiumBackdrop
import com.vghost.app.ui.theme.*

private const val PREFS = "vghost_privacy"
private const val MESSAGE_KEY = "message_permission"
private const val FRIEND_KEY = "friend_permission"

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var friendPermission by remember { mutableStateOf(prefs.getString(FRIEND_KEY, "everyone") ?: "everyone") }
    var openMenu by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val repository = remember { VGhostRepository.instance }
    val scope = rememberCoroutineScope()
    val friendOptions = listOf(trKey("everyone") to "everyone", trKey("nobody") to "nobody")

    LaunchedEffect(Unit) {
        if (repository.hasAccount()) {
            val remote = repository.getPrivacySettings()
            friendPermission = remote.second
            prefs.edit().putString(MESSAGE_KEY, "everyone").putString(FRIEND_KEY, remote.second).apply()
        }
    }
    fun saveFriendPrivacy(friend: String = friendPermission) {
        friendPermission = friend
        prefs.edit().putString(MESSAGE_KEY, "everyone").putString(FRIEND_KEY, friend).apply()
        if (repository.hasAccount()) scope.launch {
            saving = true
            repository.updatePrivacySettings("everyone", friend)
            saving = false
        }
    }

    Scaffold(modifier = Modifier.fillMaxSize().premiumBackdrop(), containerColor = Color.Transparent) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(GhostSurface.copy(alpha = .78f))
                        .border(1.dp, GhostBorder, RoundedCornerShape(14.dp))
                        .clickable(onClick = onBack), contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.ArrowBack, trKey("back"), tint = GhostTextWhite) }
                Spacer(Modifier.width(12.dp))
                Text(trKey("privacy"), color = GhostTextWhite, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                if (saving) { Spacer(Modifier.weight(1f)); CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) }
            }
            Spacer(Modifier.height(12.dp))

            Text(trKey("messages_friends"), color = GhostTextWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(trKey("choose_who_can_message_send_friend_requests"), color = GhostTextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))

            PrivacyChoice(
                icon = Icons.Outlined.Chat,
                title = trKey("messages"),
                subtitle = trKey("who_can_message"),
                selected = trKey("everyone"),
                expanded = false,
                options = emptyList(),
                onExpand = {},
                onSelect = {}
            )
            Spacer(Modifier.height(10.dp))
            PrivacyChoice(
                icon = Icons.Outlined.PersonAdd,
                title = trKey("friend_requests"),
                subtitle = trKey("who_can_send_friend_requests"),
                selected = friendOptions.firstOrNull { it.second == friendPermission }?.first ?: trKey("everyone"),
                expanded = openMenu == "friends",
                options = friendOptions,
                onExpand = { openMenu = if (openMenu == "friends") null else "friends" },
                onSelect = { saveFriendPrivacy(it); openMenu = null }
            )
        }
    }
}

@Composable
private fun PrivacyChoice(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    selected: String,
    expanded: Boolean,
    options: List<Pair<String, String>>,
    onExpand: () -> Unit,
    onSelect: (String) -> Unit
) {
    Box {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(GhostSurface.copy(alpha = .82f))
                .border(1.dp, GhostBorder, RoundedCornerShape(16.dp))
                .clickable(onClick = onExpand).padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = GhostTextWhite, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = GhostTextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = GhostTextMuted, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(selected, color = GhostTextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Icon(Icons.Outlined.ChevronRight, null, tint = GhostTextMuted)
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { onExpand() }) {
            options.forEach { (label, value) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(value) })
            }
        }
    }
}
