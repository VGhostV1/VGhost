package com.vghost.app.i18n

/** Short, localized film-category labels. Backend values stay canonical; only UI labels are translated. */
fun localizedFilmCategory(value: String): String {
    val key = when (value.trim().lowercase()) {
        "aksiya", "action" -> "film_cat_action"
        "komediya", "komedi", "comedy" -> "film_cat_comedy"
        "dram", "drama" -> "film_cat_drama"
        "romantik", "romantika", "romance", "romantic" -> "film_cat_romance"
        "qorxu", "korku", "horror" -> "film_cat_horror"
        "fantastika", "fantasy" -> "film_cat_fantasy"
        "macəra", "macera", "adventure" -> "film_cat_adventure"
        "triller", "thriller" -> "film_cat_thriller"
        "detektiv", "detective" -> "film_cat_detective"
        "kriminal", "crime", "cinayət" -> "film_cat_crime"
        "döyüş", "doyus", "döyüş filmi", "martial arts" -> "film_cat_action"
        "animasiya", "animation" -> "film_cat_animation"
        "ailə", "aile", "family" -> "film_cat_family"
        "tarixi", "historical" -> "film_cat_historical"
        "tarix", "history" -> "film_cat_history"
        "sənədli", "senedli", "documentary" -> "film_cat_documentary"
        "musiqili", "musical" -> "film_cat_musical"
        "elmi-fantastika", "science fiction", "sci-fi" -> "film_cat_scifi"
        "bioqrafiya", "biography" -> "film_cat_biography"
        "misteriya", "mystery", "sirr" -> "film_cat_mystery"
        else -> return value
    }
    return trKey(key)
}
