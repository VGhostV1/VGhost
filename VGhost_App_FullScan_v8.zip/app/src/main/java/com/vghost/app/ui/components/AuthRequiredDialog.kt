package com.vghost.app.ui.components

import com.vghost.app.i18n.tr
import com.vghost.app.i18n.trKey
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AuthRequiredDialog(
    onRegister: () -> Unit,
    onLogin: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(.88f),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF100911),
            tonalElevation = 10.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 26.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(tr("🔐 Hesab tələb olunur"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(16.dp))
                Text(
                    tr("Bu funksiyadan istifadə etmək üçün qeydiyyatdan keçin və ya hesabınıza daxil olun."),
                    color = Color(0xFFBDB4C5),
                    fontSize = 16.sp,
                    lineHeight = 23.sp
                )
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = onRegister,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744))
                ) {
                    Text(tr("Qeydiyyatdan keç"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(7.dp))
                TextButton(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                    Text(trKey("login"), color = Color(0xFFB86CFF), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text(tr("← Geri"), color = Color(0xFFA9A1AE), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}
