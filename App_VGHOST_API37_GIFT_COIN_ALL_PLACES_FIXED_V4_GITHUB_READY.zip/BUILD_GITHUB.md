# VGhost Android GitHub Actions Build

This project is prepared for GitHub Actions release builds.

- Android Gradle Plugin: 9.1.2
- Gradle: 9.3.1
- Kotlin Compose Gradle plugin: 2.4.20
- JDK: 17
- Compile/Target SDK: 37
- Workflow: `.github/workflows/android-release.yml`

## Important

GitHub Actions installs Gradle 9.3.1 **before** invoking `./gradlew`. The workflow then generates the official Gradle Wrapper 9.3.1 and runs the release build through that wrapper.

This avoids the previous failure where the custom `gradlew` bootstrap tried to download `gradle-wrapper.jar` from `raw.githubusercontent.com` before Gradle had been installed.

The generated wrapper files are verified before the build starts.

GitHub Actions produces:

`app/build/outputs/apk/release/app-release.apk`

and uploads it as the `VGhost-release-apk` artifact.
