package com.vghost.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize

private val DarkColorScheme = darkColorScheme(
    primary = GhostRedPrimary,
    onPrimary = GhostTextWhite,
    primaryContainer = GhostRedDark,
    onPrimaryContainer = GhostTextWhite,
    secondary = GhostNeonSoft,
    onSecondary = GhostBlack,
    tertiary = Color(0xFF8A5CFF),
    onTertiary = GhostTextWhite,
    tertiaryContainer = Color(0xFF35146B),
    onTertiaryContainer = GhostTextWhite,
    background = GhostBlack,
    onBackground = GhostTextWhite,
    surface = GhostSurface,
    onSurface = GhostTextWhite,
    surfaceVariant = GhostSurfaceElevated,
    onSurfaceVariant = GhostTextSecondary,
    outline = GhostBorder,
    outlineVariant = GhostBorderLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}


/** Subtle app-wide cyber/neon backdrop used behind every screen. */
@Composable
fun NeonBackdrop(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF241044),
                        Color(0xFF0D1020),
                        GhostBlack
                    ),
                    radius = 1100f
                )
            )
    ) {
        androidx.compose.foundation.layout.Box(
            modifier = androidx.compose.ui.Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0x1200E5FF),
                            Color.Transparent,
                            Color(0x18FF2BD6)
                        )
                    )
                )
        )
        content()
    }
}
