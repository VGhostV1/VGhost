package com.vghost.app.data.state

import org.json.JSONObject

import com.vghost.app.i18n.NotificationTranslations

import com.vghost.app.network.PushManager
import android.content.Context
import android.util.Base64
import com.vghost.app.data.model.*
import com.vghost.app.i18n.tr
import com.vghost.app.network.VGhostApi
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

sealed interface SessionState { data object LoggedOut:SessionState; data class LoggedInNormalUser(val nickname:String):SessionState; data object LoggedInGhost:SessionState }

/** Production repository: PHP/MySQL owns identity, sessions, chat, wallet and social data. FCM is push-only. */
class VGhostRepository private constructor() {
    companion object { val instance: VGhostRepository by lazy { VGhostRepository() }; private const val DAY=86400000L; private const val RESTORE_TIMEOUT_MS=5000L; private const val PREF_LAST_NICKNAME="last_logged_in_nickname"; private const val PREF_AVATAR_ID="avatar_id" }
    private lateinit var appContext: Context
    private var initialized=false
    private val prefs get()=appContext.getSharedPreferences("vghost_device_security",Context.MODE_PRIVATE)
    private val apiScope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private val _sessionState=MutableStateFlow<SessionState>(SessionState.LoggedOut); val sessionState=_sessionState.asStateFlow()
    private val _forcedLogoutMessage=MutableStateFlow<String?>(null); val forcedLogoutMessage=_forcedLogoutMessage.asStateFlow()
    private val _sessionRestoring=MutableStateFlow(true); val sessionRestoring=_sessionRestoring.asStateFlow()
    private val _chats=MutableStateFlow<List<ChatSummary>>(emptyList()); val chats=_chats.asStateFlow()
    private val _messages=MutableStateFlow<Map<String,List<ChatMessage>>>(emptyMap()); val messages=_messages.asStateFlow()
    private val pendingOutgoing=mutableMapOf<String, MutableList<ChatMessage>>()
    private val _recentSearches=MutableStateFlow<List<RecentSearch>>(emptyList()); val recentSearches=_recentSearches.asStateFlow()
    private val _isPanicActivated=MutableStateFlow(false); val isPanicActivated=_isPanicActivated.asStateFlow()
    private val _isGhostMode=MutableStateFlow(false); val isGhostMode=_isGhostMode.asStateFlow()
    private val _currentUserNickname=MutableStateFlow(""); val currentUserNickname=_currentUserNickname.asStateFlow()
    private val _currentUserStatus=MutableStateFlow("Offline"); val currentUserStatus=_currentUserStatus.asStateFlow()
    private val _currentUserAvatarId=MutableStateFlow("ghost"); val currentUserAvatarId=_currentUserAvatarId.asStateFlow()
    private val _isAppLocked=MutableStateFlow(false); val isAppLocked=_isAppLocked.asStateFlow()
    private val _appLockEnabled=MutableStateFlow(false); val appLockEnabled=_appLockEnabled.asStateFlow()
    private val _appPin=MutableStateFlow(""); val appPin=_appPin.asStateFlow()
    private val _ghostCoins=MutableStateFlow(0); val ghostCoins=_ghostCoins.asStateFlow()
    data class LevelUpEvent(val level:Int, val coins:Int = 100, val token:Long = System.currentTimeMillis())
    private val _levelUpEvent=MutableStateFlow<LevelUpEvent?>(null); val levelUpEvent=_levelUpEvent.asStateFlow()
    private var knownActivityLevel:Int?=null
    private val _guestMode=MutableStateFlow(false); val guestMode=_guestMode.asStateFlow()
    private data class GuestRound(val bet:Int, val mineCount:Int, val game:String, val crashAt:Double = 0.0, val revealed:MutableSet<Int> = mutableSetOf(), val mineIndexes:Set<Int> = emptySet(), var board:MutableList<Int> = mutableListOf(), var score:Int = 0, var moves:Int = 20, var combo:Int = 0, val timeLimit:Int = 60, val target:Int = 1000, val level:Int = 1, val startedAtMs:Long = System.currentTimeMillis())
    private val guestRounds=mutableMapOf<String, GuestRound>()
    data class AppNotification(
        val id: Long = 0,
        val type: String = "general",
        val title: String,
        val body: String,
        val isRead: Boolean = false,
        val createdAt: String = "",
        val target: String = "home",
        val targetValue: String = "",
        val giftId: String = "",
        val giftKey: String = "",
        val senderNickname: String = "",
        val count: Int = 1
    )
    private val _notifications=MutableStateFlow<List<AppNotification>>(emptyList()); val notifications=_notifications.asStateFlow()
    data class GiftReceivedEvent(val giftId:String, val sender:String, val token:Long=System.currentTimeMillis())
    private val _giftReceivedEvent=MutableStateFlow<GiftReceivedEvent?>(null); val giftReceivedEvent=_giftReceivedEvent.asStateFlow()
    val unreadNotificationCount = notifications.map { list -> list.filter { !it.isRead }.sumOf { it.count.coerceAtLeast(1) } }.stateIn(apiScope, SharingStarted.Eagerly, 0)
    private val _isSuperAdmin=MutableStateFlow(false); val isSuperAdmin=_isSuperAdmin.asStateFlow()
    private val syncJobs=mutableMapOf<String,Job>()
    private var chatListSyncJob:Job?=null
    private var presenceHeartbeatJob:Job?=null
    private var activityLevelSyncJob:Job?=null
    @Volatile private var appInForeground=false
    @Volatile private var activeChatNickname: String? = null
    // Chat performance: cache nickname -> numeric user id and serialize per-chat loads.
    private val chatUidCache=mutableMapOf<String,Int>()
    private val chatLoadLocks=mutableMapOf<String,kotlinx.coroutines.sync.Mutex>()
    // Prevent stale async responses from a previous account/session from overwriting the active wallet.
    @Volatile private var walletSessionEpoch=0L
    @Volatile private var sessionEpoch=0L
    private fun invalidateWalletSession(){ walletSessionEpoch++ }
    private fun resetSessionState(){
        walletSessionEpoch++; sessionEpoch++
        _ghostCoins.value=0; _isSuperAdmin.value=false; _guestMode.value=false; guestRounds.clear()
        _chats.value=emptyList(); _messages.value=emptyMap(); _recentSearches.value=emptyList(); pendingOutgoing.clear()
        _notifications.value=emptyList(); _isGhostMode.value=false
        knownActivityLevel=null; _levelUpEvent.value=null
        syncJobs.values.forEach { it.cancel() }; syncJobs.clear(); chatListSyncJob?.cancel(); chatListSyncJob=null; presenceHeartbeatJob?.cancel(); presenceHeartbeatJob=null; activityLevelSyncJob?.cancel(); activityLevelSyncJob=null
        chatUidCache.clear(); chatLoadLocks.clear()
        _currentUserNickname.value=""; _currentUserStatus.value="Offline"; _currentUserAvatarId.value="ghost"
    }

    fun initialize(context:Context){
        if(initialized)return; appContext=context.applicationContext; VGhostApi.init(appContext); initialized=true
        VGhostApi.setAuthFailureHandler { reason -> forceServerLogout(reason) }
        _appLockEnabled.value=prefs.getBoolean("lock_enabled",false)
        val token=VGhostApi.token()
        if(!token.isNullOrBlank()) apiScope.launch { restoreSession() } else _sessionRestoring.value=false
    }
    private fun forceServerLogout(reason:String){
        val message = if (reason.equals("banned", true))
            "Hesabınız administrator tərəfindən bloklandı."
        else
            "Hesabınız silinib və ya sessiya artıq etibarlı deyil."
        purgeLocalAccountData()
        _appLockEnabled.value=false
        _isAppLocked.value=false
        _forcedLogoutMessage.value=message
        resetSessionState()
        _sessionState.value=SessionState.LoggedOut
    }

    fun consumeForcedLogoutMessage(){ _forcedLogoutMessage.value=null }
    private suspend fun restoreSession(){
        val epoch=sessionEpoch
        try {
            // Never keep the first screen blank behind a slow server request.
            val r=withTimeout(RESTORE_TIMEOUT_MS){ VGhostApi.call("auth/me") }
            val u=r.optJSONObject("user") ?: throw IllegalStateException("INVALID_SESSION")
            if(u.optBoolean("is_banned")) throw IllegalStateException("banned")
            val n=u.optString("nickname")
            if(n.isBlank()) throw IllegalStateException("INVALID_SESSION")
            if(epoch!=sessionEpoch || !hasAccount()) return
            _sessionState.value=SessionState.LoggedInNormalUser(n)
            _currentUserNickname.value=n
            val avatarId=u.optString("avatarId", prefs.getString(PREF_AVATAR_ID,"ghost").orEmpty()).ifBlank { "ghost" }
            _currentUserAvatarId.value=avatarId
            prefs.edit().putString(PREF_LAST_NICKNAME,n).putString(PREF_AVATAR_ID,avatarId).apply()
            _currentUserStatus.value=if(u.optBoolean("ghostMode",false)) "Ghost" else "Online"
            _isGhostMode.value=u.optBoolean("ghostMode",false)
            // auth/me already contains the authoritative wallet. Apply it immediately so
            // stealth mode can never leave the game header temporarily stuck at 0.
            applyWalletFromResponse(r)
            _isAppLocked.value=_appLockEnabled.value
            // Release the UI immediately; secondary server sync must never block startup.
            _sessionRestoring.value=false
            apiScope.launch { refreshMyWallet() }
            apiScope.launch { refreshAdminStatus() }
            apiScope.launch { updateStatus(true) }
            startChatListSync()
            PushManager.syncToken(appContext)
            startPresenceHeartbeat()
            startActivityLevelSync()
            refreshNotifications()
        } catch(t:Throwable){
            // Network/offline errors must NEVER log the user out. Keep the saved
            // session token and restore the last known identity locally. Only a
            // server-confirmed invalid/banned session forces logout.
            val m=t.message.orEmpty()
            val invalid = m.contains("INVALID_SESSION",true) || m.contains("UNAUTHORIZED",true) || m.contains("banned",true)
            if(invalid){
                forceServerLogout(if (m.contains("banned", true)) "banned" else "deleted")
            } else {
                val n=prefs.getString(PREF_LAST_NICKNAME,"").orEmpty().trim()
                if(n.isNotBlank() && !VGhostApi.token().isNullOrBlank()){
                    _sessionState.value=SessionState.LoggedInNormalUser(n)
                    _currentUserNickname.value=n
                    _currentUserStatus.value="Offline"
                    _isGhostMode.value=false
                    _isAppLocked.value=_appLockEnabled.value
                    startChatListSync()
                    startPresenceHeartbeat()
                    startActivityLevelSync()
                } else {
                    _sessionState.value=SessionState.LoggedOut
                }
            }
        } finally { _sessionRestoring.value=false }
    }
    private fun normalize(s:String)=s.trim().removePrefix("@").trim()
    private fun validNick(s:String)=Regex("[A-Za-z0-9_]{3,32}").matches(s)
    private fun b64(bytes:ByteArray)=Base64.encodeToString(bytes,Base64.NO_WRAP)
    private fun hash(s:String,salt:ByteArray):String= b64(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(s.toCharArray(),salt,120000,256)).encoded)
    private fun constant(a:String,b:String)=MessageDigest.isEqual(a.toByteArray(),b.toByteArray())
    private fun error(t:Throwable): String = com.vghost.app.i18n.BackendErrorTranslations.localize(t.message, com.vghost.app.i18n.AppLocale.language.value)

    fun hasAccount()=initialized && !VGhostApi.token().isNullOrBlank()
    fun register(nickname:String,password:String,pin:String):String? { return if(validNick(normalize(nickname))&&password.length>=8&&Regex("\\d{4}").matches(pin)) null else "Məlumatları düzgün daxil et." }
    fun login(nickname:String,password:String):String?="Bu əməliyyat üçün internet hesab girişi istifadə olunur."

    suspend fun registerOnline(nickname:String,email:String,password:String,pin:String,gender:String="male"):String? {
        val n=normalize(nickname); if(!validNick(n))return tr("Nickname must be 3-32 characters (letters, numbers, _ only).")
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches())return "Düzgün email daxil et."
        if(password.length<8)return "Şifrə ən azı 8 simvol olmalıdır."; if(!Regex("\\d{4}").matches(pin))return "PIN 4 rəqəm olmalıdır."
        return try { val r=VGhostApi.register(n,email.trim(),password,gender); VGhostApi.setToken(r.optString("token")); finishLogin(r.optJSONObject("user")?:return "Hesab yaradılmadı.",pin); applyWalletFromResponse(r); null } catch(t:Throwable){error(t)}
    }
    suspend fun loginOnline(nickname:String,password:String):String? {
        val n=normalize(nickname); if(n.isBlank())return "Nik daxil et."
        return try { val r=VGhostApi.login(n,password); VGhostApi.setToken(r.optString("token")); finishLogin(r.optJSONObject("user")?:return "Giriş alınmadı.",null); applyWalletFromResponse(r); null } catch(t:Throwable){error(t)}
    }
    private suspend fun finishLogin(u:org.json.JSONObject,pin:String?){
        resetSessionState()
        _guestMode.value=false
        guestRounds.clear()
        _ghostCoins.value=0
        val n=u.optString("nickname")
        _sessionState.value=SessionState.LoggedInNormalUser(n)
        _currentUserNickname.value=n
        val avatarId=u.optString("avatarId", prefs.getString(PREF_AVATAR_ID,"ghost").orEmpty()).ifBlank { "ghost" }
        _currentUserAvatarId.value=avatarId
        prefs.edit().putString(PREF_LAST_NICKNAME,n).putString(PREF_AVATAR_ID,avatarId).apply()
        _currentUserStatus.value=if(u.optBoolean("ghostMode",false)) "Ghost" else "Online"
        _isGhostMode.value=u.optBoolean("ghostMode",false)
        _isPanicActivated.value=false
        if(pin!=null)setAppPin(pin)
        _isAppLocked.value=false
        // Navigation may continue immediately; these are background refreshes.
        apiScope.launch { refreshMyWallet() }
        apiScope.launch { refreshAdminStatus() }
        apiScope.launch { updateStatus(true) }
        startChatListSync()
        PushManager.syncToken(appContext)
        startPresenceHeartbeat()
        startActivityLevelSync()
        refreshNotifications()
    }

    suspend fun refreshAdminStatus(){
        val epoch=sessionEpoch
        val result=try{
            val me=VGhostApi.call("auth/me")
            val user=me.optJSONObject("user")
            user?.optBoolean("isSuperAdmin",false) == true || user?.optBoolean("isAdmin",false) == true
        }catch(_:Throwable){
            try{ VGhostApi.adminDashboard(); true }catch(_:Throwable){ false }
        }
        if(epoch==sessionEpoch && hasAccount() && !_guestMode.value) _isSuperAdmin.value=result
    }

    fun recordActivity(){ if(hasAccount() && !_guestMode.value) apiScope.launch { updateStatus(true) } }
    /** Server-backed presence. Only one heartbeat job may run at a time. */
    fun startPresenceHeartbeat(){
        presenceHeartbeatJob?.cancel()
        if(!hasAccount() || _guestMode.value) return
        presenceHeartbeatJob=apiScope.launch {
            while(isActive && hasAccount() && !_guestMode.value){
                updateStatus(true)
                delay(25_000L)
            }
        }
    }
    /** App foreground/background is the presence source of truth for this mobile client. */
    fun setAppPresence(foreground:Boolean){
        appInForeground=foreground
        if(!hasAccount() || _guestMode.value) return
        if(foreground){
            apiScope.launch { updateStatus(true) }
            startPresenceHeartbeat()
        } else {
            presenceHeartbeatJob?.cancel(); presenceHeartbeatJob=null
            apiScope.launch { updateStatus(false) }
        }
    }
    fun isAppInForeground():Boolean=appInForeground
    /** The chat currently visible on screen. Used to avoid duplicate system push alerts. */
    fun setActiveChat(nickname: String?) {
        activeChatNickname = nickname?.trim()?.removePrefix("@")?.trim()?.takeIf { it.isNotBlank() }
    }
    fun isChatOpenWith(nickname: String?): Boolean {
        val active = activeChatNickname ?: return false
        val incoming = nickname?.trim()?.removePrefix("@")?.trim()?.takeIf { it.isNotBlank() } ?: return false
        return active.equals(incoming, ignoreCase = true)
    }
    private suspend fun updateStatus(online:Boolean){try{VGhostApi.updateStatus(online)}catch(_:Throwable){}}
    fun toggleStealthMode(){
        if(!hasAccount()) return
        val target=!_isGhostMode.value
        apiScope.launch{
            try { val r=VGhostApi.setStealthMode(target); val enabled=r.optBoolean("ghostMode",target); _isGhostMode.value=enabled; _currentUserStatus.value=if(enabled)"Ghost" else "Online" }
            catch(_:Throwable){ /* server rejected: keep current server-confirmed state */ }
        }
    }
    fun enterGhostMode(){
        // Guest mode is completely local and never uses a real account wallet.
        // Invalidate all in-flight account requests before changing the visible wallet.
        resetSessionState()
        VGhostApi.setToken(null); _guestMode.value=true; _ghostCoins.value=1000
        _sessionState.value=SessionState.LoggedInGhost; _currentUserNickname.value="Qonaq"; _currentUserStatus.value="Guest"; _notifications.value=listOf(AppNotification(type="guest",title=NotificationTranslations.localize("guest", "Qonaq rejimi", "Qonaq rejiminə xoş gəldin. 1000 qonaq coin aktivdir.", mapOf("amount" to "1000" )).first,body=NotificationTranslations.localize("guest", "Qonaq rejimi", "Qonaq rejiminə xoş gəldin. 1000 qonaq coin aktivdir.", mapOf("amount" to "1000" )).second,createdAt=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()),target="game"))
    }
    fun clearInAppNotifications(){
        _notifications.value=emptyList()
        if(initialized && hasAccount() && !_guestMode.value) apiScope.launch { try { VGhostApi.clearNotifications() } catch(_:Throwable){} }
    }
    fun markNotificationRead(id:Long){
        if(id<=0L) return
        _notifications.value=_notifications.value.map { if(it.id==id) it.copy(isRead=true) else it }
        if(initialized && hasAccount() && !_guestMode.value) apiScope.launch { try { VGhostApi.readNotification(id) } catch(_:Throwable){ refreshNotifications() } }
    }
    fun markAllNotificationsRead(){
        _notifications.value=_notifications.value.map { it.copy(isRead=true) }
        if(initialized && hasAccount() && !_guestMode.value) apiScope.launch { try { VGhostApi.readNotifications() } catch(_:Throwable){ refreshNotifications() } }
    }
    /** Removes one handled notification from the in-app list immediately. */
    fun removeInAppNotification(id:Long){
        if(id<=0L) return
        _notifications.value=_notifications.value.filterNot { it.id==id }
    }
    private fun notificationTarget(type:String,data:org.json.JSONObject):Pair<String,String>{
        val explicit=data.optString("target", "").trim()
        val value=data.optString("targetValue", data.optString("url", data.optString("nickname", data.optString("userId", "")))).trim()
        if(explicit.isNotBlank()) return explicit to value
        return when(type){
            "message" -> "chat" to data.optString("senderNickname", data.optString("nickname", ""))
            "friend_request", "friend_accepted" -> "profile" to data.optString("nickname", "")
            "welcome_bonus", "daily_bonus", "gift", "coin_transfer", "coin_gift", "coin_received" -> "profile" to ""
            "guest" -> "game" to ""
            "admin" -> "home" to ""
            "broadcast" -> if(data.optString("url", "").isNotBlank()) "link" to data.optString("url", "") else "home" to ""
            else -> "home" to ""
        }
    }
    fun refreshNotifications(){
        if(!initialized || !hasAccount() || _guestMode.value) return
        val epoch=sessionEpoch
        apiScope.launch { try {
            val r=VGhostApi.notifications(); val a=r.optJSONArray("notifications")
            val list=buildList { if(a!=null) for(i in 0 until a.length()){
                val n=a.optJSONObject(i)?:continue
                val data=try{
                    val obj=n.optJSONObject("data")
                    if(obj!=null) obj else {
                        val raw=n.optString("data_json", "")
                        if(raw.isBlank()) org.json.JSONObject() else org.json.JSONObject(raw)
                    }
                }catch(_:Throwable){ org.json.JSONObject() }
                val type=n.optString("type","general")
                val target=notificationTarget(type,data)
                val sender=data.optString("senderNickname", data.optString("sender", data.optString("nickname", target.second)))
                val localized=NotificationTranslations.localize(type, n.optString("title"), n.optString("body"), mapOf(
                    "sender" to sender, "senderNickname" to sender, "amount" to data.optString("amount", "")
                ))
                add(AppNotification(
                    id=n.optLong("id",0L), type=type, title=localized.first, body=localized.second,
                    isRead=n.optInt("is_read",0)==1 || n.optBoolean("is_read",false) || n.optBoolean("isRead",false), createdAt=n.optString("created_at", n.optString("createdAt", "")),
                    target=target.first, targetValue=target.second,
                    giftId=data.optString("giftId", data.optString("gift_id", "")),
                    giftKey=data.optString("giftKey", ""),
                    senderNickname=data.optString("senderNickname", data.optString("sender", "")),
                    count=data.optInt("count", 1).coerceAtLeast(1)
                ))
            } }
            if(epoch==sessionEpoch && hasAccount()) _notifications.value=list
        } catch(_:Throwable){} }
    }
    fun onGiftReceived(giftId:String, sender:String){ if(giftId.isNotBlank()) _giftReceivedEvent.value=GiftReceivedEvent(giftId,sender) }
    fun openGiftNotification(notification:AppNotification){ val id=notification.giftKey.ifBlank { notification.giftId }; if(id.isNotBlank()) onGiftReceived(id, notification.senderNickname) }
    fun clearGiftReceived(token:Long){ if(_giftReceivedEvent.value?.token==token) _giftReceivedEvent.value=null }

    fun onPushNotification(title:String,body:String,type:String="general",target:String="home",targetValue:String="",notificationId:Long=0L,data:Map<String,String> = emptyMap()){
        if(initialized) {
            val localized=NotificationTranslations.localize(type,title,body,data + mapOf("sender" to (data["senderNickname"] ?: targetValue)))
            val local=AppNotification(id=notificationId,type=type,title=localized.first,body=localized.second,isRead=false,createdAt=java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()),target=target,targetValue=targetValue)
            _notifications.value=(listOf(local)+_notifications.value.filter { notificationId<=0L || it.id!=notificationId }).take(100)
            refreshNotifications()
        }
    }
    suspend fun refreshMyWallet(){
        // Capture the current identity/session generation. A response that arrives after logout,
        // account switch or guest mode must never update the new user's visible balance.
        val epoch=walletSessionEpoch
        if(_guestMode.value || !hasAccount()) return
        try {
            val response=VGhostApi.call("wallet/balance")
            if(!response.has("balance") || response.isNull("balance")) return
            val balance=response.optLong("balance", Long.MIN_VALUE)
            if(balance==Long.MIN_VALUE || balance<0L || balance>Int.MAX_VALUE.toLong()) return
            if(epoch==walletSessionEpoch && !_guestMode.value && hasAccount()) {
                _ghostCoins.value=balance.toInt()
            }
        } catch(_:Throwable){ /* keep last server-confirmed value while offline */ }
    }
    /** Apply a nested wallet object returned by auth/login or auth/me. */
    private fun applyWalletFromResponse(r:org.json.JSONObject) {
        val wallet=r.optJSONObject("wallet") ?: return
        if(!wallet.has("balance") || wallet.isNull("balance")) return
        val balance=wallet.optLong("balance", Long.MIN_VALUE)
        if(balance in 0L..Int.MAX_VALUE.toLong() && !_guestMode.value && hasAccount()) {
            _ghostCoins.value=balance.toInt()
        }
    }
    /** The server wallet is authoritative. Never mutate the displayed balance locally. */
    private fun applyServerBalance(r:org.json.JSONObject):org.json.JSONObject {
        if(r.has("balance") && !r.isNull("balance")) {
            val balance=r.optLong("balance", Long.MIN_VALUE)
            if(balance in 0L..Int.MAX_VALUE.toLong()) _ghostCoins.value=balance.toInt()
        }
        return r
    }
    /** Client-side coin creation is intentionally disabled. Credits only come from server-owned rewards/games/admin actions. */
    fun addGhostCoins(amount:Int){ /* no-op by design: never trust the APK with coin credits */ }
    suspend fun spendGhostCoins(amount:Int):Boolean = try{ if(amount<=0) false else { applyServerBalance(VGhostApi.call("wallet/coins","POST",org.json.JSONObject().put("amount",-amount))); true } }catch(_:Throwable){ refreshMyWallet(); false }
    private val _lastGameError = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)
    val lastGameError = _lastGameError
    suspend fun startGame(game:String,bet:Int,mineCount:Int=4,rockfallLevel:Int=1):org.json.JSONObject?=try{
        _lastGameError.value = null
        if(bet <= 0){ _lastGameError.value = tr("Mərc məbləği düzgün deyil"); return null }
        // The UI can briefly show a stale/zero wallet after locale or screen recreation.
        // Refresh once before rejecting a valid start request.
        if(!_guestMode.value && hasAccount()){
            // Always sync the server wallet before Game 4 starts. This fixes the
            // case where login succeeded but the game screen still holds a stale 0 balance.
            refreshMyWallet()
        }
        if(_guestMode.value){
            if(game=="rockfall" && rockfallLevel !in 1..guestRockfallUnlockedLevel){ _lastGameError.value="LEVEL $rockfallLevel HƏLƏ KİLİDLİDİR"; return null }
            if(bet<=0 || bet>_ghostCoins.value){ _lastGameError.value=tr("Qonaq coin kifayət etmir"); return null }
            _ghostCoins.value-=bet; val id="guest-"+UUID.randomUUID()
            val crashAt = if(game=="jet") (1.35 + java.util.Random().nextDouble()*3.65) else 0.0
            val mines = if(game=="mines") (0 until 25).shuffled().take(mineCount).toSet() else if(game=="penalty") (0..8).shuffled().take(5).toSet() else emptySet()
            val rockBoard = if(game=="rockfall") guestRockBoard() else mutableListOf()
            val ticBoard = if(game=="tictactoe") MutableList(9){0} else mutableListOf()
            val rl=rockfallLevel.coerceIn(1,10)
            val rockTime=75+(rl-1)*10
            val rockMoves=20+(rl-1)*3
            val rockTarget=300+(rl-1)*175
            val isRock = game=="rockfall"
            val guestBoard = if(game=="tictactoe") ticBoard else rockBoard
            guestRounds[id]=GuestRound(bet,mineCount,game,crashAt, mineIndexes=mines, board=guestBoard, moves=if(isRock) rockMoves else 20, timeLimit=if(isRock) rockTime else 60, target=if(isRock) rockTarget else 1000, level=if(isRock) rl else 1)
            val out=org.json.JSONObject().put("roundId",id).put("balance",_ghostCoins.value).put("multiplier",1.0).put("crashAt",crashAt)
            if(game=="mines") out.put("mineIndexes", org.json.JSONArray(mines.toList()))
            if(isRock) out.put("board",org.json.JSONArray(rockBoard)).put("level",rl).put("moves",rockMoves).put("score",0).put("target",rockTarget).put("timeLimit",rockTime).put("timeLeft",rockTime)
            if(game=="tictactoe") out.put("board",org.json.JSONArray(ticBoard)).put("turn","X")
            return out
        }
        if(!_guestMode.value && hasAccount() && _ghostCoins.value < bet){
            refreshMyWallet()
            if(_ghostCoins.value < bet){ _lastGameError.value=tr("BALANS YETƏRSİZ • %d GC").format(bet); return null }
        }
        val startPath = if (game == "rockfall") "games/rockfall/start" else "games/start"
        try {
            val payload=org.json.JSONObject().put("game",game).put("bet",bet).put("mineCount",mineCount)
            if(game=="rockfall") payload.put("level",rockfallLevel.coerceIn(1,10))
            val r=VGhostApi.call(startPath,"POST",payload)
            applyServerBalance(r)
            r
        } catch(first:Throwable){
            // Login can finish just before the game screen opens; refresh the authoritative
            // session/wallet once and retry the exact start request instead of showing a false
            // balance error caused by a stale UI state.
            if(!_guestMode.value && hasAccount()){
                refreshMyWallet()
                try {
                    val retryPayload=org.json.JSONObject().put("game",game).put("bet",bet).put("mineCount",mineCount)
                    if(game=="rockfall") retryPayload.put("level",rockfallLevel.coerceIn(1,10))
                    val retry=VGhostApi.call(startPath,"POST",retryPayload)
                    applyServerBalance(retry)
                    retry
                } catch(second:Throwable){ throw second }
            } else throw first
        }
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun rockfallProgress():org.json.JSONObject?=try{
        if(_guestMode.value){
            return org.json.JSONObject().put("unlockedLevel",guestRockfallUnlockedLevel).put("bestScore",0).put("maxLevel",10)
        }
        if(!hasAccount()) return null
        VGhostApi.call("games/rockfall/progress")
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    private var guestRockfallUnlockedLevel:Int = 1

    suspend fun rockfallMove(roundId:String,from:Int,to:Int):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){
            val r=guestRounds[roundId]?:return null; if(r.game!="rockfall" || from !in 0..63 || to !in 0..63) return null
            if(kotlin.math.abs(from/8-to/8)+kotlin.math.abs(from%8-to%8)!=1 || r.moves<=0) return null
            val timeLeft = (r.timeLimit - ((System.currentTimeMillis() - r.startedAtMs) / 1000L).toInt()).coerceAtLeast(0)
            if(timeLeft <= 0){ guestRounds.remove(roundId); return org.json.JSONObject().put("status","lost").put("movesLeft",0).put("score",r.score).put("scoreGain",0).put("matches",0).put("combo",0).put("multiplier",1.0).put("payout",0).put("balance",_ghostCoins.value).put("timeLeft",0).put("level",r.level).put("target",r.target).put("timeLimit",r.timeLimit) }
            val tmp=r.board[from]; r.board[from]=r.board[to]; r.board[to]=tmp
            val matches=guestRockMatches(r.board)
            var moveScoreGain = 0
            if(matches.isEmpty()){
                val t=r.board[from]; r.board[from]=r.board[to]; r.board[to]=t; r.combo=0
                return org.json.JSONObject().put("status","active").put("board",org.json.JSONArray(r.board)).put("movesLeft",r.moves).put("score",r.score).put("scoreGain",0).put("matches",0).put("combo",0).put("multiplier",guestRockPayoutMultiplier(r.score)).put("payout",guestRockPayout(r.bet,r.score)).put("balance",_ghostCoins.value).put("timeLeft",(r.timeLimit - ((System.currentTimeMillis() - r.startedAtMs) / 1000L).toInt()).coerceAtLeast(0))
            } else {
                r.combo++
                var totalGain = matches.size * 3 * r.combo
                moveScoreGain = totalGain
                r.score += totalGain
                matches.forEach{r.board[it]=java.util.Random().nextInt(5)}
                var cascade=0
                var next=guestRockMatches(r.board)
                while(next.isNotEmpty()){
                    cascade++
                    next.forEach{r.board[it]=java.util.Random().nextInt(5)}
                    val cascadeGain = next.size * 3 * (r.combo+cascade)
                    totalGain += cascadeGain
                    moveScoreGain = totalGain
                    r.score += cascadeGain
                    next=guestRockMatches(r.board)
                }
                // Keep the same authoritative 1000-point target as the server.
                r.score = r.score.coerceAtMost(1000)
            }
            r.moves--
            val mult=guestRockPayoutMultiplier(r.score); val payout=guestRockPayout(r.bet,r.score); val won=r.score>=r.target
            if(won){ _ghostCoins.value+=payout; guestRockfallUnlockedLevel=maxOf(guestRockfallUnlockedLevel,minOf(10,r.level+1)); guestRounds.remove(roundId) }
            return org.json.JSONObject().put("status",if(won)"won" else "active").put("level",r.level).put("target",r.target).put("timeLimit",r.timeLimit).put("board",org.json.JSONArray(r.board)).put("movesLeft",r.moves).put("score",r.score).put("scoreGain",moveScoreGain).put("matches",matches.size).put("combo",maxOf(1,r.combo)).put("multiplier",mult).put("payout",payout).put("balance",_ghostCoins.value).put("timeLeft",(r.timeLimit - ((System.currentTimeMillis() - r.startedAtMs) / 1000L).toInt()).coerceAtLeast(0))
        }
        val r=VGhostApi.call("games/rockfall/move","POST",org.json.JSONObject().put("roundId",roundId).put("from",from).put("to",to)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    private fun guestRockBoard(): MutableList<Int> {
        val random = java.util.Random()
        val board = MutableList(64) { random.nextInt(5) }
        // Build a playable opening board: never start with an automatic 3-match.
        for (i in 0 until 64) {
            val row = i / 8
            val col = i % 8
            if (col >= 2 && board[i] == board[i - 1] && board[i] == board[i - 2]) {
                board[i] = (board[i] + 1 + random.nextInt(4)) % 5
            }
            if (row >= 2 && board[i] == board[i - 8] && board[i] == board[i - 16]) {
                board[i] = (board[i] + 1 + random.nextInt(4)) % 5
            }
        }
        return board
    }

    private fun guestRockPayoutMultiplier(score:Int):Double = when {
        score <= 0 -> 1.0
        score < 200 -> 1.0
        score < 400 -> 1.5
        score < 600 -> 3.0
        score < 800 -> 4.5
        else -> 7.5
    }

    private fun guestRockPayout(bet:Int, score:Int):Int = if(score<=0) 0 else maxOf(bet, kotlin.math.round(bet * guestRockPayoutMultiplier(score)).toInt())

    private fun guestRockMatches(b:List<Int>):List<Int>{ val out=mutableSetOf<Int>(); for(row in 0 until 8){ var st=0; while(st<8){val v=b[row*8+st];var en=st+1;while(en<8&&b[row*8+en]==v)en++;if(en-st>=3)for(c in st until en)out.add(row*8+c);st=en} }; for(col in 0 until 8){var st=0;while(st<8){val v=b[st*8+col];var en=st+1;while(en<8&&b[en*8+col]==v)en++;if(en-st>=3)for(row in st until en)out.add(row*8+col);st=en}};return out.toList() }

    suspend fun rockfallCashOut(roundId:String):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){ val r=guestRounds.remove(roundId)?:return null; if(r.game!="rockfall"||r.score<=0)return null; if(((System.currentTimeMillis()-r.startedAtMs)/1000L)>=r.timeLimit) return org.json.JSONObject().put("payout",0).put("multiplier",1.0).put("balance",_ghostCoins.value).put("status","lost").put("timeLeft",0); val mult=guestRockPayoutMultiplier(r.score); val payout=guestRockPayout(r.bet,r.score); _ghostCoins.value+=payout; return org.json.JSONObject().put("payout",payout).put("multiplier",mult).put("balance",_ghostCoins.value).put("score",r.score).put("cashout",true) }
        val r=VGhostApi.call("games/rockfall/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun revealMines(roundId:String,index:Int):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){ val r=guestRounds[roundId]?:return null; if(r.game!="mines") return null; if(index !in 0..24 || index in r.revealed) return org.json.JSONObject().put("mine",false).put("balance",_ghostCoins.value); val mine = index in r.mineIndexes; if(mine){ guestRounds.remove(roundId); return org.json.JSONObject().put("mine",true).put("status","lost").put("balance",_ghostCoins.value).put("mines", org.json.JSONArray(r.mineIndexes.toList().sorted())) }; r.revealed.add(index); val safeClicks=r.revealed.size; val multiplier=1.0 + safeClicks*0.12; return org.json.JSONObject().put("mine",false).put("status","active").put("multiplier",multiplier).put("payout",(r.bet*multiplier).toInt()).put("balance",_ghostCoins.value) }
        val r=VGhostApi.call("games/mines/reveal","POST",org.json.JSONObject().put("roundId",roundId).put("index",index)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun cashOutMines(roundId:String):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){ val round=guestRounds[roundId]?:return null; val safeClicks=round.revealed.size; if(round.game!="mines" || safeClicks<=0) return null; guestRounds.remove(roundId); val multiplier=1.0 + safeClicks*0.12; val payout=(round.bet*multiplier).toInt(); _ghostCoins.value+=payout; return org.json.JSONObject().put("balance",_ghostCoins.value).put("payout",payout).put("win",payout).put("multiplier",multiplier) }
        val r=VGhostApi.call("games/mines/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun shootPenalty(roundId:String,index:Int,multiplier:Double=1.30):org.json.JSONObject?=try{
        if(index !in 0..8) return null
        if(roundId.startsWith("guest-")){
            val round=guestRounds[roundId]?:return null
            if(round.game!="penalty") return null
            val level=round.revealed.size+1
            val penaltyPattern=round.mineIndexes.toList().take(5)
            if(penaltyPattern.size < 5) return null
            val blocked=penaltyPattern.take(level)
            val keeper=blocked.firstOrNull()?:0
            val goal=index !in blocked
            val visualKeeper=if(goal) keeper else index
            val ladder=listOf(1.30,2.60,3.90,5.20,10.00)
            val safeMultiplier=ladder[(level-1).coerceIn(0,4)]
            if(!goal){
                guestRounds.remove(roundId)
                return org.json.JSONObject().put("keeperIndex",visualKeeper).put("goal",false).put("status","lost").put("level",level).put("payout",0).put("multiplier",safeMultiplier).put("balance",_ghostCoins.value)
            }
            round.revealed.add(index)
            val finalLevel=level>=5
            val payout=if(finalLevel) kotlin.math.round(round.bet*safeMultiplier).toInt() else 0
            if(finalLevel){ _ghostCoins.value+=payout; guestRounds.remove(roundId) }
            return org.json.JSONObject()
                .put("keeperIndex",visualKeeper)
                .put("goal",true)
                .put("status",if(finalLevel)"won" else "active")
                .put("level",level)
                .put("payout",payout)
                .put("multiplier",safeMultiplier)
                .put("balance",_ghostCoins.value)
        }
        val r=VGhostApi.call(
            "games/penalty/shoot",
            "POST",
            org.json.JSONObject()
                .put("roundId",roundId)
                .put("index",index)
                .put("multiplier",multiplier)
        )
        applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun cashOutPenalty(roundId:String):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){
            val round=guestRounds[roundId]?:return null
            if(round.game!="penalty" || round.revealed.isEmpty()) return null
            guestRounds.remove(roundId)
            val ladder=listOf(1.30,2.60,3.90,5.20,10.00)
            val level=round.revealed.size.coerceIn(1,5)
            val multiplier=ladder[level-1]
            val payout=kotlin.math.round(round.bet*multiplier).toInt()
            _ghostCoins.value+=payout
            return org.json.JSONObject().put("status","won").put("level",level).put("multiplier",multiplier).put("payout",payout).put("balance",_ghostCoins.value).put("cashedOut",true)
        }
        val r=VGhostApi.call("games/penalty/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    fun resolveGuestJetCrash(roundId:String):Boolean {
        if(!roundId.startsWith("guest-")) return false
        val round=guestRounds[roundId] ?: return false
        if(round.game!="jet") return false
        guestRounds.remove(roundId)
        return true
    }
    suspend fun cashOutJet(roundId:String):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){ val bet=guestRounds.remove(roundId)?.bet?:0; _ghostCoins.value+= (bet*1.2).toInt(); return org.json.JSONObject().put("balance",_ghostCoins.value).put("win",(bet*1.2).toInt()) }
        val r=VGhostApi.call("games/jet/cashout","POST",org.json.JSONObject().put("roundId",roundId)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value = error(t); null }
    suspend fun ticTacToeMove(roundId:String,index:Int):org.json.JSONObject?=try{
        if(index !in 0..8) return null
        if(roundId.startsWith("guest-")){
            val r=guestRounds[roundId]?:return null; if(r.game!="tictactoe") return null
            if(r.board.size!=9 || r.board[index]!=0) return null
            r.board[index]=1
            fun winner(b:List<Int>,v:Int):Boolean = listOf(intArrayOf(0,1,2),intArrayOf(3,4,5),intArrayOf(6,7,8),intArrayOf(0,3,6),intArrayOf(1,4,7),intArrayOf(2,5,8),intArrayOf(0,4,8),intArrayOf(2,4,6)).any{b[it[0]]==v&&b[it[1]]==v&&b[it[2]]==v}
            fun full(b:List<Int>)=b.all{it!=0}
            if(winner(r.board,1)){ val payout=r.bet*2; _ghostCoins.value+=payout; guestRounds.remove(roundId); return org.json.JSONObject().put("status","won").put("board",org.json.JSONArray(r.board.map{if(it==1)"X" else if(it==2)"O" else ""})).put("payout",payout).put("balance",_ghostCoins.value) }
            if(full(r.board)){ _ghostCoins.value+=r.bet; guestRounds.remove(roundId); return org.json.JSONObject().put("status","draw").put("board",org.json.JSONArray(r.board.map{if(it==1)"X" else if(it==2)"O" else ""})).put("payout",r.bet).put("balance",_ghostCoins.value) }
            val empty=r.board.indices.filter{r.board[it]==0}; var ai=-1
            for(i in empty){val b=r.board.toMutableList();b[i]=2;if(winner(b,2)){ai=i;break}}
            if(ai<0) for(i in empty){val b=r.board.toMutableList();b[i]=1;if(winner(b,1)){ai=i;break}}
            if(ai<0&&r.board[4]==0) ai=4
            if(ai<0){val corners=listOf(0,2,6,8).filter{r.board[it]==0};ai=if(corners.isNotEmpty())corners.random() else empty.random()}
            r.board[ai]=2
            val outBoard=org.json.JSONArray(r.board.map{if(it==1)"X" else if(it==2)"O" else ""})
            if(winner(r.board,2)){guestRounds.remove(roundId);return org.json.JSONObject().put("status","lost").put("board",outBoard).put("payout",0).put("balance",_ghostCoins.value)}
            if(full(r.board)){_ghostCoins.value+=r.bet;guestRounds.remove(roundId);return org.json.JSONObject().put("status","draw").put("board",outBoard).put("payout",r.bet).put("balance",_ghostCoins.value)}
            return org.json.JSONObject().put("status","active").put("board",outBoard).put("turn","X").put("payout",0).put("balance",_ghostCoins.value)
        }
        val r=VGhostApi.call("games/tictactoe/move","POST",org.json.JSONObject().put("roundId",roundId).put("index",index)); applyServerBalance(r)
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun tttMulti(action:String, roomId:String?=null, roomCode:String?=null, bet:Int?=null, index:Int?=null):org.json.JSONObject?=try{
        val payload=org.json.JSONObject().put("action",action)
        roomId?.let{payload.put("roomId",it)}; roomCode?.let{payload.put("roomCode",it)}; bet?.let{payload.put("bet",it)}; index?.let{payload.put("index",it)}
        val r=VGhostApi.call("games/tictactoe/multiplayer","POST",payload); applyServerBalance(r); r
    }catch(t:Throwable){ _lastGameError.value=error(t); null }
    suspend fun createTicTacToeRoom()=tttMulti("create")
    suspend fun joinTicTacToeRoom(code:String)=tttMulti("join",roomCode=code)
    suspend fun ticTacToeRoomState(roomId:String)=tttMulti("state",roomId=roomId)
    suspend fun ticTacToeMultiplayerMove(roomId:String,index:Int)=tttMulti("move",roomId=roomId,index=index)
    suspend fun cancelTicTacToeRoom(roomId:String)=tttMulti("cancel",roomId=roomId)
    suspend fun cancelGame(roundId:String):org.json.JSONObject?=try{
        if(roundId.startsWith("guest-")){
            val round=guestRounds.remove(roundId)?:return null
            _ghostCoins.value+=round.bet
            return org.json.JSONObject().put("balance",_ghostCoins.value).put("cancelled",true)
        }
        val r=VGhostApi.call("games/cancel","POST",org.json.JSONObject().put("roundId",roundId));
        _ghostCoins.value=r.optInt("balance",_ghostCoins.value); r
    }catch(t:Throwable){ _lastGameError.value = error(t); null }

    suspend fun sendPasswordResetEmail(value:String):String?=try{
        val login=value.trim()
        if(login.isBlank()) return "Email və ya ləqəbini daxil et."
        // Always send one neutral `login` field. Backend resolves nickname ->
        // account -> registered email automatically, or accepts a direct email.
        val r=VGhostApi.call("auth/reset","POST",org.json.JSONObject().put("login",login))
        when {
            !r.optBoolean("ok", false) -> r.optString("error", "Parol sıfırlama linki göndərilə bilmədi.")
            r.has("email_found") && !r.optBoolean("email_found", true) -> "Bu nickname/email üçün hesab və ya bərpa email-i tapılmadı."
            else -> null
        }
    }catch(t:Throwable){error(t)}
    suspend fun changeLoginPassword(currentPassword:String,newPassword:String,confirmPassword:String):String?=if(newPassword!=confirmPassword)"Şifrələr uyğun deyil." else try { val r=VGhostApi.changePassword(currentPassword,newPassword); VGhostApi.setToken(r.optString("token")); null } catch(t:Throwable){error(t)}
    fun changeAppPin(newPin:String,confirmPin:String):String?{if(!Regex("\\d{4}").matches(newPin)||newPin!=confirmPin)return "PIN düzgün deyil.";setAppPin(newPin);return null}
    fun setAppPin(pin:String):Boolean{if(!Regex("\\d{4}").matches(pin))return false;val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};prefs.edit().putString("pin_salt",b64(salt)).putString("pin_hash",hash(pin,salt)).putBoolean("lock_enabled",true).apply();_appLockEnabled.value=true;return true}
    fun unlock(pin:String):Boolean{val salt=prefs.getString("pin_salt",null)?.let{Base64.decode(it,Base64.NO_WRAP)}?:return false;val h=prefs.getString("pin_hash","")?:return false;val ok=constant(hash(pin,salt),h);if(ok){_isAppLocked.value=false;recordActivity()};return ok}
    fun lockApp(){if(_appLockEnabled.value)_isAppLocked.value=true}
    fun logoutAndClearLocalPin(){logout();prefs.edit().remove("pin_salt").remove("pin_hash").putBoolean("lock_enabled",false).apply();_appLockEnabled.value=false}
    fun logout(){
        // Explicit user logout clears the local session identity. A network
        // outage must never call this method automatically.
        resetSessionState(); _sessionState.value=SessionState.LoggedOut; _isAppLocked.value=false
        prefs.edit().remove(PREF_LAST_NICKNAME).apply()
        if(_guestMode.value) return
        apiScope.launch{try{VGhostApi.updateStatus(false);VGhostApi.logout()}catch(_:Throwable){}}
        VGhostApi.setToken(null)
    }

    fun getMessagesForUser(nickname:String)=_messages.value[normalize(nickname)].orEmpty().filter{System.currentTimeMillis()-it.createdAt<DAY}
    /** Keeps the messages inbox current even when no conversation screen is open. */
    fun startChatListSync(){
        chatListSyncJob?.cancel()
        chatListSyncJob=apiScope.launch{
            // Guest mode is an anonymous local session. An authenticated session
            // must always sync chats, even if an old/stale guest flag survived a
            // navigation or process recreation.
            while(isActive && hasAccount() && _sessionState.value is SessionState.LoggedInNormalUser){
                refreshChats()
                delay(3000L)
            }
        }
    }
    fun stopChatListSync(){ chatListSyncJob?.cancel(); chatListSyncJob=null }

    fun startChatSync(recipientNickname:String){
        val n=normalize(recipientNickname)
        syncJobs[n]?.cancel()
        syncJobs[n]=apiScope.launch{
            // Resolve the recipient before polling. If navigation races session restore,
            // keep retrying instead of permanently giving up on the conversation.
            var uid:Int?=null
            while(isActive && hasAccount() && _sessionState.value is SessionState.LoggedInNormalUser && uid==null){
                uid=resolveUid(n)
                if(uid==null) delay(1000L)
            }
            while(isActive && hasAccount() && _sessionState.value is SessionState.LoggedInNormalUser){
                loadMessages(n)
                delay(2000L)
            }
        }
    }
    fun stopChatSync(recipientNickname:String){syncJobs.remove(normalize(recipientNickname))?.cancel()}
    private suspend fun resolveUid(n:String):Int?{
        val key=normalize(n)
        chatUidCache[key]?.let{return it}
        return try{
            // Existing conversations already contain the authoritative numeric other_id.
            // Prefer that over fuzzy user search; this is especially important for names
            // such as "VGhost" that may have similarly named accounts.
            val conversations=VGhostApi.call("messages/conversations").optJSONArray("conversations")
            if(conversations!=null){
                for(i in 0 until conversations.length()){
                    val c=conversations.getJSONObject(i)
                    if(c.optString("nickname").trim().equals(key,true)){
                        val existing=c.optString("other_id").toIntOrNull()
                        if(existing!=null && existing>0){
                            chatUidCache[key]=existing
                            return existing
                        }
                    }
                }
            }
            // Fall back to exact user search. The backend returns both id and uid as
            // strings, so do not rely on JSONObject.optInt() converting them.
            val users=VGhostApi.call("users/search?q="+java.net.URLEncoder.encode(key,"UTF-8"))
                .optJSONArray("users")
            var uid:Int?=null
            if(users!=null){
                for(i in 0 until users.length()){
                    val u=users.getJSONObject(i)
                    val nick=u.optString("nickname").trim()
                    if(nick.equals(key,true)){
                        uid=(u.optString("uid").toIntOrNull() ?: u.optString("id").toIntOrNull())
                        if(uid!=null && uid>0) break
                    }
                }
                if(uid==null && users.length()>0){
                    val u=users.getJSONObject(0)
                    uid=(u.optString("uid").toIntOrNull() ?: u.optString("id").toIntOrNull())
                }
            }
            if(uid!=null && uid>0) chatUidCache[key]=uid
            uid?.takeIf{it>0}
        }catch(_:Throwable){null}
    }
    private fun parseCreatedAt(raw:String):Long{
        val value=raw.trim()
        if(value.isBlank()) return System.currentTimeMillis()
        val formats=listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'"
        )
        for(pattern in formats){
            try{
                val sdf=SimpleDateFormat(pattern,Locale.US)
                if(pattern.contains("'Z'")) sdf.timeZone=TimeZone.getTimeZone("UTC")
                return sdf.parse(value)?.time ?: continue
            }catch(_:Throwable){}
        }
        return value.toLongOrNull()?.let{if(it<100000000000L)it*1000 else it} ?: System.currentTimeMillis()
    }
    private suspend fun refreshChats(){
        try{
            val a=VGhostApi.conversations().optJSONArray("conversations")?:return
            val out=mutableListOf<ChatSummary>()
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                val nick=normalize(o.optString("nickname"))
                out+=ChatSummary(o.optString("conversation_id"),nick,o.optString("message"),o.optString("created_at"),o.optInt("unread_count"),true,"ghost",o.optString("avatarId","ghost"))
            }
            // Keep a just-sent message visible in the chat list until the backend
            // conversation endpoint catches up with the write.
            pendingOutgoing.forEach { (nick, pending) ->
                val last=pending.lastOrNull() ?: return@forEach
                val existing=out.firstOrNull{it.nickname.equals(nick,true)}
                if(existing==null){
                    out+=ChatSummary("local-$nick",nick,last.text,last.time,0,true,"ghost")
                }else if(existing.lastMessage != last.text){
                    val idx=out.indexOf(existing)
                    out[idx]=existing.copy(lastMessage=last.text,time=last.time)
                }
            }
            _chats.value=out
        }catch(_:Throwable){}
    }
    private suspend fun loadMessages(n:String){
        val key=normalize(n)
        val lock=chatLoadLocks.getOrPut(key){kotlinx.coroutines.sync.Mutex()}
        lock.lock()
        try{
            val uid=resolveUid(key)?:return
            val response=VGhostApi.call("messages/list?user_id=$uid")
            val a=response.optJSONArray("messages") ?: org.json.JSONArray()
            val list=mutableListOf<ChatMessage>()
            val unreadIds=mutableListOf<String>()
            for(i in a.length()-1 downTo 0){
                try{
                    val m=a.getJSONObject(i)
                    val created=parseCreatedAt(m.optString("created_at"))
                    val senderId=m.optString("sender_id").toIntOrNull() ?: m.optInt("sender_id",0)
                    val outgoing=senderId!=uid
                val read=m.optInt("is_read")!=0
                val reactionObj=m.optJSONObject("reactions")
                val reactionMap=mutableMapOf<String,Int>(); if(reactionObj!=null){ val it=reactionObj.keys(); while(it.hasNext()){val k=it.next(); reactionMap[k]=reactionObj.optInt(k,0)} }
                    val lp=m.optJSONObject("link_preview")
                    list+=ChatMessage(m.optString("id"),m.optString("message"),outgoing,SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(created)),true,read,created,m.optString("senderNickname",_currentUserNickname.value),m.optString("message_type","text"),reactionMap,m.optString("myReaction").takeIf{it.isNotBlank() && it!="null"},m.optString("audio_url").takeIf{it.isNotBlank()},m.optInt("audio_duration",0),m.optJSONObject("sticker")?.optString("image_url")?.takeIf{it.isNotBlank()},m.optJSONObject("gif")?.optString("image_url")?.takeIf{it.isNotBlank()},m.optString("attachment_url").takeIf{it.isNotBlank()},m.optString("attachment_type").takeIf{it.isNotBlank()},m.optString("attachment_name").takeIf{it.isNotBlank()},m.optString("expires_at").takeIf{it.isNotBlank()}?.let{parseCreatedAt(it)},lp?.optString("url")?.takeIf{it.isNotBlank()},lp?.optString("title")?.takeIf{it.isNotBlank()},lp?.optString("description")?.takeIf{it.isNotBlank()},lp?.optString("image")?.takeIf{it.isNotBlank()},lp?.optString("site")?.takeIf{it.isNotBlank()},lp?.optString("type")?.takeIf{it.isNotBlank()},m.optString("replyToMessageId").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToSenderNickname").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToText").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToMessageType").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAudioUrl").takeIf{it.isNotBlank() && it!="null"},m.optInt("replyToAudioDuration",0),m.optString("replyToStickerImageUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToGifImageUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAttachmentUrl").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAttachmentType").takeIf{it.isNotBlank() && it!="null"},m.optString("replyToAttachmentName").takeIf{it.isNotBlank() && it!="null"})
                    if(!outgoing&&!read) unreadIds+=m.optString("id")
                }catch(_:Throwable){
                    // One malformed row must never hide the rest of the conversation.
                }
            }
            val serverIds=list.map{it.id}.toSet()
            // Reconcile optimistic messages with the authoritative server list.
            // A polling refresh can race with messages/send: in that window the
            // optimistic bubble still has its local id while the server copy has
            // already arrived, which used to render the same message twice.
            val stillPending=pendingOutgoing[key].orEmpty().filter { p ->
                if (serverIds.contains(p.id)) return@filter false
                val duplicateOnServer = list.any { m ->
                    m.isOutgoing &&
                    m.text == p.text &&
                    m.messageType == p.messageType &&
                    kotlin.math.abs(m.createdAt - p.createdAt) <= 15_000L
                }
                !duplicateOnServer
            }
            val merged=(list + stillPending)
                .distinctBy { it.id }
                .sortedBy{it.createdAt}
            if(stillPending.isEmpty()) pendingOutgoing.remove(key)
            _messages.value=_messages.value.toMutableMap().apply{put(key,merged)}
            merged.lastOrNull()?.let{
                _chats.value=(_chats.value.filterNot{it.nickname.equals(key,true)}+ChatSummary(it.id,key,it.text,it.time,0,true,"ghost"))
            }
            // Mark reads after the UI state is updated; do not block rendering on these requests.
            unreadIds.forEach { id-> apiScope.launch{try{VGhostApi.markMessageRead(id)}catch(_:Throwable){}} }
        }catch(_:Throwable){}
        finally{lock.unlock()}
    }
    suspend fun setTyping(recipientNickname:String, typing:Boolean){
        if(_guestMode.value||!hasAccount()) return
        try { resolveUid(normalize(recipientNickname))?.let { VGhostApi.setTyping(it.toLong(), typing) } } catch(_:Throwable) {}
    }
    suspend fun getTyping(recipientNickname:String):Boolean {
        if(_guestMode.value||!hasAccount()) return false
        return try { resolveUid(normalize(recipientNickname))?.let { VGhostApi.typingStatus(it.toLong()) } ?: false } catch(_:Throwable) { false }
    }
    suspend fun sendVoice(recipientNickname:String, fileName:String, bytes:ByteArray, duration:Int):String? {
        if(_guestMode.value||!hasAccount()) return "Səsli mesaj göndərmək üçün hesaba daxil ol."
        return try {
            val uid=resolveUid(normalize(recipientNickname)) ?: throw IllegalStateException("İstifadəçi tapılmadı.")
            VGhostApi.uploadVoice(uid.toLong(), fileName, bytes, duration)
            apiScope.launch { try { loadMessages(normalize(recipientNickname)) } catch(_:Throwable){} }
            null
        } catch(t:Throwable) { error(t) }
    }

    suspend fun editMessage(recipientNickname:String, messageId:String, text:String):String? {
        if(_guestMode.value||!hasAccount()) return "Mesaj redaktə etmək üçün hesaba daxil ol."
        return try {
            VGhostApi.editMessage(messageId.toLongOrNull() ?: return "Mesaj tapılmadı.", text.trim())
            val key=normalize(recipientNickname)
            _messages.value=_messages.value.toMutableMap().apply { put(key, get(key).orEmpty().map { if(it.id==messageId) it.copy(text=text.trim(), messageType="text") else it }) }
            apiScope.launch { try { loadMessages(key) } catch(_:Throwable){} }
            null
        } catch(t:Throwable){ error(t) }
    }
    suspend fun deleteMessageForBoth(recipientNickname:String, messageId:String):String? {
        if(_guestMode.value||!hasAccount()) return "Mesaj silmək üçün hesaba daxil ol."
        return try {
            VGhostApi.deleteMessage(messageId.toLongOrNull() ?: return "Mesaj tapılmadı.")
            val key=normalize(recipientNickname)
            _messages.value=_messages.value.toMutableMap().apply { put(key, get(key).orEmpty().filterNot { it.id==messageId }) }
            // The server response is authoritative: the same shared row is now gone
            // for both participants, not merely hidden on this device.
            apiScope.launch { try { loadMessages(key) } catch(_:Throwable){} }
            null
        } catch(t:Throwable){ error(t) }
    }

    suspend fun reactToMessage(recipientNickname:String, messageId:String, reaction:String):String? {
        if(_guestMode.value||!hasAccount()) return "Reaksiya vermək üçün hesaba daxil ol."
        val id = messageId.toLongOrNull() ?: return "Mesaj tapılmadı."
        val key = normalize(recipientNickname)
        val current = _messages.value[key].orEmpty()
        val target = current.firstOrNull { it.id == messageId } ?: return "Mesaj tapılmadı."
        val oldReaction = target.myReaction
        val oldCounts = target.reactions

        // Optimistic UI: show the reaction immediately, including on voice messages.
        fun applyReaction() {
            val latest = _messages.value[key].orEmpty()
            _messages.value = _messages.value.toMutableMap().apply {
                put(key, latest.map { message ->
                    if (message.id != messageId) return@map message
                    val counts = message.reactions.toMutableMap()
                    message.myReaction?.let { old ->
                        if (old != reaction) {
                            val oldCount = (counts[old] ?: 0) - 1
                            if (oldCount > 0) counts[old] = oldCount else counts.remove(old)
                        }
                    }
                    if (message.myReaction != reaction) counts[reaction] = (counts[reaction] ?: 0) + 1
                    message.copy(reactions = counts, myReaction = reaction)
                })
            }
        }

        return try {
            applyReaction()
            VGhostApi.reactToMessage(id, reaction)
            // Do not immediately reload the whole chat here. A fast background
            // reload could briefly return stale reaction data and erase the
            // optimistic voice-message reaction from the screen.
            null
        } catch(t:Throwable) {
            // Roll back only this message when the server rejects the reaction.
            val latest = _messages.value[key].orEmpty()
            _messages.value = _messages.value.toMutableMap().apply {
                put(key, latest.map { message ->
                    if (message.id == messageId) message.copy(reactions = oldCounts, myReaction = oldReaction) else message
                })
            }
            error(t)
        }
    }

    private fun isEmojiOnlyMessage(value: String): Boolean {
        if (value.isBlank()) return false
        var sawEmoji = false
        var i = 0
        while (i < value.length) {
            val cp = value.codePointAt(i)
            i += Character.charCount(cp)
            when {
                Character.isWhitespace(cp) -> Unit
                cp == 0x200D || cp == 0xFE0F || cp == 0x20E3 || (cp in 0x1F3FB..0x1F3FF) -> Unit
                cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2300..0x23FF || cp in 0x2B00..0x2BFF || cp in 0x2190..0x21FF -> sawEmoji = true
                cp in 0x1F1E6..0x1F1FF -> sawEmoji = true
                else -> return false
            }
        }
        return sawEmoji
    }

    suspend fun sendMessage(recipientNickname:String,text:String, stickerImageUrl:String?=null, gifImageUrl:String?=null, replyToMessage:ChatMessage?=null):String?{
        // Do not compare with the previous message: sending the exact same text twice is valid.
        val body=text.trim()
        if(body.isBlank())return "Mesaj boş ola bilməz."
        val messageType = when {
            body.startsWith("__VG_STICKER__:") -> "sticker"
            body.startsWith("__VG_GIF__:") -> "gif"
            isEmojiOnlyMessage(body) -> "emoji"
            else -> "text"
        }
        if(_guestMode.value||!hasAccount())return "Mesaj göndərmək üçün hesaba daxil ol."
        val n=normalize(recipientNickname)
        val optimisticId="local-${java.util.UUID.randomUUID()}"
        val optimistic=ChatMessage(
            id=optimisticId, text=body, isOutgoing=true,
            time=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date()),
            isDelivered=false, isRead=false, createdAt=System.currentTimeMillis(),
            senderNickname=_currentUserNickname.value, messageType=messageType, stickerImageUrl=stickerImageUrl, gifImageUrl=gifImageUrl,
            replyToMessageId=replyToMessage?.id, replyToSenderNickname=replyToMessage?.senderNickname,
            replyToText=replyToMessage?.text, replyToMessageType=replyToMessage?.messageType,
            replyToAudioUrl=replyToMessage?.audioUrl, replyToAudioDuration=replyToMessage?.audioDuration ?: 0,
            replyToStickerImageUrl=replyToMessage?.stickerImageUrl, replyToGifImageUrl=replyToMessage?.gifImageUrl,
            replyToAttachmentUrl=replyToMessage?.attachmentUrl, replyToAttachmentType=replyToMessage?.attachmentType,
            replyToAttachmentName=replyToMessage?.attachmentName
        )
        // Render locally before touching the network. The message is marked undelivered
        // until the API accepts it, so a slow connection never makes the chat feel frozen.
        _messages.value=_messages.value.toMutableMap().apply {
            val current=get(n).orEmpty()
            put(n,current+optimistic)
        }
        pendingOutgoing.getOrPut(n){mutableListOf()}.add(optimistic)
        _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary("local-$n",n,body,optimistic.time,0,true,"ghost"))
        return try{
            val uid=resolveUid(n)?:throw IllegalStateException("İstifadəçi tapılmadı.")
            val response=VGhostApi.call("messages/send","POST",org.json.JSONObject().put("receiver_id",uid).put("message",body).put("message_type",messageType).apply {
                replyToMessage?.id?.toLongOrNull()?.let { put("reply_to_message_id", it) }
            })
            val serverMessage=response.optJSONObject("message")
            val serverId=serverMessage?.optString("id")?.takeIf{!it.isNullOrBlank()}
            val lp=serverMessage?.optJSONObject("link_preview")
            // Mark the optimistic bubble as delivered immediately. A background refresh
            // then replaces it with the authoritative server copy.
            val deliveredId=serverId ?: optimisticId
            _messages.value=_messages.value.toMutableMap().apply {
                put(n,get(n).orEmpty().map { if(it.id==optimisticId) it.copy(id=deliveredId,isDelivered=true,isRead=false,
                    linkPreviewUrl=lp?.optString("url")?.takeIf{v->v.isNotBlank()},
                    linkPreviewTitle=lp?.optString("title")?.takeIf{v->v.isNotBlank()},
                    linkPreviewDescription=lp?.optString("description")?.takeIf{v->v.isNotBlank()},
                    linkPreviewImage=lp?.optString("image")?.takeIf{v->v.isNotBlank()},
                    linkPreviewSite=lp?.optString("site")?.takeIf{v->v.isNotBlank()},
                    linkPreviewType=lp?.optString("type")?.takeIf{v->v.isNotBlank()},
                    replyToMessageId=serverMessage?.optString("replyToMessageId")?.takeIf{v->v.isNotBlank()},
                    replyToSenderNickname=serverMessage?.optString("replyToSenderNickname")?.takeIf{v->v.isNotBlank()},
                    replyToText=serverMessage?.optString("replyToText")?.takeIf{v->v.isNotBlank()},
                    replyToMessageType=serverMessage?.optString("replyToMessageType")?.takeIf{v->v.isNotBlank()},
                    replyToAudioUrl=serverMessage?.optString("replyToAudioUrl")?.takeIf{v->v.isNotBlank()},
                    replyToAudioDuration=serverMessage?.optInt("replyToAudioDuration",0) ?: 0,
                    replyToStickerImageUrl=serverMessage?.optString("replyToStickerImageUrl")?.takeIf{v->v.isNotBlank()},
                    replyToGifImageUrl=serverMessage?.optString("replyToGifImageUrl")?.takeIf{v->v.isNotBlank()},
                    replyToAttachmentUrl=serverMessage?.optString("replyToAttachmentUrl")?.takeIf{v->v.isNotBlank()},
                    replyToAttachmentType=serverMessage?.optString("replyToAttachmentType")?.takeIf{v->v.isNotBlank()},
                    replyToAttachmentName=serverMessage?.optString("replyToAttachmentName")?.takeIf{v->v.isNotBlank()}) else it })
            }
            pendingOutgoing[n]?.let { pending ->
                val idx=pending.indexOfFirst{it.id==optimisticId}
                if(idx>=0) pending[idx]=pending[idx].copy(id=deliveredId,isDelivered=true,isRead=false)
            }
            _chats.value=(_chats.value.filterNot{it.nickname.equals(n,true)} + ChatSummary(deliveredId,n,body,optimistic.time,0,true,"ghost"))
            apiScope.launch { try { loadMessages(n) } catch(_:Throwable){} }
            null
        }catch(t:Throwable){
            // Never leave a fake message behind when the server rejected the send.
            _messages.value=_messages.value.toMutableMap().apply { put(n,get(n).orEmpty().filterNot{it.id==optimisticId}) }
            pendingOutgoing[n]?.removeAll{it.id==optimisticId}
            if(pendingOutgoing[n].isNullOrEmpty()) pendingOutgoing.remove(n)
            error(t)
        }
    }
    suspend fun sendAttachment(recipientNickname:String, fileName:String, mimeType:String, bytes:ByteArray):String?{
        if(_guestMode.value||!hasAccount()) return "Fayl göndərmək üçün hesaba daxil ol."
        if(bytes.isEmpty()) return "Fayl boşdur."
        val n=normalize(recipientNickname)
        return try {
            val uid=resolveUid(n) ?: throw IllegalStateException("İstifadəçi tapılmadı.")
            val response=VGhostApi.uploadAttachment(uid.toLong(), fileName, bytes, mimeType)
            val sm=response.optJSONObject("message")
            val serverId=sm?.optString("id")?.takeIf{it.isNotBlank()} ?: "local-${UUID.randomUUID()}"
            apiScope.launch { try { loadMessages(n) } catch(_:Throwable){} }
            null
        } catch(t:Throwable) { error(t) }
    }
    fun cleanupExpiredRemoteMessages(){/* cPanel cron owns expiry cleanup */}
    fun clearChat(nickname:String){
        val n=normalize(nickname)
        if(!hasAccount()){
            _messages.value=_messages.value.toMutableMap().apply{remove(n)}
            _chats.value=_chats.value.filterNot{it.nickname.equals(n,true)}
            return
        }
        apiScope.launch {
            try {
                val uid=resolveUid(n) ?: throw IllegalStateException("İstifadəçi tapılmadı.")
                VGhostApi.deleteConversation(uid.toString())
                // The backend hard-deletes the shared conversation, so the local
                // cache is cleared only after the server confirms both-side deletion.
                _messages.value=_messages.value.toMutableMap().apply{remove(n)}
                _chats.value=_chats.value.filterNot{it.nickname.equals(n,true)}
            } catch (_:Throwable) {
                // Keep the local cache intact when the server did not confirm deletion.
            }
        }
    }
    fun removeRecentSearch(id:String){_recentSearches.value=_recentSearches.value.filterNot{it.id==id}}
    fun addRecentSearch(nickname:String){val n=normalize(nickname);_recentSearches.value=listOf(RecentSearch(UUID.randomUUID().toString(),n))+_recentSearches.value.filterNot{it.nickname.equals(n,true)}}

    suspend fun getOnlineUsers():List<OnlineUser>{if(_isGhostMode.value)return emptyList();return try{val a=VGhostApi.call("users/online").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);OnlineUser(o.optString("uid"),o.optString("nickname"))}}catch(_:Throwable){emptyList()}}
    suspend fun getFriends():List<UserListEntry>{return try{val a=VGhostApi.call("friends/list").optJSONArray("friends")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("id"),o.optString("nickname"),o.optString("status")=="active",o.optString("avatarId","ghost"))}}catch(_:Throwable){emptyList()}}
    suspend fun getBlockedUsers():List<UserListEntry>{return try{val a=VGhostApi.call("blocks/list").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("id"),o.optString("nickname"),false,o.optString("avatarId","ghost"))}}catch(_:Throwable){emptyList()}}
    suspend fun findUserByNickname(nickname:String):UserListEntry?{return try{val a=VGhostApi.call("users/search?q="+java.net.URLEncoder.encode(normalize(nickname),"UTF-8")).optJSONArray("users")?:return null;if(a.length()==0)null else a.getJSONObject(0).let{UserListEntry(it.optString("uid", it.optString("id")),it.optString("nickname"),it.optBoolean("online",false),it.optString("avatarId","ghost"))}}catch(_:Throwable){null}}
    suspend fun recordProfileView(targetUid:String)=try{VGhostApi.call("profile/view","POST",org.json.JSONObject().put("uid",targetUid));true}catch(_:Throwable){false}
    suspend fun getProfileVisitors():List<UserListEntry>{return try{val a=VGhostApi.call("profile/visitors").optJSONArray("users")?:return emptyList();List(a.length()){val o=a.getJSONObject(it);UserListEntry(o.optString("id"),o.optString("nickname"),o.optString("status")=="active",o.optString("avatarId","ghost"))}}catch(_:Throwable){emptyList()}}
    suspend fun setAvatar(avatarId:String):String? = try {
        val id = when (avatarId.lowercase()) { "male", "female", "ghost" -> avatarId.lowercase(); else -> "ghost" }
        val r = VGhostApi.setAvatar(id)
        val saved = r.optString("avatarId", id).ifBlank { id }
        _currentUserAvatarId.value = saved
        prefs.edit().putString(PREF_AVATAR_ID, saved).apply()
        null
    } catch(t:Throwable) { error(t) }
    suspend fun getPublicUserProfile(nickname:String): PublicUserProfile? {
        return try {
            val encoded = java.net.URLEncoder.encode(normalize(nickname), "UTF-8")
            val u = VGhostApi.call("users/public?nickname=" + encoded).optJSONObject("user") ?: return null
            val ga = u.optJSONArray("gifts")
            val gifts: List<GiftCollectionItem> = if (ga == null) {
                emptyList()
            } else {
                List(ga.length()) { index ->
                    val g = ga.getJSONObject(index)
                    val gid = g.optString("giftId")
                    val catalogGift = GiftCatalog.find(gid)
                    GiftCollectionItem(
                        giftId = gid,
                        name = g.optString("name").ifBlank { catalogGift?.name ?: "Hədiyyə" },
                        icon = catalogGift?.icon ?: g.optString("icon").takeIf { it.isNotBlank() } ?: "🎁",
                        price = g.optInt("price"),
                        count = g.optInt("count")
                    )
                }
            }
            PublicUserProfile(
                uid = u.optString("uid"),
                nickname = u.optString("nickname"),
                balance = u.optInt("balance"),
                online = u.optBoolean("online"),
                ghostMode = u.optBoolean("ghostMode"),
                friendStatus = u.optString("friendStatus", "none"),
                blockedByMe = u.optBoolean("blockedByMe"),
                blockedMe = u.optBoolean("blockedMe"),
                activityXp = u.optInt("activityXp", 0),
                activityLevel = u.optInt("activityLevel", 1),
                giftXp = u.optInt("giftXp"),
                giftLevel = u.optInt("giftLevel", 1),
                nextGiftLevelXp = u.optInt("nextGiftLevelXp", 100),
                gifts = gifts,
                avatarId = u.optString("avatarId", "ghost").ifBlank { "ghost" },
                avatarUrl = u.optString("avatarUrl").takeIf { it.isNotBlank() && it != "null" }
            )
        } catch (_: Throwable) {
            null
        }
    }
    suspend fun getUserOnlineStatus(nickname:String):Boolean? = try {
        val encoded=java.net.URLEncoder.encode(normalize(nickname),"UTF-8")
        val u=VGhostApi.call("users/public?nickname="+encoded).optJSONObject("user") ?: return null
        u.optBoolean("online",false)
    } catch(_:Throwable){ null }
    
    suspend fun getMyActivityLevel(): Pair<Int,Int> = try { val r=VGhostApi.call("profile/level"); Pair(r.optInt("xp",0),r.optInt("level",1)) } catch(_:Throwable){ Pair(0,1) }

    fun clearLevelUpEvent(token:Long){ if(_levelUpEvent.value?.token==token) _levelUpEvent.value=null }

    fun startActivityLevelSync(){
        activityLevelSyncJob?.cancel()
        if(!hasAccount() || _guestMode.value) return
        val epoch=sessionEpoch
        activityLevelSyncJob=apiScope.launch {
            while(isActive && epoch==sessionEpoch && hasAccount() && !_guestMode.value){
                try {
                    val r=VGhostApi.call("profile/level")
                    val level=r.optInt("level",1).coerceAtLeast(1)
                    val previous=knownActivityLevel
                    if(epoch==sessionEpoch && hasAccount() && !_guestMode.value){
                        if(previous!=null && level>previous){
                            _levelUpEvent.value=LevelUpEvent(level=level,coins=(level-previous)*100)
                            refreshMyWallet()
                        }
                        knownActivityLevel=level
                    }
                } catch(_:Throwable){}
                delay(3000)
            }
        }
    }
    suspend fun getPrivacySettings(): Pair<String,String> = try {
        val p=VGhostApi.call("settings/privacy").optJSONObject("privacy") ?: return "everyone" to "everyone"
        p.optString("messagePermission","everyone") to p.optString("friendPermission","everyone")
    } catch(_:Throwable) { "everyone" to "everyone" }

    suspend fun updatePrivacySettings(messagePermission:String, friendPermission:String):String? = try {
        if(messagePermission !in setOf("everyone","friends","nobody")) return com.vghost.app.i18n.VGhostLanguage.tr("Yanlış mesaj məxfilik seçimi.")
        if(friendPermission !in setOf("everyone","nobody")) return com.vghost.app.i18n.VGhostLanguage.tr("Yanlış dostluq məxfilik seçimi.")
        VGhostApi.call("settings/privacy","POST",org.json.JSONObject().put("messagePermission",messagePermission).put("friendPermission",friendPermission))
        null
    } catch(t:Throwable) { error(t) }

suspend fun getMyGiftProfile():Triple<Int,Int,List<GiftCollectionItem>> = try{val r=VGhostApi.call("gifts/profile");val a=r.optJSONArray("collection");val gifts=if(a==null) emptyList() else List(a.length()){val g=a.getJSONObject(it);val giftId=g.optString("gift_id",g.optString("giftId"));val name=g.optString("name");val serverIcon=g.optString("icon");val catalog=GiftCatalog.find(giftId) ?: GiftCatalog.items.firstOrNull{it.id.equals(name,ignoreCase=true)};GiftCollectionItem(giftId,name,serverIcon.takeIf{it.isNotBlank()} ?: catalog?.icon ?: "🎁",g.optInt("price"),g.optInt("count"))};Triple(r.optInt("giftXp"),r.optInt("giftLevel",1),gifts)}catch(_:Throwable){Triple(0,1,emptyList())}
    suspend fun addFriend(recipientUid:String):String?=social("friends/add","user_id",recipientUid,"Dostluq sorğusu göndərilmədi.")
    suspend fun acceptFriend(senderUid:String):String?=social("friends/accept","user_id",senderUid,"Dostluq sorğusu qəbul edilmədi.")
    suspend fun rejectFriend(senderUid:String):String?=social("friends/reject","user_id",senderUid,"Dostluq sorğusu rədd edilmədi.")
    suspend fun removeFriend(recipientUid:String):String?=social("friends/remove","user_id",recipientUid,"Dostluqdan çıxarılmadı.")
    suspend fun blockUser(blockedUid:String):String?=social("blocks/add","uid",blockedUid,"İstifadəçi bloklanmadı.")
    suspend fun unblockUser(blockedUid:String):String?=social("blocks/remove","uid",blockedUid,"Blok götürülmədi.")
    private suspend fun social(path:String,key:String,value:String,msg:String)=try{VGhostApi.call(path,"POST",org.json.JSONObject().put(key,value));null}catch(_:Throwable){msg}
    suspend fun sendGift(recipientUid:String,giftId:String):String?=try{
        val uid=recipientUid.toIntOrNull()?:return "İstifadəçi tapılmadı."
        if(giftId.isBlank()) return "Hədiyyə seçilməyib."
        // Catalog IDs are stable symbolic names (love, rose, ...). The backend resolves
        // both names and numeric IDs, so never reject a valid symbolic ID on the client.
        val r=VGhostApi.call("gifts/send","POST",org.json.JSONObject().put("recipientUid",uid).put("giftId",giftId))
        applyServerBalance(r); null
    }catch(t:Throwable){refreshMyWallet();error(t)}
    suspend fun sendCoins(recipientUid:String,amount:Int):String?=try{
        val uid=recipientUid.toIntOrNull()?:return "İstifadəçi tapılmadı."
        if(amount<=0) return "Coin miqdarı düzgün deyil."
        val r=VGhostApi.call("coins/send","POST",org.json.JSONObject().put("recipientUid",uid).put("amount",amount),idempotencyKey=java.util.UUID.randomUUID().toString())
        applyServerBalance(r); null
    }catch(t:Throwable){refreshMyWallet();error(t)}
    /** Remove account/session/device secrets stored locally after a permanent server-side delete. */
    private fun purgeLocalAccountData() {
        try { VGhostApi.setToken(null) } catch (_: Throwable) {}
        // Account deletion is a true local wipe: remove every app-private data
        // directory that can contain account/session/chat/media cache data.
        // The APK itself is not touched and Android recreates these directories.
        try { appContext.filesDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.cacheDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.noBackupFilesDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.codeCacheDir.deleteRecursively() } catch (_: Throwable) {}
        try { appContext.externalCacheDir?.deleteRecursively() } catch (_: Throwable) {}
        try {
            val dataDir = appContext.dataDir
            dataDir.listFiles()?.forEach { child ->
                if (child.name !in setOf("lib")) child.deleteRecursively()
            }
        } catch (_: Throwable) {}
        // Clear known preferences again after the directory wipe; recreate only
        // what the running process needs. No account credential/cache is retained.
        try { appContext.getSharedPreferences("vghost_api", Context.MODE_PRIVATE).edit().clear().commit() } catch (_: Throwable) {}
        try { appContext.getSharedPreferences("vghost_push", Context.MODE_PRIVATE).edit().clear().commit() } catch (_: Throwable) {}
        try { prefs.edit().clear().commit() } catch (_: Throwable) {}
    }

    suspend fun deleteAccount(password:String):String? {
        // Separate account-deletion flow. PANIC is intentionally untouched.
        if (_guestMode.value) {
            purgeLocalAccountData()
            resetSessionState()
            _sessionState.value=SessionState.LoggedOut
            _isPanicActivated.value=true
            _appLockEnabled.value=false
            _isAppLocked.value=false
            return null
        }
        if (password.isBlank()) return "Şifrəni daxil edin."
        try {
            if (hasAccount() && !_isGhostMode.value) {
                val nickname = _currentUserNickname.value.trim()
                if (nickname.isBlank()) return "İstifadəçi məlumatı tapılmadı."
                // Delete directly with the same credentials used by the web deletion flow.
                // This avoids a separate login/token step and keeps account deletion working
                // even when the current app session is stale or missing.
                val result = VGhostApi.call(
                    "auth/web-delete-account",
                    "POST",
                    JSONObject().put("login", nickname).put("password", password)
                )
                if (!result.optBoolean("deleted", false)) return "Hesab silinmədi."
            }
        } catch (t:Throwable) {
            return error(t)
        }
        purgeLocalAccountData(); resetSessionState(); _sessionState.value=SessionState.LoggedOut; _isPanicActivated.value=false; _appLockEnabled.value=false; _isAppLocked.value=false
        return null
    }

    suspend fun activatePanicWipe(password:String, adminPanic:Boolean=false):String? {
        // Guest panic is local-only: no password/PIN and no backend call.
        if (_guestMode.value) {
            purgeLocalAccountData()
            resetSessionState()
            _sessionState.value=SessionState.LoggedOut
            _isPanicActivated.value=true
            _appLockEnabled.value=false
            _isAppLocked.value=false
            return null
        }
        if (password.isBlank()) return "Şifrəni daxil edin."
        try {
            if (hasAccount() && !_isGhostMode.value) {
                val nickname = _currentUserNickname.value.trim()
                if (nickname.isBlank()) return "İstifadəçi məlumatı tapılmadı."
                val verified = VGhostApi.login(nickname, password)
                val verifiedToken = verified.optString("token")
                if (verifiedToken.isBlank()) return "Şifrə təsdiqlənmədi."
                VGhostApi.setToken(verifiedToken)
                VGhostApi.call("auth/panic", "POST")
            }
        } catch (t:Throwable) {
            return error(t)
        }
        purgeLocalAccountData(); resetSessionState(); _sessionState.value=SessionState.LoggedOut; _isPanicActivated.value=true; _appLockEnabled.value=false; _isAppLocked.value=false
        return null
    }
}
