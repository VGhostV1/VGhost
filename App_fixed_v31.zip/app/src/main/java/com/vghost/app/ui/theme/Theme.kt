package com.vghost.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset

private val DarkColorScheme = darkColorScheme(
    primary = GhostRedPrimary,
    onPrimary = GhostTextWhite,
    primaryContainer = GhostRedDark,
    onPrimaryContainer = GhostTextWhite,
    secondary = GhostNeonSoft,
    onSecondary = GhostBlack,
    background = GhostBlack,
    onBackground = GhostTextWhite,
    surface = GhostSurface,
    onSurface = GhostTextWhite,
    surfaceVariant = GhostSurfaceElevated,
    onSurfaceVariant = GhostTextSecondary,
    outline = GhostBorder,
    outlineVariant = GhostBorderLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}


/** Global V9-style red/black atmosphere, with restrained pearlescent star glints. */
@Composable
fun NeonBackdrop(content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "vghost_v9_atmosphere")
    val sparkle by transition.animateFloat(
        initialValue = 0.35f, targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "sparkle"
    )
    Box(Modifier.fillMaxSize().background(
        Brush.radialGradient(
            colors = listOf(Color(0xFF160308), GhostBlack, Color(0xFF020203)),
            radius = 1450f
        )
    )) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            drawCircle(Brush.radialGradient(listOf(GhostRedPrimary.copy(.12f), Color.Transparent)), Offset(w*.5f,h*.2f), w*.9f)
            val stars = listOf(0.08f to .12f,.22f to .08f,.48f to .16f,.79f to .10f,.91f to .30f,.14f to .48f,.36f to .72f,.68f to .63f,.86f to .79f,.53f to .90f)
            stars.forEachIndexed { i,(x,y) ->
                val r=if(i%4==0) 2.1f else 1.1f
                val c=Color(0xFFF2F1EC).copy(alpha=(if(i%4==0).72f else .28f)*sparkle)
                val p=Offset(w*x,h*y)
                drawLine(c, Offset(p.x-r*3,p.y), Offset(p.x+r*3,p.y), .7f)
                drawLine(c, Offset(p.x,p.y-r*3), Offset(p.x,p.y+r*3), .7f)
                drawCircle(c,r,p)
            }
        }
        content()
    }
}
